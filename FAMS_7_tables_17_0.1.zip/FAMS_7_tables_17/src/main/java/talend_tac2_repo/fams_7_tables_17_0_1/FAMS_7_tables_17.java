
package talend_tac2_repo.fams_7_tables_17_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: FAMS_7_tables_17 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230315_1127-patch
 * @status 
 */
public class FAMS_7_tables_17 implements TalendJob {
	static {System.setProperty("TalendJob.log", "FAMS_7_tables_17.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(FAMS_7_tables_17.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "FAMS_7_tables_17";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "__XfE0BD5Ee6leu5mDfS5QQ", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				FAMS_7_tables_17.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(FAMS_7_tables_17.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "MSSQL_PROP");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.118.157\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"1433\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"CHAITANYA\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"FAMS_DWH\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:z1jRUeL1dtlh7FlohkFx99nSjj9MBD4cdzbddFdYZkU6lBjQ").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "FAMS_Source", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

			    
		    String url_tDBConnection_1 = "jdbc:sqlserver://" + "115.124.118.157" ;
		String port_tDBConnection_1 = "1433";
		String dbname_tDBConnection_1 = "CHAITANYA" ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + "1433";
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    				    
		    	url_tDBConnection_1 += ";databaseName=" + "CHAITANYA"; 
    	}

		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
	String dbUser_tDBConnection_1 = "FAMS_DWH";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:/kik+LhF3AEgX33qJostB7QnkIB48jCiAGfA355mXLniAzWJ");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_1", "");

	globalMap.put("db_tDBConnection_1",  "CHAITANYA");
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

	globalMap.put("driver_tDBConnection_1", "MSSQL_PROP");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"FAMS_DWH_TGT\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:3P5ZikZv5Yiqy9AaxS/tRCG8Ex2d0Nwli8gkRWWxUHahePpB").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "FAMS_Target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "FAMS_DWH_TGT";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:bFf1pt8tICU+NNc0OqwVvzASCYuYXv2VaX+Bt1igKrOm79+g");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeeEducationInfoID;

				public int getEmployeeEducationInfoID () {
					return this.EmployeeEducationInfoID;
				}

				public Boolean EmployeeEducationInfoIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeEducationInfoIDIsKey(){
				    return true;
				}
				public Integer EmployeeEducationInfoIDLength(){
				    return 10;
				}
				public Integer EmployeeEducationInfoIDPrecision(){
				    return 0;
				}
				public String EmployeeEducationInfoIDDefault(){
				
					return null;
				
				}
				public String EmployeeEducationInfoIDComment(){
				
				    return "";
				
				}
				public String EmployeeEducationInfoIDPattern(){
				
					return "";
				
				}
				public String EmployeeEducationInfoIDOriginalDbColumnName(){
				
					return "EmployeeEducationInfoID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public String TypeofBoard;

				public String getTypeofBoard () {
					return this.TypeofBoard;
				}

				public Boolean TypeofBoardIsNullable(){
				    return false;
				}
				public Boolean TypeofBoardIsKey(){
				    return false;
				}
				public Integer TypeofBoardLength(){
				    return 50;
				}
				public Integer TypeofBoardPrecision(){
				    return 0;
				}
				public String TypeofBoardDefault(){
				
					return null;
				
				}
				public String TypeofBoardComment(){
				
				    return "";
				
				}
				public String TypeofBoardPattern(){
				
					return "";
				
				}
				public String TypeofBoardOriginalDbColumnName(){
				
					return "TypeofBoard";
				
				}

				
			    public String CompletedYear;

				public String getCompletedYear () {
					return this.CompletedYear;
				}

				public Boolean CompletedYearIsNullable(){
				    return false;
				}
				public Boolean CompletedYearIsKey(){
				    return false;
				}
				public Integer CompletedYearLength(){
				    return 8;
				}
				public Integer CompletedYearPrecision(){
				    return 0;
				}
				public String CompletedYearDefault(){
				
					return null;
				
				}
				public String CompletedYearComment(){
				
				    return "";
				
				}
				public String CompletedYearPattern(){
				
					return "";
				
				}
				public String CompletedYearOriginalDbColumnName(){
				
					return "CompletedYear";
				
				}

				
			    public String QualificationReceived;

				public String getQualificationReceived () {
					return this.QualificationReceived;
				}

				public Boolean QualificationReceivedIsNullable(){
				    return false;
				}
				public Boolean QualificationReceivedIsKey(){
				    return false;
				}
				public Integer QualificationReceivedLength(){
				    return 50;
				}
				public Integer QualificationReceivedPrecision(){
				    return 0;
				}
				public String QualificationReceivedDefault(){
				
					return null;
				
				}
				public String QualificationReceivedComment(){
				
				    return "";
				
				}
				public String QualificationReceivedPattern(){
				
					return "";
				
				}
				public String QualificationReceivedOriginalDbColumnName(){
				
					return "QualificationReceived";
				
				}

				
			    public String NameofInstitute;

				public String getNameofInstitute () {
					return this.NameofInstitute;
				}

				public Boolean NameofInstituteIsNullable(){
				    return false;
				}
				public Boolean NameofInstituteIsKey(){
				    return false;
				}
				public Integer NameofInstituteLength(){
				    return 50;
				}
				public Integer NameofInstitutePrecision(){
				    return 0;
				}
				public String NameofInstituteDefault(){
				
					return null;
				
				}
				public String NameofInstituteComment(){
				
				    return "";
				
				}
				public String NameofInstitutePattern(){
				
					return "";
				
				}
				public String NameofInstituteOriginalDbColumnName(){
				
					return "NameofInstitute";
				
				}

				
			    public BigDecimal PercentageReceived;

				public BigDecimal getPercentageReceived () {
					return this.PercentageReceived;
				}

				public Boolean PercentageReceivedIsNullable(){
				    return false;
				}
				public Boolean PercentageReceivedIsKey(){
				    return false;
				}
				public Integer PercentageReceivedLength(){
				    return 5;
				}
				public Integer PercentageReceivedPrecision(){
				    return 2;
				}
				public String PercentageReceivedDefault(){
				
					return null;
				
				}
				public String PercentageReceivedComment(){
				
				    return "";
				
				}
				public String PercentageReceivedPattern(){
				
					return "";
				
				}
				public String PercentageReceivedOriginalDbColumnName(){
				
					return "PercentageReceived";
				
				}

				
			    public String Grade;

				public String getGrade () {
					return this.Grade;
				}

				public Boolean GradeIsNullable(){
				    return true;
				}
				public Boolean GradeIsKey(){
				    return false;
				}
				public Integer GradeLength(){
				    return 4;
				}
				public Integer GradePrecision(){
				    return 0;
				}
				public String GradeDefault(){
				
					return null;
				
				}
				public String GradeComment(){
				
				    return "";
				
				}
				public String GradePattern(){
				
					return "";
				
				}
				public String GradeOriginalDbColumnName(){
				
					return "Grade";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeeEducationInfoID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.EmployeeEducationInfoID != other.EmployeeEducationInfoID)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.EmployeeEducationInfoID = this.EmployeeEducationInfoID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.TypeofBoard = this.TypeofBoard;
	            other.CompletedYear = this.CompletedYear;
	            other.QualificationReceived = this.QualificationReceived;
	            other.NameofInstitute = this.NameofInstitute;
	            other.PercentageReceived = this.PercentageReceived;
	            other.Grade = this.Grade;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.EmployeeEducationInfoID = this.EmployeeEducationInfoID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeEducationInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.TypeofBoard = readString(dis);
					
					this.CompletedYear = readString(dis);
					
					this.QualificationReceived = readString(dis);
					
					this.NameofInstitute = readString(dis);
					
						this.PercentageReceived = (BigDecimal) dis.readObject();
					
					this.Grade = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeEducationInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.TypeofBoard = readString(dis);
					
					this.CompletedYear = readString(dis);
					
					this.QualificationReceived = readString(dis);
					
					this.NameofInstitute = readString(dis);
					
						this.PercentageReceived = (BigDecimal) dis.readObject();
					
					this.Grade = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeEducationInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.TypeofBoard,dos);
					
					// String
				
						writeString(this.CompletedYear,dos);
					
					// String
				
						writeString(this.QualificationReceived,dos);
					
					// String
				
						writeString(this.NameofInstitute,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.PercentageReceived);
					
					// String
				
						writeString(this.Grade,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeEducationInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.TypeofBoard,dos);
					
					// String
				
						writeString(this.CompletedYear,dos);
					
					// String
				
						writeString(this.QualificationReceived,dos);
					
					// String
				
						writeString(this.NameofInstitute,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.PercentageReceived);
					
					// String
				
						writeString(this.Grade,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeeEducationInfoID="+String.valueOf(EmployeeEducationInfoID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",TypeofBoard="+TypeofBoard);
		sb.append(",CompletedYear="+CompletedYear);
		sb.append(",QualificationReceived="+QualificationReceived);
		sb.append(",NameofInstitute="+NameofInstitute);
		sb.append(",PercentageReceived="+String.valueOf(PercentageReceived));
		sb.append(",Grade="+Grade);
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeeEducationInfoID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(TypeofBoard == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TypeofBoard);
            			}
            		
        			sb.append("|");
        		
        				if(CompletedYear == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CompletedYear);
            			}
            		
        			sb.append("|");
        		
        				if(QualificationReceived == null){
        					sb.append("<null>");
        				}else{
            				sb.append(QualificationReceived);
            			}
            		
        			sb.append("|");
        		
        				if(NameofInstitute == null){
        					sb.append("<null>");
        				}else{
            				sb.append(NameofInstitute);
            			}
            		
        			sb.append("|");
        		
        				if(PercentageReceived == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PercentageReceived);
            			}
            		
        			sb.append("|");
        		
        				if(Grade == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Grade);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeeEducationInfoID, other.EmployeeEducationInfoID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"EmployeeEducationInfo\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("EmployeeEducationInfo");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("EmployeeEducationInfo");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"EmployeeEducationInfoID\",\"EmployeeProfessionalDetailID\",\"TypeofBoard\",\"CompletedYear\",\"QualificationReceived\",\"NameofInstitute\",\"PercentageReceived\",\"Grade\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"EmployeeEducationInfo\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT MDM.EmployeeEducationInfo.EmployeeEducationInfoID, 		MDM.EmployeeEducationInfo.EmployeeProfessionalDetailID, 		MDM.EmployeeEducationInfo.TypeofBoard, 		MDM.EmployeeEducationInfo.CompletedYear, 		MDM.EmployeeEducationInfo.QualificationReceived, 		MDM.EmployeeEducationInfo.NameofInstitute, 		MDM.EmployeeEducationInfo.PercentageReceived, 		MDM.EmployeeEducationInfo.Grade, 		MDM.EmployeeEducationInfo.CreatedBy, 		MDM.EmployeeEducationInfo.CreatedDate, 		MDM.EmployeeEducationInfo.ModifiedBy, 		MDM.EmployeeEducationInfo.ModifiedDate FROM	MDM.EmployeeEducationInfo  WHERE MDM.EmployeeEducationInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND MDM.EmployeeEducationInfo.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeEducationInfoID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TypeofBoard")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompletedYear")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("QualificationReceived")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("NameofInstitute")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PercentageReceived")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Grade")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"EmployeeEducationInfo\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1); 
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT MDM.EmployeeEducationInfo.EmployeeEducationInfoID,\n		MDM.EmployeeEducationInfo.EmployeeProfessionalDetailID,\n		M"
+"DM.EmployeeEducationInfo.TypeofBoard,\n		MDM.EmployeeEducationInfo.CompletedYear,\n		MDM.EmployeeEducationInfo.Qualificati"
+"onReceived,\n		MDM.EmployeeEducationInfo.NameofInstitute,\n		MDM.EmployeeEducationInfo.PercentageReceived,\n		MDM.EmployeeE"
+"ducationInfo.Grade,\n		MDM.EmployeeEducationInfo.CreatedBy,\n		MDM.EmployeeEducationInfo.CreatedDate,\n		MDM.EmployeeEducat"
+"ionInfo.ModifiedBy,\n		MDM.EmployeeEducationInfo.ModifiedDate\nFROM	MDM.EmployeeEducationInfo\nWHERE MDM.EmployeeEducation"
+"Info.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND MDM.EmployeeEducationInfo.CreatedDate < CAST(GE"
+"TDATE() AS DATE)";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.EmployeeEducationInfoID = 0;
							} else {
		                          
            row1.EmployeeEducationInfoID = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row1.EmployeeProfessionalDetailID = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.TypeofBoard = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(3);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.TypeofBoard = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.TypeofBoard = tmpContent_tDBInput_1;
                }
            } else {
                row1.TypeofBoard = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.CompletedYear = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(4);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CompletedYear = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.CompletedYear = tmpContent_tDBInput_1;
                }
            } else {
                row1.CompletedYear = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.QualificationReceived = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(5);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.QualificationReceived = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.QualificationReceived = tmpContent_tDBInput_1;
                }
            } else {
                row1.QualificationReceived = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.NameofInstitute = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(6);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.NameofInstitute = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.NameofInstitute = tmpContent_tDBInput_1;
                }
            } else {
                row1.NameofInstitute = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.PercentageReceived = null;
							} else {
		                          
            row1.PercentageReceived = rs_tDBInput_1.getBigDecimal(7);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.Grade = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(8);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.Grade = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.Grade = tmpContent_tDBInput_1;
                }
            } else {
                row1.Grade = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.CreatedBy = 0;
							} else {
		                          
            row1.CreatedBy = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row1.CreatedDate = null;
							} else {
										
			row1.CreatedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 10);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row1.ModifiedBy = null;
							} else {
		                          
            row1.ModifiedBy = rs_tDBInput_1.getInt(11);
            if(rs_tDBInput_1.wasNull()){
                    row1.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row1.ModifiedDate = null;
							} else {
										
			row1.ModifiedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 12);
			
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					





 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"EmployeeEducationInfo\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, row1.EmployeeEducationInfoID);

                    pstmt_tDBOutput_1.setInt(2, row1.EmployeeProfessionalDetailID);

                    if(row1.TypeofBoard == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.TypeofBoard);
}

                    if(row1.CompletedYear == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.CompletedYear);
}

                    if(row1.QualificationReceived == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, row1.QualificationReceived);
}

                    if(row1.NameofInstitute == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.NameofInstitute);
}

                    pstmt_tDBOutput_1.setBigDecimal(7, row1.PercentageReceived);

                    if(row1.Grade == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.Grade);
}

                    pstmt_tDBOutput_1.setInt(9, row1.CreatedBy);

                    if(row1.CreatedDate != null) {
pstmt_tDBOutput_1.setTimestamp(10, new java.sql.Timestamp(row1.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.TIMESTAMP);
}

                    if(row1.ModifiedBy == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(11, row1.ModifiedBy);
}

                    if(row1.ModifiedDate != null) {
pstmt_tDBOutput_1.setTimestamp(12, new java.sql.Timestamp(row1.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"EmployeeEducationInfo\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"EmployeeEducationInfo\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeeFamilyInfoID;

				public int getEmployeeFamilyInfoID () {
					return this.EmployeeFamilyInfoID;
				}

				public Boolean EmployeeFamilyInfoIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeFamilyInfoIDIsKey(){
				    return true;
				}
				public Integer EmployeeFamilyInfoIDLength(){
				    return 10;
				}
				public Integer EmployeeFamilyInfoIDPrecision(){
				    return 0;
				}
				public String EmployeeFamilyInfoIDDefault(){
				
					return null;
				
				}
				public String EmployeeFamilyInfoIDComment(){
				
				    return "";
				
				}
				public String EmployeeFamilyInfoIDPattern(){
				
					return "";
				
				}
				public String EmployeeFamilyInfoIDOriginalDbColumnName(){
				
					return "EmployeeFamilyInfoID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public String Name;

				public String getName () {
					return this.Name;
				}

				public Boolean NameIsNullable(){
				    return false;
				}
				public Boolean NameIsKey(){
				    return false;
				}
				public Integer NameLength(){
				    return 150;
				}
				public Integer NamePrecision(){
				    return 0;
				}
				public String NameDefault(){
				
					return null;
				
				}
				public String NameComment(){
				
				    return "";
				
				}
				public String NamePattern(){
				
					return "";
				
				}
				public String NameOriginalDbColumnName(){
				
					return "Name";
				
				}

				
			    public int FamilyRelationID;

				public int getFamilyRelationID () {
					return this.FamilyRelationID;
				}

				public Boolean FamilyRelationIDIsNullable(){
				    return false;
				}
				public Boolean FamilyRelationIDIsKey(){
				    return false;
				}
				public Integer FamilyRelationIDLength(){
				    return 10;
				}
				public Integer FamilyRelationIDPrecision(){
				    return 0;
				}
				public String FamilyRelationIDDefault(){
				
					return null;
				
				}
				public String FamilyRelationIDComment(){
				
				    return "";
				
				}
				public String FamilyRelationIDPattern(){
				
					return "";
				
				}
				public String FamilyRelationIDOriginalDbColumnName(){
				
					return "FamilyRelationID";
				
				}

				
			    public java.util.Date DateOfBirth;

				public java.util.Date getDateOfBirth () {
					return this.DateOfBirth;
				}

				public Boolean DateOfBirthIsNullable(){
				    return true;
				}
				public Boolean DateOfBirthIsKey(){
				    return false;
				}
				public Integer DateOfBirthLength(){
				    return 13;
				}
				public Integer DateOfBirthPrecision(){
				    return 0;
				}
				public String DateOfBirthDefault(){
				
					return null;
				
				}
				public String DateOfBirthComment(){
				
				    return "";
				
				}
				public String DateOfBirthPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateOfBirthOriginalDbColumnName(){
				
					return "DateOfBirth";
				
				}

				
			    public byte[] IsDependent;

				public byte[] getIsDependent () {
					return this.IsDependent;
				}

				public Boolean IsDependentIsNullable(){
				    return false;
				}
				public Boolean IsDependentIsKey(){
				    return false;
				}
				public Integer IsDependentLength(){
				    return 1;
				}
				public Integer IsDependentPrecision(){
				    return 0;
				}
				public String IsDependentDefault(){
				
					return null;
				
				}
				public String IsDependentComment(){
				
				    return "";
				
				}
				public String IsDependentPattern(){
				
					return "";
				
				}
				public String IsDependentOriginalDbColumnName(){
				
					return "IsDependent";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 29;
				}
				public Integer CreatedDatePrecision(){
				    return 6;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 29;
				}
				public Integer ModifiedDatePrecision(){
				    return 6;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeeFamilyInfoID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.EmployeeFamilyInfoID != other.EmployeeFamilyInfoID)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.EmployeeFamilyInfoID = this.EmployeeFamilyInfoID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.Name = this.Name;
	            other.FamilyRelationID = this.FamilyRelationID;
	            other.DateOfBirth = this.DateOfBirth;
	            other.IsDependent = this.IsDependent;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.EmployeeFamilyInfoID = this.EmployeeFamilyInfoID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private byte[] readByteArray(ObjectInputStream dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}
	
	private byte[] readByteArray(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}

    private void writeByteArray(byte[] byteArray, ObjectOutputStream dos) throws IOException{
		if(byteArray == null) {
            dos.writeInt(-1);
		} else {
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeByteArray(byte[] byteArray, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(byteArray == null) {
			marshaller.writeInt(-1);
		} else {
			marshaller.writeInt(byteArray.length);
			marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeFamilyInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.Name = readString(dis);
					
			        this.FamilyRelationID = dis.readInt();
					
					this.DateOfBirth = readDate(dis);
					
					this.IsDependent = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeFamilyInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.Name = readString(dis);
					
			        this.FamilyRelationID = dis.readInt();
					
					this.DateOfBirth = readDate(dis);
					
					this.IsDependent = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeFamilyInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.Name,dos);
					
					// int
				
		            	dos.writeInt(this.FamilyRelationID);
					
					// java.util.Date
				
						writeDate(this.DateOfBirth,dos);
					
					// byte[]
				
						writeByteArray(this.IsDependent,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeFamilyInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.Name,dos);
					
					// int
				
		            	dos.writeInt(this.FamilyRelationID);
					
					// java.util.Date
				
						writeDate(this.DateOfBirth,dos);
					
					// byte[]
				
						writeByteArray(this.IsDependent,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeeFamilyInfoID="+String.valueOf(EmployeeFamilyInfoID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",Name="+Name);
		sb.append(",FamilyRelationID="+String.valueOf(FamilyRelationID));
		sb.append(",DateOfBirth="+String.valueOf(DateOfBirth));
		sb.append(",IsDependent="+String.valueOf(IsDependent));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeeFamilyInfoID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				sb.append(FamilyRelationID);
        			
        			sb.append("|");
        		
        				if(DateOfBirth == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DateOfBirth);
            			}
            		
        			sb.append("|");
        		
        				if(IsDependent == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IsDependent);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeeFamilyInfoID, other.EmployeeFamilyInfoID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"EmployeeFamilyInfo\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("EmployeeFamilyInfo");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("EmployeeFamilyInfo");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"EmployeeFamilyInfoID\",\"EmployeeProfessionalDetailID\",\"Name\",\"FamilyRelationID\",\"DateOfBirth\",\"IsDependent\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"EmployeeFamilyInfo\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT MDM.EmployeeFamilyInfo.EmployeeFamilyInfoID, 		MDM.EmployeeFamilyInfo.EmployeeProfessionalDetailID, 		MDM.EmployeeFamilyInfo.Name, 		MDM.EmployeeFamilyInfo.FamilyRelationID, 		MDM.EmployeeFamilyInfo.DateOfBirth, 		MDM.EmployeeFamilyInfo.IsDependent, 		MDM.EmployeeFamilyInfo.CreatedBy, 		MDM.EmployeeFamilyInfo.CreatedDate, 		MDM.EmployeeFamilyInfo.ModifiedBy, 		MDM.EmployeeFamilyInfo.ModifiedDate FROM	MDM.EmployeeFamilyInfo  WHERE MDM.EmployeeFamilyInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND MDM.EmployeeFamilyInfo.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeFamilyInfoID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FamilyRelationID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DateOfBirth")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IsDependent")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"EmployeeFamilyInfo\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2); 
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT MDM.EmployeeFamilyInfo.EmployeeFamilyInfoID,\n		MDM.EmployeeFamilyInfo.EmployeeProfessionalDetailID,\n		MDM.Employ"
+"eeFamilyInfo.Name,\n		MDM.EmployeeFamilyInfo.FamilyRelationID,\n		MDM.EmployeeFamilyInfo.DateOfBirth,\n		MDM.EmployeeFamily"
+"Info.IsDependent,\n		MDM.EmployeeFamilyInfo.CreatedBy,\n		MDM.EmployeeFamilyInfo.CreatedDate,\n		MDM.EmployeeFamilyInfo.Mod"
+"ifiedBy,\n		MDM.EmployeeFamilyInfo.ModifiedDate\nFROM	MDM.EmployeeFamilyInfo\nWHERE MDM.EmployeeFamilyInfo.CreatedDate >= "
+"DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND MDM.EmployeeFamilyInfo.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.EmployeeFamilyInfoID = 0;
							} else {
		                          
            row2.EmployeeFamilyInfoID = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row2.EmployeeProfessionalDetailID = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.Name = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(3);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.Name = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.Name = tmpContent_tDBInput_2;
                }
            } else {
                row2.Name = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.FamilyRelationID = 0;
							} else {
		                          
            row2.FamilyRelationID = rs_tDBInput_2.getInt(4);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.DateOfBirth = null;
							} else {
										
			row2.DateOfBirth = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 5);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.IsDependent = null;
							} else {
		                          
            row2.IsDependent = rs_tDBInput_2.getBytes(6);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.CreatedBy = 0;
							} else {
		                          
            row2.CreatedBy = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.CreatedDate = null;
							} else {
										
			row2.CreatedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 8);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.ModifiedBy = null;
							} else {
		                          
            row2.ModifiedBy = rs_tDBInput_2.getInt(9);
            if(rs_tDBInput_2.wasNull()){
                    row2.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.ModifiedDate = null;
							} else {
										
			row2.ModifiedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 10);
			
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					





 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"EmployeeFamilyInfo\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, row2.EmployeeFamilyInfoID);

                    pstmt_tDBOutput_2.setInt(2, row2.EmployeeProfessionalDetailID);

                    if(row2.Name == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row2.Name);
}

                    pstmt_tDBOutput_2.setInt(4, row2.FamilyRelationID);

                    if(row2.DateOfBirth != null) {
pstmt_tDBOutput_2.setTimestamp(5, new java.sql.Timestamp(row2.DateOfBirth.getTime()));
} else {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(row2.IsDependent == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.ARRAY);
} else {pstmt_tDBOutput_2.setBytes(6, row2.IsDependent);
}

                    pstmt_tDBOutput_2.setInt(7, row2.CreatedBy);

                    if(row2.CreatedDate != null) {
pstmt_tDBOutput_2.setTimestamp(8, new java.sql.Timestamp(row2.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(row2.ModifiedBy == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(9, row2.ModifiedBy);
}

                    if(row2.ModifiedDate != null) {
pstmt_tDBOutput_2.setTimestamp(10, new java.sql.Timestamp(row2.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_2)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"EmployeeFamilyInfo\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"EmployeeFamilyInfo\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeeHRInfoID;

				public int getEmployeeHRInfoID () {
					return this.EmployeeHRInfoID;
				}

				public Boolean EmployeeHRInfoIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeHRInfoIDIsKey(){
				    return true;
				}
				public Integer EmployeeHRInfoIDLength(){
				    return 10;
				}
				public Integer EmployeeHRInfoIDPrecision(){
				    return 0;
				}
				public String EmployeeHRInfoIDDefault(){
				
					return null;
				
				}
				public String EmployeeHRInfoIDComment(){
				
				    return "";
				
				}
				public String EmployeeHRInfoIDPattern(){
				
					return "";
				
				}
				public String EmployeeHRInfoIDOriginalDbColumnName(){
				
					return "EmployeeHRInfoID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public String Qualification;

				public String getQualification () {
					return this.Qualification;
				}

				public Boolean QualificationIsNullable(){
				    return true;
				}
				public Boolean QualificationIsKey(){
				    return false;
				}
				public Integer QualificationLength(){
				    return 50;
				}
				public Integer QualificationPrecision(){
				    return 0;
				}
				public String QualificationDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String QualificationComment(){
				
				    return "";
				
				}
				public String QualificationPattern(){
				
					return "";
				
				}
				public String QualificationOriginalDbColumnName(){
				
					return "Qualification";
				
				}

				
			    public String LanguagesKnown;

				public String getLanguagesKnown () {
					return this.LanguagesKnown;
				}

				public Boolean LanguagesKnownIsNullable(){
				    return true;
				}
				public Boolean LanguagesKnownIsKey(){
				    return false;
				}
				public Integer LanguagesKnownLength(){
				    return 50;
				}
				public Integer LanguagesKnownPrecision(){
				    return 0;
				}
				public String LanguagesKnownDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String LanguagesKnownComment(){
				
				    return "";
				
				}
				public String LanguagesKnownPattern(){
				
					return "";
				
				}
				public String LanguagesKnownOriginalDbColumnName(){
				
					return "LanguagesKnown";
				
				}

				
			    public String Nationality;

				public String getNationality () {
					return this.Nationality;
				}

				public Boolean NationalityIsNullable(){
				    return true;
				}
				public Boolean NationalityIsKey(){
				    return false;
				}
				public Integer NationalityLength(){
				    return 50;
				}
				public Integer NationalityPrecision(){
				    return 0;
				}
				public String NationalityDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String NationalityComment(){
				
				    return "";
				
				}
				public String NationalityPattern(){
				
					return "";
				
				}
				public String NationalityOriginalDbColumnName(){
				
					return "Nationality";
				
				}

				
			    public String DrivingLicence;

				public String getDrivingLicence () {
					return this.DrivingLicence;
				}

				public Boolean DrivingLicenceIsNullable(){
				    return true;
				}
				public Boolean DrivingLicenceIsKey(){
				    return false;
				}
				public Integer DrivingLicenceLength(){
				    return 50;
				}
				public Integer DrivingLicencePrecision(){
				    return 0;
				}
				public String DrivingLicenceDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String DrivingLicenceComment(){
				
				    return "";
				
				}
				public String DrivingLicencePattern(){
				
					return "";
				
				}
				public String DrivingLicenceOriginalDbColumnName(){
				
					return "DrivingLicence";
				
				}

				
			    public String PhysicalCode;

				public String getPhysicalCode () {
					return this.PhysicalCode;
				}

				public Boolean PhysicalCodeIsNullable(){
				    return true;
				}
				public Boolean PhysicalCodeIsKey(){
				    return false;
				}
				public Integer PhysicalCodeLength(){
				    return 50;
				}
				public Integer PhysicalCodePrecision(){
				    return 0;
				}
				public String PhysicalCodeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String PhysicalCodeComment(){
				
				    return "";
				
				}
				public String PhysicalCodePattern(){
				
					return "";
				
				}
				public String PhysicalCodeOriginalDbColumnName(){
				
					return "PhysicalCode";
				
				}

				
			    public String Photo;

				public String getPhoto () {
					return this.Photo;
				}

				public Boolean PhotoIsNullable(){
				    return true;
				}
				public Boolean PhotoIsKey(){
				    return false;
				}
				public Integer PhotoLength(){
				    return 150;
				}
				public Integer PhotoPrecision(){
				    return 0;
				}
				public String PhotoDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String PhotoComment(){
				
				    return "";
				
				}
				public String PhotoPattern(){
				
					return "";
				
				}
				public String PhotoOriginalDbColumnName(){
				
					return "Photo";
				
				}

				
			    public BigDecimal YearsOfExperience;

				public BigDecimal getYearsOfExperience () {
					return this.YearsOfExperience;
				}

				public Boolean YearsOfExperienceIsNullable(){
				    return true;
				}
				public Boolean YearsOfExperienceIsKey(){
				    return false;
				}
				public Integer YearsOfExperienceLength(){
				    return 4;
				}
				public Integer YearsOfExperiencePrecision(){
				    return 2;
				}
				public String YearsOfExperienceDefault(){
				
					return "NULL::numeric";
				
				}
				public String YearsOfExperienceComment(){
				
				    return "";
				
				}
				public String YearsOfExperiencePattern(){
				
					return "";
				
				}
				public String YearsOfExperienceOriginalDbColumnName(){
				
					return "YearsOfExperience";
				
				}

				
			    public BigDecimal RelevantYearsOfExperience;

				public BigDecimal getRelevantYearsOfExperience () {
					return this.RelevantYearsOfExperience;
				}

				public Boolean RelevantYearsOfExperienceIsNullable(){
				    return true;
				}
				public Boolean RelevantYearsOfExperienceIsKey(){
				    return false;
				}
				public Integer RelevantYearsOfExperienceLength(){
				    return 4;
				}
				public Integer RelevantYearsOfExperiencePrecision(){
				    return 2;
				}
				public String RelevantYearsOfExperienceDefault(){
				
					return "NULL::numeric";
				
				}
				public String RelevantYearsOfExperienceComment(){
				
				    return "";
				
				}
				public String RelevantYearsOfExperiencePattern(){
				
					return "";
				
				}
				public String RelevantYearsOfExperienceOriginalDbColumnName(){
				
					return "RelevantYearsOfExperience";
				
				}

				
			    public String KeyStrengths;

				public String getKeyStrengths () {
					return this.KeyStrengths;
				}

				public Boolean KeyStrengthsIsNullable(){
				    return true;
				}
				public Boolean KeyStrengthsIsKey(){
				    return false;
				}
				public Integer KeyStrengthsLength(){
				    return 2147483647;
				}
				public Integer KeyStrengthsPrecision(){
				    return 0;
				}
				public String KeyStrengthsDefault(){
				
					return null;
				
				}
				public String KeyStrengthsComment(){
				
				    return "";
				
				}
				public String KeyStrengthsPattern(){
				
					return "";
				
				}
				public String KeyStrengthsOriginalDbColumnName(){
				
					return "KeyStrengths";
				
				}

				
			    public byte[] HavePassport;

				public byte[] getHavePassport () {
					return this.HavePassport;
				}

				public Boolean HavePassportIsNullable(){
				    return false;
				}
				public Boolean HavePassportIsKey(){
				    return false;
				}
				public Integer HavePassportLength(){
				    return 1;
				}
				public Integer HavePassportPrecision(){
				    return 0;
				}
				public String HavePassportDefault(){
				
					return null;
				
				}
				public String HavePassportComment(){
				
				    return "";
				
				}
				public String HavePassportPattern(){
				
					return "";
				
				}
				public String HavePassportOriginalDbColumnName(){
				
					return "HavePassport";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 29;
				}
				public Integer CreatedDatePrecision(){
				    return 6;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 29;
				}
				public Integer ModifiedDatePrecision(){
				    return 6;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeeHRInfoID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.EmployeeHRInfoID != other.EmployeeHRInfoID)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.EmployeeHRInfoID = this.EmployeeHRInfoID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.Qualification = this.Qualification;
	            other.LanguagesKnown = this.LanguagesKnown;
	            other.Nationality = this.Nationality;
	            other.DrivingLicence = this.DrivingLicence;
	            other.PhysicalCode = this.PhysicalCode;
	            other.Photo = this.Photo;
	            other.YearsOfExperience = this.YearsOfExperience;
	            other.RelevantYearsOfExperience = this.RelevantYearsOfExperience;
	            other.KeyStrengths = this.KeyStrengths;
	            other.HavePassport = this.HavePassport;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.EmployeeHRInfoID = this.EmployeeHRInfoID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private byte[] readByteArray(ObjectInputStream dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}
	
	private byte[] readByteArray(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}

    private void writeByteArray(byte[] byteArray, ObjectOutputStream dos) throws IOException{
		if(byteArray == null) {
            dos.writeInt(-1);
		} else {
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeByteArray(byte[] byteArray, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(byteArray == null) {
			marshaller.writeInt(-1);
		} else {
			marshaller.writeInt(byteArray.length);
			marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeHRInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.Qualification = readString(dis);
					
					this.LanguagesKnown = readString(dis);
					
					this.Nationality = readString(dis);
					
					this.DrivingLicence = readString(dis);
					
					this.PhysicalCode = readString(dis);
					
					this.Photo = readString(dis);
					
						this.YearsOfExperience = (BigDecimal) dis.readObject();
					
						this.RelevantYearsOfExperience = (BigDecimal) dis.readObject();
					
					this.KeyStrengths = readString(dis);
					
					this.HavePassport = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeHRInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.Qualification = readString(dis);
					
					this.LanguagesKnown = readString(dis);
					
					this.Nationality = readString(dis);
					
					this.DrivingLicence = readString(dis);
					
					this.PhysicalCode = readString(dis);
					
					this.Photo = readString(dis);
					
						this.YearsOfExperience = (BigDecimal) dis.readObject();
					
						this.RelevantYearsOfExperience = (BigDecimal) dis.readObject();
					
					this.KeyStrengths = readString(dis);
					
					this.HavePassport = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeHRInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.Qualification,dos);
					
					// String
				
						writeString(this.LanguagesKnown,dos);
					
					// String
				
						writeString(this.Nationality,dos);
					
					// String
				
						writeString(this.DrivingLicence,dos);
					
					// String
				
						writeString(this.PhysicalCode,dos);
					
					// String
				
						writeString(this.Photo,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.YearsOfExperience);
					
					// BigDecimal
				
       			    	dos.writeObject(this.RelevantYearsOfExperience);
					
					// String
				
						writeString(this.KeyStrengths,dos);
					
					// byte[]
				
						writeByteArray(this.HavePassport,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeHRInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.Qualification,dos);
					
					// String
				
						writeString(this.LanguagesKnown,dos);
					
					// String
				
						writeString(this.Nationality,dos);
					
					// String
				
						writeString(this.DrivingLicence,dos);
					
					// String
				
						writeString(this.PhysicalCode,dos);
					
					// String
				
						writeString(this.Photo,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.YearsOfExperience);
					
					// BigDecimal
				
       			    	dos.writeObject(this.RelevantYearsOfExperience);
					
					// String
				
						writeString(this.KeyStrengths,dos);
					
					// byte[]
				
						writeByteArray(this.HavePassport,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeeHRInfoID="+String.valueOf(EmployeeHRInfoID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",Qualification="+Qualification);
		sb.append(",LanguagesKnown="+LanguagesKnown);
		sb.append(",Nationality="+Nationality);
		sb.append(",DrivingLicence="+DrivingLicence);
		sb.append(",PhysicalCode="+PhysicalCode);
		sb.append(",Photo="+Photo);
		sb.append(",YearsOfExperience="+String.valueOf(YearsOfExperience));
		sb.append(",RelevantYearsOfExperience="+String.valueOf(RelevantYearsOfExperience));
		sb.append(",KeyStrengths="+KeyStrengths);
		sb.append(",HavePassport="+String.valueOf(HavePassport));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeeHRInfoID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(Qualification == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Qualification);
            			}
            		
        			sb.append("|");
        		
        				if(LanguagesKnown == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LanguagesKnown);
            			}
            		
        			sb.append("|");
        		
        				if(Nationality == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Nationality);
            			}
            		
        			sb.append("|");
        		
        				if(DrivingLicence == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DrivingLicence);
            			}
            		
        			sb.append("|");
        		
        				if(PhysicalCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhysicalCode);
            			}
            		
        			sb.append("|");
        		
        				if(Photo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Photo);
            			}
            		
        			sb.append("|");
        		
        				if(YearsOfExperience == null){
        					sb.append("<null>");
        				}else{
            				sb.append(YearsOfExperience);
            			}
            		
        			sb.append("|");
        		
        				if(RelevantYearsOfExperience == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RelevantYearsOfExperience);
            			}
            		
        			sb.append("|");
        		
        				if(KeyStrengths == null){
        					sb.append("<null>");
        				}else{
            				sb.append(KeyStrengths);
            			}
            		
        			sb.append("|");
        		
        				if(HavePassport == null){
        					sb.append("<null>");
        				}else{
            				sb.append(HavePassport);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeeHRInfoID, other.EmployeeHRInfoID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"EmployeeHRInfo\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("EmployeeHRInfo");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("EmployeeHRInfo");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"EmployeeHRInfoID\",\"EmployeeProfessionalDetailID\",\"Qualification\",\"LanguagesKnown\",\"Nationality\",\"DrivingLicence\",\"PhysicalCode\",\"Photo\",\"YearsOfExperience\",\"RelevantYearsOfExperience\",\"KeyStrengths\",\"HavePassport\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"EmployeeHRInfo\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT MDM.EmployeeHRInfo.EmployeeHRInfoID, 		MDM.EmployeeHRInfo.EmployeeProfessionalDetailID, 		MDM.EmployeeHRInfo.Qualification, 		MDM.EmployeeHRInfo.LanguagesKnown, 		MDM.EmployeeHRInfo.Nationality, 		MDM.EmployeeHRInfo.DrivingLicence, 		MDM.EmployeeHRInfo.PhysicalCode, 		MDM.EmployeeHRInfo.Photo, 		MDM.EmployeeHRInfo.YearsOfExperience, 		MDM.EmployeeHRInfo.RelevantYearsOfExperience, 		MDM.EmployeeHRInfo.KeyStrengths, 		MDM.EmployeeHRInfo.HavePassport, 		MDM.EmployeeHRInfo.CreatedBy, 		MDM.EmployeeHRInfo.CreatedDate, 		MDM.EmployeeHRInfo.ModifiedBy, 		MDM.EmployeeHRInfo.ModifiedDate FROM	MDM.EmployeeHRInfo  WHERE MDM.EmployeeHRInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND MDM.EmployeeHRInfo.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeHRInfoID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Qualification")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("LanguagesKnown")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Nationality")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DrivingLicence")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PhysicalCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Photo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("YearsOfExperience")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("RelevantYearsOfExperience")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("KeyStrengths")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("HavePassport")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"EmployeeHRInfo\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3); 
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT MDM.EmployeeHRInfo.EmployeeHRInfoID,\n		MDM.EmployeeHRInfo.EmployeeProfessionalDetailID,\n		MDM.EmployeeHRInfo.Qua"
+"lification,\n		MDM.EmployeeHRInfo.LanguagesKnown,\n		MDM.EmployeeHRInfo.Nationality,\n		MDM.EmployeeHRInfo.DrivingLicence,\n"
+"		MDM.EmployeeHRInfo.PhysicalCode,\n		MDM.EmployeeHRInfo.Photo,\n		MDM.EmployeeHRInfo.YearsOfExperience,\n		MDM.EmployeeHRI"
+"nfo.RelevantYearsOfExperience,\n		MDM.EmployeeHRInfo.KeyStrengths,\n		MDM.EmployeeHRInfo.HavePassport,\n		MDM.EmployeeHRInf"
+"o.CreatedBy,\n		MDM.EmployeeHRInfo.CreatedDate,\n		MDM.EmployeeHRInfo.ModifiedBy,\n		MDM.EmployeeHRInfo.ModifiedDate\nFROM	M"
+"DM.EmployeeHRInfo\nWHERE MDM.EmployeeHRInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND MDM.Empl"
+"oyeeHRInfo.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.EmployeeHRInfoID = 0;
							} else {
		                          
            row3.EmployeeHRInfoID = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row3.EmployeeProfessionalDetailID = rs_tDBInput_3.getInt(2);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.Qualification = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(3);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Qualification = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Qualification = tmpContent_tDBInput_3;
                }
            } else {
                row3.Qualification = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.LanguagesKnown = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(4);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.LanguagesKnown = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.LanguagesKnown = tmpContent_tDBInput_3;
                }
            } else {
                row3.LanguagesKnown = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.Nationality = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(5);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Nationality = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Nationality = tmpContent_tDBInput_3;
                }
            } else {
                row3.Nationality = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.DrivingLicence = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(6);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.DrivingLicence = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.DrivingLicence = tmpContent_tDBInput_3;
                }
            } else {
                row3.DrivingLicence = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.PhysicalCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(7);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.PhysicalCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.PhysicalCode = tmpContent_tDBInput_3;
                }
            } else {
                row3.PhysicalCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.Photo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(8);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Photo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Photo = tmpContent_tDBInput_3;
                }
            } else {
                row3.Photo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.YearsOfExperience = null;
							} else {
		                          
            row3.YearsOfExperience = rs_tDBInput_3.getBigDecimal(9);
            if(rs_tDBInput_3.wasNull()){
                    row3.YearsOfExperience = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.RelevantYearsOfExperience = null;
							} else {
		                          
            row3.RelevantYearsOfExperience = rs_tDBInput_3.getBigDecimal(10);
            if(rs_tDBInput_3.wasNull()){
                    row3.RelevantYearsOfExperience = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 11) {
								row3.KeyStrengths = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(11);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.KeyStrengths = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.KeyStrengths = tmpContent_tDBInput_3;
                }
            } else {
                row3.KeyStrengths = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 12) {
								row3.HavePassport = null;
							} else {
		                          
            row3.HavePassport = rs_tDBInput_3.getBytes(12);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 13) {
								row3.CreatedBy = 0;
							} else {
		                          
            row3.CreatedBy = rs_tDBInput_3.getInt(13);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 14) {
								row3.CreatedDate = null;
							} else {
										
			row3.CreatedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 14);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 15) {
								row3.ModifiedBy = null;
							} else {
		                          
            row3.ModifiedBy = rs_tDBInput_3.getInt(15);
            if(rs_tDBInput_3.wasNull()){
                    row3.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 16) {
								row3.ModifiedDate = null;
							} else {
										
			row3.ModifiedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 16);
			
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					





 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"EmployeeHRInfo\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, row3.EmployeeHRInfoID);

                    pstmt_tDBOutput_3.setInt(2, row3.EmployeeProfessionalDetailID);

                    if(row3.Qualification == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row3.Qualification);
}

                    if(row3.LanguagesKnown == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, row3.LanguagesKnown);
}

                    if(row3.Nationality == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row3.Nationality);
}

                    if(row3.DrivingLicence == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, row3.DrivingLicence);
}

                    if(row3.PhysicalCode == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, row3.PhysicalCode);
}

                    if(row3.Photo == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, row3.Photo);
}

                    pstmt_tDBOutput_3.setBigDecimal(9, row3.YearsOfExperience);

                    pstmt_tDBOutput_3.setBigDecimal(10, row3.RelevantYearsOfExperience);

                    if(row3.KeyStrengths == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, row3.KeyStrengths);
}

                    if(row3.HavePassport == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.ARRAY);
} else {pstmt_tDBOutput_3.setBytes(12, row3.HavePassport);
}

                    pstmt_tDBOutput_3.setInt(13, row3.CreatedBy);

                    if(row3.CreatedDate != null) {
pstmt_tDBOutput_3.setTimestamp(14, new java.sql.Timestamp(row3.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(row3.ModifiedBy == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(15, row3.ModifiedBy);
}

                    if(row3.ModifiedDate != null) {
pstmt_tDBOutput_3.setTimestamp(16, new java.sql.Timestamp(row3.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_3)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"EmployeeHRInfo\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"EmployeeHRInfo\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeeMasterChangeID;

				public int getEmployeeMasterChangeID () {
					return this.EmployeeMasterChangeID;
				}

				public Boolean EmployeeMasterChangeIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeMasterChangeIDIsKey(){
				    return true;
				}
				public Integer EmployeeMasterChangeIDLength(){
				    return 10;
				}
				public Integer EmployeeMasterChangeIDPrecision(){
				    return 0;
				}
				public String EmployeeMasterChangeIDDefault(){
				
					return null;
				
				}
				public String EmployeeMasterChangeIDComment(){
				
				    return "";
				
				}
				public String EmployeeMasterChangeIDPattern(){
				
					return "";
				
				}
				public String EmployeeMasterChangeIDOriginalDbColumnName(){
				
					return "EmployeeMasterChangeID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public Integer MDMMasterID;

				public Integer getMDMMasterID () {
					return this.MDMMasterID;
				}

				public Boolean MDMMasterIDIsNullable(){
				    return true;
				}
				public Boolean MDMMasterIDIsKey(){
				    return false;
				}
				public Integer MDMMasterIDLength(){
				    return 10;
				}
				public Integer MDMMasterIDPrecision(){
				    return 0;
				}
				public String MDMMasterIDDefault(){
				
					return null;
				
				}
				public String MDMMasterIDComment(){
				
				    return "";
				
				}
				public String MDMMasterIDPattern(){
				
					return "";
				
				}
				public String MDMMasterIDOriginalDbColumnName(){
				
					return "MDMMasterID";
				
				}

				
			    public Integer UDMID;

				public Integer getUDMID () {
					return this.UDMID;
				}

				public Boolean UDMIDIsNullable(){
				    return true;
				}
				public Boolean UDMIDIsKey(){
				    return false;
				}
				public Integer UDMIDLength(){
				    return 10;
				}
				public Integer UDMIDPrecision(){
				    return 0;
				}
				public String UDMIDDefault(){
				
					return null;
				
				}
				public String UDMIDComment(){
				
				    return "";
				
				}
				public String UDMIDPattern(){
				
					return "";
				
				}
				public String UDMIDOriginalDbColumnName(){
				
					return "UDMID";
				
				}

				
			    public Integer OldID;

				public Integer getOldID () {
					return this.OldID;
				}

				public Boolean OldIDIsNullable(){
				    return true;
				}
				public Boolean OldIDIsKey(){
				    return false;
				}
				public Integer OldIDLength(){
				    return 10;
				}
				public Integer OldIDPrecision(){
				    return 0;
				}
				public String OldIDDefault(){
				
					return null;
				
				}
				public String OldIDComment(){
				
				    return "";
				
				}
				public String OldIDPattern(){
				
					return "";
				
				}
				public String OldIDOriginalDbColumnName(){
				
					return "OldID";
				
				}

				
			    public Integer NewID;

				public Integer getNewID () {
					return this.NewID;
				}

				public Boolean NewIDIsNullable(){
				    return true;
				}
				public Boolean NewIDIsKey(){
				    return false;
				}
				public Integer NewIDLength(){
				    return 10;
				}
				public Integer NewIDPrecision(){
				    return 0;
				}
				public String NewIDDefault(){
				
					return null;
				
				}
				public String NewIDComment(){
				
				    return "";
				
				}
				public String NewIDPattern(){
				
					return "";
				
				}
				public String NewIDOriginalDbColumnName(){
				
					return "NewID";
				
				}

				
			    public java.util.Date EffectiveDate;

				public java.util.Date getEffectiveDate () {
					return this.EffectiveDate;
				}

				public Boolean EffectiveDateIsNullable(){
				    return false;
				}
				public Boolean EffectiveDateIsKey(){
				    return false;
				}
				public Integer EffectiveDateLength(){
				    return 23;
				}
				public Integer EffectiveDatePrecision(){
				    return 3;
				}
				public String EffectiveDateDefault(){
				
					return null;
				
				}
				public String EffectiveDateComment(){
				
				    return "";
				
				}
				public String EffectiveDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String EffectiveDateOriginalDbColumnName(){
				
					return "EffectiveDate";
				
				}

				
			    public String Comments;

				public String getComments () {
					return this.Comments;
				}

				public Boolean CommentsIsNullable(){
				    return true;
				}
				public Boolean CommentsIsKey(){
				    return false;
				}
				public Integer CommentsLength(){
				    return 150;
				}
				public Integer CommentsPrecision(){
				    return 0;
				}
				public String CommentsDefault(){
				
					return null;
				
				}
				public String CommentsComment(){
				
				    return "";
				
				}
				public String CommentsPattern(){
				
					return "";
				
				}
				public String CommentsOriginalDbColumnName(){
				
					return "Comments";
				
				}

				
			    public Integer ChangedBy;

				public Integer getChangedBy () {
					return this.ChangedBy;
				}

				public Boolean ChangedByIsNullable(){
				    return true;
				}
				public Boolean ChangedByIsKey(){
				    return false;
				}
				public Integer ChangedByLength(){
				    return 10;
				}
				public Integer ChangedByPrecision(){
				    return 0;
				}
				public String ChangedByDefault(){
				
					return null;
				
				}
				public String ChangedByComment(){
				
				    return "";
				
				}
				public String ChangedByPattern(){
				
					return "";
				
				}
				public String ChangedByOriginalDbColumnName(){
				
					return "ChangedBy";
				
				}

				
			    public java.util.Date ChangedDate;

				public java.util.Date getChangedDate () {
					return this.ChangedDate;
				}

				public Boolean ChangedDateIsNullable(){
				    return true;
				}
				public Boolean ChangedDateIsKey(){
				    return false;
				}
				public Integer ChangedDateLength(){
				    return 23;
				}
				public Integer ChangedDatePrecision(){
				    return 3;
				}
				public String ChangedDateDefault(){
				
					return null;
				
				}
				public String ChangedDateComment(){
				
				    return "";
				
				}
				public String ChangedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ChangedDateOriginalDbColumnName(){
				
					return "ChangedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeeMasterChangeID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.EmployeeMasterChangeID != other.EmployeeMasterChangeID)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.EmployeeMasterChangeID = this.EmployeeMasterChangeID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.MDMMasterID = this.MDMMasterID;
	            other.UDMID = this.UDMID;
	            other.OldID = this.OldID;
	            other.NewID = this.NewID;
	            other.EffectiveDate = this.EffectiveDate;
	            other.Comments = this.Comments;
	            other.ChangedBy = this.ChangedBy;
	            other.ChangedDate = this.ChangedDate;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.EmployeeMasterChangeID = this.EmployeeMasterChangeID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeMasterChangeID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
						this.MDMMasterID = readInteger(dis);
					
						this.UDMID = readInteger(dis);
					
						this.OldID = readInteger(dis);
					
						this.NewID = readInteger(dis);
					
					this.EffectiveDate = readDate(dis);
					
					this.Comments = readString(dis);
					
						this.ChangedBy = readInteger(dis);
					
					this.ChangedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeeMasterChangeID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
						this.MDMMasterID = readInteger(dis);
					
						this.UDMID = readInteger(dis);
					
						this.OldID = readInteger(dis);
					
						this.NewID = readInteger(dis);
					
					this.EffectiveDate = readDate(dis);
					
					this.Comments = readString(dis);
					
						this.ChangedBy = readInteger(dis);
					
					this.ChangedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeMasterChangeID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// Integer
				
						writeInteger(this.MDMMasterID,dos);
					
					// Integer
				
						writeInteger(this.UDMID,dos);
					
					// Integer
				
						writeInteger(this.OldID,dos);
					
					// Integer
				
						writeInteger(this.NewID,dos);
					
					// java.util.Date
				
						writeDate(this.EffectiveDate,dos);
					
					// String
				
						writeString(this.Comments,dos);
					
					// Integer
				
						writeInteger(this.ChangedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ChangedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeeMasterChangeID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// Integer
				
						writeInteger(this.MDMMasterID,dos);
					
					// Integer
				
						writeInteger(this.UDMID,dos);
					
					// Integer
				
						writeInteger(this.OldID,dos);
					
					// Integer
				
						writeInteger(this.NewID,dos);
					
					// java.util.Date
				
						writeDate(this.EffectiveDate,dos);
					
					// String
				
						writeString(this.Comments,dos);
					
					// Integer
				
						writeInteger(this.ChangedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ChangedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeeMasterChangeID="+String.valueOf(EmployeeMasterChangeID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",MDMMasterID="+String.valueOf(MDMMasterID));
		sb.append(",UDMID="+String.valueOf(UDMID));
		sb.append(",OldID="+String.valueOf(OldID));
		sb.append(",NewID="+String.valueOf(NewID));
		sb.append(",EffectiveDate="+String.valueOf(EffectiveDate));
		sb.append(",Comments="+Comments);
		sb.append(",ChangedBy="+String.valueOf(ChangedBy));
		sb.append(",ChangedDate="+String.valueOf(ChangedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeeMasterChangeID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(MDMMasterID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MDMMasterID);
            			}
            		
        			sb.append("|");
        		
        				if(UDMID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UDMID);
            			}
            		
        			sb.append("|");
        		
        				if(OldID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OldID);
            			}
            		
        			sb.append("|");
        		
        				if(NewID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(NewID);
            			}
            		
        			sb.append("|");
        		
        				if(EffectiveDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EffectiveDate);
            			}
            		
        			sb.append("|");
        		
        				if(Comments == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Comments);
            			}
            		
        			sb.append("|");
        		
        				if(ChangedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ChangedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ChangedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ChangedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeeMasterChangeID, other.EmployeeMasterChangeID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"EmployeeMasterChange\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("EmployeeMasterChange");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("EmployeeMasterChange");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_4 + "\"")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_4 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"EmployeeMasterChangeID\",\"EmployeeProfessionalDetailID\",\"MDMMasterID\",\"UDMID\",\"OldID\",\"NewID\",\"EffectiveDate\",\"Comments\",\"ChangedBy\",\"ChangedDate\") VALUES (?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"EmployeeMasterChange\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT MDM.EmployeeMasterChange.EmployeeMasterChangeID, 		MDM.EmployeeMasterChange.EmployeeProfessionalDetailID, 		MDM.EmployeeMasterChange.MDMMasterID, 		MDM.EmployeeMasterChange.UDMID, 		MDM.EmployeeMasterChange.OldID, 		MDM.EmployeeMasterChange.\\\"NewID\\\", 		MDM.EmployeeMasterChange.EffectiveDate, 		MDM.EmployeeMasterChange.Comments, 		MDM.EmployeeMasterChange.ChangedBy, 		MDM.EmployeeMasterChange.ChangedDate FROM	MDM.EmployeeMasterChange\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeMasterChangeID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MDMMasterID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UDMID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OldID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("NewID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EffectiveDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Comments")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ChangedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ChangedDate")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"EmployeeMasterChange\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_4  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4); 
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_4 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT MDM.EmployeeMasterChange.EmployeeMasterChangeID,\n		MDM.EmployeeMasterChange.EmployeeProfessionalDetailID,\n		MDM."
+"EmployeeMasterChange.MDMMasterID,\n		MDM.EmployeeMasterChange.UDMID,\n		MDM.EmployeeMasterChange.OldID,\n		MDM.EmployeeMast"
+"erChange.\"NewID\",\n		MDM.EmployeeMasterChange.EffectiveDate,\n		MDM.EmployeeMasterChange.Comments,\n		MDM.EmployeeMasterC"
+"hange.ChangedBy,\n		MDM.EmployeeMasterChange.ChangedDate\nFROM	MDM.EmployeeMasterChange";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.EmployeeMasterChangeID = 0;
							} else {
		                          
            row4.EmployeeMasterChangeID = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row4.EmployeeProfessionalDetailID = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.MDMMasterID = null;
							} else {
		                          
            row4.MDMMasterID = rs_tDBInput_4.getInt(3);
            if(rs_tDBInput_4.wasNull()){
                    row4.MDMMasterID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.UDMID = null;
							} else {
		                          
            row4.UDMID = rs_tDBInput_4.getInt(4);
            if(rs_tDBInput_4.wasNull()){
                    row4.UDMID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.OldID = null;
							} else {
		                          
            row4.OldID = rs_tDBInput_4.getInt(5);
            if(rs_tDBInput_4.wasNull()){
                    row4.OldID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.NewID = null;
							} else {
		                          
            row4.NewID = rs_tDBInput_4.getInt(6);
            if(rs_tDBInput_4.wasNull()){
                    row4.NewID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.EffectiveDate = null;
							} else {
										
			row4.EffectiveDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 7);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.Comments = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(8);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Comments = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Comments = tmpContent_tDBInput_4;
                }
            } else {
                row4.Comments = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.ChangedBy = null;
							} else {
		                          
            row4.ChangedBy = rs_tDBInput_4.getInt(9);
            if(rs_tDBInput_4.wasNull()){
                    row4.ChangedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.ChangedDate = null;
							} else {
										
			row4.ChangedDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 10);
			
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					





 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"EmployeeMasterChange\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, row4.EmployeeMasterChangeID);

                    pstmt_tDBOutput_4.setInt(2, row4.EmployeeProfessionalDetailID);

                    if(row4.MDMMasterID == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(3, row4.MDMMasterID);
}

                    if(row4.UDMID == null) {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(4, row4.UDMID);
}

                    if(row4.OldID == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(5, row4.OldID);
}

                    if(row4.NewID == null) {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(6, row4.NewID);
}

                    if(row4.EffectiveDate != null) {
pstmt_tDBOutput_4.setTimestamp(7, new java.sql.Timestamp(row4.EffectiveDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.TIMESTAMP);
}

                    if(row4.Comments == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(8, row4.Comments);
}

                    if(row4.ChangedBy == null) {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(9, row4.ChangedBy);
}

                    if(row4.ChangedDate != null) {
pstmt_tDBOutput_4.setTimestamp(10, new java.sql.Timestamp(row4.ChangedDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_4)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"EmployeeMasterChange\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"EmployeeMasterChange\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeePassportInfoID;

				public int getEmployeePassportInfoID () {
					return this.EmployeePassportInfoID;
				}

				public Boolean EmployeePassportInfoIDIsNullable(){
				    return false;
				}
				public Boolean EmployeePassportInfoIDIsKey(){
				    return true;
				}
				public Integer EmployeePassportInfoIDLength(){
				    return 10;
				}
				public Integer EmployeePassportInfoIDPrecision(){
				    return 0;
				}
				public String EmployeePassportInfoIDDefault(){
				
					return null;
				
				}
				public String EmployeePassportInfoIDComment(){
				
				    return "";
				
				}
				public String EmployeePassportInfoIDPattern(){
				
					return "";
				
				}
				public String EmployeePassportInfoIDOriginalDbColumnName(){
				
					return "EmployeePassportInfoID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public String PassportNumber;

				public String getPassportNumber () {
					return this.PassportNumber;
				}

				public Boolean PassportNumberIsNullable(){
				    return false;
				}
				public Boolean PassportNumberIsKey(){
				    return false;
				}
				public Integer PassportNumberLength(){
				    return 20;
				}
				public Integer PassportNumberPrecision(){
				    return 0;
				}
				public String PassportNumberDefault(){
				
					return null;
				
				}
				public String PassportNumberComment(){
				
				    return "";
				
				}
				public String PassportNumberPattern(){
				
					return "";
				
				}
				public String PassportNumberOriginalDbColumnName(){
				
					return "PassportNumber";
				
				}

				
			    public String IssuedAt;

				public String getIssuedAt () {
					return this.IssuedAt;
				}

				public Boolean IssuedAtIsNullable(){
				    return false;
				}
				public Boolean IssuedAtIsKey(){
				    return false;
				}
				public Integer IssuedAtLength(){
				    return 50;
				}
				public Integer IssuedAtPrecision(){
				    return 0;
				}
				public String IssuedAtDefault(){
				
					return null;
				
				}
				public String IssuedAtComment(){
				
				    return "";
				
				}
				public String IssuedAtPattern(){
				
					return "";
				
				}
				public String IssuedAtOriginalDbColumnName(){
				
					return "IssuedAt";
				
				}

				
			    public java.util.Date IssuedDate;

				public java.util.Date getIssuedDate () {
					return this.IssuedDate;
				}

				public Boolean IssuedDateIsNullable(){
				    return false;
				}
				public Boolean IssuedDateIsKey(){
				    return false;
				}
				public Integer IssuedDateLength(){
				    return 13;
				}
				public Integer IssuedDatePrecision(){
				    return 0;
				}
				public String IssuedDateDefault(){
				
					return null;
				
				}
				public String IssuedDateComment(){
				
				    return "";
				
				}
				public String IssuedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String IssuedDateOriginalDbColumnName(){
				
					return "IssuedDate";
				
				}

				
			    public java.util.Date ExpiryDate;

				public java.util.Date getExpiryDate () {
					return this.ExpiryDate;
				}

				public Boolean ExpiryDateIsNullable(){
				    return false;
				}
				public Boolean ExpiryDateIsKey(){
				    return false;
				}
				public Integer ExpiryDateLength(){
				    return 13;
				}
				public Integer ExpiryDatePrecision(){
				    return 0;
				}
				public String ExpiryDateDefault(){
				
					return null;
				
				}
				public String ExpiryDateComment(){
				
				    return "";
				
				}
				public String ExpiryDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpiryDateOriginalDbColumnName(){
				
					return "ExpiryDate";
				
				}

				
			    public String SSNNumber;

				public String getSSNNumber () {
					return this.SSNNumber;
				}

				public Boolean SSNNumberIsNullable(){
				    return true;
				}
				public Boolean SSNNumberIsKey(){
				    return false;
				}
				public Integer SSNNumberLength(){
				    return 20;
				}
				public Integer SSNNumberPrecision(){
				    return 0;
				}
				public String SSNNumberDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String SSNNumberComment(){
				
				    return "";
				
				}
				public String SSNNumberPattern(){
				
					return "";
				
				}
				public String SSNNumberOriginalDbColumnName(){
				
					return "SSNNumber";
				
				}

				
			    public byte[] IsInternationalWorker;

				public byte[] getIsInternationalWorker () {
					return this.IsInternationalWorker;
				}

				public Boolean IsInternationalWorkerIsNullable(){
				    return false;
				}
				public Boolean IsInternationalWorkerIsKey(){
				    return false;
				}
				public Integer IsInternationalWorkerLength(){
				    return 1;
				}
				public Integer IsInternationalWorkerPrecision(){
				    return 0;
				}
				public String IsInternationalWorkerDefault(){
				
					return null;
				
				}
				public String IsInternationalWorkerComment(){
				
				    return "";
				
				}
				public String IsInternationalWorkerPattern(){
				
					return "";
				
				}
				public String IsInternationalWorkerOriginalDbColumnName(){
				
					return "IsInternationalWorker";
				
				}

				
			    public byte[] IsDisabled;

				public byte[] getIsDisabled () {
					return this.IsDisabled;
				}

				public Boolean IsDisabledIsNullable(){
				    return false;
				}
				public Boolean IsDisabledIsKey(){
				    return false;
				}
				public Integer IsDisabledLength(){
				    return 1;
				}
				public Integer IsDisabledPrecision(){
				    return 0;
				}
				public String IsDisabledDefault(){
				
					return null;
				
				}
				public String IsDisabledComment(){
				
				    return "";
				
				}
				public String IsDisabledPattern(){
				
					return "";
				
				}
				public String IsDisabledOriginalDbColumnName(){
				
					return "IsDisabled";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 29;
				}
				public Integer CreatedDatePrecision(){
				    return 6;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 29;
				}
				public Integer ModifiedDatePrecision(){
				    return 6;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeePassportInfoID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.EmployeePassportInfoID != other.EmployeePassportInfoID)
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.EmployeePassportInfoID = this.EmployeePassportInfoID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.PassportNumber = this.PassportNumber;
	            other.IssuedAt = this.IssuedAt;
	            other.IssuedDate = this.IssuedDate;
	            other.ExpiryDate = this.ExpiryDate;
	            other.SSNNumber = this.SSNNumber;
	            other.IsInternationalWorker = this.IsInternationalWorker;
	            other.IsDisabled = this.IsDisabled;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.EmployeePassportInfoID = this.EmployeePassportInfoID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private byte[] readByteArray(ObjectInputStream dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}
	
	private byte[] readByteArray(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		byte[] byteArrayReturn;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			byteArrayReturn = null;
		} else {
			byte[] byteArray = new byte[length];
			dis.readFully(byteArray);
			byteArrayReturn = byteArray;
		}
		return byteArrayReturn;
	}

    private void writeByteArray(byte[] byteArray, ObjectOutputStream dos) throws IOException{
		if(byteArray == null) {
            dos.writeInt(-1);
		} else {
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeByteArray(byte[] byteArray, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(byteArray == null) {
			marshaller.writeInt(-1);
		} else {
			marshaller.writeInt(byteArray.length);
			marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeePassportInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.PassportNumber = readString(dis);
					
					this.IssuedAt = readString(dis);
					
					this.IssuedDate = readDate(dis);
					
					this.ExpiryDate = readDate(dis);
					
					this.SSNNumber = readString(dis);
					
					this.IsInternationalWorker = readByteArray(dis);
					
					this.IsDisabled = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeePassportInfoID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.PassportNumber = readString(dis);
					
					this.IssuedAt = readString(dis);
					
					this.IssuedDate = readDate(dis);
					
					this.ExpiryDate = readDate(dis);
					
					this.SSNNumber = readString(dis);
					
					this.IsInternationalWorker = readByteArray(dis);
					
					this.IsDisabled = readByteArray(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeePassportInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.PassportNumber,dos);
					
					// String
				
						writeString(this.IssuedAt,dos);
					
					// java.util.Date
				
						writeDate(this.IssuedDate,dos);
					
					// java.util.Date
				
						writeDate(this.ExpiryDate,dos);
					
					// String
				
						writeString(this.SSNNumber,dos);
					
					// byte[]
				
						writeByteArray(this.IsInternationalWorker,dos);
					
					// byte[]
				
						writeByteArray(this.IsDisabled,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeePassportInfoID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.PassportNumber,dos);
					
					// String
				
						writeString(this.IssuedAt,dos);
					
					// java.util.Date
				
						writeDate(this.IssuedDate,dos);
					
					// java.util.Date
				
						writeDate(this.ExpiryDate,dos);
					
					// String
				
						writeString(this.SSNNumber,dos);
					
					// byte[]
				
						writeByteArray(this.IsInternationalWorker,dos);
					
					// byte[]
				
						writeByteArray(this.IsDisabled,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeePassportInfoID="+String.valueOf(EmployeePassportInfoID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",PassportNumber="+PassportNumber);
		sb.append(",IssuedAt="+IssuedAt);
		sb.append(",IssuedDate="+String.valueOf(IssuedDate));
		sb.append(",ExpiryDate="+String.valueOf(ExpiryDate));
		sb.append(",SSNNumber="+SSNNumber);
		sb.append(",IsInternationalWorker="+String.valueOf(IsInternationalWorker));
		sb.append(",IsDisabled="+String.valueOf(IsDisabled));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeePassportInfoID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(PassportNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PassportNumber);
            			}
            		
        			sb.append("|");
        		
        				if(IssuedAt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IssuedAt);
            			}
            		
        			sb.append("|");
        		
        				if(IssuedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IssuedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ExpiryDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ExpiryDate);
            			}
            		
        			sb.append("|");
        		
        				if(SSNNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SSNNumber);
            			}
            		
        			sb.append("|");
        		
        				if(IsInternationalWorker == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IsInternationalWorker);
            			}
            		
        			sb.append("|");
        		
        				if(IsDisabled == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IsDisabled);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeePassportInfoID, other.EmployeePassportInfoID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"EmployeePassportInfo\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_5 = null;
	dbschema_tDBOutput_5 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_5 = null;
if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
	tableName_tDBOutput_5 = ("EmployeePassportInfo");
} else {
	tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "\".\"" + ("EmployeePassportInfo");
}


int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

boolean whetherReject_tDBOutput_5 = false;

java.sql.Connection conn_tDBOutput_5 = null;
String dbUser_tDBOutput_5 = null;

	conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_5 = 10000;
   int batchSizeCounter_tDBOutput_5=0;

int count_tDBOutput_5=0;
        java.lang.StringBuilder sb_tDBOutput_5 = new java.lang.StringBuilder();
        sb_tDBOutput_5.append("INSERT INTO \"").append(tableName_tDBOutput_5).append("\" (\"EmployeePassportInfoID\",\"EmployeeProfessionalDetailID\",\"PassportNumber\",\"IssuedAt\",\"IssuedDate\",\"ExpiryDate\",\"SSNNumber\",\"IsInternationalWorker\",\"IsDisabled\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_5 = sb_tDBOutput_5.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing '")  + (insert_tDBOutput_5)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
	    resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
	    

 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		
		int tos_count_tDBInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
                    log4jParamters_tDBInput_5.append("Parameters:");
                            log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"EmployeePassportInfo\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERY" + " = " + "\"SELECT MDM.EmployeePassportInfo.EmployeePassportInfoID, 		MDM.EmployeePassportInfo.EmployeeProfessionalDetailID, 		MDM.EmployeePassportInfo.PassportNumber, 		MDM.EmployeePassportInfo.IssuedAt, 		MDM.EmployeePassportInfo.IssuedDate, 		MDM.EmployeePassportInfo.ExpiryDate, 		MDM.EmployeePassportInfo.SSNNumber, 		MDM.EmployeePassportInfo.IsInternationalWorker, 		MDM.EmployeePassportInfo.IsDisabled, 		MDM.EmployeePassportInfo.CreatedBy, 		MDM.EmployeePassportInfo.CreatedDate, 		MDM.EmployeePassportInfo.ModifiedBy, 		MDM.EmployeePassportInfo.ModifiedDate FROM	MDM.EmployeePassportInfo  WHERE MDM.EmployeePassportInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND MDM.EmployeePassportInfo.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeePassportInfoID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PassportNumber")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IssuedAt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IssuedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ExpiryDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SSNNumber")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IsInternationalWorker")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IsDisabled")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + (log4jParamters_tDBInput_5) );
                    } 
                } 
            new BytesLimit65535_tDBInput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_5", "\"EmployeePassportInfo\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_5 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_5 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_5  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_5, talendToDBArray_tDBInput_5); 
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				conn_tDBInput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_5 != null) {
					if(conn_tDBInput_5.getMetaData() != null) {
						
							log.debug("tDBInput_5 - Uses an existing connection with username '" + conn_tDBInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_5 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

		    String dbquery_tDBInput_5 = "SELECT MDM.EmployeePassportInfo.EmployeePassportInfoID,\n		MDM.EmployeePassportInfo.EmployeeProfessionalDetailID,\n		MDM."
+"EmployeePassportInfo.PassportNumber,\n		MDM.EmployeePassportInfo.IssuedAt,\n		MDM.EmployeePassportInfo.IssuedDate,\n		MDM.E"
+"mployeePassportInfo.ExpiryDate,\n		MDM.EmployeePassportInfo.SSNNumber,\n		MDM.EmployeePassportInfo.IsInternationalWorker,\n"
+"		MDM.EmployeePassportInfo.IsDisabled,\n		MDM.EmployeePassportInfo.CreatedBy,\n		MDM.EmployeePassportInfo.CreatedDate,\n		M"
+"DM.EmployeePassportInfo.ModifiedBy,\n		MDM.EmployeePassportInfo.ModifiedDate\nFROM	MDM.EmployeePassportInfo\nWHERE MDM.Emp"
+"loyeePassportInfo.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND MDM.EmployeePassportInfo.CreatedDa"
+"te < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");
			

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    	log.debug("tDBInput_5 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row5.EmployeePassportInfoID = 0;
							} else {
		                          
            row5.EmployeePassportInfoID = rs_tDBInput_5.getInt(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row5.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row5.EmployeeProfessionalDetailID = rs_tDBInput_5.getInt(2);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row5.PassportNumber = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(3);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.PassportNumber = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.PassportNumber = tmpContent_tDBInput_5;
                }
            } else {
                row5.PassportNumber = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row5.IssuedAt = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(4);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.IssuedAt = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.IssuedAt = tmpContent_tDBInput_5;
                }
            } else {
                row5.IssuedAt = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row5.IssuedDate = null;
							} else {
										
			row5.IssuedDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 5);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row5.ExpiryDate = null;
							} else {
										
			row5.ExpiryDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 6);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 7) {
								row5.SSNNumber = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(7);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.SSNNumber = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.SSNNumber = tmpContent_tDBInput_5;
                }
            } else {
                row5.SSNNumber = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 8) {
								row5.IsInternationalWorker = null;
							} else {
		                          
            row5.IsInternationalWorker = rs_tDBInput_5.getBytes(8);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 9) {
								row5.IsDisabled = null;
							} else {
		                          
            row5.IsDisabled = rs_tDBInput_5.getBytes(9);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 10) {
								row5.CreatedBy = 0;
							} else {
		                          
            row5.CreatedBy = rs_tDBInput_5.getInt(10);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 11) {
								row5.CreatedDate = null;
							} else {
										
			row5.CreatedDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 11);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 12) {
								row5.ModifiedBy = null;
							} else {
		                          
            row5.ModifiedBy = rs_tDBInput_5.getInt(12);
            if(rs_tDBInput_5.wasNull()){
                    row5.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 13) {
								row5.ModifiedDate = null;
							} else {
										
			row5.ModifiedDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 13);
			
		                    }
					
						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");
					





 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tDBInput_5","\"EmployeePassportInfo\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		



        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, row5.EmployeePassportInfoID);

                    pstmt_tDBOutput_5.setInt(2, row5.EmployeeProfessionalDetailID);

                    if(row5.PassportNumber == null) {
pstmt_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(3, row5.PassportNumber);
}

                    if(row5.IssuedAt == null) {
pstmt_tDBOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(4, row5.IssuedAt);
}

                    if(row5.IssuedDate != null) {
pstmt_tDBOutput_5.setTimestamp(5, new java.sql.Timestamp(row5.IssuedDate.getTime()));
} else {
pstmt_tDBOutput_5.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(row5.ExpiryDate != null) {
pstmt_tDBOutput_5.setTimestamp(6, new java.sql.Timestamp(row5.ExpiryDate.getTime()));
} else {
pstmt_tDBOutput_5.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row5.SSNNumber == null) {
pstmt_tDBOutput_5.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(7, row5.SSNNumber);
}

                    if(row5.IsInternationalWorker == null) {
pstmt_tDBOutput_5.setNull(8, java.sql.Types.ARRAY);
} else {pstmt_tDBOutput_5.setBytes(8, row5.IsInternationalWorker);
}

                    if(row5.IsDisabled == null) {
pstmt_tDBOutput_5.setNull(9, java.sql.Types.ARRAY);
} else {pstmt_tDBOutput_5.setBytes(9, row5.IsDisabled);
}

                    pstmt_tDBOutput_5.setInt(10, row5.CreatedBy);

                    if(row5.CreatedDate != null) {
pstmt_tDBOutput_5.setTimestamp(11, new java.sql.Timestamp(row5.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_5.setNull(11, java.sql.Types.TIMESTAMP);
}

                    if(row5.ModifiedBy == null) {
pstmt_tDBOutput_5.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(12, row5.ModifiedBy);
}

                    if(row5.ModifiedDate != null) {
pstmt_tDBOutput_5.setTimestamp(13, new java.sql.Timestamp(row5.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_5.setNull(13, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_5.addBatch();
    		nb_line_tDBOutput_5++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_5++;
    		  
    			if ((batchSize_tDBOutput_5 > 0) && (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {
                try {
						int countSum_tDBOutput_5 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            	    	batchSizeCounter_tDBOutput_5 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
				    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
				    	String errormessage_tDBOutput_5;
						if (ne_tDBOutput_5 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
							errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
						}else{
							errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
						}
				    	
				    	int countSum_tDBOutput_5 = 0;
						for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
				    	System.err.println(errormessage_tDBOutput_5);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
}
globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
	    		log.debug("tDBInput_5 - Retrieved records count: "+nb_line_tDBInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Done.") );

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());




/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_5 = 0;
				if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
	    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
	    	String errormessage_tDBOutput_5;
			if (ne_tDBOutput_5 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
				errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
			}else{
				errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
			}
	    	
	    	int countSum_tDBOutput_5 = 0;
			for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
				countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
			}
			rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
			
	    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
	    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
	    	System.err.println(errormessage_tDBOutput_5);
	    	
		}
	    
        if(pstmt_tDBOutput_5 != null) {
        		
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_5)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tDBInput_5","\"EmployeePassportInfo\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"EmployeePassportInfo\"";
		

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmployeePersonalDetailID;

				public int getEmployeePersonalDetailID () {
					return this.EmployeePersonalDetailID;
				}

				public Boolean EmployeePersonalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeePersonalDetailIDIsKey(){
				    return true;
				}
				public Integer EmployeePersonalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeePersonalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeePersonalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeePersonalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeePersonalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeePersonalDetailIDOriginalDbColumnName(){
				
					return "EmployeePersonalDetailID";
				
				}

				
			    public int EmployeeProfessionalDetailID;

				public int getEmployeeProfessionalDetailID () {
					return this.EmployeeProfessionalDetailID;
				}

				public Boolean EmployeeProfessionalDetailIDIsNullable(){
				    return false;
				}
				public Boolean EmployeeProfessionalDetailIDIsKey(){
				    return false;
				}
				public Integer EmployeeProfessionalDetailIDLength(){
				    return 10;
				}
				public Integer EmployeeProfessionalDetailIDPrecision(){
				    return 0;
				}
				public String EmployeeProfessionalDetailIDDefault(){
				
					return null;
				
				}
				public String EmployeeProfessionalDetailIDComment(){
				
				    return "";
				
				}
				public String EmployeeProfessionalDetailIDPattern(){
				
					return "";
				
				}
				public String EmployeeProfessionalDetailIDOriginalDbColumnName(){
				
					return "EmployeeProfessionalDetailID";
				
				}

				
			    public String PermanentAddress1;

				public String getPermanentAddress1 () {
					return this.PermanentAddress1;
				}

				public Boolean PermanentAddress1IsNullable(){
				    return true;
				}
				public Boolean PermanentAddress1IsKey(){
				    return false;
				}
				public Integer PermanentAddress1Length(){
				    return 250;
				}
				public Integer PermanentAddress1Precision(){
				    return 0;
				}
				public String PermanentAddress1Default(){
				
					return null;
				
				}
				public String PermanentAddress1Comment(){
				
				    return "";
				
				}
				public String PermanentAddress1Pattern(){
				
					return "";
				
				}
				public String PermanentAddress1OriginalDbColumnName(){
				
					return "PermanentAddress1";
				
				}

				
			    public String PermanentAddress2;

				public String getPermanentAddress2 () {
					return this.PermanentAddress2;
				}

				public Boolean PermanentAddress2IsNullable(){
				    return true;
				}
				public Boolean PermanentAddress2IsKey(){
				    return false;
				}
				public Integer PermanentAddress2Length(){
				    return 250;
				}
				public Integer PermanentAddress2Precision(){
				    return 0;
				}
				public String PermanentAddress2Default(){
				
					return null;
				
				}
				public String PermanentAddress2Comment(){
				
				    return "";
				
				}
				public String PermanentAddress2Pattern(){
				
					return "";
				
				}
				public String PermanentAddress2OriginalDbColumnName(){
				
					return "PermanentAddress2";
				
				}

				
			    public Integer PermanentCityID;

				public Integer getPermanentCityID () {
					return this.PermanentCityID;
				}

				public Boolean PermanentCityIDIsNullable(){
				    return true;
				}
				public Boolean PermanentCityIDIsKey(){
				    return false;
				}
				public Integer PermanentCityIDLength(){
				    return 10;
				}
				public Integer PermanentCityIDPrecision(){
				    return 0;
				}
				public String PermanentCityIDDefault(){
				
					return null;
				
				}
				public String PermanentCityIDComment(){
				
				    return "";
				
				}
				public String PermanentCityIDPattern(){
				
					return "";
				
				}
				public String PermanentCityIDOriginalDbColumnName(){
				
					return "PermanentCityID";
				
				}

				
			    public String PermanentPinCode;

				public String getPermanentPinCode () {
					return this.PermanentPinCode;
				}

				public Boolean PermanentPinCodeIsNullable(){
				    return true;
				}
				public Boolean PermanentPinCodeIsKey(){
				    return false;
				}
				public Integer PermanentPinCodeLength(){
				    return 50;
				}
				public Integer PermanentPinCodePrecision(){
				    return 0;
				}
				public String PermanentPinCodeDefault(){
				
					return null;
				
				}
				public String PermanentPinCodeComment(){
				
				    return "";
				
				}
				public String PermanentPinCodePattern(){
				
					return "";
				
				}
				public String PermanentPinCodeOriginalDbColumnName(){
				
					return "PermanentPinCode";
				
				}

				
			    public String TemparoryAddress1;

				public String getTemparoryAddress1 () {
					return this.TemparoryAddress1;
				}

				public Boolean TemparoryAddress1IsNullable(){
				    return true;
				}
				public Boolean TemparoryAddress1IsKey(){
				    return false;
				}
				public Integer TemparoryAddress1Length(){
				    return 250;
				}
				public Integer TemparoryAddress1Precision(){
				    return 0;
				}
				public String TemparoryAddress1Default(){
				
					return null;
				
				}
				public String TemparoryAddress1Comment(){
				
				    return "";
				
				}
				public String TemparoryAddress1Pattern(){
				
					return "";
				
				}
				public String TemparoryAddress1OriginalDbColumnName(){
				
					return "TemparoryAddress1";
				
				}

				
			    public String TemparoryAddress2;

				public String getTemparoryAddress2 () {
					return this.TemparoryAddress2;
				}

				public Boolean TemparoryAddress2IsNullable(){
				    return true;
				}
				public Boolean TemparoryAddress2IsKey(){
				    return false;
				}
				public Integer TemparoryAddress2Length(){
				    return 250;
				}
				public Integer TemparoryAddress2Precision(){
				    return 0;
				}
				public String TemparoryAddress2Default(){
				
					return null;
				
				}
				public String TemparoryAddress2Comment(){
				
				    return "";
				
				}
				public String TemparoryAddress2Pattern(){
				
					return "";
				
				}
				public String TemparoryAddress2OriginalDbColumnName(){
				
					return "TemparoryAddress2";
				
				}

				
			    public Integer TemparoryCityID;

				public Integer getTemparoryCityID () {
					return this.TemparoryCityID;
				}

				public Boolean TemparoryCityIDIsNullable(){
				    return true;
				}
				public Boolean TemparoryCityIDIsKey(){
				    return false;
				}
				public Integer TemparoryCityIDLength(){
				    return 10;
				}
				public Integer TemparoryCityIDPrecision(){
				    return 0;
				}
				public String TemparoryCityIDDefault(){
				
					return null;
				
				}
				public String TemparoryCityIDComment(){
				
				    return "";
				
				}
				public String TemparoryCityIDPattern(){
				
					return "";
				
				}
				public String TemparoryCityIDOriginalDbColumnName(){
				
					return "TemparoryCityID";
				
				}

				
			    public String TemparoryPinCode;

				public String getTemparoryPinCode () {
					return this.TemparoryPinCode;
				}

				public Boolean TemparoryPinCodeIsNullable(){
				    return true;
				}
				public Boolean TemparoryPinCodeIsKey(){
				    return false;
				}
				public Integer TemparoryPinCodeLength(){
				    return 50;
				}
				public Integer TemparoryPinCodePrecision(){
				    return 0;
				}
				public String TemparoryPinCodeDefault(){
				
					return null;
				
				}
				public String TemparoryPinCodeComment(){
				
				    return "";
				
				}
				public String TemparoryPinCodePattern(){
				
					return "";
				
				}
				public String TemparoryPinCodeOriginalDbColumnName(){
				
					return "TemparoryPinCode";
				
				}

				
			    public String PersonalMail;

				public String getPersonalMail () {
					return this.PersonalMail;
				}

				public Boolean PersonalMailIsNullable(){
				    return true;
				}
				public Boolean PersonalMailIsKey(){
				    return false;
				}
				public Integer PersonalMailLength(){
				    return 250;
				}
				public Integer PersonalMailPrecision(){
				    return 0;
				}
				public String PersonalMailDefault(){
				
					return null;
				
				}
				public String PersonalMailComment(){
				
				    return "";
				
				}
				public String PersonalMailPattern(){
				
					return "";
				
				}
				public String PersonalMailOriginalDbColumnName(){
				
					return "PersonalMail";
				
				}

				
			    public java.util.Date DateofBirth;

				public java.util.Date getDateofBirth () {
					return this.DateofBirth;
				}

				public Boolean DateofBirthIsNullable(){
				    return true;
				}
				public Boolean DateofBirthIsKey(){
				    return false;
				}
				public Integer DateofBirthLength(){
				    return 23;
				}
				public Integer DateofBirthPrecision(){
				    return 3;
				}
				public String DateofBirthDefault(){
				
					return null;
				
				}
				public String DateofBirthComment(){
				
				    return "";
				
				}
				public String DateofBirthPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateofBirthOriginalDbColumnName(){
				
					return "DateofBirth";
				
				}

				
			    public Integer BloodGroup;

				public Integer getBloodGroup () {
					return this.BloodGroup;
				}

				public Boolean BloodGroupIsNullable(){
				    return true;
				}
				public Boolean BloodGroupIsKey(){
				    return false;
				}
				public Integer BloodGroupLength(){
				    return 10;
				}
				public Integer BloodGroupPrecision(){
				    return 0;
				}
				public String BloodGroupDefault(){
				
					return null;
				
				}
				public String BloodGroupComment(){
				
				    return "";
				
				}
				public String BloodGroupPattern(){
				
					return "";
				
				}
				public String BloodGroupOriginalDbColumnName(){
				
					return "BloodGroup";
				
				}

				
			    public Short MaritalStatus;

				public Short getMaritalStatus () {
					return this.MaritalStatus;
				}

				public Boolean MaritalStatusIsNullable(){
				    return true;
				}
				public Boolean MaritalStatusIsKey(){
				    return false;
				}
				public Integer MaritalStatusLength(){
				    return 5;
				}
				public Integer MaritalStatusPrecision(){
				    return 0;
				}
				public String MaritalStatusDefault(){
				
					return null;
				
				}
				public String MaritalStatusComment(){
				
				    return "";
				
				}
				public String MaritalStatusPattern(){
				
					return "";
				
				}
				public String MaritalStatusOriginalDbColumnName(){
				
					return "MaritalStatus";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmployeePersonalDetailID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.EmployeePersonalDetailID != other.EmployeePersonalDetailID)
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.EmployeePersonalDetailID = this.EmployeePersonalDetailID;
	            other.EmployeeProfessionalDetailID = this.EmployeeProfessionalDetailID;
	            other.PermanentAddress1 = this.PermanentAddress1;
	            other.PermanentAddress2 = this.PermanentAddress2;
	            other.PermanentCityID = this.PermanentCityID;
	            other.PermanentPinCode = this.PermanentPinCode;
	            other.TemparoryAddress1 = this.TemparoryAddress1;
	            other.TemparoryAddress2 = this.TemparoryAddress2;
	            other.TemparoryCityID = this.TemparoryCityID;
	            other.TemparoryPinCode = this.TemparoryPinCode;
	            other.PersonalMail = this.PersonalMail;
	            other.DateofBirth = this.DateofBirth;
	            other.BloodGroup = this.BloodGroup;
	            other.MaritalStatus = this.MaritalStatus;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.EmployeePersonalDetailID = this.EmployeePersonalDetailID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_17, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeePersonalDetailID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.PermanentAddress1 = readString(dis);
					
					this.PermanentAddress2 = readString(dis);
					
						this.PermanentCityID = readInteger(dis);
					
					this.PermanentPinCode = readString(dis);
					
					this.TemparoryAddress1 = readString(dis);
					
					this.TemparoryAddress2 = readString(dis);
					
						this.TemparoryCityID = readInteger(dis);
					
					this.TemparoryPinCode = readString(dis);
					
					this.PersonalMail = readString(dis);
					
					this.DateofBirth = readDate(dis);
					
						this.BloodGroup = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MaritalStatus = null;
           				} else {
           			    	this.MaritalStatus = dis.readShort();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_17) {

        	try {

        		int length = 0;
		
			        this.EmployeePersonalDetailID = dis.readInt();
					
			        this.EmployeeProfessionalDetailID = dis.readInt();
					
					this.PermanentAddress1 = readString(dis);
					
					this.PermanentAddress2 = readString(dis);
					
						this.PermanentCityID = readInteger(dis);
					
					this.PermanentPinCode = readString(dis);
					
					this.TemparoryAddress1 = readString(dis);
					
					this.TemparoryAddress2 = readString(dis);
					
						this.TemparoryCityID = readInteger(dis);
					
					this.TemparoryPinCode = readString(dis);
					
					this.PersonalMail = readString(dis);
					
					this.DateofBirth = readDate(dis);
					
						this.BloodGroup = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.MaritalStatus = null;
           				} else {
           			    	this.MaritalStatus = dis.readShort();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeePersonalDetailID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.PermanentAddress1,dos);
					
					// String
				
						writeString(this.PermanentAddress2,dos);
					
					// Integer
				
						writeInteger(this.PermanentCityID,dos);
					
					// String
				
						writeString(this.PermanentPinCode,dos);
					
					// String
				
						writeString(this.TemparoryAddress1,dos);
					
					// String
				
						writeString(this.TemparoryAddress2,dos);
					
					// Integer
				
						writeInteger(this.TemparoryCityID,dos);
					
					// String
				
						writeString(this.TemparoryPinCode,dos);
					
					// String
				
						writeString(this.PersonalMail,dos);
					
					// java.util.Date
				
						writeDate(this.DateofBirth,dos);
					
					// Integer
				
						writeInteger(this.BloodGroup,dos);
					
					// Short
				
						if(this.MaritalStatus == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.MaritalStatus);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmployeePersonalDetailID);
					
					// int
				
		            	dos.writeInt(this.EmployeeProfessionalDetailID);
					
					// String
				
						writeString(this.PermanentAddress1,dos);
					
					// String
				
						writeString(this.PermanentAddress2,dos);
					
					// Integer
				
						writeInteger(this.PermanentCityID,dos);
					
					// String
				
						writeString(this.PermanentPinCode,dos);
					
					// String
				
						writeString(this.TemparoryAddress1,dos);
					
					// String
				
						writeString(this.TemparoryAddress2,dos);
					
					// Integer
				
						writeInteger(this.TemparoryCityID,dos);
					
					// String
				
						writeString(this.TemparoryPinCode,dos);
					
					// String
				
						writeString(this.PersonalMail,dos);
					
					// java.util.Date
				
						writeDate(this.DateofBirth,dos);
					
					// Integer
				
						writeInteger(this.BloodGroup,dos);
					
					// Short
				
						if(this.MaritalStatus == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.MaritalStatus);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmployeePersonalDetailID="+String.valueOf(EmployeePersonalDetailID));
		sb.append(",EmployeeProfessionalDetailID="+String.valueOf(EmployeeProfessionalDetailID));
		sb.append(",PermanentAddress1="+PermanentAddress1);
		sb.append(",PermanentAddress2="+PermanentAddress2);
		sb.append(",PermanentCityID="+String.valueOf(PermanentCityID));
		sb.append(",PermanentPinCode="+PermanentPinCode);
		sb.append(",TemparoryAddress1="+TemparoryAddress1);
		sb.append(",TemparoryAddress2="+TemparoryAddress2);
		sb.append(",TemparoryCityID="+String.valueOf(TemparoryCityID));
		sb.append(",TemparoryPinCode="+TemparoryPinCode);
		sb.append(",PersonalMail="+PersonalMail);
		sb.append(",DateofBirth="+String.valueOf(DateofBirth));
		sb.append(",BloodGroup="+String.valueOf(BloodGroup));
		sb.append(",MaritalStatus="+String.valueOf(MaritalStatus));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmployeePersonalDetailID);
        			
        			sb.append("|");
        		
        				sb.append(EmployeeProfessionalDetailID);
        			
        			sb.append("|");
        		
        				if(PermanentAddress1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PermanentAddress1);
            			}
            		
        			sb.append("|");
        		
        				if(PermanentAddress2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PermanentAddress2);
            			}
            		
        			sb.append("|");
        		
        				if(PermanentCityID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PermanentCityID);
            			}
            		
        			sb.append("|");
        		
        				if(PermanentPinCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PermanentPinCode);
            			}
            		
        			sb.append("|");
        		
        				if(TemparoryAddress1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TemparoryAddress1);
            			}
            		
        			sb.append("|");
        		
        				if(TemparoryAddress2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TemparoryAddress2);
            			}
            		
        			sb.append("|");
        		
        				if(TemparoryCityID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TemparoryCityID);
            			}
            		
        			sb.append("|");
        		
        				if(TemparoryPinCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TemparoryPinCode);
            			}
            		
        			sb.append("|");
        		
        				if(PersonalMail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PersonalMail);
            			}
            		
        			sb.append("|");
        		
        				if(DateofBirth == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DateofBirth);
            			}
            		
        			sb.append("|");
        		
        				if(BloodGroup == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BloodGroup);
            			}
            		
        			sb.append("|");
        		
        				if(MaritalStatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MaritalStatus);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmployeePersonalDetailID, other.EmployeePersonalDetailID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tDBOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
                    log4jParamters_tDBOutput_6.append("Parameters:");
                            log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"EmployeePersonalDetail\"");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + (log4jParamters_tDBOutput_6) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_6", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_6 = null;
	dbschema_tDBOutput_6 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_6 = null;
if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
	tableName_tDBOutput_6 = ("EmployeePersonalDetail");
} else {
	tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "\".\"" + ("EmployeePersonalDetail");
}


int nb_line_tDBOutput_6 = 0;
int nb_line_update_tDBOutput_6 = 0;
int nb_line_inserted_tDBOutput_6 = 0;
int nb_line_deleted_tDBOutput_6 = 0;
int nb_line_rejected_tDBOutput_6 = 0;

int deletedCount_tDBOutput_6=0;
int updatedCount_tDBOutput_6=0;
int insertedCount_tDBOutput_6=0;
int rowsToCommitCount_tDBOutput_6=0;
int rejectedCount_tDBOutput_6=0;

boolean whetherReject_tDBOutput_6 = false;

java.sql.Connection conn_tDBOutput_6 = null;
String dbUser_tDBOutput_6 = null;

	conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_6.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_6.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_6 = 10000;
   int batchSizeCounter_tDBOutput_6=0;

int count_tDBOutput_6=0;
            int rsTruncCountNumber_tDBOutput_6 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_6 = stmtTruncCount_tDBOutput_6.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_6 + "\"")) {
                    if(rsTruncCount_tDBOutput_6.next()) {
                        rsTruncCountNumber_tDBOutput_6 = rsTruncCount_tDBOutput_6.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_6+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_6.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_6 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_6+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_6 += rsTruncCountNumber_tDBOutput_6;
            }
        java.lang.StringBuilder sb_tDBOutput_6 = new java.lang.StringBuilder();
        sb_tDBOutput_6.append("INSERT INTO \"").append(tableName_tDBOutput_6).append("\" (\"EmployeePersonalDetailID\",\"EmployeeProfessionalDetailID\",\"PermanentAddress1\",\"PermanentAddress2\",\"PermanentCityID\",\"PermanentPinCode\",\"TemparoryAddress1\",\"TemparoryAddress2\",\"TemparoryCityID\",\"TemparoryPinCode\",\"PersonalMail\",\"DateofBirth\",\"BloodGroup\",\"MaritalStatus\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_6 = sb_tDBOutput_6.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing '")  + (insert_tDBOutput_6)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
	    resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
	    

 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		
		int tos_count_tDBInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
                    log4jParamters_tDBInput_6.append("Parameters:");
                            log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"EmployeePersonalDetail\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERY" + " = " + "\"SELECT MDM.EmployeePersonalDetail.EmployeePersonalDetailID, 		MDM.EmployeePersonalDetail.EmployeeProfessionalDetailID, 		MDM.EmployeePersonalDetail.PermanentAddress1, 		MDM.EmployeePersonalDetail.PermanentAddress2, 		MDM.EmployeePersonalDetail.PermanentCityID, 		MDM.EmployeePersonalDetail.PermanentPinCode, 		MDM.EmployeePersonalDetail.TemparoryAddress1, 		MDM.EmployeePersonalDetail.TemparoryAddress2, 		MDM.EmployeePersonalDetail.TemparoryCityID, 		MDM.EmployeePersonalDetail.TemparoryPinCode, 		MDM.EmployeePersonalDetail.PersonalMail, 		MDM.EmployeePersonalDetail.DateofBirth, 		MDM.EmployeePersonalDetail.BloodGroup, 		MDM.EmployeePersonalDetail.MaritalStatus FROM	MDM.EmployeePersonalDetail\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeePersonalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmployeeProfessionalDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PermanentAddress1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PermanentAddress2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PermanentCityID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PermanentPinCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TemparoryAddress1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TemparoryAddress2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TemparoryCityID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TemparoryPinCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PersonalMail")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DateofBirth")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BloodGroup")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MaritalStatus")+"}]");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + (log4jParamters_tDBInput_6) );
                    } 
                } 
            new BytesLimit65535_tDBInput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_6", "\"EmployeePersonalDetail\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_6 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_6 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_6  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_6, talendToDBArray_tDBInput_6); 
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				conn_tDBInput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_6 != null) {
					if(conn_tDBInput_6.getMetaData() != null) {
						
							log.debug("tDBInput_6 - Uses an existing connection with username '" + conn_tDBInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_6 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

		    String dbquery_tDBInput_6 = "SELECT MDM.EmployeePersonalDetail.EmployeePersonalDetailID,\n		MDM.EmployeePersonalDetail.EmployeeProfessionalDetailID,\n"
+"		MDM.EmployeePersonalDetail.PermanentAddress1,\n		MDM.EmployeePersonalDetail.PermanentAddress2,\n		MDM.EmployeePersonalDe"
+"tail.PermanentCityID,\n		MDM.EmployeePersonalDetail.PermanentPinCode,\n		MDM.EmployeePersonalDetail.TemparoryAddress1,\n		M"
+"DM.EmployeePersonalDetail.TemparoryAddress2,\n		MDM.EmployeePersonalDetail.TemparoryCityID,\n		MDM.EmployeePersonalDetail."
+"TemparoryPinCode,\n		MDM.EmployeePersonalDetail.PersonalMail,\n		MDM.EmployeePersonalDetail.DateofBirth,\n		MDM.EmployeePer"
+"sonalDetail.BloodGroup,\n		MDM.EmployeePersonalDetail.MaritalStatus\nFROM	MDM.EmployeePersonalDetail";
		    
	    		log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");
			

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    	log.debug("tDBInput_6 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row6.EmployeePersonalDetailID = 0;
							} else {
		                          
            row6.EmployeePersonalDetailID = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row6.EmployeeProfessionalDetailID = 0;
							} else {
		                          
            row6.EmployeeProfessionalDetailID = rs_tDBInput_6.getInt(2);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row6.PermanentAddress1 = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(3);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.PermanentAddress1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.PermanentAddress1 = tmpContent_tDBInput_6;
                }
            } else {
                row6.PermanentAddress1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row6.PermanentAddress2 = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(4);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.PermanentAddress2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.PermanentAddress2 = tmpContent_tDBInput_6;
                }
            } else {
                row6.PermanentAddress2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 5) {
								row6.PermanentCityID = null;
							} else {
		                          
            row6.PermanentCityID = rs_tDBInput_6.getInt(5);
            if(rs_tDBInput_6.wasNull()){
                    row6.PermanentCityID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 6) {
								row6.PermanentPinCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(6);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.PermanentPinCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.PermanentPinCode = tmpContent_tDBInput_6;
                }
            } else {
                row6.PermanentPinCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 7) {
								row6.TemparoryAddress1 = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(7);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.TemparoryAddress1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.TemparoryAddress1 = tmpContent_tDBInput_6;
                }
            } else {
                row6.TemparoryAddress1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 8) {
								row6.TemparoryAddress2 = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(8);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.TemparoryAddress2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.TemparoryAddress2 = tmpContent_tDBInput_6;
                }
            } else {
                row6.TemparoryAddress2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 9) {
								row6.TemparoryCityID = null;
							} else {
		                          
            row6.TemparoryCityID = rs_tDBInput_6.getInt(9);
            if(rs_tDBInput_6.wasNull()){
                    row6.TemparoryCityID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 10) {
								row6.TemparoryPinCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(10);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.TemparoryPinCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.TemparoryPinCode = tmpContent_tDBInput_6;
                }
            } else {
                row6.TemparoryPinCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 11) {
								row6.PersonalMail = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(11);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.PersonalMail = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.PersonalMail = tmpContent_tDBInput_6;
                }
            } else {
                row6.PersonalMail = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 12) {
								row6.DateofBirth = null;
							} else {
										
			row6.DateofBirth = mssqlGTU_tDBInput_6.getDate(rsmd_tDBInput_6, rs_tDBInput_6, 12);
			
		                    }
							if(colQtyInRs_tDBInput_6 < 13) {
								row6.BloodGroup = null;
							} else {
		                          
            row6.BloodGroup = rs_tDBInput_6.getInt(13);
            if(rs_tDBInput_6.wasNull()){
                    row6.BloodGroup = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 14) {
								row6.MaritalStatus = null;
							} else {
		                          
            row6.MaritalStatus = rs_tDBInput_6.getShort(14);
            if(rs_tDBInput_6.wasNull()){
                    row6.MaritalStatus = null;
            }
		                    }
					
						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");
					





 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_6","\"EmployeePersonalDetail\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		



        whetherReject_tDBOutput_6 = false;
                    pstmt_tDBOutput_6.setInt(1, row6.EmployeePersonalDetailID);

                    pstmt_tDBOutput_6.setInt(2, row6.EmployeeProfessionalDetailID);

                    if(row6.PermanentAddress1 == null) {
pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(3, row6.PermanentAddress1);
}

                    if(row6.PermanentAddress2 == null) {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(4, row6.PermanentAddress2);
}

                    if(row6.PermanentCityID == null) {
pstmt_tDBOutput_6.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(5, row6.PermanentCityID);
}

                    if(row6.PermanentPinCode == null) {
pstmt_tDBOutput_6.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(6, row6.PermanentPinCode);
}

                    if(row6.TemparoryAddress1 == null) {
pstmt_tDBOutput_6.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(7, row6.TemparoryAddress1);
}

                    if(row6.TemparoryAddress2 == null) {
pstmt_tDBOutput_6.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(8, row6.TemparoryAddress2);
}

                    if(row6.TemparoryCityID == null) {
pstmt_tDBOutput_6.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(9, row6.TemparoryCityID);
}

                    if(row6.TemparoryPinCode == null) {
pstmt_tDBOutput_6.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(10, row6.TemparoryPinCode);
}

                    if(row6.PersonalMail == null) {
pstmt_tDBOutput_6.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(11, row6.PersonalMail);
}

                    if(row6.DateofBirth != null) {
pstmt_tDBOutput_6.setTimestamp(12, new java.sql.Timestamp(row6.DateofBirth.getTime()));
} else {
pstmt_tDBOutput_6.setNull(12, java.sql.Types.TIMESTAMP);
}

                    if(row6.BloodGroup == null) {
pstmt_tDBOutput_6.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(13, row6.BloodGroup);
}

                    if(row6.MaritalStatus == null) {
pstmt_tDBOutput_6.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setShort(14, row6.MaritalStatus);
}

			
    		pstmt_tDBOutput_6.addBatch();
    		nb_line_tDBOutput_6++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Adding the record ")  + (nb_line_tDBOutput_6)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_6++;
    		  
    			if ((batchSize_tDBOutput_6 > 0) && (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {
                try {
						int countSum_tDBOutput_6 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            	    	batchSizeCounter_tDBOutput_6 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
				    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
				    	String errormessage_tDBOutput_6;
						if (ne_tDBOutput_6 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
							errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
						}else{
							errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
						}
				    	
				    	int countSum_tDBOutput_6 = 0;
						for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
				    	System.err.println(errormessage_tDBOutput_6);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
}
globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
	    		log.debug("tDBInput_6 - Retrieved records count: "+nb_line_tDBInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Done.") );

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());




/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_6 = 0;
				if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
	    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
	    	String errormessage_tDBOutput_6;
			if (ne_tDBOutput_6 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
				errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
			}else{
				errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
			}
	    	
	    	int countSum_tDBOutput_6 = 0;
			for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
				countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
			}
			rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
			
	    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
	    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
	    	System.err.println(errormessage_tDBOutput_6);
	    	
		}
	    
        if(pstmt_tDBOutput_6 != null) {
        		
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
        globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_6)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_6","\"EmployeePersonalDetail\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Done.") );

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"EmployeePersonalDetail\"";
		

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMSSqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();

    public static void main(String[] args){
        final FAMS_7_tables_17 FAMS_7_tables_17Class = new FAMS_7_tables_17();

        int exitCode = FAMS_7_tables_17Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'FAMS_7_tables_17' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try {
            	jobInfo.load(new java.io.FileInputStream(jobInfoFile));
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230315_1127-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'FAMS_7_tables_17' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","__XfE0BD5Ee6leu5mDfS5QQ");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-07-11T13:31:23.495110200Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = FAMS_7_tables_17.class.getClassLoader().getResourceAsStream("talend_tac2_repo/fams_7_tables_17_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = FAMS_7_tables_17.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'FAMS_7_tables_17' - Started.");

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}
try {
errorCode = null;tDBInput_5Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_5) {
globalMap.put("tDBInput_5_SUBPROCESS_STATE", -1);

e_tDBInput_5.printStackTrace();

}
try {
errorCode = null;tDBInput_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_6) {
globalMap.put("tDBInput_6_SUBPROCESS_STATE", -1);

e_tDBInput_6.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : FAMS_7_tables_17");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'FAMS_7_tables_17' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     428805 characters generated by Talend Data Integration 
 *     on the July 11, 2023 at 7:01:23 PM IST
 ************************************************************************************************/