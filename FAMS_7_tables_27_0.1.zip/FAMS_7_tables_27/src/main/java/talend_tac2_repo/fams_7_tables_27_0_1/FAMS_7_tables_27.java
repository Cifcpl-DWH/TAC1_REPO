
package talend_tac2_repo.fams_7_tables_27_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: FAMS_7_tables_27 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230315_1127-patch
 * @status 
 */
public class FAMS_7_tables_27 implements TalendJob {
	static {System.setProperty("TalendJob.log", "FAMS_7_tables_27.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(FAMS_7_tables_27.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "FAMS_7_tables_27";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_IR758BpTEe6YNIEe2AXj-Q", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				FAMS_7_tables_27.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(FAMS_7_tables_27.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "MSSQL_PROP");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.118.157\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"1433\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"CHAITANYA\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"FAMS_DWH\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:VPpqQVXJrT0O0tHWRgQmnc1R1mMQ5jZbY8C86+KuWJarPjNF").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "FAMS_Source", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

			    
		    String url_tDBConnection_1 = "jdbc:sqlserver://" + "115.124.118.157" ;
		String port_tDBConnection_1 = "1433";
		String dbname_tDBConnection_1 = "CHAITANYA" ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + "1433";
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    				    
		    	url_tDBConnection_1 += ";databaseName=" + "CHAITANYA"; 
    	}

		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
	String dbUser_tDBConnection_1 = "FAMS_DWH";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:f5vmBkuSBw9lXd0QyyXDCciDsJvKe9p2hj+SDc8zEu1K1uq9");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_1", "");

	globalMap.put("db_tDBConnection_1",  "CHAITANYA");
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

	globalMap.put("driver_tDBConnection_1", "MSSQL_PROP");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"FAMS_DWH_TGT\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:m22Z+ZLaagwwpJwUJVVULUiKHaMz4y+EQIeKooM2MUJYmFNd").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "FAMS_Target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "FAMS_DWH_TGT";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:wuB4BXH8ZbXpdhYUznbegQ6ze411UeroQgK1zBjQlXIgx5hk");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int StateID;

				public int getStateID () {
					return this.StateID;
				}

				public Boolean StateIDIsNullable(){
				    return false;
				}
				public Boolean StateIDIsKey(){
				    return true;
				}
				public Integer StateIDLength(){
				    return 10;
				}
				public Integer StateIDPrecision(){
				    return 0;
				}
				public String StateIDDefault(){
				
					return null;
				
				}
				public String StateIDComment(){
				
				    return "";
				
				}
				public String StateIDPattern(){
				
					return "";
				
				}
				public String StateIDOriginalDbColumnName(){
				
					return "StateID";
				
				}

				
			    public String StateName;

				public String getStateName () {
					return this.StateName;
				}

				public Boolean StateNameIsNullable(){
				    return false;
				}
				public Boolean StateNameIsKey(){
				    return false;
				}
				public Integer StateNameLength(){
				    return 150;
				}
				public Integer StateNamePrecision(){
				    return 0;
				}
				public String StateNameDefault(){
				
					return null;
				
				}
				public String StateNameComment(){
				
				    return "";
				
				}
				public String StateNamePattern(){
				
					return "";
				
				}
				public String StateNameOriginalDbColumnName(){
				
					return "StateName";
				
				}

				
			    public String StateCode;

				public String getStateCode () {
					return this.StateCode;
				}

				public Boolean StateCodeIsNullable(){
				    return false;
				}
				public Boolean StateCodeIsKey(){
				    return false;
				}
				public Integer StateCodeLength(){
				    return 50;
				}
				public Integer StateCodePrecision(){
				    return 0;
				}
				public String StateCodeDefault(){
				
					return null;
				
				}
				public String StateCodeComment(){
				
				    return "";
				
				}
				public String StateCodePattern(){
				
					return "";
				
				}
				public String StateCodeOriginalDbColumnName(){
				
					return "StateCode";
				
				}

				
			    public int CountryID;

				public int getCountryID () {
					return this.CountryID;
				}

				public Boolean CountryIDIsNullable(){
				    return false;
				}
				public Boolean CountryIDIsKey(){
				    return false;
				}
				public Integer CountryIDLength(){
				    return 10;
				}
				public Integer CountryIDPrecision(){
				    return 0;
				}
				public String CountryIDDefault(){
				
					return null;
				
				}
				public String CountryIDComment(){
				
				    return "";
				
				}
				public String CountryIDPattern(){
				
					return "";
				
				}
				public String CountryIDOriginalDbColumnName(){
				
					return "CountryID";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.StateID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.StateID != other.StateID)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.StateID = this.StateID;
	            other.StateName = this.StateName;
	            other.StateCode = this.StateCode;
	            other.CountryID = this.CountryID;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.StateID = this.StateID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.StateID = dis.readInt();
					
					this.StateName = readString(dis);
					
					this.StateCode = readString(dis);
					
			        this.CountryID = dis.readInt();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.StateID = dis.readInt();
					
					this.StateName = readString(dis);
					
					this.StateCode = readString(dis);
					
			        this.CountryID = dis.readInt();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.StateID);
					
					// String
				
						writeString(this.StateName,dos);
					
					// String
				
						writeString(this.StateCode,dos);
					
					// int
				
		            	dos.writeInt(this.CountryID);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.StateID);
					
					// String
				
						writeString(this.StateName,dos);
					
					// String
				
						writeString(this.StateCode,dos);
					
					// int
				
		            	dos.writeInt(this.CountryID);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("StateID="+String.valueOf(StateID));
		sb.append(",StateName="+StateName);
		sb.append(",StateCode="+StateCode);
		sb.append(",CountryID="+String.valueOf(CountryID));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(StateID);
        			
        			sb.append("|");
        		
        				if(StateName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(StateName);
            			}
            		
        			sb.append("|");
        		
        				if(StateCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(StateCode);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CountryID);
        			
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.StateID, other.StateID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"State\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("State");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("State");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"StateID\",\"StateName\",\"StateCode\",\"CountryID\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"State\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT MDM.State.StateID, 		MDM.State.StateName, 		MDM.State.StateCode, 		MDM.State.CountryID, 		MDM.State.CreatedBy, 		MDM.State.CreatedDate, 		MDM.State.ModifiedBy, 		MDM.State.ModifiedDate FROM	MDM.State  WHERE MDM.State.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND MDM.State.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("StateID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("StateName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("StateCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CountryID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"State\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1); 
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT MDM.State.StateID,\n		MDM.State.StateName,\n		MDM.State.StateCode,\n		MDM.State.CountryID,\n		MDM.State.CreatedBy,\n	"
+"	MDM.State.CreatedDate,\n		MDM.State.ModifiedBy,\n		MDM.State.ModifiedDate\nFROM	MDM.State\nWHERE MDM.State.CreatedDate >= "
+"DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND MDM.State.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.StateID = 0;
							} else {
		                          
            row1.StateID = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.StateName = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(2);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.StateName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.StateName = tmpContent_tDBInput_1;
                }
            } else {
                row1.StateName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.StateCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(3);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.StateCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.StateCode = tmpContent_tDBInput_1;
                }
            } else {
                row1.StateCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.CountryID = 0;
							} else {
		                          
            row1.CountryID = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.CreatedBy = 0;
							} else {
		                          
            row1.CreatedBy = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.CreatedDate = null;
							} else {
										
			row1.CreatedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 6);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.ModifiedBy = null;
							} else {
		                          
            row1.ModifiedBy = rs_tDBInput_1.getInt(7);
            if(rs_tDBInput_1.wasNull()){
                    row1.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.ModifiedDate = null;
							} else {
										
			row1.ModifiedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 8);
			
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					





 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"State\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, row1.StateID);

                    if(row1.StateName == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.StateName);
}

                    if(row1.StateCode == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.StateCode);
}

                    pstmt_tDBOutput_1.setInt(4, row1.CountryID);

                    pstmt_tDBOutput_1.setInt(5, row1.CreatedBy);

                    if(row1.CreatedDate != null) {
pstmt_tDBOutput_1.setTimestamp(6, new java.sql.Timestamp(row1.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row1.ModifiedBy == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(7, row1.ModifiedBy);
}

                    if(row1.ModifiedDate != null) {
pstmt_tDBOutput_1.setTimestamp(8, new java.sql.Timestamp(row1.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"State\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"State\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMSSqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int Id;

				public int getId () {
					return this.Id;
				}

				public Boolean IdIsNullable(){
				    return false;
				}
				public Boolean IdIsKey(){
				    return true;
				}
				public Integer IdLength(){
				    return 10;
				}
				public Integer IdPrecision(){
				    return 0;
				}
				public String IdDefault(){
				
					return null;
				
				}
				public String IdComment(){
				
				    return "";
				
				}
				public String IdPattern(){
				
					return "";
				
				}
				public String IdOriginalDbColumnName(){
				
					return "Id";
				
				}

				
			    public Integer UsExternalAssetUserID;

				public Integer getUsExternalAssetUserID () {
					return this.UsExternalAssetUserID;
				}

				public Boolean UsExternalAssetUserIDIsNullable(){
				    return true;
				}
				public Boolean UsExternalAssetUserIDIsKey(){
				    return false;
				}
				public Integer UsExternalAssetUserIDLength(){
				    return 10;
				}
				public Integer UsExternalAssetUserIDPrecision(){
				    return 0;
				}
				public String UsExternalAssetUserIDDefault(){
				
					return null;
				
				}
				public String UsExternalAssetUserIDComment(){
				
				    return "";
				
				}
				public String UsExternalAssetUserIDPattern(){
				
					return "";
				
				}
				public String UsExternalAssetUserIDOriginalDbColumnName(){
				
					return "UsExternalAssetUserID";
				
				}

				
			    public String UsUsername;

				public String getUsUsername () {
					return this.UsUsername;
				}

				public Boolean UsUsernameIsNullable(){
				    return true;
				}
				public Boolean UsUsernameIsKey(){
				    return false;
				}
				public Integer UsUsernameLength(){
				    return 500;
				}
				public Integer UsUsernamePrecision(){
				    return 0;
				}
				public String UsUsernameDefault(){
				
					return null;
				
				}
				public String UsUsernameComment(){
				
				    return "";
				
				}
				public String UsUsernamePattern(){
				
					return "";
				
				}
				public String UsUsernameOriginalDbColumnName(){
				
					return "UsUsername";
				
				}

				
			    public String UsCompanyName;

				public String getUsCompanyName () {
					return this.UsCompanyName;
				}

				public Boolean UsCompanyNameIsNullable(){
				    return true;
				}
				public Boolean UsCompanyNameIsKey(){
				    return false;
				}
				public Integer UsCompanyNameLength(){
				    return 500;
				}
				public Integer UsCompanyNamePrecision(){
				    return 0;
				}
				public String UsCompanyNameDefault(){
				
					return null;
				
				}
				public String UsCompanyNameComment(){
				
				    return "";
				
				}
				public String UsCompanyNamePattern(){
				
					return "";
				
				}
				public String UsCompanyNameOriginalDbColumnName(){
				
					return "UsCompanyName";
				
				}

				
			    public String UsDepartmentName;

				public String getUsDepartmentName () {
					return this.UsDepartmentName;
				}

				public Boolean UsDepartmentNameIsNullable(){
				    return true;
				}
				public Boolean UsDepartmentNameIsKey(){
				    return false;
				}
				public Integer UsDepartmentNameLength(){
				    return 500;
				}
				public Integer UsDepartmentNamePrecision(){
				    return 0;
				}
				public String UsDepartmentNameDefault(){
				
					return null;
				
				}
				public String UsDepartmentNameComment(){
				
				    return "";
				
				}
				public String UsDepartmentNamePattern(){
				
					return "";
				
				}
				public String UsDepartmentNameOriginalDbColumnName(){
				
					return "UsDepartmentName";
				
				}

				
			    public String UsCostCenter;

				public String getUsCostCenter () {
					return this.UsCostCenter;
				}

				public Boolean UsCostCenterIsNullable(){
				    return true;
				}
				public Boolean UsCostCenterIsKey(){
				    return false;
				}
				public Integer UsCostCenterLength(){
				    return 500;
				}
				public Integer UsCostCenterPrecision(){
				    return 0;
				}
				public String UsCostCenterDefault(){
				
					return null;
				
				}
				public String UsCostCenterComment(){
				
				    return "";
				
				}
				public String UsCostCenterPattern(){
				
					return "";
				
				}
				public String UsCostCenterOriginalDbColumnName(){
				
					return "UsCostCenter";
				
				}

				
			    public Integer AsAssetUser;

				public Integer getAsAssetUser () {
					return this.AsAssetUser;
				}

				public Boolean AsAssetUserIsNullable(){
				    return true;
				}
				public Boolean AsAssetUserIsKey(){
				    return false;
				}
				public Integer AsAssetUserLength(){
				    return 10;
				}
				public Integer AsAssetUserPrecision(){
				    return 0;
				}
				public String AsAssetUserDefault(){
				
					return null;
				
				}
				public String AsAssetUserComment(){
				
				    return "";
				
				}
				public String AsAssetUserPattern(){
				
					return "";
				
				}
				public String AsAssetUserOriginalDbColumnName(){
				
					return "AsAssetUser";
				
				}

				
			    public Integer AsAssetID;

				public Integer getAsAssetID () {
					return this.AsAssetID;
				}

				public Boolean AsAssetIDIsNullable(){
				    return true;
				}
				public Boolean AsAssetIDIsKey(){
				    return false;
				}
				public Integer AsAssetIDLength(){
				    return 10;
				}
				public Integer AsAssetIDPrecision(){
				    return 0;
				}
				public String AsAssetIDDefault(){
				
					return null;
				
				}
				public String AsAssetIDComment(){
				
				    return "";
				
				}
				public String AsAssetIDPattern(){
				
					return "";
				
				}
				public String AsAssetIDOriginalDbColumnName(){
				
					return "AsAssetID";
				
				}

				
			    public String AsUsername;

				public String getAsUsername () {
					return this.AsUsername;
				}

				public Boolean AsUsernameIsNullable(){
				    return true;
				}
				public Boolean AsUsernameIsKey(){
				    return false;
				}
				public Integer AsUsernameLength(){
				    return 500;
				}
				public Integer AsUsernamePrecision(){
				    return 0;
				}
				public String AsUsernameDefault(){
				
					return null;
				
				}
				public String AsUsernameComment(){
				
				    return "";
				
				}
				public String AsUsernamePattern(){
				
					return "";
				
				}
				public String AsUsernameOriginalDbColumnName(){
				
					return "AsUsername";
				
				}

				
			    public String AsCompanyName;

				public String getAsCompanyName () {
					return this.AsCompanyName;
				}

				public Boolean AsCompanyNameIsNullable(){
				    return true;
				}
				public Boolean AsCompanyNameIsKey(){
				    return false;
				}
				public Integer AsCompanyNameLength(){
				    return 500;
				}
				public Integer AsCompanyNamePrecision(){
				    return 0;
				}
				public String AsCompanyNameDefault(){
				
					return null;
				
				}
				public String AsCompanyNameComment(){
				
				    return "";
				
				}
				public String AsCompanyNamePattern(){
				
					return "";
				
				}
				public String AsCompanyNameOriginalDbColumnName(){
				
					return "AsCompanyName";
				
				}

				
			    public String AsDepartmentName;

				public String getAsDepartmentName () {
					return this.AsDepartmentName;
				}

				public Boolean AsDepartmentNameIsNullable(){
				    return true;
				}
				public Boolean AsDepartmentNameIsKey(){
				    return false;
				}
				public Integer AsDepartmentNameLength(){
				    return 500;
				}
				public Integer AsDepartmentNamePrecision(){
				    return 0;
				}
				public String AsDepartmentNameDefault(){
				
					return null;
				
				}
				public String AsDepartmentNameComment(){
				
				    return "";
				
				}
				public String AsDepartmentNamePattern(){
				
					return "";
				
				}
				public String AsDepartmentNameOriginalDbColumnName(){
				
					return "AsDepartmentName";
				
				}

				
			    public String AsCostCenter;

				public String getAsCostCenter () {
					return this.AsCostCenter;
				}

				public Boolean AsCostCenterIsNullable(){
				    return true;
				}
				public Boolean AsCostCenterIsKey(){
				    return false;
				}
				public Integer AsCostCenterLength(){
				    return 500;
				}
				public Integer AsCostCenterPrecision(){
				    return 0;
				}
				public String AsCostCenterDefault(){
				
					return null;
				
				}
				public String AsCostCenterComment(){
				
				    return "";
				
				}
				public String AsCostCenterPattern(){
				
					return "";
				
				}
				public String AsCostCenterOriginalDbColumnName(){
				
					return "AsCostCenter";
				
				}

				
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 200;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.Id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.Id != other.Id)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.Id = this.Id;
	            other.UsExternalAssetUserID = this.UsExternalAssetUserID;
	            other.UsUsername = this.UsUsername;
	            other.UsCompanyName = this.UsCompanyName;
	            other.UsDepartmentName = this.UsDepartmentName;
	            other.UsCostCenter = this.UsCostCenter;
	            other.AsAssetUser = this.AsAssetUser;
	            other.AsAssetID = this.AsAssetID;
	            other.AsUsername = this.AsUsername;
	            other.AsCompanyName = this.AsCompanyName;
	            other.AsDepartmentName = this.AsDepartmentName;
	            other.AsCostCenter = this.AsCostCenter;
	            other.AssetCode = this.AssetCode;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.Id = this.Id;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.Id = dis.readInt();
					
						this.UsExternalAssetUserID = readInteger(dis);
					
					this.UsUsername = readString(dis);
					
					this.UsCompanyName = readString(dis);
					
					this.UsDepartmentName = readString(dis);
					
					this.UsCostCenter = readString(dis);
					
						this.AsAssetUser = readInteger(dis);
					
						this.AsAssetID = readInteger(dis);
					
					this.AsUsername = readString(dis);
					
					this.AsCompanyName = readString(dis);
					
					this.AsDepartmentName = readString(dis);
					
					this.AsCostCenter = readString(dis);
					
					this.AssetCode = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.Id = dis.readInt();
					
						this.UsExternalAssetUserID = readInteger(dis);
					
					this.UsUsername = readString(dis);
					
					this.UsCompanyName = readString(dis);
					
					this.UsDepartmentName = readString(dis);
					
					this.UsCostCenter = readString(dis);
					
						this.AsAssetUser = readInteger(dis);
					
						this.AsAssetID = readInteger(dis);
					
					this.AsUsername = readString(dis);
					
					this.AsCompanyName = readString(dis);
					
					this.AsDepartmentName = readString(dis);
					
					this.AsCostCenter = readString(dis);
					
					this.AssetCode = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.Id);
					
					// Integer
				
						writeInteger(this.UsExternalAssetUserID,dos);
					
					// String
				
						writeString(this.UsUsername,dos);
					
					// String
				
						writeString(this.UsCompanyName,dos);
					
					// String
				
						writeString(this.UsDepartmentName,dos);
					
					// String
				
						writeString(this.UsCostCenter,dos);
					
					// Integer
				
						writeInteger(this.AsAssetUser,dos);
					
					// Integer
				
						writeInteger(this.AsAssetID,dos);
					
					// String
				
						writeString(this.AsUsername,dos);
					
					// String
				
						writeString(this.AsCompanyName,dos);
					
					// String
				
						writeString(this.AsDepartmentName,dos);
					
					// String
				
						writeString(this.AsCostCenter,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.Id);
					
					// Integer
				
						writeInteger(this.UsExternalAssetUserID,dos);
					
					// String
				
						writeString(this.UsUsername,dos);
					
					// String
				
						writeString(this.UsCompanyName,dos);
					
					// String
				
						writeString(this.UsDepartmentName,dos);
					
					// String
				
						writeString(this.UsCostCenter,dos);
					
					// Integer
				
						writeInteger(this.AsAssetUser,dos);
					
					// Integer
				
						writeInteger(this.AsAssetID,dos);
					
					// String
				
						writeString(this.AsUsername,dos);
					
					// String
				
						writeString(this.AsCompanyName,dos);
					
					// String
				
						writeString(this.AsDepartmentName,dos);
					
					// String
				
						writeString(this.AsCostCenter,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Id="+String.valueOf(Id));
		sb.append(",UsExternalAssetUserID="+String.valueOf(UsExternalAssetUserID));
		sb.append(",UsUsername="+UsUsername);
		sb.append(",UsCompanyName="+UsCompanyName);
		sb.append(",UsDepartmentName="+UsDepartmentName);
		sb.append(",UsCostCenter="+UsCostCenter);
		sb.append(",AsAssetUser="+String.valueOf(AsAssetUser));
		sb.append(",AsAssetID="+String.valueOf(AsAssetID));
		sb.append(",AsUsername="+AsUsername);
		sb.append(",AsCompanyName="+AsCompanyName);
		sb.append(",AsDepartmentName="+AsDepartmentName);
		sb.append(",AsCostCenter="+AsCostCenter);
		sb.append(",AssetCode="+AssetCode);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(Id);
        			
        			sb.append("|");
        		
        				if(UsExternalAssetUserID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UsExternalAssetUserID);
            			}
            		
        			sb.append("|");
        		
        				if(UsUsername == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UsUsername);
            			}
            		
        			sb.append("|");
        		
        				if(UsCompanyName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UsCompanyName);
            			}
            		
        			sb.append("|");
        		
        				if(UsDepartmentName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UsDepartmentName);
            			}
            		
        			sb.append("|");
        		
        				if(UsCostCenter == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UsCostCenter);
            			}
            		
        			sb.append("|");
        		
        				if(AsAssetUser == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsAssetUser);
            			}
            		
        			sb.append("|");
        		
        				if(AsAssetID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsAssetID);
            			}
            		
        			sb.append("|");
        		
        				if(AsUsername == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsUsername);
            			}
            		
        			sb.append("|");
        		
        				if(AsCompanyName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsCompanyName);
            			}
            		
        			sb.append("|");
        		
        				if(AsDepartmentName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsDepartmentName);
            			}
            		
        			sb.append("|");
        		
        				if(AsCostCenter == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AsCostCenter);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.Id, other.Id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"TblAssetUserAnalysis\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("TblAssetUserAnalysis");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("TblAssetUserAnalysis");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
            int rsTruncCountNumber_tDBOutput_2 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_2 = stmtTruncCount_tDBOutput_2.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_2 + "\"")) {
                    if(rsTruncCount_tDBOutput_2.next()) {
                        rsTruncCountNumber_tDBOutput_2 = rsTruncCount_tDBOutput_2.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_2.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_2 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_2 += rsTruncCountNumber_tDBOutput_2;
            }
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"Id\",\"UsExternalAssetUserID\",\"UsUsername\",\"UsCompanyName\",\"UsDepartmentName\",\"UsCostCenter\",\"AsAssetUser\",\"AsAssetID\",\"AsUsername\",\"AsCompanyName\",\"AsDepartmentName\",\"AsCostCenter\",\"AssetCode\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"TblAssetUserAnalysis\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT dbo.TblAssetUserAnalysis.\\\"Id\\\", 		dbo.TblAssetUserAnalysis.UsExternalAssetUserID, 		dbo.TblAssetUserAnalysis.UsUsername, 		dbo.TblAssetUserAnalysis.UsCompanyName, 		dbo.TblAssetUserAnalysis.UsDepartmentName, 		dbo.TblAssetUserAnalysis.UsCostCenter, 		dbo.TblAssetUserAnalysis.AsAssetUser, 		dbo.TblAssetUserAnalysis.AsAssetID, 		dbo.TblAssetUserAnalysis.AsUsername, 		dbo.TblAssetUserAnalysis.AsCompanyName, 		dbo.TblAssetUserAnalysis.AsDepartmentName, 		dbo.TblAssetUserAnalysis.AsCostCenter, 		dbo.TblAssetUserAnalysis.AssetCode FROM	dbo.TblAssetUserAnalysis\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("Id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UsExternalAssetUserID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UsUsername")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UsCompanyName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UsDepartmentName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UsCostCenter")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsAssetUser")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsAssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsUsername")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsCompanyName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsDepartmentName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AsCostCenter")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"TblAssetUserAnalysis\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2); 
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT dbo.TblAssetUserAnalysis.\"Id\",\n		dbo.TblAssetUserAnalysis.UsExternalAssetUserID,\n		dbo.TblAssetUserAnalysis.Us"
+"Username,\n		dbo.TblAssetUserAnalysis.UsCompanyName,\n		dbo.TblAssetUserAnalysis.UsDepartmentName,\n		dbo.TblAssetUserAnaly"
+"sis.UsCostCenter,\n		dbo.TblAssetUserAnalysis.AsAssetUser,\n		dbo.TblAssetUserAnalysis.AsAssetID,\n		dbo.TblAssetUserAnalys"
+"is.AsUsername,\n		dbo.TblAssetUserAnalysis.AsCompanyName,\n		dbo.TblAssetUserAnalysis.AsDepartmentName,\n		dbo.TblAssetUser"
+"Analysis.AsCostCenter,\n		dbo.TblAssetUserAnalysis.AssetCode\nFROM	dbo.TblAssetUserAnalysis";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.Id = 0;
							} else {
		                          
            row2.Id = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.UsExternalAssetUserID = null;
							} else {
		                          
            row2.UsExternalAssetUserID = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    row2.UsExternalAssetUserID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.UsUsername = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(3);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.UsUsername = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.UsUsername = tmpContent_tDBInput_2;
                }
            } else {
                row2.UsUsername = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.UsCompanyName = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(4);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.UsCompanyName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.UsCompanyName = tmpContent_tDBInput_2;
                }
            } else {
                row2.UsCompanyName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.UsDepartmentName = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(5);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.UsDepartmentName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.UsDepartmentName = tmpContent_tDBInput_2;
                }
            } else {
                row2.UsDepartmentName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.UsCostCenter = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(6);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.UsCostCenter = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.UsCostCenter = tmpContent_tDBInput_2;
                }
            } else {
                row2.UsCostCenter = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.AsAssetUser = null;
							} else {
		                          
            row2.AsAssetUser = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    row2.AsAssetUser = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.AsAssetID = null;
							} else {
		                          
            row2.AsAssetID = rs_tDBInput_2.getInt(8);
            if(rs_tDBInput_2.wasNull()){
                    row2.AsAssetID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.AsUsername = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(9);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.AsUsername = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.AsUsername = tmpContent_tDBInput_2;
                }
            } else {
                row2.AsUsername = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.AsCompanyName = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(10);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.AsCompanyName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.AsCompanyName = tmpContent_tDBInput_2;
                }
            } else {
                row2.AsCompanyName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row2.AsDepartmentName = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(11);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.AsDepartmentName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.AsDepartmentName = tmpContent_tDBInput_2;
                }
            } else {
                row2.AsDepartmentName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row2.AsCostCenter = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(12);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.AsCostCenter = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.AsCostCenter = tmpContent_tDBInput_2;
                }
            } else {
                row2.AsCostCenter = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row2.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(13);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.AssetCode = tmpContent_tDBInput_2;
                }
            } else {
                row2.AssetCode = null;
            }
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					





 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"TblAssetUserAnalysis\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, row2.Id);

                    if(row2.UsExternalAssetUserID == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(2, row2.UsExternalAssetUserID);
}

                    if(row2.UsUsername == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, row2.UsUsername);
}

                    if(row2.UsCompanyName == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, row2.UsCompanyName);
}

                    if(row2.UsDepartmentName == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, row2.UsDepartmentName);
}

                    if(row2.UsCostCenter == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, row2.UsCostCenter);
}

                    if(row2.AsAssetUser == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, row2.AsAssetUser);
}

                    if(row2.AsAssetID == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, row2.AsAssetID);
}

                    if(row2.AsUsername == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, row2.AsUsername);
}

                    if(row2.AsCompanyName == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(10, row2.AsCompanyName);
}

                    if(row2.AsDepartmentName == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, row2.AsDepartmentName);
}

                    if(row2.AsCostCenter == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, row2.AsCostCenter);
}

                    if(row2.AssetCode == null) {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(13, row2.AssetCode);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_2)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"TblAssetUserAnalysis\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"TblAssetUserAnalysis\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];

	
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 200;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				
			    public String DepartmentName;

				public String getDepartmentName () {
					return this.DepartmentName;
				}

				public Boolean DepartmentNameIsNullable(){
				    return true;
				}
				public Boolean DepartmentNameIsKey(){
				    return false;
				}
				public Integer DepartmentNameLength(){
				    return 200;
				}
				public Integer DepartmentNamePrecision(){
				    return 0;
				}
				public String DepartmentNameDefault(){
				
					return null;
				
				}
				public String DepartmentNameComment(){
				
				    return "";
				
				}
				public String DepartmentNamePattern(){
				
					return "";
				
				}
				public String DepartmentNameOriginalDbColumnName(){
				
					return "DepartmentName";
				
				}

				
			    public String CostCenter;

				public String getCostCenter () {
					return this.CostCenter;
				}

				public Boolean CostCenterIsNullable(){
				    return true;
				}
				public Boolean CostCenterIsKey(){
				    return false;
				}
				public Integer CostCenterLength(){
				    return 200;
				}
				public Integer CostCenterPrecision(){
				    return 0;
				}
				public String CostCenterDefault(){
				
					return null;
				
				}
				public String CostCenterComment(){
				
				    return "";
				
				}
				public String CostCenterPattern(){
				
					return "";
				
				}
				public String CostCenterOriginalDbColumnName(){
				
					return "CostCenter";
				
				}

				
			    public Integer AssetID;

				public Integer getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return true;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public String CompanyName;

				public String getCompanyName () {
					return this.CompanyName;
				}

				public Boolean CompanyNameIsNullable(){
				    return true;
				}
				public Boolean CompanyNameIsKey(){
				    return false;
				}
				public Integer CompanyNameLength(){
				    return 200;
				}
				public Integer CompanyNamePrecision(){
				    return 0;
				}
				public String CompanyNameDefault(){
				
					return null;
				
				}
				public String CompanyNameComment(){
				
				    return "";
				
				}
				public String CompanyNamePattern(){
				
					return "";
				
				}
				public String CompanyNameOriginalDbColumnName(){
				
					return "CompanyName";
				
				}

				
			    public String AssetCategoryID1Desc;

				public String getAssetCategoryID1Desc () {
					return this.AssetCategoryID1Desc;
				}

				public Boolean AssetCategoryID1DescIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryID1DescIsKey(){
				    return false;
				}
				public Integer AssetCategoryID1DescLength(){
				    return 200;
				}
				public Integer AssetCategoryID1DescPrecision(){
				    return 0;
				}
				public String AssetCategoryID1DescDefault(){
				
					return null;
				
				}
				public String AssetCategoryID1DescComment(){
				
				    return "";
				
				}
				public String AssetCategoryID1DescPattern(){
				
					return "";
				
				}
				public String AssetCategoryID1DescOriginalDbColumnName(){
				
					return "AssetCategoryID1Desc";
				
				}

				
			    public String AssetCategoryID2Desc;

				public String getAssetCategoryID2Desc () {
					return this.AssetCategoryID2Desc;
				}

				public Boolean AssetCategoryID2DescIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryID2DescIsKey(){
				    return false;
				}
				public Integer AssetCategoryID2DescLength(){
				    return 200;
				}
				public Integer AssetCategoryID2DescPrecision(){
				    return 0;
				}
				public String AssetCategoryID2DescDefault(){
				
					return null;
				
				}
				public String AssetCategoryID2DescComment(){
				
				    return "";
				
				}
				public String AssetCategoryID2DescPattern(){
				
					return "";
				
				}
				public String AssetCategoryID2DescOriginalDbColumnName(){
				
					return "AssetCategoryID2Desc";
				
				}

				
			    public String AssetCategoryID3Desc;

				public String getAssetCategoryID3Desc () {
					return this.AssetCategoryID3Desc;
				}

				public Boolean AssetCategoryID3DescIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryID3DescIsKey(){
				    return false;
				}
				public Integer AssetCategoryID3DescLength(){
				    return 200;
				}
				public Integer AssetCategoryID3DescPrecision(){
				    return 0;
				}
				public String AssetCategoryID3DescDefault(){
				
					return null;
				
				}
				public String AssetCategoryID3DescComment(){
				
				    return "";
				
				}
				public String AssetCategoryID3DescPattern(){
				
					return "";
				
				}
				public String AssetCategoryID3DescOriginalDbColumnName(){
				
					return "AssetCategoryID3Desc";
				
				}

				
			    public String AssetCategoryID4Desc;

				public String getAssetCategoryID4Desc () {
					return this.AssetCategoryID4Desc;
				}

				public Boolean AssetCategoryID4DescIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryID4DescIsKey(){
				    return false;
				}
				public Integer AssetCategoryID4DescLength(){
				    return 200;
				}
				public Integer AssetCategoryID4DescPrecision(){
				    return 0;
				}
				public String AssetCategoryID4DescDefault(){
				
					return null;
				
				}
				public String AssetCategoryID4DescComment(){
				
				    return "";
				
				}
				public String AssetCategoryID4DescPattern(){
				
					return "";
				
				}
				public String AssetCategoryID4DescOriginalDbColumnName(){
				
					return "AssetCategoryID4Desc";
				
				}

				
			    public Integer AssetCategoryID;

				public Integer getAssetCategoryID () {
					return this.AssetCategoryID;
				}

				public Boolean AssetCategoryIDIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryIDIsKey(){
				    return false;
				}
				public Integer AssetCategoryIDLength(){
				    return 10;
				}
				public Integer AssetCategoryIDPrecision(){
				    return 0;
				}
				public String AssetCategoryIDDefault(){
				
					return null;
				
				}
				public String AssetCategoryIDComment(){
				
				    return "";
				
				}
				public String AssetCategoryIDPattern(){
				
					return "";
				
				}
				public String AssetCategoryIDOriginalDbColumnName(){
				
					return "AssetCategoryID";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
					this.AssetCode = readString(dis);
					
					this.DepartmentName = readString(dis);
					
					this.CostCenter = readString(dis);
					
						this.AssetID = readInteger(dis);
					
					this.CompanyName = readString(dis);
					
					this.AssetCategoryID1Desc = readString(dis);
					
					this.AssetCategoryID2Desc = readString(dis);
					
					this.AssetCategoryID3Desc = readString(dis);
					
					this.AssetCategoryID4Desc = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
					this.AssetCode = readString(dis);
					
					this.DepartmentName = readString(dis);
					
					this.CostCenter = readString(dis);
					
						this.AssetID = readInteger(dis);
					
					this.CompanyName = readString(dis);
					
					this.AssetCategoryID1Desc = readString(dis);
					
					this.AssetCategoryID2Desc = readString(dis);
					
					this.AssetCategoryID3Desc = readString(dis);
					
					this.AssetCategoryID4Desc = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.DepartmentName,dos);
					
					// String
				
						writeString(this.CostCenter,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// String
				
						writeString(this.CompanyName,dos);
					
					// String
				
						writeString(this.AssetCategoryID1Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID2Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID3Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID4Desc,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.DepartmentName,dos);
					
					// String
				
						writeString(this.CostCenter,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// String
				
						writeString(this.CompanyName,dos);
					
					// String
				
						writeString(this.AssetCategoryID1Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID2Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID3Desc,dos);
					
					// String
				
						writeString(this.AssetCategoryID4Desc,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetCode="+AssetCode);
		sb.append(",DepartmentName="+DepartmentName);
		sb.append(",CostCenter="+CostCenter);
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",CompanyName="+CompanyName);
		sb.append(",AssetCategoryID1Desc="+AssetCategoryID1Desc);
		sb.append(",AssetCategoryID2Desc="+AssetCategoryID2Desc);
		sb.append(",AssetCategoryID3Desc="+AssetCategoryID3Desc);
		sb.append(",AssetCategoryID4Desc="+AssetCategoryID4Desc);
		sb.append(",AssetCategoryID="+String.valueOf(AssetCategoryID));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(DepartmentName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepartmentName);
            			}
            		
        			sb.append("|");
        		
        				if(CostCenter == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CostCenter);
            			}
            		
        			sb.append("|");
        		
        				if(AssetID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetID);
            			}
            		
        			sb.append("|");
        		
        				if(CompanyName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CompanyName);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID1Desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID1Desc);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID2Desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID2Desc);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID3Desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID3Desc);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID4Desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID4Desc);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"TblCostCatAnalysis\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("TblCostCatAnalysis");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("TblCostCatAnalysis");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
            int rsTruncCountNumber_tDBOutput_3 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_3 = stmtTruncCount_tDBOutput_3.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_3 + "\"")) {
                    if(rsTruncCount_tDBOutput_3.next()) {
                        rsTruncCountNumber_tDBOutput_3 = rsTruncCount_tDBOutput_3.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_3+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_3.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_3 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_3+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_3 += rsTruncCountNumber_tDBOutput_3;
            }
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"AssetCode\",\"DepartmentName\",\"CostCenter\",\"AssetID\",\"CompanyName\",\"AssetCategoryID1Desc\",\"AssetCategoryID2Desc\",\"AssetCategoryID3Desc\",\"AssetCategoryID4Desc\",\"AssetCategoryID\") VALUES (?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"TblCostCatAnalysis\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT dbo.TblCostCatAnalysis.AssetCode, 		dbo.TblCostCatAnalysis.DepartmentName, 		dbo.TblCostCatAnalysis.CostCenter, 		dbo.TblCostCatAnalysis.AssetID, 		dbo.TblCostCatAnalysis.CompanyName, 		dbo.TblCostCatAnalysis.AssetCategoryID1Desc, 		dbo.TblCostCatAnalysis.AssetCategoryID2Desc, 		dbo.TblCostCatAnalysis.AssetCategoryID3Desc, 		dbo.TblCostCatAnalysis.AssetCategoryID4Desc, 		dbo.TblCostCatAnalysis.AssetCategoryID FROM	dbo.TblCostCatAnalysis\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepartmentName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostCenter")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID1Desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID2Desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID3Desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID4Desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"TblCostCatAnalysis\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3); 
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT dbo.TblCostCatAnalysis.AssetCode,\n		dbo.TblCostCatAnalysis.DepartmentName,\n		dbo.TblCostCatAnalysis.CostCenter,\n"
+"		dbo.TblCostCatAnalysis.AssetID,\n		dbo.TblCostCatAnalysis.CompanyName,\n		dbo.TblCostCatAnalysis.AssetCategoryID1Desc,\n	"
+"	dbo.TblCostCatAnalysis.AssetCategoryID2Desc,\n		dbo.TblCostCatAnalysis.AssetCategoryID3Desc,\n		dbo.TblCostCatAnalysis.As"
+"setCategoryID4Desc,\n		dbo.TblCostCatAnalysis.AssetCategoryID\nFROM	dbo.TblCostCatAnalysis";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(1);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.AssetCode = tmpContent_tDBInput_3;
                }
            } else {
                row3.AssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.DepartmentName = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(2);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.DepartmentName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.DepartmentName = tmpContent_tDBInput_3;
                }
            } else {
                row3.DepartmentName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.CostCenter = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(3);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.CostCenter = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.CostCenter = tmpContent_tDBInput_3;
                }
            } else {
                row3.CostCenter = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.AssetID = null;
							} else {
		                          
            row3.AssetID = rs_tDBInput_3.getInt(4);
            if(rs_tDBInput_3.wasNull()){
                    row3.AssetID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.CompanyName = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(5);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.CompanyName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.CompanyName = tmpContent_tDBInput_3;
                }
            } else {
                row3.CompanyName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.AssetCategoryID1Desc = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(6);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.AssetCategoryID1Desc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.AssetCategoryID1Desc = tmpContent_tDBInput_3;
                }
            } else {
                row3.AssetCategoryID1Desc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.AssetCategoryID2Desc = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(7);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.AssetCategoryID2Desc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.AssetCategoryID2Desc = tmpContent_tDBInput_3;
                }
            } else {
                row3.AssetCategoryID2Desc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.AssetCategoryID3Desc = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(8);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.AssetCategoryID3Desc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.AssetCategoryID3Desc = tmpContent_tDBInput_3;
                }
            } else {
                row3.AssetCategoryID3Desc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.AssetCategoryID4Desc = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(9);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.AssetCategoryID4Desc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.AssetCategoryID4Desc = tmpContent_tDBInput_3;
                }
            } else {
                row3.AssetCategoryID4Desc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.AssetCategoryID = null;
							} else {
		                          
            row3.AssetCategoryID = rs_tDBInput_3.getInt(10);
            if(rs_tDBInput_3.wasNull()){
                    row3.AssetCategoryID = null;
            }
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					





 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"TblCostCatAnalysis\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    if(row3.AssetCode == null) {
pstmt_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(1, row3.AssetCode);
}

                    if(row3.DepartmentName == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row3.DepartmentName);
}

                    if(row3.CostCenter == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row3.CostCenter);
}

                    if(row3.AssetID == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(4, row3.AssetID);
}

                    if(row3.CompanyName == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row3.CompanyName);
}

                    if(row3.AssetCategoryID1Desc == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, row3.AssetCategoryID1Desc);
}

                    if(row3.AssetCategoryID2Desc == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, row3.AssetCategoryID2Desc);
}

                    if(row3.AssetCategoryID3Desc == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, row3.AssetCategoryID3Desc);
}

                    if(row3.AssetCategoryID4Desc == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9, row3.AssetCategoryID4Desc);
}

                    if(row3.AssetCategoryID == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(10, row3.AssetCategoryID);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_3)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"TblCostCatAnalysis\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"TblCostCatAnalysis\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];

	
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 200;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				
			    public Integer AssetID;

				public Integer getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return true;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public String AssetCategorylevel1;

				public String getAssetCategorylevel1 () {
					return this.AssetCategorylevel1;
				}

				public Boolean AssetCategorylevel1IsNullable(){
				    return true;
				}
				public Boolean AssetCategorylevel1IsKey(){
				    return false;
				}
				public Integer AssetCategorylevel1Length(){
				    return 200;
				}
				public Integer AssetCategorylevel1Precision(){
				    return 0;
				}
				public String AssetCategorylevel1Default(){
				
					return null;
				
				}
				public String AssetCategorylevel1Comment(){
				
				    return "";
				
				}
				public String AssetCategorylevel1Pattern(){
				
					return "";
				
				}
				public String AssetCategorylevel1OriginalDbColumnName(){
				
					return "AssetCategorylevel1";
				
				}

				
			    public String AssetCategorylevel2;

				public String getAssetCategorylevel2 () {
					return this.AssetCategorylevel2;
				}

				public Boolean AssetCategorylevel2IsNullable(){
				    return true;
				}
				public Boolean AssetCategorylevel2IsKey(){
				    return false;
				}
				public Integer AssetCategorylevel2Length(){
				    return 200;
				}
				public Integer AssetCategorylevel2Precision(){
				    return 0;
				}
				public String AssetCategorylevel2Default(){
				
					return null;
				
				}
				public String AssetCategorylevel2Comment(){
				
				    return "";
				
				}
				public String AssetCategorylevel2Pattern(){
				
					return "";
				
				}
				public String AssetCategorylevel2OriginalDbColumnName(){
				
					return "AssetCategorylevel2";
				
				}

				
			    public String AssetCategorylevel3;

				public String getAssetCategorylevel3 () {
					return this.AssetCategorylevel3;
				}

				public Boolean AssetCategorylevel3IsNullable(){
				    return true;
				}
				public Boolean AssetCategorylevel3IsKey(){
				    return false;
				}
				public Integer AssetCategorylevel3Length(){
				    return 200;
				}
				public Integer AssetCategorylevel3Precision(){
				    return 0;
				}
				public String AssetCategorylevel3Default(){
				
					return null;
				
				}
				public String AssetCategorylevel3Comment(){
				
				    return "";
				
				}
				public String AssetCategorylevel3Pattern(){
				
					return "";
				
				}
				public String AssetCategorylevel3OriginalDbColumnName(){
				
					return "AssetCategorylevel3";
				
				}

				
			    public String AssetCategorylevel4;

				public String getAssetCategorylevel4 () {
					return this.AssetCategorylevel4;
				}

				public Boolean AssetCategorylevel4IsNullable(){
				    return true;
				}
				public Boolean AssetCategorylevel4IsKey(){
				    return false;
				}
				public Integer AssetCategorylevel4Length(){
				    return 200;
				}
				public Integer AssetCategorylevel4Precision(){
				    return 0;
				}
				public String AssetCategorylevel4Default(){
				
					return null;
				
				}
				public String AssetCategorylevel4Comment(){
				
				    return "";
				
				}
				public String AssetCategorylevel4Pattern(){
				
					return "";
				
				}
				public String AssetCategorylevel4OriginalDbColumnName(){
				
					return "AssetCategorylevel4";
				
				}

				
			    public Integer AssetCategoryID;

				public Integer getAssetCategoryID () {
					return this.AssetCategoryID;
				}

				public Boolean AssetCategoryIDIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryIDIsKey(){
				    return false;
				}
				public Integer AssetCategoryIDLength(){
				    return 10;
				}
				public Integer AssetCategoryIDPrecision(){
				    return 0;
				}
				public String AssetCategoryIDDefault(){
				
					return null;
				
				}
				public String AssetCategoryIDComment(){
				
				    return "";
				
				}
				public String AssetCategoryIDPattern(){
				
					return "";
				
				}
				public String AssetCategoryIDOriginalDbColumnName(){
				
					return "AssetCategoryID";
				
				}

				
			    public java.util.Date FromDate;

				public java.util.Date getFromDate () {
					return this.FromDate;
				}

				public Boolean FromDateIsNullable(){
				    return true;
				}
				public Boolean FromDateIsKey(){
				    return false;
				}
				public Integer FromDateLength(){
				    return 10;
				}
				public Integer FromDatePrecision(){
				    return 0;
				}
				public String FromDateDefault(){
				
					return null;
				
				}
				public String FromDateComment(){
				
				    return "";
				
				}
				public String FromDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String FromDateOriginalDbColumnName(){
				
					return "FromDate";
				
				}

				
			    public java.util.Date ToDate;

				public java.util.Date getToDate () {
					return this.ToDate;
				}

				public Boolean ToDateIsNullable(){
				    return true;
				}
				public Boolean ToDateIsKey(){
				    return false;
				}
				public Integer ToDateLength(){
				    return 10;
				}
				public Integer ToDatePrecision(){
				    return 0;
				}
				public String ToDateDefault(){
				
					return null;
				
				}
				public String ToDateComment(){
				
				    return "";
				
				}
				public String ToDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ToDateOriginalDbColumnName(){
				
					return "ToDate";
				
				}

				
			    public java.util.Date PurchaseDate;

				public java.util.Date getPurchaseDate () {
					return this.PurchaseDate;
				}

				public Boolean PurchaseDateIsNullable(){
				    return true;
				}
				public Boolean PurchaseDateIsKey(){
				    return false;
				}
				public Integer PurchaseDateLength(){
				    return 10;
				}
				public Integer PurchaseDatePrecision(){
				    return 0;
				}
				public String PurchaseDateDefault(){
				
					return null;
				
				}
				public String PurchaseDateComment(){
				
				    return "";
				
				}
				public String PurchaseDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PurchaseDateOriginalDbColumnName(){
				
					return "PurchaseDate";
				
				}

				
			    public String AssetDesc;

				public String getAssetDesc () {
					return this.AssetDesc;
				}

				public Boolean AssetDescIsNullable(){
				    return true;
				}
				public Boolean AssetDescIsKey(){
				    return false;
				}
				public Integer AssetDescLength(){
				    return 200;
				}
				public Integer AssetDescPrecision(){
				    return 0;
				}
				public String AssetDescDefault(){
				
					return null;
				
				}
				public String AssetDescComment(){
				
				    return "";
				
				}
				public String AssetDescPattern(){
				
					return "";
				
				}
				public String AssetDescOriginalDbColumnName(){
				
					return "AssetDesc";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 200;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public String MachineTagNo;

				public String getMachineTagNo () {
					return this.MachineTagNo;
				}

				public Boolean MachineTagNoIsNullable(){
				    return true;
				}
				public Boolean MachineTagNoIsKey(){
				    return false;
				}
				public Integer MachineTagNoLength(){
				    return 200;
				}
				public Integer MachineTagNoPrecision(){
				    return 0;
				}
				public String MachineTagNoDefault(){
				
					return null;
				
				}
				public String MachineTagNoComment(){
				
				    return "";
				
				}
				public String MachineTagNoPattern(){
				
					return "";
				
				}
				public String MachineTagNoOriginalDbColumnName(){
				
					return "MachineTagNo";
				
				}

				
			    public Integer Qty;

				public Integer getQty () {
					return this.Qty;
				}

				public Boolean QtyIsNullable(){
				    return true;
				}
				public Boolean QtyIsKey(){
				    return false;
				}
				public Integer QtyLength(){
				    return 10;
				}
				public Integer QtyPrecision(){
				    return 0;
				}
				public String QtyDefault(){
				
					return null;
				
				}
				public String QtyComment(){
				
				    return "";
				
				}
				public String QtyPattern(){
				
					return "";
				
				}
				public String QtyOriginalDbColumnName(){
				
					return "Qty";
				
				}

				
			    public String EmailID;

				public String getEmailID () {
					return this.EmailID;
				}

				public Boolean EmailIDIsNullable(){
				    return true;
				}
				public Boolean EmailIDIsKey(){
				    return false;
				}
				public Integer EmailIDLength(){
				    return 200;
				}
				public Integer EmailIDPrecision(){
				    return 0;
				}
				public String EmailIDDefault(){
				
					return null;
				
				}
				public String EmailIDComment(){
				
				    return "";
				
				}
				public String EmailIDPattern(){
				
					return "";
				
				}
				public String EmailIDOriginalDbColumnName(){
				
					return "EmailID";
				
				}

				
			    public String PhysicalID;

				public String getPhysicalID () {
					return this.PhysicalID;
				}

				public Boolean PhysicalIDIsNullable(){
				    return true;
				}
				public Boolean PhysicalIDIsKey(){
				    return false;
				}
				public Integer PhysicalIDLength(){
				    return 200;
				}
				public Integer PhysicalIDPrecision(){
				    return 0;
				}
				public String PhysicalIDDefault(){
				
					return null;
				
				}
				public String PhysicalIDComment(){
				
				    return "";
				
				}
				public String PhysicalIDPattern(){
				
					return "";
				
				}
				public String PhysicalIDOriginalDbColumnName(){
				
					return "PhysicalID";
				
				}

				
			    public String InvoiceRefNo;

				public String getInvoiceRefNo () {
					return this.InvoiceRefNo;
				}

				public Boolean InvoiceRefNoIsNullable(){
				    return true;
				}
				public Boolean InvoiceRefNoIsKey(){
				    return false;
				}
				public Integer InvoiceRefNoLength(){
				    return 200;
				}
				public Integer InvoiceRefNoPrecision(){
				    return 0;
				}
				public String InvoiceRefNoDefault(){
				
					return null;
				
				}
				public String InvoiceRefNoComment(){
				
				    return "";
				
				}
				public String InvoiceRefNoPattern(){
				
					return "";
				
				}
				public String InvoiceRefNoOriginalDbColumnName(){
				
					return "InvoiceRefNo";
				
				}

				
			    public String VendorName;

				public String getVendorName () {
					return this.VendorName;
				}

				public Boolean VendorNameIsNullable(){
				    return true;
				}
				public Boolean VendorNameIsKey(){
				    return false;
				}
				public Integer VendorNameLength(){
				    return 200;
				}
				public Integer VendorNamePrecision(){
				    return 0;
				}
				public String VendorNameDefault(){
				
					return null;
				
				}
				public String VendorNameComment(){
				
				    return "";
				
				}
				public String VendorNamePattern(){
				
					return "";
				
				}
				public String VendorNameOriginalDbColumnName(){
				
					return "VendorName";
				
				}

				
			    public java.util.Date DatePutToUse;

				public java.util.Date getDatePutToUse () {
					return this.DatePutToUse;
				}

				public Boolean DatePutToUseIsNullable(){
				    return true;
				}
				public Boolean DatePutToUseIsKey(){
				    return false;
				}
				public Integer DatePutToUseLength(){
				    return 10;
				}
				public Integer DatePutToUsePrecision(){
				    return 0;
				}
				public String DatePutToUseDefault(){
				
					return null;
				
				}
				public String DatePutToUseComment(){
				
				    return "";
				
				}
				public String DatePutToUsePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DatePutToUseOriginalDbColumnName(){
				
					return "DatePutToUse";
				
				}

				
			    public String Amount;

				public String getAmount () {
					return this.Amount;
				}

				public Boolean AmountIsNullable(){
				    return true;
				}
				public Boolean AmountIsKey(){
				    return false;
				}
				public Integer AmountLength(){
				    return 200;
				}
				public Integer AmountPrecision(){
				    return 0;
				}
				public String AmountDefault(){
				
					return null;
				
				}
				public String AmountComment(){
				
				    return "";
				
				}
				public String AmountPattern(){
				
					return "";
				
				}
				public String AmountOriginalDbColumnName(){
				
					return "Amount";
				
				}

				
			    public String AMCNumber;

				public String getAMCNumber () {
					return this.AMCNumber;
				}

				public Boolean AMCNumberIsNullable(){
				    return true;
				}
				public Boolean AMCNumberIsKey(){
				    return false;
				}
				public Integer AMCNumberLength(){
				    return 200;
				}
				public Integer AMCNumberPrecision(){
				    return 0;
				}
				public String AMCNumberDefault(){
				
					return null;
				
				}
				public String AMCNumberComment(){
				
				    return "";
				
				}
				public String AMCNumberPattern(){
				
					return "";
				
				}
				public String AMCNumberOriginalDbColumnName(){
				
					return "AMCNumber";
				
				}

				
			    public String BranchCode;

				public String getBranchCode () {
					return this.BranchCode;
				}

				public Boolean BranchCodeIsNullable(){
				    return true;
				}
				public Boolean BranchCodeIsKey(){
				    return false;
				}
				public Integer BranchCodeLength(){
				    return 200;
				}
				public Integer BranchCodePrecision(){
				    return 0;
				}
				public String BranchCodeDefault(){
				
					return null;
				
				}
				public String BranchCodeComment(){
				
				    return "";
				
				}
				public String BranchCodePattern(){
				
					return "";
				
				}
				public String BranchCodeOriginalDbColumnName(){
				
					return "BranchCode";
				
				}

				
			    public String BranchName;

				public String getBranchName () {
					return this.BranchName;
				}

				public Boolean BranchNameIsNullable(){
				    return true;
				}
				public Boolean BranchNameIsKey(){
				    return false;
				}
				public Integer BranchNameLength(){
				    return 200;
				}
				public Integer BranchNamePrecision(){
				    return 0;
				}
				public String BranchNameDefault(){
				
					return null;
				
				}
				public String BranchNameComment(){
				
				    return "";
				
				}
				public String BranchNamePattern(){
				
					return "";
				
				}
				public String BranchNameOriginalDbColumnName(){
				
					return "BranchName";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
					this.AssetCode = readString(dis);
					
						this.AssetID = readInteger(dis);
					
					this.AssetCategorylevel1 = readString(dis);
					
					this.AssetCategorylevel2 = readString(dis);
					
					this.AssetCategorylevel3 = readString(dis);
					
					this.AssetCategorylevel4 = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
					this.FromDate = readDate(dis);
					
					this.ToDate = readDate(dis);
					
					this.PurchaseDate = readDate(dis);
					
					this.AssetDesc = readString(dis);
					
					this.Remarks = readString(dis);
					
					this.MachineTagNo = readString(dis);
					
						this.Qty = readInteger(dis);
					
					this.EmailID = readString(dis);
					
					this.PhysicalID = readString(dis);
					
					this.InvoiceRefNo = readString(dis);
					
					this.VendorName = readString(dis);
					
					this.DatePutToUse = readDate(dis);
					
					this.Amount = readString(dis);
					
					this.AMCNumber = readString(dis);
					
					this.BranchCode = readString(dis);
					
					this.BranchName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
					this.AssetCode = readString(dis);
					
						this.AssetID = readInteger(dis);
					
					this.AssetCategorylevel1 = readString(dis);
					
					this.AssetCategorylevel2 = readString(dis);
					
					this.AssetCategorylevel3 = readString(dis);
					
					this.AssetCategorylevel4 = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
					this.FromDate = readDate(dis);
					
					this.ToDate = readDate(dis);
					
					this.PurchaseDate = readDate(dis);
					
					this.AssetDesc = readString(dis);
					
					this.Remarks = readString(dis);
					
					this.MachineTagNo = readString(dis);
					
						this.Qty = readInteger(dis);
					
					this.EmailID = readString(dis);
					
					this.PhysicalID = readString(dis);
					
					this.InvoiceRefNo = readString(dis);
					
					this.VendorName = readString(dis);
					
					this.DatePutToUse = readDate(dis);
					
					this.Amount = readString(dis);
					
					this.AMCNumber = readString(dis);
					
					this.BranchCode = readString(dis);
					
					this.BranchName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.AssetCode,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// String
				
						writeString(this.AssetCategorylevel1,dos);
					
					// String
				
						writeString(this.AssetCategorylevel2,dos);
					
					// String
				
						writeString(this.AssetCategorylevel3,dos);
					
					// String
				
						writeString(this.AssetCategorylevel4,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// java.util.Date
				
						writeDate(this.FromDate,dos);
					
					// java.util.Date
				
						writeDate(this.ToDate,dos);
					
					// java.util.Date
				
						writeDate(this.PurchaseDate,dos);
					
					// String
				
						writeString(this.AssetDesc,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// String
				
						writeString(this.MachineTagNo,dos);
					
					// Integer
				
						writeInteger(this.Qty,dos);
					
					// String
				
						writeString(this.EmailID,dos);
					
					// String
				
						writeString(this.PhysicalID,dos);
					
					// String
				
						writeString(this.InvoiceRefNo,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// java.util.Date
				
						writeDate(this.DatePutToUse,dos);
					
					// String
				
						writeString(this.Amount,dos);
					
					// String
				
						writeString(this.AMCNumber,dos);
					
					// String
				
						writeString(this.BranchCode,dos);
					
					// String
				
						writeString(this.BranchName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.AssetCode,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// String
				
						writeString(this.AssetCategorylevel1,dos);
					
					// String
				
						writeString(this.AssetCategorylevel2,dos);
					
					// String
				
						writeString(this.AssetCategorylevel3,dos);
					
					// String
				
						writeString(this.AssetCategorylevel4,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// java.util.Date
				
						writeDate(this.FromDate,dos);
					
					// java.util.Date
				
						writeDate(this.ToDate,dos);
					
					// java.util.Date
				
						writeDate(this.PurchaseDate,dos);
					
					// String
				
						writeString(this.AssetDesc,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// String
				
						writeString(this.MachineTagNo,dos);
					
					// Integer
				
						writeInteger(this.Qty,dos);
					
					// String
				
						writeString(this.EmailID,dos);
					
					// String
				
						writeString(this.PhysicalID,dos);
					
					// String
				
						writeString(this.InvoiceRefNo,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// java.util.Date
				
						writeDate(this.DatePutToUse,dos);
					
					// String
				
						writeString(this.Amount,dos);
					
					// String
				
						writeString(this.AMCNumber,dos);
					
					// String
				
						writeString(this.BranchCode,dos);
					
					// String
				
						writeString(this.BranchName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetCode="+AssetCode);
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",AssetCategorylevel1="+AssetCategorylevel1);
		sb.append(",AssetCategorylevel2="+AssetCategorylevel2);
		sb.append(",AssetCategorylevel3="+AssetCategorylevel3);
		sb.append(",AssetCategorylevel4="+AssetCategorylevel4);
		sb.append(",AssetCategoryID="+String.valueOf(AssetCategoryID));
		sb.append(",FromDate="+String.valueOf(FromDate));
		sb.append(",ToDate="+String.valueOf(ToDate));
		sb.append(",PurchaseDate="+String.valueOf(PurchaseDate));
		sb.append(",AssetDesc="+AssetDesc);
		sb.append(",Remarks="+Remarks);
		sb.append(",MachineTagNo="+MachineTagNo);
		sb.append(",Qty="+String.valueOf(Qty));
		sb.append(",EmailID="+EmailID);
		sb.append(",PhysicalID="+PhysicalID);
		sb.append(",InvoiceRefNo="+InvoiceRefNo);
		sb.append(",VendorName="+VendorName);
		sb.append(",DatePutToUse="+String.valueOf(DatePutToUse));
		sb.append(",Amount="+Amount);
		sb.append(",AMCNumber="+AMCNumber);
		sb.append(",BranchCode="+BranchCode);
		sb.append(",BranchName="+BranchName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(AssetID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategorylevel1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategorylevel1);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategorylevel2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategorylevel2);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategorylevel3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategorylevel3);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategorylevel4 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategorylevel4);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID);
            			}
            		
        			sb.append("|");
        		
        				if(FromDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FromDate);
            			}
            		
        			sb.append("|");
        		
        				if(ToDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ToDate);
            			}
            		
        			sb.append("|");
        		
        				if(PurchaseDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PurchaseDate);
            			}
            		
        			sb.append("|");
        		
        				if(AssetDesc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetDesc);
            			}
            		
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(MachineTagNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MachineTagNo);
            			}
            		
        			sb.append("|");
        		
        				if(Qty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Qty);
            			}
            		
        			sb.append("|");
        		
        				if(EmailID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailID);
            			}
            		
        			sb.append("|");
        		
        				if(PhysicalID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhysicalID);
            			}
            		
        			sb.append("|");
        		
        				if(InvoiceRefNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(InvoiceRefNo);
            			}
            		
        			sb.append("|");
        		
        				if(VendorName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorName);
            			}
            		
        			sb.append("|");
        		
        				if(DatePutToUse == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DatePutToUse);
            			}
            		
        			sb.append("|");
        		
        				if(Amount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Amount);
            			}
            		
        			sb.append("|");
        		
        				if(AMCNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AMCNumber);
            			}
            		
        			sb.append("|");
        		
        				if(BranchCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BranchCode);
            			}
            		
        			sb.append("|");
        		
        				if(BranchName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BranchName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tDBOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
                    log4jParamters_tDBOutput_6.append("Parameters:");
                            log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"TblCostCatAnalysis1\"");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + (log4jParamters_tDBOutput_6) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_6", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_6 = null;
	dbschema_tDBOutput_6 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_6 = null;
if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
	tableName_tDBOutput_6 = ("TblCostCatAnalysis1");
} else {
	tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "\".\"" + ("TblCostCatAnalysis1");
}


int nb_line_tDBOutput_6 = 0;
int nb_line_update_tDBOutput_6 = 0;
int nb_line_inserted_tDBOutput_6 = 0;
int nb_line_deleted_tDBOutput_6 = 0;
int nb_line_rejected_tDBOutput_6 = 0;

int deletedCount_tDBOutput_6=0;
int updatedCount_tDBOutput_6=0;
int insertedCount_tDBOutput_6=0;
int rowsToCommitCount_tDBOutput_6=0;
int rejectedCount_tDBOutput_6=0;

boolean whetherReject_tDBOutput_6 = false;

java.sql.Connection conn_tDBOutput_6 = null;
String dbUser_tDBOutput_6 = null;

	conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_6.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_6.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_6 = 10000;
   int batchSizeCounter_tDBOutput_6=0;

int count_tDBOutput_6=0;
            int rsTruncCountNumber_tDBOutput_6 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_6 = stmtTruncCount_tDBOutput_6.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_6 + "\"")) {
                    if(rsTruncCount_tDBOutput_6.next()) {
                        rsTruncCountNumber_tDBOutput_6 = rsTruncCount_tDBOutput_6.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_6+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_6.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_6 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_6+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_6 += rsTruncCountNumber_tDBOutput_6;
            }
        java.lang.StringBuilder sb_tDBOutput_6 = new java.lang.StringBuilder();
        sb_tDBOutput_6.append("INSERT INTO \"").append(tableName_tDBOutput_6).append("\" (\"AssetCode\",\"AssetID\",\"AssetCategorylevel1\",\"AssetCategorylevel2\",\"AssetCategorylevel3\",\"AssetCategorylevel4\",\"AssetCategoryID\",\"FromDate\",\"ToDate\",\"PurchaseDate\",\"AssetDesc\",\"Remarks\",\"MachineTagNo\",\"Qty\",\"EmailID\",\"PhysicalID\",\"InvoiceRefNo\",\"VendorName\",\"DatePutToUse\",\"Amount\",\"AMCNumber\",\"BranchCode\",\"BranchName\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_6 = sb_tDBOutput_6.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing '")  + (insert_tDBOutput_6)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
	    resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
	    

 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"TblCostCatAnalysis1\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT dbo.TblCostCatAnalysis1.AssetCode, 		dbo.TblCostCatAnalysis1.AssetID, 		dbo.TblCostCatAnalysis1.AssetCategorylevel1, 		dbo.TblCostCatAnalysis1.AssetCategorylevel2, 		dbo.TblCostCatAnalysis1.AssetCategorylevel3, 		dbo.TblCostCatAnalysis1.AssetCategorylevel4, 		dbo.TblCostCatAnalysis1.AssetCategoryID, 		dbo.TblCostCatAnalysis1.FromDate, 		dbo.TblCostCatAnalysis1.ToDate, 		dbo.TblCostCatAnalysis1.PurchaseDate, 		dbo.TblCostCatAnalysis1.AssetDesc, 		dbo.TblCostCatAnalysis1.Remarks, 		dbo.TblCostCatAnalysis1.MachineTagNo, 		dbo.TblCostCatAnalysis1.Qty, 		dbo.TblCostCatAnalysis1.EmailID, 		dbo.TblCostCatAnalysis1.PhysicalID, 		dbo.TblCostCatAnalysis1.InvoiceRefNo, 		dbo.TblCostCatAnalysis1.VendorName, 		dbo.TblCostCatAnalysis1.DatePutToUse, 		dbo.TblCostCatAnalysis1.Amount, 		dbo.TblCostCatAnalysis1.AMCNumber, 		dbo.TblCostCatAnalysis1.BranchCode, 		dbo.TblCostCatAnalysis1.BranchName FROM	dbo.TblCostCatAnalysis1\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategorylevel1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategorylevel2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategorylevel3")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategorylevel4")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FromDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ToDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PurchaseDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetDesc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MachineTagNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Qty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PhysicalID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("InvoiceRefNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DatePutToUse")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Amount")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AMCNumber")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BranchCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BranchName")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"TblCostCatAnalysis1\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_4  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4); 
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_4 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT dbo.TblCostCatAnalysis1.AssetCode,\n		dbo.TblCostCatAnalysis1.AssetID,\n		dbo.TblCostCatAnalysis1.AssetCategorylev"
+"el1,\n		dbo.TblCostCatAnalysis1.AssetCategorylevel2,\n		dbo.TblCostCatAnalysis1.AssetCategorylevel3,\n		dbo.TblCostCatAnaly"
+"sis1.AssetCategorylevel4,\n		dbo.TblCostCatAnalysis1.AssetCategoryID,\n		dbo.TblCostCatAnalysis1.FromDate,\n		dbo.TblCostCa"
+"tAnalysis1.ToDate,\n		dbo.TblCostCatAnalysis1.PurchaseDate,\n		dbo.TblCostCatAnalysis1.AssetDesc,\n		dbo.TblCostCatAnalysis"
+"1.Remarks,\n		dbo.TblCostCatAnalysis1.MachineTagNo,\n		dbo.TblCostCatAnalysis1.Qty,\n		dbo.TblCostCatAnalysis1.EmailID,\n		d"
+"bo.TblCostCatAnalysis1.PhysicalID,\n		dbo.TblCostCatAnalysis1.InvoiceRefNo,\n		dbo.TblCostCatAnalysis1.VendorName,\n		dbo.T"
+"blCostCatAnalysis1.DatePutToUse,\n		dbo.TblCostCatAnalysis1.Amount,\n		dbo.TblCostCatAnalysis1.AMCNumber,\n		dbo.TblCostCat"
+"Analysis1.BranchCode,\n		dbo.TblCostCatAnalysis1.BranchName\nFROM	dbo.TblCostCatAnalysis1";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(1);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetCode = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.AssetID = null;
							} else {
		                          
            row4.AssetID = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    row4.AssetID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.AssetCategorylevel1 = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(3);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetCategorylevel1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetCategorylevel1 = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetCategorylevel1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.AssetCategorylevel2 = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(4);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetCategorylevel2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetCategorylevel2 = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetCategorylevel2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.AssetCategorylevel3 = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(5);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetCategorylevel3 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetCategorylevel3 = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetCategorylevel3 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.AssetCategorylevel4 = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(6);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetCategorylevel4 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetCategorylevel4 = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetCategorylevel4 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.AssetCategoryID = null;
							} else {
		                          
            row4.AssetCategoryID = rs_tDBInput_4.getInt(7);
            if(rs_tDBInput_4.wasNull()){
                    row4.AssetCategoryID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.FromDate = null;
							} else {
										
			row4.FromDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 8);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.ToDate = null;
							} else {
										
			row4.ToDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 9);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.PurchaseDate = null;
							} else {
										
			row4.PurchaseDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 10);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 11) {
								row4.AssetDesc = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(11);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AssetDesc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AssetDesc = tmpContent_tDBInput_4;
                }
            } else {
                row4.AssetDesc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 12) {
								row4.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(12);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Remarks = tmpContent_tDBInput_4;
                }
            } else {
                row4.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 13) {
								row4.MachineTagNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(13);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.MachineTagNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.MachineTagNo = tmpContent_tDBInput_4;
                }
            } else {
                row4.MachineTagNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 14) {
								row4.Qty = null;
							} else {
		                          
            row4.Qty = rs_tDBInput_4.getInt(14);
            if(rs_tDBInput_4.wasNull()){
                    row4.Qty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 15) {
								row4.EmailID = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(15);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.EmailID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.EmailID = tmpContent_tDBInput_4;
                }
            } else {
                row4.EmailID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 16) {
								row4.PhysicalID = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(16);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.PhysicalID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.PhysicalID = tmpContent_tDBInput_4;
                }
            } else {
                row4.PhysicalID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 17) {
								row4.InvoiceRefNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(17);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.InvoiceRefNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.InvoiceRefNo = tmpContent_tDBInput_4;
                }
            } else {
                row4.InvoiceRefNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 18) {
								row4.VendorName = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(18);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.VendorName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.VendorName = tmpContent_tDBInput_4;
                }
            } else {
                row4.VendorName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 19) {
								row4.DatePutToUse = null;
							} else {
										
			row4.DatePutToUse = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 19);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 20) {
								row4.Amount = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(20);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Amount = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Amount = tmpContent_tDBInput_4;
                }
            } else {
                row4.Amount = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 21) {
								row4.AMCNumber = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(21);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(21).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.AMCNumber = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.AMCNumber = tmpContent_tDBInput_4;
                }
            } else {
                row4.AMCNumber = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 22) {
								row4.BranchCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(22);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(22).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.BranchCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.BranchCode = tmpContent_tDBInput_4;
                }
            } else {
                row4.BranchCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 23) {
								row4.BranchName = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(23);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(23).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.BranchName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.BranchName = tmpContent_tDBInput_4;
                }
            } else {
                row4.BranchName = null;
            }
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					





 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"TblCostCatAnalysis1\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



        whetherReject_tDBOutput_6 = false;
                    if(row4.AssetCode == null) {
pstmt_tDBOutput_6.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(1, row4.AssetCode);
}

                    if(row4.AssetID == null) {
pstmt_tDBOutput_6.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(2, row4.AssetID);
}

                    if(row4.AssetCategorylevel1 == null) {
pstmt_tDBOutput_6.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(3, row4.AssetCategorylevel1);
}

                    if(row4.AssetCategorylevel2 == null) {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(4, row4.AssetCategorylevel2);
}

                    if(row4.AssetCategorylevel3 == null) {
pstmt_tDBOutput_6.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(5, row4.AssetCategorylevel3);
}

                    if(row4.AssetCategorylevel4 == null) {
pstmt_tDBOutput_6.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(6, row4.AssetCategorylevel4);
}

                    if(row4.AssetCategoryID == null) {
pstmt_tDBOutput_6.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(7, row4.AssetCategoryID);
}

                    if(row4.FromDate != null) {
pstmt_tDBOutput_6.setTimestamp(8, new java.sql.Timestamp(row4.FromDate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(row4.ToDate != null) {
pstmt_tDBOutput_6.setTimestamp(9, new java.sql.Timestamp(row4.ToDate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(row4.PurchaseDate != null) {
pstmt_tDBOutput_6.setTimestamp(10, new java.sql.Timestamp(row4.PurchaseDate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(10, java.sql.Types.TIMESTAMP);
}

                    if(row4.AssetDesc == null) {
pstmt_tDBOutput_6.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(11, row4.AssetDesc);
}

                    if(row4.Remarks == null) {
pstmt_tDBOutput_6.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(12, row4.Remarks);
}

                    if(row4.MachineTagNo == null) {
pstmt_tDBOutput_6.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(13, row4.MachineTagNo);
}

                    if(row4.Qty == null) {
pstmt_tDBOutput_6.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(14, row4.Qty);
}

                    if(row4.EmailID == null) {
pstmt_tDBOutput_6.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(15, row4.EmailID);
}

                    if(row4.PhysicalID == null) {
pstmt_tDBOutput_6.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(16, row4.PhysicalID);
}

                    if(row4.InvoiceRefNo == null) {
pstmt_tDBOutput_6.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(17, row4.InvoiceRefNo);
}

                    if(row4.VendorName == null) {
pstmt_tDBOutput_6.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(18, row4.VendorName);
}

                    if(row4.DatePutToUse != null) {
pstmt_tDBOutput_6.setTimestamp(19, new java.sql.Timestamp(row4.DatePutToUse.getTime()));
} else {
pstmt_tDBOutput_6.setNull(19, java.sql.Types.TIMESTAMP);
}

                    if(row4.Amount == null) {
pstmt_tDBOutput_6.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(20, row4.Amount);
}

                    if(row4.AMCNumber == null) {
pstmt_tDBOutput_6.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(21, row4.AMCNumber);
}

                    if(row4.BranchCode == null) {
pstmt_tDBOutput_6.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(22, row4.BranchCode);
}

                    if(row4.BranchName == null) {
pstmt_tDBOutput_6.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(23, row4.BranchName);
}

			
    		pstmt_tDBOutput_6.addBatch();
    		nb_line_tDBOutput_6++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Adding the record ")  + (nb_line_tDBOutput_6)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_6++;
    		  
    			if ((batchSize_tDBOutput_6 > 0) && (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {
                try {
						int countSum_tDBOutput_6 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            	    	batchSizeCounter_tDBOutput_6 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
				    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
				    	String errormessage_tDBOutput_6;
						if (ne_tDBOutput_6 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
							errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
						}else{
							errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
						}
				    	
				    	int countSum_tDBOutput_6 = 0;
						for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
				    	System.err.println(errormessage_tDBOutput_6);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_6 = 0;
				if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
	    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
	    	String errormessage_tDBOutput_6;
			if (ne_tDBOutput_6 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
				errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
			}else{
				errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
			}
	    	
	    	int countSum_tDBOutput_6 = 0;
			for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
				countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
			}
			rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
			
	    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
	    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
	    	System.err.println(errormessage_tDBOutput_6);
	    	
		}
	    
        if(pstmt_tDBOutput_6 != null) {
        		
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
        globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_6)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"TblCostCatAnalysis1\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Done.") );

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"TblCostCatAnalysis1\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public long id;

				public long getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 19;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 500;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				
			    public String MachineTagNo;

				public String getMachineTagNo () {
					return this.MachineTagNo;
				}

				public Boolean MachineTagNoIsNullable(){
				    return true;
				}
				public Boolean MachineTagNoIsKey(){
				    return false;
				}
				public Integer MachineTagNoLength(){
				    return 2147483647;
				}
				public Integer MachineTagNoPrecision(){
				    return 0;
				}
				public String MachineTagNoDefault(){
				
					return null;
				
				}
				public String MachineTagNoComment(){
				
				    return "";
				
				}
				public String MachineTagNoPattern(){
				
					return "";
				
				}
				public String MachineTagNoOriginalDbColumnName(){
				
					return "MachineTagNo";
				
				}

				
			    public String AssetCategory;

				public String getAssetCategory () {
					return this.AssetCategory;
				}

				public Boolean AssetCategoryIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryIsKey(){
				    return false;
				}
				public Integer AssetCategoryLength(){
				    return 500;
				}
				public Integer AssetCategoryPrecision(){
				    return 0;
				}
				public String AssetCategoryDefault(){
				
					return null;
				
				}
				public String AssetCategoryComment(){
				
				    return "";
				
				}
				public String AssetCategoryPattern(){
				
					return "";
				
				}
				public String AssetCategoryOriginalDbColumnName(){
				
					return "AssetCategory";
				
				}

				
			    public String AssetDesc;

				public String getAssetDesc () {
					return this.AssetDesc;
				}

				public Boolean AssetDescIsNullable(){
				    return true;
				}
				public Boolean AssetDescIsKey(){
				    return false;
				}
				public Integer AssetDescLength(){
				    return 500;
				}
				public Integer AssetDescPrecision(){
				    return 0;
				}
				public String AssetDescDefault(){
				
					return null;
				
				}
				public String AssetDescComment(){
				
				    return "";
				
				}
				public String AssetDescPattern(){
				
					return "";
				
				}
				public String AssetDescOriginalDbColumnName(){
				
					return "AssetDesc";
				
				}

				
			    public String LocationName;

				public String getLocationName () {
					return this.LocationName;
				}

				public Boolean LocationNameIsNullable(){
				    return true;
				}
				public Boolean LocationNameIsKey(){
				    return false;
				}
				public Integer LocationNameLength(){
				    return 500;
				}
				public Integer LocationNamePrecision(){
				    return 0;
				}
				public String LocationNameDefault(){
				
					return null;
				
				}
				public String LocationNameComment(){
				
				    return "";
				
				}
				public String LocationNamePattern(){
				
					return "";
				
				}
				public String LocationNameOriginalDbColumnName(){
				
					return "LocationName";
				
				}

				
			    public String DepartmentName;

				public String getDepartmentName () {
					return this.DepartmentName;
				}

				public Boolean DepartmentNameIsNullable(){
				    return true;
				}
				public Boolean DepartmentNameIsKey(){
				    return false;
				}
				public Integer DepartmentNameLength(){
				    return 500;
				}
				public Integer DepartmentNamePrecision(){
				    return 0;
				}
				public String DepartmentNameDefault(){
				
					return null;
				
				}
				public String DepartmentNameComment(){
				
				    return "";
				
				}
				public String DepartmentNamePattern(){
				
					return "";
				
				}
				public String DepartmentNameOriginalDbColumnName(){
				
					return "DepartmentName";
				
				}

				
			    public java.util.Date DatePutToUse;

				public java.util.Date getDatePutToUse () {
					return this.DatePutToUse;
				}

				public Boolean DatePutToUseIsNullable(){
				    return true;
				}
				public Boolean DatePutToUseIsKey(){
				    return false;
				}
				public Integer DatePutToUseLength(){
				    return 23;
				}
				public Integer DatePutToUsePrecision(){
				    return 3;
				}
				public String DatePutToUseDefault(){
				
					return null;
				
				}
				public String DatePutToUseComment(){
				
				    return "";
				
				}
				public String DatePutToUsePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DatePutToUseOriginalDbColumnName(){
				
					return "DatePutToUse";
				
				}

				
			    public java.util.Date PurchaseDate;

				public java.util.Date getPurchaseDate () {
					return this.PurchaseDate;
				}

				public Boolean PurchaseDateIsNullable(){
				    return true;
				}
				public Boolean PurchaseDateIsKey(){
				    return false;
				}
				public Integer PurchaseDateLength(){
				    return 23;
				}
				public Integer PurchaseDatePrecision(){
				    return 3;
				}
				public String PurchaseDateDefault(){
				
					return null;
				
				}
				public String PurchaseDateComment(){
				
				    return "";
				
				}
				public String PurchaseDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PurchaseDateOriginalDbColumnName(){
				
					return "PurchaseDate";
				
				}

				
			    public String PhysicalID;

				public String getPhysicalID () {
					return this.PhysicalID;
				}

				public Boolean PhysicalIDIsNullable(){
				    return true;
				}
				public Boolean PhysicalIDIsKey(){
				    return false;
				}
				public Integer PhysicalIDLength(){
				    return 500;
				}
				public Integer PhysicalIDPrecision(){
				    return 0;
				}
				public String PhysicalIDDefault(){
				
					return null;
				
				}
				public String PhysicalIDComment(){
				
				    return "";
				
				}
				public String PhysicalIDPattern(){
				
					return "";
				
				}
				public String PhysicalIDOriginalDbColumnName(){
				
					return "PhysicalID";
				
				}

				
			    public String CostCenter;

				public String getCostCenter () {
					return this.CostCenter;
				}

				public Boolean CostCenterIsNullable(){
				    return true;
				}
				public Boolean CostCenterIsKey(){
				    return false;
				}
				public Integer CostCenterLength(){
				    return 500;
				}
				public Integer CostCenterPrecision(){
				    return 0;
				}
				public String CostCenterDefault(){
				
					return null;
				
				}
				public String CostCenterComment(){
				
				    return "";
				
				}
				public String CostCenterPattern(){
				
					return "";
				
				}
				public String CostCenterOriginalDbColumnName(){
				
					return "CostCenter";
				
				}

				
			    public BigDecimal AssetCost;

				public BigDecimal getAssetCost () {
					return this.AssetCost;
				}

				public Boolean AssetCostIsNullable(){
				    return true;
				}
				public Boolean AssetCostIsKey(){
				    return false;
				}
				public Integer AssetCostLength(){
				    return 12;
				}
				public Integer AssetCostPrecision(){
				    return 2;
				}
				public String AssetCostDefault(){
				
					return null;
				
				}
				public String AssetCostComment(){
				
				    return "";
				
				}
				public String AssetCostPattern(){
				
					return "";
				
				}
				public String AssetCostOriginalDbColumnName(){
				
					return "AssetCost";
				
				}

				
			    public Boolean verify_status;

				public Boolean getVerify_status () {
					return this.verify_status;
				}

				public Boolean verify_statusIsNullable(){
				    return true;
				}
				public Boolean verify_statusIsKey(){
				    return false;
				}
				public Integer verify_statusLength(){
				    return 1;
				}
				public Integer verify_statusPrecision(){
				    return 0;
				}
				public String verify_statusDefault(){
				
					return null;
				
				}
				public String verify_statusComment(){
				
				    return "";
				
				}
				public String verify_statusPattern(){
				
					return "";
				
				}
				public String verify_statusOriginalDbColumnName(){
				
					return "verify_status";
				
				}

				
			    public java.util.Date verified_on;

				public java.util.Date getVerified_on () {
					return this.verified_on;
				}

				public Boolean verified_onIsNullable(){
				    return true;
				}
				public Boolean verified_onIsKey(){
				    return false;
				}
				public Integer verified_onLength(){
				    return 23;
				}
				public Integer verified_onPrecision(){
				    return 3;
				}
				public String verified_onDefault(){
				
					return null;
				
				}
				public String verified_onComment(){
				
				    return "";
				
				}
				public String verified_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String verified_onOriginalDbColumnName(){
				
					return "verified_on";
				
				}

				
			    public String verified_by;

				public String getVerified_by () {
					return this.verified_by;
				}

				public Boolean verified_byIsNullable(){
				    return true;
				}
				public Boolean verified_byIsKey(){
				    return false;
				}
				public Integer verified_byLength(){
				    return 500;
				}
				public Integer verified_byPrecision(){
				    return 0;
				}
				public String verified_byDefault(){
				
					return null;
				
				}
				public String verified_byComment(){
				
				    return "";
				
				}
				public String verified_byPattern(){
				
					return "";
				
				}
				public String verified_byOriginalDbColumnName(){
				
					return "verified_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return true;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 23;
				}
				public Integer created_onPrecision(){
				    return 3;
				}
				public String created_onDefault(){
				
					return null;
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public String photostring;

				public String getPhotostring () {
					return this.photostring;
				}

				public Boolean photostringIsNullable(){
				    return true;
				}
				public Boolean photostringIsKey(){
				    return false;
				}
				public Integer photostringLength(){
				    return 2147483647;
				}
				public Integer photostringPrecision(){
				    return 0;
				}
				public String photostringDefault(){
				
					return null;
				
				}
				public String photostringComment(){
				
				    return "";
				
				}
				public String photostringPattern(){
				
					return "";
				
				}
				public String photostringOriginalDbColumnName(){
				
					return "photostring";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.id = this.id;
	            other.AssetCode = this.AssetCode;
	            other.MachineTagNo = this.MachineTagNo;
	            other.AssetCategory = this.AssetCategory;
	            other.AssetDesc = this.AssetDesc;
	            other.LocationName = this.LocationName;
	            other.DepartmentName = this.DepartmentName;
	            other.DatePutToUse = this.DatePutToUse;
	            other.PurchaseDate = this.PurchaseDate;
	            other.PhysicalID = this.PhysicalID;
	            other.CostCenter = this.CostCenter;
	            other.AssetCost = this.AssetCost;
	            other.verify_status = this.verify_status;
	            other.verified_on = this.verified_on;
	            other.verified_by = this.verified_by;
	            other.created_on = this.created_on;
	            other.photostring = this.photostring;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.id = dis.readLong();
					
					this.AssetCode = readString(dis);
					
					this.MachineTagNo = readString(dis);
					
					this.AssetCategory = readString(dis);
					
					this.AssetDesc = readString(dis);
					
					this.LocationName = readString(dis);
					
					this.DepartmentName = readString(dis);
					
					this.DatePutToUse = readDate(dis);
					
					this.PurchaseDate = readDate(dis);
					
					this.PhysicalID = readString(dis);
					
					this.CostCenter = readString(dis);
					
						this.AssetCost = (BigDecimal) dis.readObject();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.verify_status = null;
           				} else {
           			    	this.verify_status = dis.readBoolean();
           				}
					
					this.verified_on = readDate(dis);
					
					this.verified_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.photostring = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.id = dis.readLong();
					
					this.AssetCode = readString(dis);
					
					this.MachineTagNo = readString(dis);
					
					this.AssetCategory = readString(dis);
					
					this.AssetDesc = readString(dis);
					
					this.LocationName = readString(dis);
					
					this.DepartmentName = readString(dis);
					
					this.DatePutToUse = readDate(dis);
					
					this.PurchaseDate = readDate(dis);
					
					this.PhysicalID = readString(dis);
					
					this.CostCenter = readString(dis);
					
						this.AssetCost = (BigDecimal) dis.readObject();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.verify_status = null;
           				} else {
           			    	this.verify_status = dis.readBoolean();
           				}
					
					this.verified_on = readDate(dis);
					
					this.verified_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.photostring = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// long
				
		            	dos.writeLong(this.id);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.MachineTagNo,dos);
					
					// String
				
						writeString(this.AssetCategory,dos);
					
					// String
				
						writeString(this.AssetDesc,dos);
					
					// String
				
						writeString(this.LocationName,dos);
					
					// String
				
						writeString(this.DepartmentName,dos);
					
					// java.util.Date
				
						writeDate(this.DatePutToUse,dos);
					
					// java.util.Date
				
						writeDate(this.PurchaseDate,dos);
					
					// String
				
						writeString(this.PhysicalID,dos);
					
					// String
				
						writeString(this.CostCenter,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AssetCost);
					
					// Boolean
				
						if(this.verify_status == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.verify_status);
		            	}
					
					// java.util.Date
				
						writeDate(this.verified_on,dos);
					
					// String
				
						writeString(this.verified_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.photostring,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// long
				
		            	dos.writeLong(this.id);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.MachineTagNo,dos);
					
					// String
				
						writeString(this.AssetCategory,dos);
					
					// String
				
						writeString(this.AssetDesc,dos);
					
					// String
				
						writeString(this.LocationName,dos);
					
					// String
				
						writeString(this.DepartmentName,dos);
					
					// java.util.Date
				
						writeDate(this.DatePutToUse,dos);
					
					// java.util.Date
				
						writeDate(this.PurchaseDate,dos);
					
					// String
				
						writeString(this.PhysicalID,dos);
					
					// String
				
						writeString(this.CostCenter,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AssetCost);
					
					// Boolean
				
						if(this.verify_status == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.verify_status);
		            	}
					
					// java.util.Date
				
						writeDate(this.verified_on,dos);
					
					// String
				
						writeString(this.verified_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.photostring,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",AssetCode="+AssetCode);
		sb.append(",MachineTagNo="+MachineTagNo);
		sb.append(",AssetCategory="+AssetCategory);
		sb.append(",AssetDesc="+AssetDesc);
		sb.append(",LocationName="+LocationName);
		sb.append(",DepartmentName="+DepartmentName);
		sb.append(",DatePutToUse="+String.valueOf(DatePutToUse));
		sb.append(",PurchaseDate="+String.valueOf(PurchaseDate));
		sb.append(",PhysicalID="+PhysicalID);
		sb.append(",CostCenter="+CostCenter);
		sb.append(",AssetCost="+String.valueOf(AssetCost));
		sb.append(",verify_status="+String.valueOf(verify_status));
		sb.append(",verified_on="+String.valueOf(verified_on));
		sb.append(",verified_by="+verified_by);
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",photostring="+photostring);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(MachineTagNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MachineTagNo);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategory == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategory);
            			}
            		
        			sb.append("|");
        		
        				if(AssetDesc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetDesc);
            			}
            		
        			sb.append("|");
        		
        				if(LocationName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LocationName);
            			}
            		
        			sb.append("|");
        		
        				if(DepartmentName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepartmentName);
            			}
            		
        			sb.append("|");
        		
        				if(DatePutToUse == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DatePutToUse);
            			}
            		
        			sb.append("|");
        		
        				if(PurchaseDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PurchaseDate);
            			}
            		
        			sb.append("|");
        		
        				if(PhysicalID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhysicalID);
            			}
            		
        			sb.append("|");
        		
        				if(CostCenter == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CostCenter);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCost);
            			}
            		
        			sb.append("|");
        		
        				if(verify_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(verify_status);
            			}
            		
        			sb.append("|");
        		
        				if(verified_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(verified_on);
            			}
            		
        			sb.append("|");
        		
        				if(verified_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(verified_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(photostring == null){
        					sb.append("<null>");
        				}else{
            				sb.append(photostring);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"tb_asset_verify_details\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("tb_asset_verify_details");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("tb_asset_verify_details");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_4 + "\"")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_4 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"id\",\"AssetCode\",\"MachineTagNo\",\"AssetCategory\",\"AssetDesc\",\"LocationName\",\"DepartmentName\",\"DatePutToUse\",\"PurchaseDate\",\"PhysicalID\",\"CostCenter\",\"AssetCost\",\"verify_status\",\"verified_on\",\"verified_by\",\"created_on\",\"photostring\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		
		int tos_count_tDBInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
                    log4jParamters_tDBInput_5.append("Parameters:");
                            log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"tb_asset_verify_details\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERY" + " = " + "\"SELECT dbo.tb_asset_verify_details.\\\"id\\\", 		dbo.tb_asset_verify_details.AssetCode, 		dbo.tb_asset_verify_details.MachineTagNo, 		dbo.tb_asset_verify_details.AssetCategory, 		dbo.tb_asset_verify_details.AssetDesc, 		dbo.tb_asset_verify_details.LocationName, 		dbo.tb_asset_verify_details.DepartmentName, 		dbo.tb_asset_verify_details.DatePutToUse, 		dbo.tb_asset_verify_details.PurchaseDate, 		dbo.tb_asset_verify_details.PhysicalID, 		dbo.tb_asset_verify_details.CostCenter, 		dbo.tb_asset_verify_details.AssetCost, 		dbo.tb_asset_verify_details.verify_status, 		dbo.tb_asset_verify_details.verified_on, 		dbo.tb_asset_verify_details.verified_by, 		dbo.tb_asset_verify_details.created_on, 		dbo.tb_asset_verify_details.photostring FROM	dbo.tb_asset_verify_details\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MachineTagNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategory")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetDesc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("LocationName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepartmentName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DatePutToUse")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PurchaseDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PhysicalID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostCenter")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("verify_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("verified_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("verified_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("photostring")+"}]");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + (log4jParamters_tDBInput_5) );
                    } 
                } 
            new BytesLimit65535_tDBInput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_5", "\"tb_asset_verify_details\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_5 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_5 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_5  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_5, talendToDBArray_tDBInput_5); 
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				conn_tDBInput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_5 != null) {
					if(conn_tDBInput_5.getMetaData() != null) {
						
							log.debug("tDBInput_5 - Uses an existing connection with username '" + conn_tDBInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_5 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

		    String dbquery_tDBInput_5 = "SELECT dbo.tb_asset_verify_details.\"id\",\n		dbo.tb_asset_verify_details.AssetCode,\n		dbo.tb_asset_verify_details.Machi"
+"neTagNo,\n		dbo.tb_asset_verify_details.AssetCategory,\n		dbo.tb_asset_verify_details.AssetDesc,\n		dbo.tb_asset_verify_det"
+"ails.LocationName,\n		dbo.tb_asset_verify_details.DepartmentName,\n		dbo.tb_asset_verify_details.DatePutToUse,\n		dbo.tb_as"
+"set_verify_details.PurchaseDate,\n		dbo.tb_asset_verify_details.PhysicalID,\n		dbo.tb_asset_verify_details.CostCenter,\n		d"
+"bo.tb_asset_verify_details.AssetCost,\n		dbo.tb_asset_verify_details.verify_status,\n		dbo.tb_asset_verify_details.verifie"
+"d_on,\n		dbo.tb_asset_verify_details.verified_by,\n		dbo.tb_asset_verify_details.created_on,\n		dbo.tb_asset_verify_details"
+".photostring\nFROM	dbo.tb_asset_verify_details";
		    
	    		log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");
			

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    	log.debug("tDBInput_5 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row5.id = 0;
							} else {
		                          
            row5.id = rs_tDBInput_5.getLong(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row5.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(2);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.AssetCode = tmpContent_tDBInput_5;
                }
            } else {
                row5.AssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row5.MachineTagNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(3);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.MachineTagNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.MachineTagNo = tmpContent_tDBInput_5;
                }
            } else {
                row5.MachineTagNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row5.AssetCategory = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(4);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.AssetCategory = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.AssetCategory = tmpContent_tDBInput_5;
                }
            } else {
                row5.AssetCategory = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row5.AssetDesc = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(5);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.AssetDesc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.AssetDesc = tmpContent_tDBInput_5;
                }
            } else {
                row5.AssetDesc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row5.LocationName = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(6);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.LocationName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.LocationName = tmpContent_tDBInput_5;
                }
            } else {
                row5.LocationName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 7) {
								row5.DepartmentName = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(7);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.DepartmentName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.DepartmentName = tmpContent_tDBInput_5;
                }
            } else {
                row5.DepartmentName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 8) {
								row5.DatePutToUse = null;
							} else {
										
			row5.DatePutToUse = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 8);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 9) {
								row5.PurchaseDate = null;
							} else {
										
			row5.PurchaseDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 9);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 10) {
								row5.PhysicalID = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(10);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.PhysicalID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.PhysicalID = tmpContent_tDBInput_5;
                }
            } else {
                row5.PhysicalID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 11) {
								row5.CostCenter = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(11);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.CostCenter = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.CostCenter = tmpContent_tDBInput_5;
                }
            } else {
                row5.CostCenter = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 12) {
								row5.AssetCost = null;
							} else {
		                          
            row5.AssetCost = rs_tDBInput_5.getBigDecimal(12);
            if(rs_tDBInput_5.wasNull()){
                    row5.AssetCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 13) {
								row5.verify_status = null;
							} else {
	                         		
            row5.verify_status = rs_tDBInput_5.getBoolean(13);
            if(rs_tDBInput_5.wasNull()){
                    row5.verify_status = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 14) {
								row5.verified_on = null;
							} else {
										
			row5.verified_on = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 14);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 15) {
								row5.verified_by = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(15);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.verified_by = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.verified_by = tmpContent_tDBInput_5;
                }
            } else {
                row5.verified_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 16) {
								row5.created_on = null;
							} else {
										
			row5.created_on = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 16);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 17) {
								row5.photostring = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(17);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.photostring = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.photostring = tmpContent_tDBInput_5;
                }
            } else {
                row5.photostring = null;
            }
		                    }
					
						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");
					





 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tDBInput_5","\"tb_asset_verify_details\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setLong(1, row5.id);

                    if(row5.AssetCode == null) {
pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(2, row5.AssetCode);
}

                    if(row5.MachineTagNo == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(3, row5.MachineTagNo);
}

                    if(row5.AssetCategory == null) {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(4, row5.AssetCategory);
}

                    if(row5.AssetDesc == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(5, row5.AssetDesc);
}

                    if(row5.LocationName == null) {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(6, row5.LocationName);
}

                    if(row5.DepartmentName == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(7, row5.DepartmentName);
}

                    if(row5.DatePutToUse != null) {
pstmt_tDBOutput_4.setTimestamp(8, new java.sql.Timestamp(row5.DatePutToUse.getTime()));
} else {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(row5.PurchaseDate != null) {
pstmt_tDBOutput_4.setTimestamp(9, new java.sql.Timestamp(row5.PurchaseDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(row5.PhysicalID == null) {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(10, row5.PhysicalID);
}

                    if(row5.CostCenter == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(11, row5.CostCenter);
}

                    pstmt_tDBOutput_4.setBigDecimal(12, row5.AssetCost);

                    if(row5.verify_status == null) {
pstmt_tDBOutput_4.setNull(13, java.sql.Types.BOOLEAN);
} else {pstmt_tDBOutput_4.setBoolean(13, row5.verify_status);
}

                    if(row5.verified_on != null) {
pstmt_tDBOutput_4.setTimestamp(14, new java.sql.Timestamp(row5.verified_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(row5.verified_by == null) {
pstmt_tDBOutput_4.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(15, row5.verified_by);
}

                    if(row5.created_on != null) {
pstmt_tDBOutput_4.setTimestamp(16, new java.sql.Timestamp(row5.created_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(16, java.sql.Types.TIMESTAMP);
}

                    if(row5.photostring == null) {
pstmt_tDBOutput_4.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(17, row5.photostring);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
}
globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
	    		log.debug("tDBInput_5 - Retrieved records count: "+nb_line_tDBInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Done.") );

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());




/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_4)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tDBInput_5","\"tb_asset_verify_details\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"tb_asset_verify_details\"";
		

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[0];

	
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public Integer AssetCategoryID;

				public Integer getAssetCategoryID () {
					return this.AssetCategoryID;
				}

				public Boolean AssetCategoryIDIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryIDIsKey(){
				    return false;
				}
				public Integer AssetCategoryIDLength(){
				    return 10;
				}
				public Integer AssetCategoryIDPrecision(){
				    return 0;
				}
				public String AssetCategoryIDDefault(){
				
					return null;
				
				}
				public String AssetCategoryIDComment(){
				
				    return "";
				
				}
				public String AssetCategoryIDPattern(){
				
					return "";
				
				}
				public String AssetCategoryIDOriginalDbColumnName(){
				
					return "AssetCategoryID";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public Integer DepartmentID;

				public Integer getDepartmentID () {
					return this.DepartmentID;
				}

				public Boolean DepartmentIDIsNullable(){
				    return true;
				}
				public Boolean DepartmentIDIsKey(){
				    return false;
				}
				public Integer DepartmentIDLength(){
				    return 10;
				}
				public Integer DepartmentIDPrecision(){
				    return 0;
				}
				public String DepartmentIDDefault(){
				
					return null;
				
				}
				public String DepartmentIDComment(){
				
				    return "";
				
				}
				public String DepartmentIDPattern(){
				
					return "";
				
				}
				public String DepartmentIDOriginalDbColumnName(){
				
					return "DepartmentID";
				
				}

				
			    public Integer CostCenterID;

				public Integer getCostCenterID () {
					return this.CostCenterID;
				}

				public Boolean CostCenterIDIsNullable(){
				    return true;
				}
				public Boolean CostCenterIDIsKey(){
				    return false;
				}
				public Integer CostCenterIDLength(){
				    return 10;
				}
				public Integer CostCenterIDPrecision(){
				    return 0;
				}
				public String CostCenterIDDefault(){
				
					return null;
				
				}
				public String CostCenterIDComment(){
				
				    return "";
				
				}
				public String CostCenterIDPattern(){
				
					return "";
				
				}
				public String CostCenterIDOriginalDbColumnName(){
				
					return "CostCenterID";
				
				}

				
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 50;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				
			    public String CODECONFIG;

				public String getCODECONFIG () {
					return this.CODECONFIG;
				}

				public Boolean CODECONFIGIsNullable(){
				    return true;
				}
				public Boolean CODECONFIGIsKey(){
				    return false;
				}
				public Integer CODECONFIGLength(){
				    return 10;
				}
				public Integer CODECONFIGPrecision(){
				    return 0;
				}
				public String CODECONFIGDefault(){
				
					return null;
				
				}
				public String CODECONFIGComment(){
				
				    return "";
				
				}
				public String CODECONFIGPattern(){
				
					return "";
				
				}
				public String CODECONFIGOriginalDbColumnName(){
				
					return "CODECONFIG";
				
				}

				
			    public Integer PostFixDigits;

				public Integer getPostFixDigits () {
					return this.PostFixDigits;
				}

				public Boolean PostFixDigitsIsNullable(){
				    return true;
				}
				public Boolean PostFixDigitsIsKey(){
				    return false;
				}
				public Integer PostFixDigitsLength(){
				    return 10;
				}
				public Integer PostFixDigitsPrecision(){
				    return 0;
				}
				public String PostFixDigitsDefault(){
				
					return null;
				
				}
				public String PostFixDigitsComment(){
				
				    return "";
				
				}
				public String PostFixDigitsPattern(){
				
					return "";
				
				}
				public String PostFixDigitsOriginalDbColumnName(){
				
					return "PostFixDigits";
				
				}

				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_27, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.AssetID = dis.readInt();
					
						this.AssetCategoryID = readInteger(dis);
					
			        this.CompanyID = dis.readInt();
					
						this.DepartmentID = readInteger(dis);
					
						this.CostCenterID = readInteger(dis);
					
					this.AssetCode = readString(dis);
					
					this.CODECONFIG = readString(dis);
					
						this.PostFixDigits = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_27) {

        	try {

        		int length = 0;
		
			        this.AssetID = dis.readInt();
					
						this.AssetCategoryID = readInteger(dis);
					
			        this.CompanyID = dis.readInt();
					
						this.DepartmentID = readInteger(dis);
					
						this.CostCenterID = readInteger(dis);
					
					this.AssetCode = readString(dis);
					
					this.CODECONFIG = readString(dis);
					
						this.PostFixDigits = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// Integer
				
						writeInteger(this.DepartmentID,dos);
					
					// Integer
				
						writeInteger(this.CostCenterID,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.CODECONFIG,dos);
					
					// Integer
				
						writeInteger(this.PostFixDigits,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// Integer
				
						writeInteger(this.DepartmentID,dos);
					
					// Integer
				
						writeInteger(this.CostCenterID,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.CODECONFIG,dos);
					
					// Integer
				
						writeInteger(this.PostFixDigits,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetID="+String.valueOf(AssetID));
		sb.append(",AssetCategoryID="+String.valueOf(AssetCategoryID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",DepartmentID="+String.valueOf(DepartmentID));
		sb.append(",CostCenterID="+String.valueOf(CostCenterID));
		sb.append(",AssetCode="+AssetCode);
		sb.append(",CODECONFIG="+CODECONFIG);
		sb.append(",PostFixDigits="+String.valueOf(PostFixDigits));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				if(AssetCategoryID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				if(DepartmentID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepartmentID);
            			}
            		
        			sb.append("|");
        		
        				if(CostCenterID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CostCenterID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(CODECONFIG == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CODECONFIG);
            			}
            		
        			sb.append("|");
        		
        				if(PostFixDigits == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PostFixDigits);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"testt\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_5 = null;
	dbschema_tDBOutput_5 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_5 = null;
if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
	tableName_tDBOutput_5 = ("testt");
} else {
	tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "\".\"" + ("testt");
}


int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

boolean whetherReject_tDBOutput_5 = false;

java.sql.Connection conn_tDBOutput_5 = null;
String dbUser_tDBOutput_5 = null;

	conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_5 = 10000;
   int batchSizeCounter_tDBOutput_5=0;

int count_tDBOutput_5=0;
            int rsTruncCountNumber_tDBOutput_5 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_5 = stmtTruncCount_tDBOutput_5.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_5 + "\"")) {
                    if(rsTruncCount_tDBOutput_5.next()) {
                        rsTruncCountNumber_tDBOutput_5 = rsTruncCount_tDBOutput_5.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_5+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_5.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_5 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_5+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_5 += rsTruncCountNumber_tDBOutput_5;
            }
        java.lang.StringBuilder sb_tDBOutput_5 = new java.lang.StringBuilder();
        sb_tDBOutput_5.append("INSERT INTO \"").append(tableName_tDBOutput_5).append("\" (\"AssetID\",\"AssetCategoryID\",\"CompanyID\",\"DepartmentID\",\"CostCenterID\",\"AssetCode\",\"CODECONFIG\",\"PostFixDigits\") VALUES (?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_5 = sb_tDBOutput_5.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing '")  + (insert_tDBOutput_5)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
	    resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
	    

 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		
		int tos_count_tDBInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
                    log4jParamters_tDBInput_6.append("Parameters:");
                            log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"testt\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERY" + " = " + "\"SELECT dbo.testt.AssetID, 		dbo.testt.AssetCategoryID, 		dbo.testt.CompanyID, 		dbo.testt.DepartmentID, 		dbo.testt.CostCenterID, 		dbo.testt.AssetCode, 		dbo.testt.CODECONFIG, 		dbo.testt.PostFixDigits FROM	dbo.testt\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepartmentID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostCenterID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CODECONFIG")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PostFixDigits")+"}]");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + (log4jParamters_tDBInput_6) );
                    } 
                } 
            new BytesLimit65535_tDBInput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_6", "\"testt\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_6 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_6 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_6  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_6, talendToDBArray_tDBInput_6); 
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				conn_tDBInput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_6 != null) {
					if(conn_tDBInput_6.getMetaData() != null) {
						
							log.debug("tDBInput_6 - Uses an existing connection with username '" + conn_tDBInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_6 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

		    String dbquery_tDBInput_6 = "SELECT dbo.testt.AssetID,\n		dbo.testt.AssetCategoryID,\n		dbo.testt.CompanyID,\n		dbo.testt.DepartmentID,\n		dbo.testt.Cos"
+"tCenterID,\n		dbo.testt.AssetCode,\n		dbo.testt.CODECONFIG,\n		dbo.testt.PostFixDigits\nFROM	dbo.testt";
		    
	    		log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");
			

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    	log.debug("tDBInput_6 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row6.AssetID = 0;
							} else {
		                          
            row6.AssetID = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row6.AssetCategoryID = null;
							} else {
		                          
            row6.AssetCategoryID = rs_tDBInput_6.getInt(2);
            if(rs_tDBInput_6.wasNull()){
                    row6.AssetCategoryID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row6.CompanyID = 0;
							} else {
		                          
            row6.CompanyID = rs_tDBInput_6.getInt(3);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row6.DepartmentID = null;
							} else {
		                          
            row6.DepartmentID = rs_tDBInput_6.getInt(4);
            if(rs_tDBInput_6.wasNull()){
                    row6.DepartmentID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 5) {
								row6.CostCenterID = null;
							} else {
		                          
            row6.CostCenterID = rs_tDBInput_6.getInt(5);
            if(rs_tDBInput_6.wasNull()){
                    row6.CostCenterID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 6) {
								row6.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(6);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.AssetCode = tmpContent_tDBInput_6;
                }
            } else {
                row6.AssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 7) {
								row6.CODECONFIG = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(7);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.CODECONFIG = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.CODECONFIG = tmpContent_tDBInput_6;
                }
            } else {
                row6.CODECONFIG = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 8) {
								row6.PostFixDigits = null;
							} else {
		                          
            row6.PostFixDigits = rs_tDBInput_6.getInt(8);
            if(rs_tDBInput_6.wasNull()){
                    row6.PostFixDigits = null;
            }
		                    }
					
						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");
					





 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_6","\"testt\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		



        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, row6.AssetID);

                    if(row6.AssetCategoryID == null) {
pstmt_tDBOutput_5.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(2, row6.AssetCategoryID);
}

                    pstmt_tDBOutput_5.setInt(3, row6.CompanyID);

                    if(row6.DepartmentID == null) {
pstmt_tDBOutput_5.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(4, row6.DepartmentID);
}

                    if(row6.CostCenterID == null) {
pstmt_tDBOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(5, row6.CostCenterID);
}

                    if(row6.AssetCode == null) {
pstmt_tDBOutput_5.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(6, row6.AssetCode);
}

                    if(row6.CODECONFIG == null) {
pstmt_tDBOutput_5.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(7, row6.CODECONFIG);
}

                    if(row6.PostFixDigits == null) {
pstmt_tDBOutput_5.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(8, row6.PostFixDigits);
}

			
    		pstmt_tDBOutput_5.addBatch();
    		nb_line_tDBOutput_5++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_5++;
    		  
    			if ((batchSize_tDBOutput_5 > 0) && (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {
                try {
						int countSum_tDBOutput_5 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            	    	batchSizeCounter_tDBOutput_5 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
				    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
				    	String errormessage_tDBOutput_5;
						if (ne_tDBOutput_5 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
							errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
						}else{
							errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
						}
				    	
				    	int countSum_tDBOutput_5 = 0;
						for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
				    	System.err.println(errormessage_tDBOutput_5);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
}
globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
	    		log.debug("tDBInput_6 - Retrieved records count: "+nb_line_tDBInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Done.") );

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());




/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_5 = 0;
				if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
	    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
	    	String errormessage_tDBOutput_5;
			if (ne_tDBOutput_5 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
				errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
			}else{
				errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
			}
	    	
	    	int countSum_tDBOutput_5 = 0;
			for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
				countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
			}
			rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
			
	    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
	    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
	    	System.err.println(errormessage_tDBOutput_5);
	    	
		}
	    
        if(pstmt_tDBOutput_5 != null) {
        		
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_5)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_6","\"testt\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"testt\"";
		

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();

    public static void main(String[] args){
        final FAMS_7_tables_27 FAMS_7_tables_27Class = new FAMS_7_tables_27();

        int exitCode = FAMS_7_tables_27Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'FAMS_7_tables_27' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try {
            	jobInfo.load(new java.io.FileInputStream(jobInfoFile));
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230315_1127-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'FAMS_7_tables_27' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_IR758BpTEe6YNIEe2AXj-Q");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-07-11T13:34:12.375051200Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = FAMS_7_tables_27.class.getClassLoader().getResourceAsStream("talend_tac2_repo/fams_7_tables_27_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = FAMS_7_tables_27.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'FAMS_7_tables_27' - Started.");

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}
try {
errorCode = null;tDBInput_5Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_5) {
globalMap.put("tDBInput_5_SUBPROCESS_STATE", -1);

e_tDBInput_5.printStackTrace();

}
try {
errorCode = null;tDBInput_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_6) {
globalMap.put("tDBInput_6_SUBPROCESS_STATE", -1);

e_tDBInput_6.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : FAMS_7_tables_27");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'FAMS_7_tables_27' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     427354 characters generated by Talend Data Integration 
 *     on the July 11, 2023 at 7:04:12 PM IST
 ************************************************************************************************/