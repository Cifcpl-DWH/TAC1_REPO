
package talend_tac2_repo.fams_7_tables_30_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: FAMS_7_tables_30 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230315_1127-patch
 * @status 
 */
public class FAMS_7_tables_30 implements TalendJob {
	static {System.setProperty("TalendJob.log", "FAMS_7_tables_30.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(FAMS_7_tables_30.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "FAMS_7_tables_30";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_6DmnMBr7Ee6Et43_rExQxg", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				FAMS_7_tables_30.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(FAMS_7_tables_30.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "MSSQL_PROP");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.118.157\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"1433\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"CHAITANYA\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"FAMS_DWH\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:AoPj6rBktEnKB8jmIF8b/motkF7Ko0Q7Bv/6qKyUjxpAoGmL").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "FAMS_Source", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

			    
		    String url_tDBConnection_1 = "jdbc:sqlserver://" + "115.124.118.157" ;
		String port_tDBConnection_1 = "1433";
		String dbname_tDBConnection_1 = "CHAITANYA" ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + "1433";
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    				    
		    	url_tDBConnection_1 += ";databaseName=" + "CHAITANYA"; 
    	}

		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
	String dbUser_tDBConnection_1 = "FAMS_DWH";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:EZ90X8OYSiMMatrrSmh2AxeIrQzMWPEqeB89ygYTdLoXMmCY");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_1", "");

	globalMap.put("db_tDBConnection_1",  "CHAITANYA");
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

	globalMap.put("driver_tDBConnection_1", "MSSQL_PROP");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"FAMS_DWH_TGT\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:jtObNX97lsJ/Ku6lyawkqMp9QicKtJd9Oo05FWIcsTvop5Pm").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "FAMS_Target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "FAMS_DWH_TGT";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:uCZvuMFvHT7vEeLY6fhXYn/QIbpIaYnH2wScEkJXnnPPHMRG");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int UserRoleID;

				public int getUserRoleID () {
					return this.UserRoleID;
				}

				public Boolean UserRoleIDIsNullable(){
				    return false;
				}
				public Boolean UserRoleIDIsKey(){
				    return true;
				}
				public Integer UserRoleIDLength(){
				    return 10;
				}
				public Integer UserRoleIDPrecision(){
				    return 0;
				}
				public String UserRoleIDDefault(){
				
					return null;
				
				}
				public String UserRoleIDComment(){
				
				    return "";
				
				}
				public String UserRoleIDPattern(){
				
					return "";
				
				}
				public String UserRoleIDOriginalDbColumnName(){
				
					return "UserRoleID";
				
				}

				
			    public int AppUserID;

				public int getAppUserID () {
					return this.AppUserID;
				}

				public Boolean AppUserIDIsNullable(){
				    return false;
				}
				public Boolean AppUserIDIsKey(){
				    return false;
				}
				public Integer AppUserIDLength(){
				    return 10;
				}
				public Integer AppUserIDPrecision(){
				    return 0;
				}
				public String AppUserIDDefault(){
				
					return null;
				
				}
				public String AppUserIDComment(){
				
				    return "";
				
				}
				public String AppUserIDPattern(){
				
					return "";
				
				}
				public String AppUserIDOriginalDbColumnName(){
				
					return "AppUserID";
				
				}

				
			    public int AppRoleID;

				public int getAppRoleID () {
					return this.AppRoleID;
				}

				public Boolean AppRoleIDIsNullable(){
				    return false;
				}
				public Boolean AppRoleIDIsKey(){
				    return false;
				}
				public Integer AppRoleIDLength(){
				    return 10;
				}
				public Integer AppRoleIDPrecision(){
				    return 0;
				}
				public String AppRoleIDDefault(){
				
					return null;
				
				}
				public String AppRoleIDComment(){
				
				    return "";
				
				}
				public String AppRoleIDPattern(){
				
					return "";
				
				}
				public String AppRoleIDOriginalDbColumnName(){
				
					return "AppRoleID";
				
				}

				
			    public Integer CompanyID;

				public Integer getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return true;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return "((1))";
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.UserRoleID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.UserRoleID != other.UserRoleID)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.UserRoleID = this.UserRoleID;
	            other.AppUserID = this.AppUserID;
	            other.AppRoleID = this.AppRoleID;
	            other.CompanyID = this.CompanyID;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.UserRoleID = this.UserRoleID;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.UserRoleID = dis.readInt();
					
			        this.AppUserID = dis.readInt();
					
			        this.AppRoleID = dis.readInt();
					
						this.CompanyID = readInteger(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.UserRoleID = dis.readInt();
					
			        this.AppUserID = dis.readInt();
					
			        this.AppRoleID = dis.readInt();
					
						this.CompanyID = readInteger(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.UserRoleID);
					
					// int
				
		            	dos.writeInt(this.AppUserID);
					
					// int
				
		            	dos.writeInt(this.AppRoleID);
					
					// Integer
				
						writeInteger(this.CompanyID,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.UserRoleID);
					
					// int
				
		            	dos.writeInt(this.AppUserID);
					
					// int
				
		            	dos.writeInt(this.AppRoleID);
					
					// Integer
				
						writeInteger(this.CompanyID,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("UserRoleID="+String.valueOf(UserRoleID));
		sb.append(",AppUserID="+String.valueOf(AppUserID));
		sb.append(",AppRoleID="+String.valueOf(AppRoleID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(UserRoleID);
        			
        			sb.append("|");
        		
        				sb.append(AppUserID);
        			
        			sb.append("|");
        		
        				sb.append(AppRoleID);
        			
        			sb.append("|");
        		
        				if(CompanyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CompanyID);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.UserRoleID, other.UserRoleID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"UserRole\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "CREATE_IF_NOT_EXISTS");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_SPATIAL_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("UserRole");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("UserRole");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
                                boolean whetherExist_tDBOutput_1 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables(null, null, null, new String[]{"TABLE"})) {
                                    String defaultSchema_tDBOutput_1 = "public";
                                    if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
                                        try(java.sql.Statement stmtSchema_tDBOutput_1 = conn_tDBOutput_1.createStatement();
                                            java.sql.ResultSet rsSchema_tDBOutput_1 = stmtSchema_tDBOutput_1.executeQuery("select current_schema() ")) {
                                            while(rsSchema_tDBOutput_1.next()){
                                                defaultSchema_tDBOutput_1 = rsSchema_tDBOutput_1.getString("current_schema");
                                            }
                                        }
                                    }
                                    while(rsTable_tDBOutput_1.next()) {
                                        String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
                                        String schema_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_SCHEM");
                                        if(table_tDBOutput_1.equals(("UserRole"))
                                            && (schema_tDBOutput_1.equals(dbschema_tDBOutput_1) || ((dbschema_tDBOutput_1 ==null || dbschema_tDBOutput_1.trim().length() ==0) && defaultSchema_tDBOutput_1.equals(schema_tDBOutput_1)))) {
                                            whetherExist_tDBOutput_1 = true;
                                            break;
                                        }
                                    }
                                }
                                if(!whetherExist_tDBOutput_1) {
                                    try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Creating")  + (" table '")  + ("\"" +tableName_tDBOutput_1+ "\"")  + ("'.") );
                                        stmtCreate_tDBOutput_1.execute("CREATE TABLE \"" + tableName_tDBOutput_1 + "\"(\"UserRoleID\" INT4  not null ,\"AppUserID\" INT4  not null ,\"AppRoleID\" INT4  not null ,\"CompanyID\" INT4 default ((1)) ,\"CreatedBy\" INT4  not null ,\"CreatedDate\" TIMESTAMP(23)   not null ,\"ModifiedBy\" INT4 ,\"ModifiedDate\" TIMESTAMP(23)  ,primary key(\"UserRoleID\"))");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Create")  + (" table '")  + ("\"" +tableName_tDBOutput_1+ "\"")  + ("' has succeeded.") );
                                    }
                                }
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"UserRoleID\",\"AppUserID\",\"AppRoleID\",\"CompanyID\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"UserRole\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT FAMS.UserRole.UserRoleID, 		FAMS.UserRole.AppUserID, 		FAMS.UserRole.AppRoleID, 		FAMS.UserRole.CompanyID, 		FAMS.UserRole.CreatedBy, 		FAMS.UserRole.CreatedDate, 		FAMS.UserRole.ModifiedBy, 		FAMS.UserRole.ModifiedDate FROM	FAMS.UserRole  WHERE FAMS.UserRole.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.UserRole.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("UserRoleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AppUserID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AppRoleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"UserRole\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1); 
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT FAMS.UserRole.UserRoleID,\n		FAMS.UserRole.AppUserID,\n		FAMS.UserRole.AppRoleID,\n		FAMS.UserRole.CompanyID,\n		FAM"
+"S.UserRole.CreatedBy,\n		FAMS.UserRole.CreatedDate,\n		FAMS.UserRole.ModifiedBy,\n		FAMS.UserRole.ModifiedDate\nFROM	FAMS.Us"
+"erRole\nWHERE FAMS.UserRole.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAMS.UserRole.CreatedDat"
+"e < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.UserRoleID = 0;
							} else {
		                          
            row1.UserRoleID = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.AppUserID = 0;
							} else {
		                          
            row1.AppUserID = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.AppRoleID = 0;
							} else {
		                          
            row1.AppRoleID = rs_tDBInput_1.getInt(3);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.CompanyID = null;
							} else {
		                          
            row1.CompanyID = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    row1.CompanyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.CreatedBy = 0;
							} else {
		                          
            row1.CreatedBy = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.CreatedDate = null;
							} else {
										
			row1.CreatedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 6);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.ModifiedBy = null;
							} else {
		                          
            row1.ModifiedBy = rs_tDBInput_1.getInt(7);
            if(rs_tDBInput_1.wasNull()){
                    row1.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.ModifiedDate = null;
							} else {
										
			row1.ModifiedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 8);
			
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					





 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"UserRole\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, row1.UserRoleID);

                    pstmt_tDBOutput_1.setInt(2, row1.AppUserID);

                    pstmt_tDBOutput_1.setInt(3, row1.AppRoleID);

                    if(row1.CompanyID == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(4, row1.CompanyID);
}

                    pstmt_tDBOutput_1.setInt(5, row1.CreatedBy);

                    if(row1.CreatedDate != null) {
pstmt_tDBOutput_1.setTimestamp(6, new java.sql.Timestamp(row1.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row1.ModifiedBy == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(7, row1.ModifiedBy);
}

                    if(row1.ModifiedDate != null) {
pstmt_tDBOutput_1.setTimestamp(8, new java.sql.Timestamp(row1.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"UserRole\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"UserRole\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMSSqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];

	
			    public int UserRoleID;

				public int getUserRoleID () {
					return this.UserRoleID;
				}

				public Boolean UserRoleIDIsNullable(){
				    return false;
				}
				public Boolean UserRoleIDIsKey(){
				    return false;
				}
				public Integer UserRoleIDLength(){
				    return 10;
				}
				public Integer UserRoleIDPrecision(){
				    return 0;
				}
				public String UserRoleIDDefault(){
				
					return null;
				
				}
				public String UserRoleIDComment(){
				
				    return "";
				
				}
				public String UserRoleIDPattern(){
				
					return "";
				
				}
				public String UserRoleIDOriginalDbColumnName(){
				
					return "UserRoleID";
				
				}

				
			    public int AppUserID;

				public int getAppUserID () {
					return this.AppUserID;
				}

				public Boolean AppUserIDIsNullable(){
				    return false;
				}
				public Boolean AppUserIDIsKey(){
				    return false;
				}
				public Integer AppUserIDLength(){
				    return 10;
				}
				public Integer AppUserIDPrecision(){
				    return 0;
				}
				public String AppUserIDDefault(){
				
					return null;
				
				}
				public String AppUserIDComment(){
				
				    return "";
				
				}
				public String AppUserIDPattern(){
				
					return "";
				
				}
				public String AppUserIDOriginalDbColumnName(){
				
					return "AppUserID";
				
				}

				
			    public int AppRoleID;

				public int getAppRoleID () {
					return this.AppRoleID;
				}

				public Boolean AppRoleIDIsNullable(){
				    return false;
				}
				public Boolean AppRoleIDIsKey(){
				    return false;
				}
				public Integer AppRoleIDLength(){
				    return 10;
				}
				public Integer AppRoleIDPrecision(){
				    return 0;
				}
				public String AppRoleIDDefault(){
				
					return null;
				
				}
				public String AppRoleIDComment(){
				
				    return "";
				
				}
				public String AppRoleIDPattern(){
				
					return "";
				
				}
				public String AppRoleIDOriginalDbColumnName(){
				
					return "AppRoleID";
				
				}

				
			    public Integer CompanyID;

				public Integer getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return true;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public String OperationType;

				public String getOperationType () {
					return this.OperationType;
				}

				public Boolean OperationTypeIsNullable(){
				    return true;
				}
				public Boolean OperationTypeIsKey(){
				    return false;
				}
				public Integer OperationTypeLength(){
				    return 10;
				}
				public Integer OperationTypePrecision(){
				    return 0;
				}
				public String OperationTypeDefault(){
				
					return null;
				
				}
				public String OperationTypeComment(){
				
				    return "";
				
				}
				public String OperationTypePattern(){
				
					return "";
				
				}
				public String OperationTypeOriginalDbColumnName(){
				
					return "OperationType";
				
				}

				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.UserRoleID = dis.readInt();
					
			        this.AppUserID = dis.readInt();
					
			        this.AppRoleID = dis.readInt();
					
						this.CompanyID = readInteger(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.UserRoleID = dis.readInt();
					
			        this.AppUserID = dis.readInt();
					
			        this.AppRoleID = dis.readInt();
					
						this.CompanyID = readInteger(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.UserRoleID);
					
					// int
				
		            	dos.writeInt(this.AppUserID);
					
					// int
				
		            	dos.writeInt(this.AppRoleID);
					
					// Integer
				
						writeInteger(this.CompanyID,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.UserRoleID);
					
					// int
				
		            	dos.writeInt(this.AppUserID);
					
					// int
				
		            	dos.writeInt(this.AppRoleID);
					
					// Integer
				
						writeInteger(this.CompanyID,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("UserRoleID="+String.valueOf(UserRoleID));
		sb.append(",AppUserID="+String.valueOf(AppUserID));
		sb.append(",AppRoleID="+String.valueOf(AppRoleID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",OperationType="+OperationType);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(UserRoleID);
        			
        			sb.append("|");
        		
        				sb.append(AppUserID);
        			
        			sb.append("|");
        		
        				sb.append(AppRoleID);
        			
        			sb.append("|");
        		
        				if(CompanyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CompanyID);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(OperationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OperationType);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"UserRole_Log\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "CREATE_IF_NOT_EXISTS");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_SPATIAL_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("UserRole_Log");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("UserRole_Log");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
                                java.sql.DatabaseMetaData dbMetaData_tDBOutput_2 = conn_tDBOutput_2.getMetaData();
                                boolean whetherExist_tDBOutput_2 = false;
                                try (java.sql.ResultSet rsTable_tDBOutput_2 = dbMetaData_tDBOutput_2.getTables(null, null, null, new String[]{"TABLE"})) {
                                    String defaultSchema_tDBOutput_2 = "public";
                                    if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
                                        try(java.sql.Statement stmtSchema_tDBOutput_2 = conn_tDBOutput_2.createStatement();
                                            java.sql.ResultSet rsSchema_tDBOutput_2 = stmtSchema_tDBOutput_2.executeQuery("select current_schema() ")) {
                                            while(rsSchema_tDBOutput_2.next()){
                                                defaultSchema_tDBOutput_2 = rsSchema_tDBOutput_2.getString("current_schema");
                                            }
                                        }
                                    }
                                    while(rsTable_tDBOutput_2.next()) {
                                        String table_tDBOutput_2 = rsTable_tDBOutput_2.getString("TABLE_NAME");
                                        String schema_tDBOutput_2 = rsTable_tDBOutput_2.getString("TABLE_SCHEM");
                                        if(table_tDBOutput_2.equals(("UserRole_Log"))
                                            && (schema_tDBOutput_2.equals(dbschema_tDBOutput_2) || ((dbschema_tDBOutput_2 ==null || dbschema_tDBOutput_2.trim().length() ==0) && defaultSchema_tDBOutput_2.equals(schema_tDBOutput_2)))) {
                                            whetherExist_tDBOutput_2 = true;
                                            break;
                                        }
                                    }
                                }
                                if(!whetherExist_tDBOutput_2) {
                                    try (java.sql.Statement stmtCreate_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Creating")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("'.") );
                                        stmtCreate_tDBOutput_2.execute("CREATE TABLE \"" + tableName_tDBOutput_2 + "\"(\"UserRoleID\" INT4  not null ,\"AppUserID\" INT4  not null ,\"AppRoleID\" INT4  not null ,\"CompanyID\" INT4 ,\"CreatedBy\" INT4  not null ,\"CreatedDate\" TIMESTAMP(23)   not null ,\"ModifiedBy\" INT4 ,\"ModifiedDate\" TIMESTAMP(23)  ,\"OperationType\" VARCHAR(10)  )");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Create")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("' has succeeded.") );
                                    }
                                }
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"UserRoleID\",\"AppUserID\",\"AppRoleID\",\"CompanyID\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"OperationType\") VALUES (?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"UserRole_Log\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT FAMS.UserRole_Log.UserRoleID, 		FAMS.UserRole_Log.AppUserID, 		FAMS.UserRole_Log.AppRoleID, 		FAMS.UserRole_Log.CompanyID, 		FAMS.UserRole_Log.CreatedBy, 		FAMS.UserRole_Log.CreatedDate, 		FAMS.UserRole_Log.ModifiedBy, 		FAMS.UserRole_Log.ModifiedDate, 		FAMS.UserRole_Log.OperationType FROM	FAMS.UserRole_Log  WHERE FAMS.UserRole_Log.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.UserRole_Log.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("UserRoleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AppUserID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AppRoleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OperationType")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"UserRole_Log\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2); 
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT FAMS.UserRole_Log.UserRoleID,\n		FAMS.UserRole_Log.AppUserID,\n		FAMS.UserRole_Log.AppRoleID,\n		FAMS.UserRole_Log."
+"CompanyID,\n		FAMS.UserRole_Log.CreatedBy,\n		FAMS.UserRole_Log.CreatedDate,\n		FAMS.UserRole_Log.ModifiedBy,\n		FAMS.UserRo"
+"le_Log.ModifiedDate,\n		FAMS.UserRole_Log.OperationType\nFROM	FAMS.UserRole_Log\nWHERE FAMS.UserRole_Log.CreatedDate >= DA"
+"TEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAMS.UserRole_Log.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.UserRoleID = 0;
							} else {
		                          
            row2.UserRoleID = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.AppUserID = 0;
							} else {
		                          
            row2.AppUserID = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.AppRoleID = 0;
							} else {
		                          
            row2.AppRoleID = rs_tDBInput_2.getInt(3);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.CompanyID = null;
							} else {
		                          
            row2.CompanyID = rs_tDBInput_2.getInt(4);
            if(rs_tDBInput_2.wasNull()){
                    row2.CompanyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.CreatedBy = 0;
							} else {
		                          
            row2.CreatedBy = rs_tDBInput_2.getInt(5);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.CreatedDate = null;
							} else {
										
			row2.CreatedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 6);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.ModifiedBy = null;
							} else {
		                          
            row2.ModifiedBy = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    row2.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.ModifiedDate = null;
							} else {
										
			row2.ModifiedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 8);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.OperationType = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(9);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.OperationType = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.OperationType = tmpContent_tDBInput_2;
                }
            } else {
                row2.OperationType = null;
            }
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					





 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"UserRole_Log\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, row2.UserRoleID);

                    pstmt_tDBOutput_2.setInt(2, row2.AppUserID);

                    pstmt_tDBOutput_2.setInt(3, row2.AppRoleID);

                    if(row2.CompanyID == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(4, row2.CompanyID);
}

                    pstmt_tDBOutput_2.setInt(5, row2.CreatedBy);

                    if(row2.CreatedDate != null) {
pstmt_tDBOutput_2.setTimestamp(6, new java.sql.Timestamp(row2.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row2.ModifiedBy == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, row2.ModifiedBy);
}

                    if(row2.ModifiedDate != null) {
pstmt_tDBOutput_2.setTimestamp(8, new java.sql.Timestamp(row2.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(row2.OperationType == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(9, row2.OperationType);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_2)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"UserRole_Log\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"UserRole_Log\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int VendorID;

				public int getVendorID () {
					return this.VendorID;
				}

				public Boolean VendorIDIsNullable(){
				    return false;
				}
				public Boolean VendorIDIsKey(){
				    return true;
				}
				public Integer VendorIDLength(){
				    return 10;
				}
				public Integer VendorIDPrecision(){
				    return 0;
				}
				public String VendorIDDefault(){
				
					return null;
				
				}
				public String VendorIDComment(){
				
				    return "";
				
				}
				public String VendorIDPattern(){
				
					return "";
				
				}
				public String VendorIDOriginalDbColumnName(){
				
					return "VendorID";
				
				}

				
			    public String VendorCode;

				public String getVendorCode () {
					return this.VendorCode;
				}

				public Boolean VendorCodeIsNullable(){
				    return false;
				}
				public Boolean VendorCodeIsKey(){
				    return false;
				}
				public Integer VendorCodeLength(){
				    return 50;
				}
				public Integer VendorCodePrecision(){
				    return 0;
				}
				public String VendorCodeDefault(){
				
					return null;
				
				}
				public String VendorCodeComment(){
				
				    return "";
				
				}
				public String VendorCodePattern(){
				
					return "";
				
				}
				public String VendorCodeOriginalDbColumnName(){
				
					return "VendorCode";
				
				}

				
			    public String VendorName;

				public String getVendorName () {
					return this.VendorName;
				}

				public Boolean VendorNameIsNullable(){
				    return true;
				}
				public Boolean VendorNameIsKey(){
				    return false;
				}
				public Integer VendorNameLength(){
				    return 200;
				}
				public Integer VendorNamePrecision(){
				    return 0;
				}
				public String VendorNameDefault(){
				
					return null;
				
				}
				public String VendorNameComment(){
				
				    return "";
				
				}
				public String VendorNamePattern(){
				
					return "";
				
				}
				public String VendorNameOriginalDbColumnName(){
				
					return "VendorName";
				
				}

				
			    public Integer BusinessTypeID;

				public Integer getBusinessTypeID () {
					return this.BusinessTypeID;
				}

				public Boolean BusinessTypeIDIsNullable(){
				    return true;
				}
				public Boolean BusinessTypeIDIsKey(){
				    return false;
				}
				public Integer BusinessTypeIDLength(){
				    return 10;
				}
				public Integer BusinessTypeIDPrecision(){
				    return 0;
				}
				public String BusinessTypeIDDefault(){
				
					return null;
				
				}
				public String BusinessTypeIDComment(){
				
				    return "";
				
				}
				public String BusinessTypeIDPattern(){
				
					return "";
				
				}
				public String BusinessTypeIDOriginalDbColumnName(){
				
					return "BusinessTypeID";
				
				}

				
			    public String Add1;

				public String getAdd1 () {
					return this.Add1;
				}

				public Boolean Add1IsNullable(){
				    return true;
				}
				public Boolean Add1IsKey(){
				    return false;
				}
				public Integer Add1Length(){
				    return 100;
				}
				public Integer Add1Precision(){
				    return 0;
				}
				public String Add1Default(){
				
					return null;
				
				}
				public String Add1Comment(){
				
				    return "";
				
				}
				public String Add1Pattern(){
				
					return "";
				
				}
				public String Add1OriginalDbColumnName(){
				
					return "Add1";
				
				}

				
			    public String Add2;

				public String getAdd2 () {
					return this.Add2;
				}

				public Boolean Add2IsNullable(){
				    return true;
				}
				public Boolean Add2IsKey(){
				    return false;
				}
				public Integer Add2Length(){
				    return 100;
				}
				public Integer Add2Precision(){
				    return 0;
				}
				public String Add2Default(){
				
					return null;
				
				}
				public String Add2Comment(){
				
				    return "";
				
				}
				public String Add2Pattern(){
				
					return "";
				
				}
				public String Add2OriginalDbColumnName(){
				
					return "Add2";
				
				}

				
			    public String Add3;

				public String getAdd3 () {
					return this.Add3;
				}

				public Boolean Add3IsNullable(){
				    return true;
				}
				public Boolean Add3IsKey(){
				    return false;
				}
				public Integer Add3Length(){
				    return 100;
				}
				public Integer Add3Precision(){
				    return 0;
				}
				public String Add3Default(){
				
					return null;
				
				}
				public String Add3Comment(){
				
				    return "";
				
				}
				public String Add3Pattern(){
				
					return "";
				
				}
				public String Add3OriginalDbColumnName(){
				
					return "Add3";
				
				}

				
			    public String Add4;

				public String getAdd4 () {
					return this.Add4;
				}

				public Boolean Add4IsNullable(){
				    return true;
				}
				public Boolean Add4IsKey(){
				    return false;
				}
				public Integer Add4Length(){
				    return 100;
				}
				public Integer Add4Precision(){
				    return 0;
				}
				public String Add4Default(){
				
					return null;
				
				}
				public String Add4Comment(){
				
				    return "";
				
				}
				public String Add4Pattern(){
				
					return "";
				
				}
				public String Add4OriginalDbColumnName(){
				
					return "Add4";
				
				}

				
			    public Integer City;

				public Integer getCity () {
					return this.City;
				}

				public Boolean CityIsNullable(){
				    return true;
				}
				public Boolean CityIsKey(){
				    return false;
				}
				public Integer CityLength(){
				    return 10;
				}
				public Integer CityPrecision(){
				    return 0;
				}
				public String CityDefault(){
				
					return null;
				
				}
				public String CityComment(){
				
				    return "";
				
				}
				public String CityPattern(){
				
					return "";
				
				}
				public String CityOriginalDbColumnName(){
				
					return "City";
				
				}

				
			    public Integer State;

				public Integer getState () {
					return this.State;
				}

				public Boolean StateIsNullable(){
				    return true;
				}
				public Boolean StateIsKey(){
				    return false;
				}
				public Integer StateLength(){
				    return 10;
				}
				public Integer StatePrecision(){
				    return 0;
				}
				public String StateDefault(){
				
					return null;
				
				}
				public String StateComment(){
				
				    return "";
				
				}
				public String StatePattern(){
				
					return "";
				
				}
				public String StateOriginalDbColumnName(){
				
					return "State";
				
				}

				
			    public String PinCode;

				public String getPinCode () {
					return this.PinCode;
				}

				public Boolean PinCodeIsNullable(){
				    return true;
				}
				public Boolean PinCodeIsKey(){
				    return false;
				}
				public Integer PinCodeLength(){
				    return 6;
				}
				public Integer PinCodePrecision(){
				    return 0;
				}
				public String PinCodeDefault(){
				
					return null;
				
				}
				public String PinCodeComment(){
				
				    return "";
				
				}
				public String PinCodePattern(){
				
					return "";
				
				}
				public String PinCodeOriginalDbColumnName(){
				
					return "PinCode";
				
				}

				
			    public String STDCode;

				public String getSTDCode () {
					return this.STDCode;
				}

				public Boolean STDCodeIsNullable(){
				    return true;
				}
				public Boolean STDCodeIsKey(){
				    return false;
				}
				public Integer STDCodeLength(){
				    return 10;
				}
				public Integer STDCodePrecision(){
				    return 0;
				}
				public String STDCodeDefault(){
				
					return null;
				
				}
				public String STDCodeComment(){
				
				    return "";
				
				}
				public String STDCodePattern(){
				
					return "";
				
				}
				public String STDCodeOriginalDbColumnName(){
				
					return "STDCode";
				
				}

				
			    public String TelephoneNo;

				public String getTelephoneNo () {
					return this.TelephoneNo;
				}

				public Boolean TelephoneNoIsNullable(){
				    return true;
				}
				public Boolean TelephoneNoIsKey(){
				    return false;
				}
				public Integer TelephoneNoLength(){
				    return 20;
				}
				public Integer TelephoneNoPrecision(){
				    return 0;
				}
				public String TelephoneNoDefault(){
				
					return null;
				
				}
				public String TelephoneNoComment(){
				
				    return "";
				
				}
				public String TelephoneNoPattern(){
				
					return "";
				
				}
				public String TelephoneNoOriginalDbColumnName(){
				
					return "TelephoneNo";
				
				}

				
			    public String EmailID;

				public String getEmailID () {
					return this.EmailID;
				}

				public Boolean EmailIDIsNullable(){
				    return true;
				}
				public Boolean EmailIDIsKey(){
				    return false;
				}
				public Integer EmailIDLength(){
				    return 50;
				}
				public Integer EmailIDPrecision(){
				    return 0;
				}
				public String EmailIDDefault(){
				
					return null;
				
				}
				public String EmailIDComment(){
				
				    return "";
				
				}
				public String EmailIDPattern(){
				
					return "";
				
				}
				public String EmailIDOriginalDbColumnName(){
				
					return "EmailID";
				
				}

				
			    public String MobNo;

				public String getMobNo () {
					return this.MobNo;
				}

				public Boolean MobNoIsNullable(){
				    return true;
				}
				public Boolean MobNoIsKey(){
				    return false;
				}
				public Integer MobNoLength(){
				    return 20;
				}
				public Integer MobNoPrecision(){
				    return 0;
				}
				public String MobNoDefault(){
				
					return null;
				
				}
				public String MobNoComment(){
				
				    return "";
				
				}
				public String MobNoPattern(){
				
					return "";
				
				}
				public String MobNoOriginalDbColumnName(){
				
					return "MobNo";
				
				}

				
			    public String VATTINNo;

				public String getVATTINNo () {
					return this.VATTINNo;
				}

				public Boolean VATTINNoIsNullable(){
				    return true;
				}
				public Boolean VATTINNoIsKey(){
				    return false;
				}
				public Integer VATTINNoLength(){
				    return 50;
				}
				public Integer VATTINNoPrecision(){
				    return 0;
				}
				public String VATTINNoDefault(){
				
					return null;
				
				}
				public String VATTINNoComment(){
				
				    return "";
				
				}
				public String VATTINNoPattern(){
				
					return "";
				
				}
				public String VATTINNoOriginalDbColumnName(){
				
					return "VATTINNo";
				
				}

				
			    public String CSTTINNo;

				public String getCSTTINNo () {
					return this.CSTTINNo;
				}

				public Boolean CSTTINNoIsNullable(){
				    return true;
				}
				public Boolean CSTTINNoIsKey(){
				    return false;
				}
				public Integer CSTTINNoLength(){
				    return 50;
				}
				public Integer CSTTINNoPrecision(){
				    return 0;
				}
				public String CSTTINNoDefault(){
				
					return null;
				
				}
				public String CSTTINNoComment(){
				
				    return "";
				
				}
				public String CSTTINNoPattern(){
				
					return "";
				
				}
				public String CSTTINNoOriginalDbColumnName(){
				
					return "CSTTINNo";
				
				}

				
			    public String PANNo;

				public String getPANNo () {
					return this.PANNo;
				}

				public Boolean PANNoIsNullable(){
				    return true;
				}
				public Boolean PANNoIsKey(){
				    return false;
				}
				public Integer PANNoLength(){
				    return 50;
				}
				public Integer PANNoPrecision(){
				    return 0;
				}
				public String PANNoDefault(){
				
					return null;
				
				}
				public String PANNoComment(){
				
				    return "";
				
				}
				public String PANNoPattern(){
				
					return "";
				
				}
				public String PANNoOriginalDbColumnName(){
				
					return "PANNo";
				
				}

				
			    public String CompanyWebsite;

				public String getCompanyWebsite () {
					return this.CompanyWebsite;
				}

				public Boolean CompanyWebsiteIsNullable(){
				    return true;
				}
				public Boolean CompanyWebsiteIsKey(){
				    return false;
				}
				public Integer CompanyWebsiteLength(){
				    return 50;
				}
				public Integer CompanyWebsitePrecision(){
				    return 0;
				}
				public String CompanyWebsiteDefault(){
				
					return null;
				
				}
				public String CompanyWebsiteComment(){
				
				    return "";
				
				}
				public String CompanyWebsitePattern(){
				
					return "";
				
				}
				public String CompanyWebsiteOriginalDbColumnName(){
				
					return "CompanyWebsite";
				
				}

				
			    public String VendorServiceTaxNo;

				public String getVendorServiceTaxNo () {
					return this.VendorServiceTaxNo;
				}

				public Boolean VendorServiceTaxNoIsNullable(){
				    return true;
				}
				public Boolean VendorServiceTaxNoIsKey(){
				    return false;
				}
				public Integer VendorServiceTaxNoLength(){
				    return 50;
				}
				public Integer VendorServiceTaxNoPrecision(){
				    return 0;
				}
				public String VendorServiceTaxNoDefault(){
				
					return null;
				
				}
				public String VendorServiceTaxNoComment(){
				
				    return "";
				
				}
				public String VendorServiceTaxNoPattern(){
				
					return "";
				
				}
				public String VendorServiceTaxNoOriginalDbColumnName(){
				
					return "VendorServiceTaxNo";
				
				}

				
			    public Short IsVendorRegistered;

				public Short getIsVendorRegistered () {
					return this.IsVendorRegistered;
				}

				public Boolean IsVendorRegisteredIsNullable(){
				    return true;
				}
				public Boolean IsVendorRegisteredIsKey(){
				    return false;
				}
				public Integer IsVendorRegisteredLength(){
				    return 5;
				}
				public Integer IsVendorRegisteredPrecision(){
				    return 0;
				}
				public String IsVendorRegisteredDefault(){
				
					return null;
				
				}
				public String IsVendorRegisteredComment(){
				
				    return "";
				
				}
				public String IsVendorRegisteredPattern(){
				
					return "";
				
				}
				public String IsVendorRegisteredOriginalDbColumnName(){
				
					return "IsVendorRegistered";
				
				}

				
			    public String VendorProfile;

				public String getVendorProfile () {
					return this.VendorProfile;
				}

				public Boolean VendorProfileIsNullable(){
				    return true;
				}
				public Boolean VendorProfileIsKey(){
				    return false;
				}
				public Integer VendorProfileLength(){
				    return 50;
				}
				public Integer VendorProfilePrecision(){
				    return 0;
				}
				public String VendorProfileDefault(){
				
					return null;
				
				}
				public String VendorProfileComment(){
				
				    return "";
				
				}
				public String VendorProfilePattern(){
				
					return "";
				
				}
				public String VendorProfileOriginalDbColumnName(){
				
					return "VendorProfile";
				
				}

				
			    public String VendorProductLine;

				public String getVendorProductLine () {
					return this.VendorProductLine;
				}

				public Boolean VendorProductLineIsNullable(){
				    return true;
				}
				public Boolean VendorProductLineIsKey(){
				    return false;
				}
				public Integer VendorProductLineLength(){
				    return 50;
				}
				public Integer VendorProductLinePrecision(){
				    return 0;
				}
				public String VendorProductLineDefault(){
				
					return null;
				
				}
				public String VendorProductLineComment(){
				
				    return "";
				
				}
				public String VendorProductLinePattern(){
				
					return "";
				
				}
				public String VendorProductLineOriginalDbColumnName(){
				
					return "VendorProductLine";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return "((1))";
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public String GSTINNo;

				public String getGSTINNo () {
					return this.GSTINNo;
				}

				public Boolean GSTINNoIsNullable(){
				    return true;
				}
				public Boolean GSTINNoIsKey(){
				    return false;
				}
				public Integer GSTINNoLength(){
				    return 30;
				}
				public Integer GSTINNoPrecision(){
				    return 0;
				}
				public String GSTINNoDefault(){
				
					return null;
				
				}
				public String GSTINNoComment(){
				
				    return "";
				
				}
				public String GSTINNoPattern(){
				
					return "";
				
				}
				public String GSTINNoOriginalDbColumnName(){
				
					return "GSTINNo";
				
				}

				
			    public String SiteLocation;

				public String getSiteLocation () {
					return this.SiteLocation;
				}

				public Boolean SiteLocationIsNullable(){
				    return true;
				}
				public Boolean SiteLocationIsKey(){
				    return false;
				}
				public Integer SiteLocationLength(){
				    return 200;
				}
				public Integer SiteLocationPrecision(){
				    return 0;
				}
				public String SiteLocationDefault(){
				
					return null;
				
				}
				public String SiteLocationComment(){
				
				    return "";
				
				}
				public String SiteLocationPattern(){
				
					return "";
				
				}
				public String SiteLocationOriginalDbColumnName(){
				
					return "SiteLocation";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.VendorID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.VendorID != other.VendorID)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.VendorID = this.VendorID;
	            other.VendorCode = this.VendorCode;
	            other.VendorName = this.VendorName;
	            other.BusinessTypeID = this.BusinessTypeID;
	            other.Add1 = this.Add1;
	            other.Add2 = this.Add2;
	            other.Add3 = this.Add3;
	            other.Add4 = this.Add4;
	            other.City = this.City;
	            other.State = this.State;
	            other.PinCode = this.PinCode;
	            other.STDCode = this.STDCode;
	            other.TelephoneNo = this.TelephoneNo;
	            other.EmailID = this.EmailID;
	            other.MobNo = this.MobNo;
	            other.VATTINNo = this.VATTINNo;
	            other.CSTTINNo = this.CSTTINNo;
	            other.PANNo = this.PANNo;
	            other.CompanyWebsite = this.CompanyWebsite;
	            other.VendorServiceTaxNo = this.VendorServiceTaxNo;
	            other.IsVendorRegistered = this.IsVendorRegistered;
	            other.VendorProfile = this.VendorProfile;
	            other.VendorProductLine = this.VendorProductLine;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            other.CompanyID = this.CompanyID;
	            other.GSTINNo = this.GSTINNo;
	            other.SiteLocation = this.SiteLocation;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.VendorID = this.VendorID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.VendorID = dis.readInt();
					
					this.VendorCode = readString(dis);
					
					this.VendorName = readString(dis);
					
						this.BusinessTypeID = readInteger(dis);
					
					this.Add1 = readString(dis);
					
					this.Add2 = readString(dis);
					
					this.Add3 = readString(dis);
					
					this.Add4 = readString(dis);
					
						this.City = readInteger(dis);
					
						this.State = readInteger(dis);
					
					this.PinCode = readString(dis);
					
					this.STDCode = readString(dis);
					
					this.TelephoneNo = readString(dis);
					
					this.EmailID = readString(dis);
					
					this.MobNo = readString(dis);
					
					this.VATTINNo = readString(dis);
					
					this.CSTTINNo = readString(dis);
					
					this.PANNo = readString(dis);
					
					this.CompanyWebsite = readString(dis);
					
					this.VendorServiceTaxNo = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.IsVendorRegistered = null;
           				} else {
           			    	this.IsVendorRegistered = dis.readShort();
           				}
					
					this.VendorProfile = readString(dis);
					
					this.VendorProductLine = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
			        this.CompanyID = dis.readInt();
					
					this.GSTINNo = readString(dis);
					
					this.SiteLocation = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.VendorID = dis.readInt();
					
					this.VendorCode = readString(dis);
					
					this.VendorName = readString(dis);
					
						this.BusinessTypeID = readInteger(dis);
					
					this.Add1 = readString(dis);
					
					this.Add2 = readString(dis);
					
					this.Add3 = readString(dis);
					
					this.Add4 = readString(dis);
					
						this.City = readInteger(dis);
					
						this.State = readInteger(dis);
					
					this.PinCode = readString(dis);
					
					this.STDCode = readString(dis);
					
					this.TelephoneNo = readString(dis);
					
					this.EmailID = readString(dis);
					
					this.MobNo = readString(dis);
					
					this.VATTINNo = readString(dis);
					
					this.CSTTINNo = readString(dis);
					
					this.PANNo = readString(dis);
					
					this.CompanyWebsite = readString(dis);
					
					this.VendorServiceTaxNo = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.IsVendorRegistered = null;
           				} else {
           			    	this.IsVendorRegistered = dis.readShort();
           				}
					
					this.VendorProfile = readString(dis);
					
					this.VendorProductLine = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
			        this.CompanyID = dis.readInt();
					
					this.GSTINNo = readString(dis);
					
					this.SiteLocation = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.VendorID);
					
					// String
				
						writeString(this.VendorCode,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// Integer
				
						writeInteger(this.BusinessTypeID,dos);
					
					// String
				
						writeString(this.Add1,dos);
					
					// String
				
						writeString(this.Add2,dos);
					
					// String
				
						writeString(this.Add3,dos);
					
					// String
				
						writeString(this.Add4,dos);
					
					// Integer
				
						writeInteger(this.City,dos);
					
					// Integer
				
						writeInteger(this.State,dos);
					
					// String
				
						writeString(this.PinCode,dos);
					
					// String
				
						writeString(this.STDCode,dos);
					
					// String
				
						writeString(this.TelephoneNo,dos);
					
					// String
				
						writeString(this.EmailID,dos);
					
					// String
				
						writeString(this.MobNo,dos);
					
					// String
				
						writeString(this.VATTINNo,dos);
					
					// String
				
						writeString(this.CSTTINNo,dos);
					
					// String
				
						writeString(this.PANNo,dos);
					
					// String
				
						writeString(this.CompanyWebsite,dos);
					
					// String
				
						writeString(this.VendorServiceTaxNo,dos);
					
					// Short
				
						if(this.IsVendorRegistered == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.IsVendorRegistered);
		            	}
					
					// String
				
						writeString(this.VendorProfile,dos);
					
					// String
				
						writeString(this.VendorProductLine,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// String
				
						writeString(this.GSTINNo,dos);
					
					// String
				
						writeString(this.SiteLocation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.VendorID);
					
					// String
				
						writeString(this.VendorCode,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// Integer
				
						writeInteger(this.BusinessTypeID,dos);
					
					// String
				
						writeString(this.Add1,dos);
					
					// String
				
						writeString(this.Add2,dos);
					
					// String
				
						writeString(this.Add3,dos);
					
					// String
				
						writeString(this.Add4,dos);
					
					// Integer
				
						writeInteger(this.City,dos);
					
					// Integer
				
						writeInteger(this.State,dos);
					
					// String
				
						writeString(this.PinCode,dos);
					
					// String
				
						writeString(this.STDCode,dos);
					
					// String
				
						writeString(this.TelephoneNo,dos);
					
					// String
				
						writeString(this.EmailID,dos);
					
					// String
				
						writeString(this.MobNo,dos);
					
					// String
				
						writeString(this.VATTINNo,dos);
					
					// String
				
						writeString(this.CSTTINNo,dos);
					
					// String
				
						writeString(this.PANNo,dos);
					
					// String
				
						writeString(this.CompanyWebsite,dos);
					
					// String
				
						writeString(this.VendorServiceTaxNo,dos);
					
					// Short
				
						if(this.IsVendorRegistered == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.IsVendorRegistered);
		            	}
					
					// String
				
						writeString(this.VendorProfile,dos);
					
					// String
				
						writeString(this.VendorProductLine,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// String
				
						writeString(this.GSTINNo,dos);
					
					// String
				
						writeString(this.SiteLocation,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("VendorID="+String.valueOf(VendorID));
		sb.append(",VendorCode="+VendorCode);
		sb.append(",VendorName="+VendorName);
		sb.append(",BusinessTypeID="+String.valueOf(BusinessTypeID));
		sb.append(",Add1="+Add1);
		sb.append(",Add2="+Add2);
		sb.append(",Add3="+Add3);
		sb.append(",Add4="+Add4);
		sb.append(",City="+String.valueOf(City));
		sb.append(",State="+String.valueOf(State));
		sb.append(",PinCode="+PinCode);
		sb.append(",STDCode="+STDCode);
		sb.append(",TelephoneNo="+TelephoneNo);
		sb.append(",EmailID="+EmailID);
		sb.append(",MobNo="+MobNo);
		sb.append(",VATTINNo="+VATTINNo);
		sb.append(",CSTTINNo="+CSTTINNo);
		sb.append(",PANNo="+PANNo);
		sb.append(",CompanyWebsite="+CompanyWebsite);
		sb.append(",VendorServiceTaxNo="+VendorServiceTaxNo);
		sb.append(",IsVendorRegistered="+String.valueOf(IsVendorRegistered));
		sb.append(",VendorProfile="+VendorProfile);
		sb.append(",VendorProductLine="+VendorProductLine);
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",GSTINNo="+GSTINNo);
		sb.append(",SiteLocation="+SiteLocation);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(VendorID);
        			
        			sb.append("|");
        		
        				if(VendorCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorCode);
            			}
            		
        			sb.append("|");
        		
        				if(VendorName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorName);
            			}
            		
        			sb.append("|");
        		
        				if(BusinessTypeID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BusinessTypeID);
            			}
            		
        			sb.append("|");
        		
        				if(Add1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Add1);
            			}
            		
        			sb.append("|");
        		
        				if(Add2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Add2);
            			}
            		
        			sb.append("|");
        		
        				if(Add3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Add3);
            			}
            		
        			sb.append("|");
        		
        				if(Add4 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Add4);
            			}
            		
        			sb.append("|");
        		
        				if(City == null){
        					sb.append("<null>");
        				}else{
            				sb.append(City);
            			}
            		
        			sb.append("|");
        		
        				if(State == null){
        					sb.append("<null>");
        				}else{
            				sb.append(State);
            			}
            		
        			sb.append("|");
        		
        				if(PinCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PinCode);
            			}
            		
        			sb.append("|");
        		
        				if(STDCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STDCode);
            			}
            		
        			sb.append("|");
        		
        				if(TelephoneNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TelephoneNo);
            			}
            		
        			sb.append("|");
        		
        				if(EmailID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EmailID);
            			}
            		
        			sb.append("|");
        		
        				if(MobNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MobNo);
            			}
            		
        			sb.append("|");
        		
        				if(VATTINNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VATTINNo);
            			}
            		
        			sb.append("|");
        		
        				if(CSTTINNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CSTTINNo);
            			}
            		
        			sb.append("|");
        		
        				if(PANNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PANNo);
            			}
            		
        			sb.append("|");
        		
        				if(CompanyWebsite == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CompanyWebsite);
            			}
            		
        			sb.append("|");
        		
        				if(VendorServiceTaxNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorServiceTaxNo);
            			}
            		
        			sb.append("|");
        		
        				if(IsVendorRegistered == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IsVendorRegistered);
            			}
            		
        			sb.append("|");
        		
        				if(VendorProfile == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorProfile);
            			}
            		
        			sb.append("|");
        		
        				if(VendorProductLine == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorProductLine);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				if(GSTINNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(GSTINNo);
            			}
            		
        			sb.append("|");
        		
        				if(SiteLocation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SiteLocation);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.VendorID, other.VendorID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"Vendor\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("Vendor");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("Vendor");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"VendorID\",\"VendorCode\",\"VendorName\",\"BusinessTypeID\",\"Add1\",\"Add2\",\"Add3\",\"Add4\",\"City\",\"State\",\"PinCode\",\"STDCode\",\"TelephoneNo\",\"EmailID\",\"MobNo\",\"VATTINNo\",\"CSTTINNo\",\"PANNo\",\"CompanyWebsite\",\"VendorServiceTaxNo\",\"IsVendorRegistered\",\"VendorProfile\",\"VendorProductLine\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"CompanyID\",\"GSTINNo\",\"SiteLocation\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"Vendor\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT FAMS.Vendor.VendorID, 		FAMS.Vendor.VendorCode, 		FAMS.Vendor.VendorName, 		FAMS.Vendor.BusinessTypeID, 		FAMS.Vendor.Add1, 		FAMS.Vendor.Add2, 		FAMS.Vendor.Add3, 		FAMS.Vendor.Add4, 		FAMS.Vendor.City, 		FAMS.Vendor.State, 		FAMS.Vendor.PinCode, 		FAMS.Vendor.STDCode, 		FAMS.Vendor.TelephoneNo, 		FAMS.Vendor.EmailID, 		FAMS.Vendor.MobNo, 		FAMS.Vendor.VATTINNo, 		FAMS.Vendor.CSTTINNo, 		FAMS.Vendor.PANNo, 		FAMS.Vendor.CompanyWebsite, 		FAMS.Vendor.VendorServiceTaxNo, 		FAMS.Vendor.IsVendorRegistered, 		FAMS.Vendor.VendorProfile, 		FAMS.Vendor.VendorProductLine, 		FAMS.Vendor.CreatedBy, 		FAMS.Vendor.CreatedDate, 		FAMS.Vendor.ModifiedBy, 		FAMS.Vendor.ModifiedDate, 		FAMS.Vendor.CompanyID, 		FAMS.Vendor.GSTINNo, 		FAMS.Vendor.SiteLocation FROM	FAMS.Vendor  WHERE FAMS.Vendor.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.Vendor.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("VendorID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BusinessTypeID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Add1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Add2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Add3")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Add4")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("City")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("State")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PinCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("STDCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TelephoneNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EmailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MobNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VATTINNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CSTTINNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PANNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyWebsite")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorServiceTaxNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IsVendorRegistered")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorProfile")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorProductLine")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("GSTINNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SiteLocation")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"Vendor\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3); 
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT FAMS.Vendor.VendorID,\n		FAMS.Vendor.VendorCode,\n		FAMS.Vendor.VendorName,\n		FAMS.Vendor.BusinessTypeID,\n		FAMS.V"
+"endor.Add1,\n		FAMS.Vendor.Add2,\n		FAMS.Vendor.Add3,\n		FAMS.Vendor.Add4,\n		FAMS.Vendor.City,\n		FAMS.Vendor.State,\n		FAMS."
+"Vendor.PinCode,\n		FAMS.Vendor.STDCode,\n		FAMS.Vendor.TelephoneNo,\n		FAMS.Vendor.EmailID,\n		FAMS.Vendor.MobNo,\n		FAMS.Ven"
+"dor.VATTINNo,\n		FAMS.Vendor.CSTTINNo,\n		FAMS.Vendor.PANNo,\n		FAMS.Vendor.CompanyWebsite,\n		FAMS.Vendor.VendorServiceTaxN"
+"o,\n		FAMS.Vendor.IsVendorRegistered,\n		FAMS.Vendor.VendorProfile,\n		FAMS.Vendor.VendorProductLine,\n		FAMS.Vendor.Created"
+"By,\n		FAMS.Vendor.CreatedDate,\n		FAMS.Vendor.ModifiedBy,\n		FAMS.Vendor.ModifiedDate,\n		FAMS.Vendor.CompanyID,\n		FAMS.Ven"
+"dor.GSTINNo,\n		FAMS.Vendor.SiteLocation\nFROM	FAMS.Vendor\nWHERE FAMS.Vendor.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE"
+"() AS DATE))\n      AND FAMS.Vendor.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.VendorID = 0;
							} else {
		                          
            row3.VendorID = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.VendorCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(2);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VendorCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VendorCode = tmpContent_tDBInput_3;
                }
            } else {
                row3.VendorCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.VendorName = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(3);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VendorName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VendorName = tmpContent_tDBInput_3;
                }
            } else {
                row3.VendorName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.BusinessTypeID = null;
							} else {
		                          
            row3.BusinessTypeID = rs_tDBInput_3.getInt(4);
            if(rs_tDBInput_3.wasNull()){
                    row3.BusinessTypeID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.Add1 = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(5);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Add1 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Add1 = tmpContent_tDBInput_3;
                }
            } else {
                row3.Add1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.Add2 = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(6);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Add2 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Add2 = tmpContent_tDBInput_3;
                }
            } else {
                row3.Add2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.Add3 = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(7);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Add3 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Add3 = tmpContent_tDBInput_3;
                }
            } else {
                row3.Add3 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.Add4 = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(8);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Add4 = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Add4 = tmpContent_tDBInput_3;
                }
            } else {
                row3.Add4 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.City = null;
							} else {
		                          
            row3.City = rs_tDBInput_3.getInt(9);
            if(rs_tDBInput_3.wasNull()){
                    row3.City = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.State = null;
							} else {
		                          
            row3.State = rs_tDBInput_3.getInt(10);
            if(rs_tDBInput_3.wasNull()){
                    row3.State = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 11) {
								row3.PinCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(11);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.PinCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.PinCode = tmpContent_tDBInput_3;
                }
            } else {
                row3.PinCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 12) {
								row3.STDCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(12);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.STDCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.STDCode = tmpContent_tDBInput_3;
                }
            } else {
                row3.STDCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 13) {
								row3.TelephoneNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(13);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.TelephoneNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.TelephoneNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.TelephoneNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 14) {
								row3.EmailID = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(14);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.EmailID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.EmailID = tmpContent_tDBInput_3;
                }
            } else {
                row3.EmailID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 15) {
								row3.MobNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(15);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.MobNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.MobNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.MobNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 16) {
								row3.VATTINNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(16);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VATTINNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VATTINNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.VATTINNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 17) {
								row3.CSTTINNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(17);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.CSTTINNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.CSTTINNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.CSTTINNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 18) {
								row3.PANNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(18);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.PANNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.PANNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.PANNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 19) {
								row3.CompanyWebsite = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(19);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.CompanyWebsite = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.CompanyWebsite = tmpContent_tDBInput_3;
                }
            } else {
                row3.CompanyWebsite = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 20) {
								row3.VendorServiceTaxNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(20);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VendorServiceTaxNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VendorServiceTaxNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.VendorServiceTaxNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 21) {
								row3.IsVendorRegistered = null;
							} else {
		                          
            row3.IsVendorRegistered = rs_tDBInput_3.getShort(21);
            if(rs_tDBInput_3.wasNull()){
                    row3.IsVendorRegistered = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 22) {
								row3.VendorProfile = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(22);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(22).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VendorProfile = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VendorProfile = tmpContent_tDBInput_3;
                }
            } else {
                row3.VendorProfile = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 23) {
								row3.VendorProductLine = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(23);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(23).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VendorProductLine = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VendorProductLine = tmpContent_tDBInput_3;
                }
            } else {
                row3.VendorProductLine = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 24) {
								row3.CreatedBy = 0;
							} else {
		                          
            row3.CreatedBy = rs_tDBInput_3.getInt(24);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 25) {
								row3.CreatedDate = null;
							} else {
										
			row3.CreatedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 25);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 26) {
								row3.ModifiedBy = null;
							} else {
		                          
            row3.ModifiedBy = rs_tDBInput_3.getInt(26);
            if(rs_tDBInput_3.wasNull()){
                    row3.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 27) {
								row3.ModifiedDate = null;
							} else {
										
			row3.ModifiedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 27);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 28) {
								row3.CompanyID = 0;
							} else {
		                          
            row3.CompanyID = rs_tDBInput_3.getInt(28);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 29) {
								row3.GSTINNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(29);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(29).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.GSTINNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.GSTINNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.GSTINNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 30) {
								row3.SiteLocation = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(30);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(30).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.SiteLocation = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.SiteLocation = tmpContent_tDBInput_3;
                }
            } else {
                row3.SiteLocation = null;
            }
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					





 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"Vendor\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, row3.VendorID);

                    if(row3.VendorCode == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row3.VendorCode);
}

                    if(row3.VendorName == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row3.VendorName);
}

                    if(row3.BusinessTypeID == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(4, row3.BusinessTypeID);
}

                    if(row3.Add1 == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row3.Add1);
}

                    if(row3.Add2 == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, row3.Add2);
}

                    if(row3.Add3 == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, row3.Add3);
}

                    if(row3.Add4 == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, row3.Add4);
}

                    if(row3.City == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(9, row3.City);
}

                    if(row3.State == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(10, row3.State);
}

                    if(row3.PinCode == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, row3.PinCode);
}

                    if(row3.STDCode == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(12, row3.STDCode);
}

                    if(row3.TelephoneNo == null) {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(13, row3.TelephoneNo);
}

                    if(row3.EmailID == null) {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(14, row3.EmailID);
}

                    if(row3.MobNo == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(15, row3.MobNo);
}

                    if(row3.VATTINNo == null) {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(16, row3.VATTINNo);
}

                    if(row3.CSTTINNo == null) {
pstmt_tDBOutput_3.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(17, row3.CSTTINNo);
}

                    if(row3.PANNo == null) {
pstmt_tDBOutput_3.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(18, row3.PANNo);
}

                    if(row3.CompanyWebsite == null) {
pstmt_tDBOutput_3.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(19, row3.CompanyWebsite);
}

                    if(row3.VendorServiceTaxNo == null) {
pstmt_tDBOutput_3.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(20, row3.VendorServiceTaxNo);
}

                    if(row3.IsVendorRegistered == null) {
pstmt_tDBOutput_3.setNull(21, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setShort(21, row3.IsVendorRegistered);
}

                    if(row3.VendorProfile == null) {
pstmt_tDBOutput_3.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(22, row3.VendorProfile);
}

                    if(row3.VendorProductLine == null) {
pstmt_tDBOutput_3.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(23, row3.VendorProductLine);
}

                    pstmt_tDBOutput_3.setInt(24, row3.CreatedBy);

                    if(row3.CreatedDate != null) {
pstmt_tDBOutput_3.setTimestamp(25, new java.sql.Timestamp(row3.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(25, java.sql.Types.TIMESTAMP);
}

                    if(row3.ModifiedBy == null) {
pstmt_tDBOutput_3.setNull(26, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(26, row3.ModifiedBy);
}

                    if(row3.ModifiedDate != null) {
pstmt_tDBOutput_3.setTimestamp(27, new java.sql.Timestamp(row3.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(27, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_3.setInt(28, row3.CompanyID);

                    if(row3.GSTINNo == null) {
pstmt_tDBOutput_3.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(29, row3.GSTINNo);
}

                    if(row3.SiteLocation == null) {
pstmt_tDBOutput_3.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(30, row3.SiteLocation);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_3)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"Vendor\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"Vendor\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int VerificationTransactionId;

				public int getVerificationTransactionId () {
					return this.VerificationTransactionId;
				}

				public Boolean VerificationTransactionIdIsNullable(){
				    return false;
				}
				public Boolean VerificationTransactionIdIsKey(){
				    return true;
				}
				public Integer VerificationTransactionIdLength(){
				    return 10;
				}
				public Integer VerificationTransactionIdPrecision(){
				    return 0;
				}
				public String VerificationTransactionIdDefault(){
				
					return null;
				
				}
				public String VerificationTransactionIdComment(){
				
				    return "";
				
				}
				public String VerificationTransactionIdPattern(){
				
					return "";
				
				}
				public String VerificationTransactionIdOriginalDbColumnName(){
				
					return "VerificationTransactionId";
				
				}

				
			    public int CompanyId;

				public int getCompanyId () {
					return this.CompanyId;
				}

				public Boolean CompanyIdIsNullable(){
				    return false;
				}
				public Boolean CompanyIdIsKey(){
				    return false;
				}
				public Integer CompanyIdLength(){
				    return 10;
				}
				public Integer CompanyIdPrecision(){
				    return 0;
				}
				public String CompanyIdDefault(){
				
					return null;
				
				}
				public String CompanyIdComment(){
				
				    return "";
				
				}
				public String CompanyIdPattern(){
				
					return "";
				
				}
				public String CompanyIdOriginalDbColumnName(){
				
					return "CompanyId";
				
				}

				
			    public java.util.Date StartDate;

				public java.util.Date getStartDate () {
					return this.StartDate;
				}

				public Boolean StartDateIsNullable(){
				    return false;
				}
				public Boolean StartDateIsKey(){
				    return false;
				}
				public Integer StartDateLength(){
				    return 23;
				}
				public Integer StartDatePrecision(){
				    return 3;
				}
				public String StartDateDefault(){
				
					return null;
				
				}
				public String StartDateComment(){
				
				    return "";
				
				}
				public String StartDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String StartDateOriginalDbColumnName(){
				
					return "StartDate";
				
				}

				
			    public java.util.Date EndDate;

				public java.util.Date getEndDate () {
					return this.EndDate;
				}

				public Boolean EndDateIsNullable(){
				    return false;
				}
				public Boolean EndDateIsKey(){
				    return false;
				}
				public Integer EndDateLength(){
				    return 23;
				}
				public Integer EndDatePrecision(){
				    return 3;
				}
				public String EndDateDefault(){
				
					return null;
				
				}
				public String EndDateComment(){
				
				    return "";
				
				}
				public String EndDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String EndDateOriginalDbColumnName(){
				
					return "EndDate";
				
				}

				
			    public String Description;

				public String getDescription () {
					return this.Description;
				}

				public Boolean DescriptionIsNullable(){
				    return true;
				}
				public Boolean DescriptionIsKey(){
				    return false;
				}
				public Integer DescriptionLength(){
				    return 2147483647;
				}
				public Integer DescriptionPrecision(){
				    return 0;
				}
				public String DescriptionDefault(){
				
					return null;
				
				}
				public String DescriptionComment(){
				
				    return "";
				
				}
				public String DescriptionPattern(){
				
					return "";
				
				}
				public String DescriptionOriginalDbColumnName(){
				
					return "Description";
				
				}

				
			    public String ReferenceNo;

				public String getReferenceNo () {
					return this.ReferenceNo;
				}

				public Boolean ReferenceNoIsNullable(){
				    return false;
				}
				public Boolean ReferenceNoIsKey(){
				    return false;
				}
				public Integer ReferenceNoLength(){
				    return 50;
				}
				public Integer ReferenceNoPrecision(){
				    return 0;
				}
				public String ReferenceNoDefault(){
				
					return null;
				
				}
				public String ReferenceNoComment(){
				
				    return "";
				
				}
				public String ReferenceNoPattern(){
				
					return "";
				
				}
				public String ReferenceNoOriginalDbColumnName(){
				
					return "ReferenceNo";
				
				}

				
			    public Integer AssetCategoryID;

				public Integer getAssetCategoryID () {
					return this.AssetCategoryID;
				}

				public Boolean AssetCategoryIDIsNullable(){
				    return true;
				}
				public Boolean AssetCategoryIDIsKey(){
				    return false;
				}
				public Integer AssetCategoryIDLength(){
				    return 10;
				}
				public Integer AssetCategoryIDPrecision(){
				    return 0;
				}
				public String AssetCategoryIDDefault(){
				
					return null;
				
				}
				public String AssetCategoryIDComment(){
				
				    return "";
				
				}
				public String AssetCategoryIDPattern(){
				
					return "";
				
				}
				public String AssetCategoryIDOriginalDbColumnName(){
				
					return "AssetCategoryID";
				
				}

				
			    public Integer OfficeLocationID;

				public Integer getOfficeLocationID () {
					return this.OfficeLocationID;
				}

				public Boolean OfficeLocationIDIsNullable(){
				    return true;
				}
				public Boolean OfficeLocationIDIsKey(){
				    return false;
				}
				public Integer OfficeLocationIDLength(){
				    return 10;
				}
				public Integer OfficeLocationIDPrecision(){
				    return 0;
				}
				public String OfficeLocationIDDefault(){
				
					return null;
				
				}
				public String OfficeLocationIDComment(){
				
				    return "";
				
				}
				public String OfficeLocationIDPattern(){
				
					return "";
				
				}
				public String OfficeLocationIDOriginalDbColumnName(){
				
					return "OfficeLocationID";
				
				}

				
			    public Integer OfficePhysicalLocationID;

				public Integer getOfficePhysicalLocationID () {
					return this.OfficePhysicalLocationID;
				}

				public Boolean OfficePhysicalLocationIDIsNullable(){
				    return true;
				}
				public Boolean OfficePhysicalLocationIDIsKey(){
				    return false;
				}
				public Integer OfficePhysicalLocationIDLength(){
				    return 10;
				}
				public Integer OfficePhysicalLocationIDPrecision(){
				    return 0;
				}
				public String OfficePhysicalLocationIDDefault(){
				
					return null;
				
				}
				public String OfficePhysicalLocationIDComment(){
				
				    return "";
				
				}
				public String OfficePhysicalLocationIDPattern(){
				
					return "";
				
				}
				public String OfficePhysicalLocationIDOriginalDbColumnName(){
				
					return "OfficePhysicalLocationID";
				
				}

				
			    public Integer DepartmentID;

				public Integer getDepartmentID () {
					return this.DepartmentID;
				}

				public Boolean DepartmentIDIsNullable(){
				    return true;
				}
				public Boolean DepartmentIDIsKey(){
				    return false;
				}
				public Integer DepartmentIDLength(){
				    return 10;
				}
				public Integer DepartmentIDPrecision(){
				    return 0;
				}
				public String DepartmentIDDefault(){
				
					return null;
				
				}
				public String DepartmentIDComment(){
				
				    return "";
				
				}
				public String DepartmentIDPattern(){
				
					return "";
				
				}
				public String DepartmentIDOriginalDbColumnName(){
				
					return "DepartmentID";
				
				}

				
			    public Integer CostCenterID;

				public Integer getCostCenterID () {
					return this.CostCenterID;
				}

				public Boolean CostCenterIDIsNullable(){
				    return true;
				}
				public Boolean CostCenterIDIsKey(){
				    return false;
				}
				public Integer CostCenterIDLength(){
				    return 10;
				}
				public Integer CostCenterIDPrecision(){
				    return 0;
				}
				public String CostCenterIDDefault(){
				
					return null;
				
				}
				public String CostCenterIDComment(){
				
				    return "";
				
				}
				public String CostCenterIDPattern(){
				
					return "";
				
				}
				public String CostCenterIDOriginalDbColumnName(){
				
					return "CostCenterID";
				
				}

				
			    public Short VerificationOnAssetCode;

				public Short getVerificationOnAssetCode () {
					return this.VerificationOnAssetCode;
				}

				public Boolean VerificationOnAssetCodeIsNullable(){
				    return true;
				}
				public Boolean VerificationOnAssetCodeIsKey(){
				    return false;
				}
				public Integer VerificationOnAssetCodeLength(){
				    return 5;
				}
				public Integer VerificationOnAssetCodePrecision(){
				    return 0;
				}
				public String VerificationOnAssetCodeDefault(){
				
					return null;
				
				}
				public String VerificationOnAssetCodeComment(){
				
				    return "";
				
				}
				public String VerificationOnAssetCodePattern(){
				
					return "";
				
				}
				public String VerificationOnAssetCodeOriginalDbColumnName(){
				
					return "VerificationOnAssetCode";
				
				}

				
			    public Short PrintBarCodeOption;

				public Short getPrintBarCodeOption () {
					return this.PrintBarCodeOption;
				}

				public Boolean PrintBarCodeOptionIsNullable(){
				    return true;
				}
				public Boolean PrintBarCodeOptionIsKey(){
				    return false;
				}
				public Integer PrintBarCodeOptionLength(){
				    return 5;
				}
				public Integer PrintBarCodeOptionPrecision(){
				    return 0;
				}
				public String PrintBarCodeOptionDefault(){
				
					return null;
				
				}
				public String PrintBarCodeOptionComment(){
				
				    return "";
				
				}
				public String PrintBarCodeOptionPattern(){
				
					return "";
				
				}
				public String PrintBarCodeOptionOriginalDbColumnName(){
				
					return "PrintBarCodeOption";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.VerificationTransactionId;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.VerificationTransactionId != other.VerificationTransactionId)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.VerificationTransactionId = this.VerificationTransactionId;
	            other.CompanyId = this.CompanyId;
	            other.StartDate = this.StartDate;
	            other.EndDate = this.EndDate;
	            other.Description = this.Description;
	            other.ReferenceNo = this.ReferenceNo;
	            other.AssetCategoryID = this.AssetCategoryID;
	            other.OfficeLocationID = this.OfficeLocationID;
	            other.OfficePhysicalLocationID = this.OfficePhysicalLocationID;
	            other.DepartmentID = this.DepartmentID;
	            other.CostCenterID = this.CostCenterID;
	            other.VerificationOnAssetCode = this.VerificationOnAssetCode;
	            other.PrintBarCodeOption = this.PrintBarCodeOption;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.VerificationTransactionId = this.VerificationTransactionId;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_30, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.VerificationTransactionId = dis.readInt();
					
			        this.CompanyId = dis.readInt();
					
					this.StartDate = readDate(dis);
					
					this.EndDate = readDate(dis);
					
					this.Description = readString(dis);
					
					this.ReferenceNo = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
						this.OfficeLocationID = readInteger(dis);
					
						this.OfficePhysicalLocationID = readInteger(dis);
					
						this.DepartmentID = readInteger(dis);
					
						this.CostCenterID = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.VerificationOnAssetCode = null;
           				} else {
           			    	this.VerificationOnAssetCode = dis.readShort();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrintBarCodeOption = null;
           				} else {
           			    	this.PrintBarCodeOption = dis.readShort();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_30) {

        	try {

        		int length = 0;
		
			        this.VerificationTransactionId = dis.readInt();
					
			        this.CompanyId = dis.readInt();
					
					this.StartDate = readDate(dis);
					
					this.EndDate = readDate(dis);
					
					this.Description = readString(dis);
					
					this.ReferenceNo = readString(dis);
					
						this.AssetCategoryID = readInteger(dis);
					
						this.OfficeLocationID = readInteger(dis);
					
						this.OfficePhysicalLocationID = readInteger(dis);
					
						this.DepartmentID = readInteger(dis);
					
						this.CostCenterID = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.VerificationOnAssetCode = null;
           				} else {
           			    	this.VerificationOnAssetCode = dis.readShort();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrintBarCodeOption = null;
           				} else {
           			    	this.PrintBarCodeOption = dis.readShort();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.VerificationTransactionId);
					
					// int
				
		            	dos.writeInt(this.CompanyId);
					
					// java.util.Date
				
						writeDate(this.StartDate,dos);
					
					// java.util.Date
				
						writeDate(this.EndDate,dos);
					
					// String
				
						writeString(this.Description,dos);
					
					// String
				
						writeString(this.ReferenceNo,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// Integer
				
						writeInteger(this.OfficeLocationID,dos);
					
					// Integer
				
						writeInteger(this.OfficePhysicalLocationID,dos);
					
					// Integer
				
						writeInteger(this.DepartmentID,dos);
					
					// Integer
				
						writeInteger(this.CostCenterID,dos);
					
					// Short
				
						if(this.VerificationOnAssetCode == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.VerificationOnAssetCode);
		            	}
					
					// Short
				
						if(this.PrintBarCodeOption == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.PrintBarCodeOption);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.VerificationTransactionId);
					
					// int
				
		            	dos.writeInt(this.CompanyId);
					
					// java.util.Date
				
						writeDate(this.StartDate,dos);
					
					// java.util.Date
				
						writeDate(this.EndDate,dos);
					
					// String
				
						writeString(this.Description,dos);
					
					// String
				
						writeString(this.ReferenceNo,dos);
					
					// Integer
				
						writeInteger(this.AssetCategoryID,dos);
					
					// Integer
				
						writeInteger(this.OfficeLocationID,dos);
					
					// Integer
				
						writeInteger(this.OfficePhysicalLocationID,dos);
					
					// Integer
				
						writeInteger(this.DepartmentID,dos);
					
					// Integer
				
						writeInteger(this.CostCenterID,dos);
					
					// Short
				
						if(this.VerificationOnAssetCode == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.VerificationOnAssetCode);
		            	}
					
					// Short
				
						if(this.PrintBarCodeOption == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.PrintBarCodeOption);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("VerificationTransactionId="+String.valueOf(VerificationTransactionId));
		sb.append(",CompanyId="+String.valueOf(CompanyId));
		sb.append(",StartDate="+String.valueOf(StartDate));
		sb.append(",EndDate="+String.valueOf(EndDate));
		sb.append(",Description="+Description);
		sb.append(",ReferenceNo="+ReferenceNo);
		sb.append(",AssetCategoryID="+String.valueOf(AssetCategoryID));
		sb.append(",OfficeLocationID="+String.valueOf(OfficeLocationID));
		sb.append(",OfficePhysicalLocationID="+String.valueOf(OfficePhysicalLocationID));
		sb.append(",DepartmentID="+String.valueOf(DepartmentID));
		sb.append(",CostCenterID="+String.valueOf(CostCenterID));
		sb.append(",VerificationOnAssetCode="+String.valueOf(VerificationOnAssetCode));
		sb.append(",PrintBarCodeOption="+String.valueOf(PrintBarCodeOption));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(VerificationTransactionId);
        			
        			sb.append("|");
        		
        				sb.append(CompanyId);
        			
        			sb.append("|");
        		
        				if(StartDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(StartDate);
            			}
            		
        			sb.append("|");
        		
        				if(EndDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(EndDate);
            			}
            		
        			sb.append("|");
        		
        				if(Description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Description);
            			}
            		
        			sb.append("|");
        		
        				if(ReferenceNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ReferenceNo);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCategoryID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCategoryID);
            			}
            		
        			sb.append("|");
        		
        				if(OfficeLocationID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OfficeLocationID);
            			}
            		
        			sb.append("|");
        		
        				if(OfficePhysicalLocationID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OfficePhysicalLocationID);
            			}
            		
        			sb.append("|");
        		
        				if(DepartmentID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepartmentID);
            			}
            		
        			sb.append("|");
        		
        				if(CostCenterID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CostCenterID);
            			}
            		
        			sb.append("|");
        		
        				if(VerificationOnAssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VerificationOnAssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(PrintBarCodeOption == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PrintBarCodeOption);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.VerificationTransactionId, other.VerificationTransactionId);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"VerificationTransactionDetails\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("VerificationTransactionDetails");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("VerificationTransactionDetails");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_4 + "\"")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_4 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"VerificationTransactionId\",\"CompanyId\",\"StartDate\",\"EndDate\",\"Description\",\"ReferenceNo\",\"AssetCategoryID\",\"OfficeLocationID\",\"OfficePhysicalLocationID\",\"DepartmentID\",\"CostCenterID\",\"VerificationOnAssetCode\",\"PrintBarCodeOption\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"VerificationTransactionDetails\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT FAMS.VerificationTransactionDetails.VerificationTransactionId, 		FAMS.VerificationTransactionDetails.CompanyId, 		FAMS.VerificationTransactionDetails.StartDate, 		FAMS.VerificationTransactionDetails.EndDate, 		FAMS.VerificationTransactionDetails.Description, 		FAMS.VerificationTransactionDetails.ReferenceNo, 		FAMS.VerificationTransactionDetails.AssetCategoryID, 		FAMS.VerificationTransactionDetails.OfficeLocationID, 		FAMS.VerificationTransactionDetails.OfficePhysicalLocationID, 		FAMS.VerificationTransactionDetails.DepartmentID, 		FAMS.VerificationTransactionDetails.CostCenterID, 		FAMS.VerificationTransactionDetails.VerificationOnAssetCode, 		FAMS.VerificationTransactionDetails.PrintBarCodeOption FROM	FAMS.VerificationTransactionDetails\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("VerificationTransactionId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("StartDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("EndDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Description")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ReferenceNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCategoryID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OfficeLocationID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OfficePhysicalLocationID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepartmentID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostCenterID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VerificationOnAssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PrintBarCodeOption")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"VerificationTransactionDetails\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_4  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4); 
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_4 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT FAMS.VerificationTransactionDetails.VerificationTransactionId,\n		FAMS.VerificationTransactionDetails.CompanyId,\n"
+"		FAMS.VerificationTransactionDetails.StartDate,\n		FAMS.VerificationTransactionDetails.EndDate,\n		FAMS.VerificationTrans"
+"actionDetails.Description,\n		FAMS.VerificationTransactionDetails.ReferenceNo,\n		FAMS.VerificationTransactionDetails.Asse"
+"tCategoryID,\n		FAMS.VerificationTransactionDetails.OfficeLocationID,\n		FAMS.VerificationTransactionDetails.OfficePhysica"
+"lLocationID,\n		FAMS.VerificationTransactionDetails.DepartmentID,\n		FAMS.VerificationTransactionDetails.CostCenterID,\n		F"
+"AMS.VerificationTransactionDetails.VerificationOnAssetCode,\n		FAMS.VerificationTransactionDetails.PrintBarCodeOption\nFRO"
+"M	FAMS.VerificationTransactionDetails";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.VerificationTransactionId = 0;
							} else {
		                          
            row4.VerificationTransactionId = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.CompanyId = 0;
							} else {
		                          
            row4.CompanyId = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.StartDate = null;
							} else {
										
			row4.StartDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 3);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.EndDate = null;
							} else {
										
			row4.EndDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 4);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.Description = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(5);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Description = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Description = tmpContent_tDBInput_4;
                }
            } else {
                row4.Description = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.ReferenceNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(6);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.ReferenceNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.ReferenceNo = tmpContent_tDBInput_4;
                }
            } else {
                row4.ReferenceNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.AssetCategoryID = null;
							} else {
		                          
            row4.AssetCategoryID = rs_tDBInput_4.getInt(7);
            if(rs_tDBInput_4.wasNull()){
                    row4.AssetCategoryID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.OfficeLocationID = null;
							} else {
		                          
            row4.OfficeLocationID = rs_tDBInput_4.getInt(8);
            if(rs_tDBInput_4.wasNull()){
                    row4.OfficeLocationID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.OfficePhysicalLocationID = null;
							} else {
		                          
            row4.OfficePhysicalLocationID = rs_tDBInput_4.getInt(9);
            if(rs_tDBInput_4.wasNull()){
                    row4.OfficePhysicalLocationID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.DepartmentID = null;
							} else {
		                          
            row4.DepartmentID = rs_tDBInput_4.getInt(10);
            if(rs_tDBInput_4.wasNull()){
                    row4.DepartmentID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 11) {
								row4.CostCenterID = null;
							} else {
		                          
            row4.CostCenterID = rs_tDBInput_4.getInt(11);
            if(rs_tDBInput_4.wasNull()){
                    row4.CostCenterID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 12) {
								row4.VerificationOnAssetCode = null;
							} else {
		                          
            row4.VerificationOnAssetCode = rs_tDBInput_4.getShort(12);
            if(rs_tDBInput_4.wasNull()){
                    row4.VerificationOnAssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 13) {
								row4.PrintBarCodeOption = null;
							} else {
		                          
            row4.PrintBarCodeOption = rs_tDBInput_4.getShort(13);
            if(rs_tDBInput_4.wasNull()){
                    row4.PrintBarCodeOption = null;
            }
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					





 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"VerificationTransactionDetails\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, row4.VerificationTransactionId);

                    pstmt_tDBOutput_4.setInt(2, row4.CompanyId);

                    if(row4.StartDate != null) {
pstmt_tDBOutput_4.setTimestamp(3, new java.sql.Timestamp(row4.StartDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(row4.EndDate != null) {
pstmt_tDBOutput_4.setTimestamp(4, new java.sql.Timestamp(row4.EndDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row4.Description == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(5, row4.Description);
}

                    if(row4.ReferenceNo == null) {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(6, row4.ReferenceNo);
}

                    if(row4.AssetCategoryID == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(7, row4.AssetCategoryID);
}

                    if(row4.OfficeLocationID == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(8, row4.OfficeLocationID);
}

                    if(row4.OfficePhysicalLocationID == null) {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(9, row4.OfficePhysicalLocationID);
}

                    if(row4.DepartmentID == null) {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(10, row4.DepartmentID);
}

                    if(row4.CostCenterID == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(11, row4.CostCenterID);
}

                    if(row4.VerificationOnAssetCode == null) {
pstmt_tDBOutput_4.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setShort(12, row4.VerificationOnAssetCode);
}

                    if(row4.PrintBarCodeOption == null) {
pstmt_tDBOutput_4.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setShort(13, row4.PrintBarCodeOption);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_4)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"VerificationTransactionDetails\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"VerificationTransactionDetails\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();

    public static void main(String[] args){
        final FAMS_7_tables_30 FAMS_7_tables_30Class = new FAMS_7_tables_30();

        int exitCode = FAMS_7_tables_30Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'FAMS_7_tables_30' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try {
            	jobInfo.load(new java.io.FileInputStream(jobInfoFile));
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230315_1127-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'FAMS_7_tables_30' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_6DmnMBr7Ee6Et43_rExQxg");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-07-11T13:35:15.466720100Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = FAMS_7_tables_30.class.getClassLoader().getResourceAsStream("talend_tac2_repo/fams_7_tables_30_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = FAMS_7_tables_30.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'FAMS_7_tables_30' - Started.");

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : FAMS_7_tables_30");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'FAMS_7_tables_30' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     327672 characters generated by Talend Data Integration 
 *     on the July 11, 2023 at 7:05:15 PM IST
 ************************************************************************************************/