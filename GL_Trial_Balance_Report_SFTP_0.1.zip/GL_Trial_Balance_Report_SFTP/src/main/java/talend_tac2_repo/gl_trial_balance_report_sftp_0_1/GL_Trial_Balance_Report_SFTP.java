
package talend_tac2_repo.gl_trial_balance_report_sftp_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: GL_Trial_Balance_Report_SFTP Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230612_1054-patch
 * @status 
 */
public class GL_Trial_Balance_Report_SFTP implements TalendJob {
	static {System.setProperty("TalendJob.log", "GL_Trial_Balance_Report_SFTP.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(GL_Trial_Balance_Report_SFTP.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(file_path != null){
				
					this.setProperty("file_path", file_path.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

		public String file_path;
		public String getFile_path(){
			return this.file_path;
		}
		
	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "GL_Trial_Balance_Report_SFTP";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_7KvQQN9kEe2CtfQ-GaHJEQ", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				GL_Trial_Balance_Report_SFTP.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(GL_Trial_Balance_Report_SFTP.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFTPGet_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPGet_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPGet_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFTPGet_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFTPGet_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	



public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "U6V39l_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFTPConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPConnection_1");
		org.slf4j.MDC.put("_subJobPid", "BBJhgL_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPConnection_1", false);
		start_Hash.put("tFTPConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		
		int tos_count_tFTPConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPConnection_1 = new StringBuilder();
                    log4jParamters_tFTPConnection_1.append("Parameters:");
                            log4jParamters_tFTPConnection_1.append("HOST" + " = " + "\"115.124.118.248\"");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("PORT" + " = " + "5522");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USER" + " = " + "\"cifcpl\"");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:oNatWdJA/58iLqKWLAFFGvuFOs/N3evz6S1eJwY9yUvaV7gOfbi4Bwva").substring(0, 4) + "...");     
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("SFTP" + " = " + "true");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("AUTH_METHOD" + " = " + "PASSWORD");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USE_ENCODING" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USE_PROXY" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("CONNECTION_TIMEOUT" + " = " + "1000000");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("USE_STRICT_REPLY_PARSING" + " = " + "true");
                        log4jParamters_tFTPConnection_1.append(" | ");
                            log4jParamters_tFTPConnection_1.append("CONFIG_CLIENT" + " = " + "false");
                        log4jParamters_tFTPConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + (log4jParamters_tFTPConnection_1) );
                    } 
                } 
            new BytesLimit65535_tFTPConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPConnection_1", "SFTP_Connection", "tFTPConnection");
				talendJobLogProcess(globalMap);
			}
			

 
int connectionTimeout_tFTPConnection_1 = Integer.valueOf(1000000);	
	


class MyUserInfo implements com.jcraft.jsch.UserInfo, com.jcraft.jsch.UIKeyboardInteractive {

    public String getPassphrase() { return "secret"; }

    public boolean promptPassword(String arg0) { return true; } 

    public boolean promptPassphrase(String arg0) { return true; } 

    public boolean promptYesNo(String arg0) { return true; } 

    public void showMessage(String arg0) { } 

    public String[] promptKeyboardInteractive(String destination, String name, String instruction, String[] prompt,
    boolean[] echo) {
        return new String[] {getPassword()};
    }

    public String getPassword() {
 
	final String decryptedPassword_tFTPConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:UpqbnfYlZosCg91l1zwGlk5/fSYRkC2H/8h1UCH7b41QNZ9qeYPd+eyX");

            return decryptedPassword_tFTPConnection_1;
    }
};
final com.jcraft.jsch.UserInfo defaultUserInfo_tFTPConnection_1 = new MyUserInfo();


boolean retry_tFTPConnection_1 = false;
int retry_count_tFTPConnection_1 = 0;
int retry_max_tFTPConnection_1 = 5;

com.jcraft.jsch.Session session_tFTPConnection_1 = null;
com.jcraft.jsch.Channel channel_tFTPConnection_1 = null;

class JschLogger_tFTPConnection_1 implements com.jcraft.jsch.Logger {
    public boolean isEnabled(int level){
        return true;
    }
    public void log(int level, String message){
    	
        	log.debug(message);
    }
}

do {
    retry_tFTPConnection_1 = false;

    com.jcraft.jsch.JSch.setLogger(new JschLogger_tFTPConnection_1());
    com.jcraft.jsch.JSch jsch_tFTPConnection_1 = new com.jcraft.jsch.JSch(); 


    session_tFTPConnection_1 = jsch_tFTPConnection_1.getSession("cifcpl", "115.124.118.248", 5522);
    session_tFTPConnection_1.setConfig("PreferredAuthentications", "publickey,password,keyboard-interactive,gssapi-with-mic");

            log.info("tFTPConnection_1 - SFTP authentication using a password.");
 
	final String decryptedPassword_tFTPConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:/YhWz9uw6ubk0jm3GATDxefT91zZJpmcgA5h/oec2Z0ZEcxym6ZXrY5d");

        session_tFTPConnection_1.setPassword(decryptedPassword_tFTPConnection_1); 

    session_tFTPConnection_1.setUserInfo(defaultUserInfo_tFTPConnection_1); 
        if(("true").equals(System.getProperty("http.proxySet"))) {

//check if the host is in the excludes for proxy
    boolean isHostIgnored_tFTPConnection_1 = false;
    String nonProxyHostsString_tFTPConnection_1 = System.getProperty("http.nonProxyHosts");
    String[] nonProxyHosts_tFTPConnection_1 = (nonProxyHostsString_tFTPConnection_1 == null) ? new String[0] : nonProxyHostsString_tFTPConnection_1.split("\\|");
    for (String nonProxyHost : nonProxyHosts_tFTPConnection_1) {
        if (("115.124.118.248").matches(nonProxyHost.trim())) {
            isHostIgnored_tFTPConnection_1 = true;
            break;
        }
    }
            if (!isHostIgnored_tFTPConnection_1) {
                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_1 = new com.jcraft.jsch.ProxyHTTP(System.getProperty("http.proxyHost"),Integer.parseInt(System.getProperty("http.proxyPort")));
                if(!"".equals(System.getProperty("http.proxyUser"))){
                    proxy_tFTPConnection_1.setUserPasswd(System.getProperty("http.proxyUser"),System.getProperty("http.proxyPassword"));
                }
                session_tFTPConnection_1.setProxy(proxy_tFTPConnection_1);
            }
        } else if ("local".equals(System.getProperty("http.proxySet"))) {
            String uriString = "115.124.118.248" + ":" + 5522;
            java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);

            if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {
                java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();
                String proxyHost = proxyAddress.getAddress().getHostAddress();
                int proxyPort = proxyAddress.getPort();

                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_1 = new com.jcraft.jsch.ProxyHTTP(proxyHost, proxyPort);

                org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(proxyHost + ":" + proxyPort);
                if (proxyCreds != null) {
                    proxy_tFTPConnection_1.setUserPasswd(proxyCreds.getUser(), proxyCreds.getPass());
                }

                session_tFTPConnection_1.setProxy(proxy_tFTPConnection_1);
            }
        }

        log.info("tFTPConnection_1 - Attempt to connect to  '" + "115.124.118.248" + "' with username '" + "cifcpl" + "'.");

    channel_tFTPConnection_1 = null;
    try {
        if (connectionTimeout_tFTPConnection_1 > 0) {
            session_tFTPConnection_1.connect(connectionTimeout_tFTPConnection_1);
        } else {
            session_tFTPConnection_1.connect();
        }
        channel_tFTPConnection_1 = session_tFTPConnection_1.openChannel("sftp");
        if (connectionTimeout_tFTPConnection_1 > 0) {
            channel_tFTPConnection_1.connect(connectionTimeout_tFTPConnection_1);
        } else {
            channel_tFTPConnection_1.connect();
        }
            log.info("tFTPConnection_1 - Connect to '" + "115.124.118.248" + "' has succeeded.");
    } catch (com.jcraft.jsch.JSchException e_tFTPConnection_1) {
        try {
            if(channel_tFTPConnection_1!=null) {
                channel_tFTPConnection_1.disconnect();
            }

            if(session_tFTPConnection_1!=null) {
                session_tFTPConnection_1.disconnect();
            }
        } catch(java.lang.Exception ce_tFTPConnection_1) {
                log.warn("tFTPConnection_1 - close sftp connection failed : " + ce_tFTPConnection_1.getClass() + " : " + ce_tFTPConnection_1.getMessage());
        }

        String message_tFTPConnection_1 = new TalendException(null, null, null).getExceptionCauseMessage(e_tFTPConnection_1);
        if(message_tFTPConnection_1.contains("Signature length not correct") || message_tFTPConnection_1.contains("connection is closed by foreign host")) {
            retry_tFTPConnection_1 = true;
            retry_count_tFTPConnection_1++;
            log.info("tFTPConnection_1 - connect: Signature length not correct or connection is closed by foreign host, so retry, retry time : " + retry_count_tFTPConnection_1);
        } else {
            throw e_tFTPConnection_1;
        }
    }
} while(retry_tFTPConnection_1 && (retry_count_tFTPConnection_1 < retry_max_tFTPConnection_1));

com.jcraft.jsch.ChannelSftp c_tFTPConnection_1 = (com.jcraft.jsch.ChannelSftp)channel_tFTPConnection_1;
	
	
	
	globalMap.put("conn_tFTPConnection_1", c_tFTPConnection_1);

 



/**
 * [tFTPConnection_1 begin ] stop
 */
	
	/**
	 * [tFTPConnection_1 main ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		

 


	tos_count_tFTPConnection_1++;

/**
 * [tFTPConnection_1 main ] stop
 */
	
	/**
	 * [tFTPConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		

 



/**
 * [tFTPConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		

 



/**
 * [tFTPConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPConnection_1 end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		

 
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_1 - "  + ("Done.") );

ok_Hash.put("tFTPConnection_1", true);
end_Hash.put("tFTPConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tFTPConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPConnection_1";
	
	
			cLabel="SFTP_Connection";
		

 



/**
 * [tFTPConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "ysqERq_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"projects\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:JHme1L41XB0havA7qYxHtiKOV9c0fy8VPiEQNp42DxbfJgXhghl/dnjg").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "ESDS_Test", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_1 = "";
            String url_tDBConnection_1 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_1 != null && !"".equals(dbProperties_tDBConnection_1.trim())) {
                url_tDBConnection_1 = url_tDBConnection_1 + "?" + dbProperties_tDBConnection_1;
            }
	String dbUser_tDBConnection_1 = "projects";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:XH27m36mdMrc9+Hb5VcGkwRGoAUUOFTluyDF56bSXnzLe8TL+VsJQj8O");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_1 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_1 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_1.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_1 = drivers_tDBConnection_1.nextElement();
        if (redShiftDriverNames_tDBConnection_1.contains(d_tDBConnection_1.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_1);
                java.sql.DriverManager.registerDriver(d_tDBConnection_1);
            } catch (java.lang.Exception e_tDBConnection_1) {
globalMap.put("tDBConnection_1_ERROR_MESSAGE",e_tDBConnection_1.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_1 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_1","");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="ESDS_Test";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "Ut4QJX_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tFTPClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPClose_1");
		org.slf4j.MDC.put("_subJobPid", "CtkCu4_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPClose_1", false);
		start_Hash.put("tFTPClose_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPClose_1";
	
	
		int tos_count_tFTPClose_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tFTPClose_1", "tFTPClose_1", "tFTPClose");
				talendJobLogProcess(globalMap);
			}
			
	 Object connObj = globalMap.get("conn_tFTPConnection_1");
	 if (connObj != null) {
      try {
			
              com.jcraft.jsch.ChannelSftp channel = (com.jcraft.jsch.ChannelSftp) connObj; 
              com.jcraft.jsch.Session session = channel.getSession();
			  channel.disconnect();
              session.disconnect();
			
      } catch (Exception e) {
           globalMap.put("tFTPClose_1_ERROR_MESSAGE", e.getMessage()); 
           throw e;
      }
  }
 



/**
 * [tFTPClose_1 begin ] stop
 */
	
	/**
	 * [tFTPClose_1 main ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 


	tos_count_tFTPClose_1++;

/**
 * [tFTPClose_1 main ] stop
 */
	
	/**
	 * [tFTPClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 



/**
 * [tFTPClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tFTPClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 



/**
 * [tFTPClose_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPClose_1 end ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	

 

ok_Hash.put("tFTPClose_1", true);
end_Hash.put("tFTPClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tFTPClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPClose_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPClose_1";
	
	
	 Object connObj = globalMap.get("conn_tFTPConnection_1");
	 if (connObj != null) {   
              com.jcraft.jsch.ChannelSftp channel = (com.jcraft.jsch.ChannelSftp) connObj; 
              com.jcraft.jsch.Session session = channel.getSession();
              channel.disconnect();
			  session.disconnect();
     
  }
 



/**
 * [tFTPClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "5Y3m8Y_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());




/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tFTPConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPConnection_2");
		org.slf4j.MDC.put("_subJobPid", "JJIJDg_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFTPConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFTPConnection_2", false);
		start_Hash.put("tFTPConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tFTPConnection_2";
	
	
		int tos_count_tFTPConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPConnection_2 = new StringBuilder();
                    log4jParamters_tFTPConnection_2.append("Parameters:");
                            log4jParamters_tFTPConnection_2.append("HOST" + " = " + "\"115.124.118.248\"");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("PORT" + " = " + "5522");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USER" + " = " + "\"cifcpl\"");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:ChhtTrbWAOasSUH+nHP1cJPeEOp2dAbzQoP5W4X+fJzFejIVagJZTk8T").substring(0, 4) + "...");     
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("SFTP" + " = " + "true");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("AUTH_METHOD" + " = " + "PASSWORD");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_ENCODING" + " = " + "false");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_PROXY" + " = " + "false");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("CONNECTION_TIMEOUT" + " = " + "0");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("USE_STRICT_REPLY_PARSING" + " = " + "true");
                        log4jParamters_tFTPConnection_2.append(" | ");
                            log4jParamters_tFTPConnection_2.append("CONFIG_CLIENT" + " = " + "false");
                        log4jParamters_tFTPConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + (log4jParamters_tFTPConnection_2) );
                    } 
                } 
            new BytesLimit65535_tFTPConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPConnection_2", "tFTPConnection_2", "tFTPConnection");
				talendJobLogProcess(globalMap);
			}
			

 
int connectionTimeout_tFTPConnection_2 = Integer.valueOf(0);	
	


class MyUserInfo implements com.jcraft.jsch.UserInfo, com.jcraft.jsch.UIKeyboardInteractive {

    public String getPassphrase() { return "secret"; }

    public boolean promptPassword(String arg0) { return true; } 

    public boolean promptPassphrase(String arg0) { return true; } 

    public boolean promptYesNo(String arg0) { return true; } 

    public void showMessage(String arg0) { } 

    public String[] promptKeyboardInteractive(String destination, String name, String instruction, String[] prompt,
    boolean[] echo) {
        return new String[] {getPassword()};
    }

    public String getPassword() {
 
	final String decryptedPassword_tFTPConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ujfgP1R4xQ3NxUguOr9R6FrkzjcCK+UWsweAWceT8rd1bAwg38RneCWh");

            return decryptedPassword_tFTPConnection_2;
    }
};
final com.jcraft.jsch.UserInfo defaultUserInfo_tFTPConnection_2 = new MyUserInfo();


boolean retry_tFTPConnection_2 = false;
int retry_count_tFTPConnection_2 = 0;
int retry_max_tFTPConnection_2 = 5;

com.jcraft.jsch.Session session_tFTPConnection_2 = null;
com.jcraft.jsch.Channel channel_tFTPConnection_2 = null;

class JschLogger_tFTPConnection_2 implements com.jcraft.jsch.Logger {
    public boolean isEnabled(int level){
        return true;
    }
    public void log(int level, String message){
    	
        	log.debug(message);
    }
}

do {
    retry_tFTPConnection_2 = false;

    com.jcraft.jsch.JSch.setLogger(new JschLogger_tFTPConnection_2());
    com.jcraft.jsch.JSch jsch_tFTPConnection_2 = new com.jcraft.jsch.JSch(); 


    session_tFTPConnection_2 = jsch_tFTPConnection_2.getSession("cifcpl", "115.124.118.248", 5522);
    session_tFTPConnection_2.setConfig("PreferredAuthentications", "publickey,password,keyboard-interactive,gssapi-with-mic");

            log.info("tFTPConnection_2 - SFTP authentication using a password.");
 
	final String decryptedPassword_tFTPConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:0XwnvXszUT4zZO7ZA5l3DfqMo4VBYbdXkCi7oUQd4LVgzsrh5Gt75DWR");

        session_tFTPConnection_2.setPassword(decryptedPassword_tFTPConnection_2); 

    session_tFTPConnection_2.setUserInfo(defaultUserInfo_tFTPConnection_2); 
        if(("true").equals(System.getProperty("http.proxySet"))) {

//check if the host is in the excludes for proxy
    boolean isHostIgnored_tFTPConnection_2 = false;
    String nonProxyHostsString_tFTPConnection_2 = System.getProperty("http.nonProxyHosts");
    String[] nonProxyHosts_tFTPConnection_2 = (nonProxyHostsString_tFTPConnection_2 == null) ? new String[0] : nonProxyHostsString_tFTPConnection_2.split("\\|");
    for (String nonProxyHost : nonProxyHosts_tFTPConnection_2) {
        if (("115.124.118.248").matches(nonProxyHost.trim())) {
            isHostIgnored_tFTPConnection_2 = true;
            break;
        }
    }
            if (!isHostIgnored_tFTPConnection_2) {
                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_2 = new com.jcraft.jsch.ProxyHTTP(System.getProperty("http.proxyHost"),Integer.parseInt(System.getProperty("http.proxyPort")));
                if(!"".equals(System.getProperty("http.proxyUser"))){
                    proxy_tFTPConnection_2.setUserPasswd(System.getProperty("http.proxyUser"),System.getProperty("http.proxyPassword"));
                }
                session_tFTPConnection_2.setProxy(proxy_tFTPConnection_2);
            }
        } else if ("local".equals(System.getProperty("http.proxySet"))) {
            String uriString = "115.124.118.248" + ":" + 5522;
            java.net.Proxy proxyToUse = org.talend.proxy.TalendProxySelector.getInstance().getProxyForUriString(uriString);

            if (!proxyToUse.equals(java.net.Proxy.NO_PROXY)) {
                java.net.InetSocketAddress proxyAddress = (java.net.InetSocketAddress) proxyToUse.address();
                String proxyHost = proxyAddress.getAddress().getHostAddress();
                int proxyPort = proxyAddress.getPort();

                com.jcraft.jsch.ProxyHTTP proxy_tFTPConnection_2 = new com.jcraft.jsch.ProxyHTTP(proxyHost, proxyPort);

                org.talend.proxy.ProxyCreds proxyCreds = org.talend.proxy.TalendProxyAuthenticator.getInstance().getCredsForProxyURI(proxyHost + ":" + proxyPort);
                if (proxyCreds != null) {
                    proxy_tFTPConnection_2.setUserPasswd(proxyCreds.getUser(), proxyCreds.getPass());
                }

                session_tFTPConnection_2.setProxy(proxy_tFTPConnection_2);
            }
        }

        log.info("tFTPConnection_2 - Attempt to connect to  '" + "115.124.118.248" + "' with username '" + "cifcpl" + "'.");

    channel_tFTPConnection_2 = null;
    try {
        if (connectionTimeout_tFTPConnection_2 > 0) {
            session_tFTPConnection_2.connect(connectionTimeout_tFTPConnection_2);
        } else {
            session_tFTPConnection_2.connect();
        }
        channel_tFTPConnection_2 = session_tFTPConnection_2.openChannel("sftp");
        if (connectionTimeout_tFTPConnection_2 > 0) {
            channel_tFTPConnection_2.connect(connectionTimeout_tFTPConnection_2);
        } else {
            channel_tFTPConnection_2.connect();
        }
            log.info("tFTPConnection_2 - Connect to '" + "115.124.118.248" + "' has succeeded.");
    } catch (com.jcraft.jsch.JSchException e_tFTPConnection_2) {
        try {
            if(channel_tFTPConnection_2!=null) {
                channel_tFTPConnection_2.disconnect();
            }

            if(session_tFTPConnection_2!=null) {
                session_tFTPConnection_2.disconnect();
            }
        } catch(java.lang.Exception ce_tFTPConnection_2) {
                log.warn("tFTPConnection_2 - close sftp connection failed : " + ce_tFTPConnection_2.getClass() + " : " + ce_tFTPConnection_2.getMessage());
        }

        String message_tFTPConnection_2 = new TalendException(null, null, null).getExceptionCauseMessage(e_tFTPConnection_2);
        if(message_tFTPConnection_2.contains("Signature length not correct") || message_tFTPConnection_2.contains("connection is closed by foreign host")) {
            retry_tFTPConnection_2 = true;
            retry_count_tFTPConnection_2++;
            log.info("tFTPConnection_2 - connect: Signature length not correct or connection is closed by foreign host, so retry, retry time : " + retry_count_tFTPConnection_2);
        } else {
            throw e_tFTPConnection_2;
        }
    }
} while(retry_tFTPConnection_2 && (retry_count_tFTPConnection_2 < retry_max_tFTPConnection_2));

com.jcraft.jsch.ChannelSftp c_tFTPConnection_2 = (com.jcraft.jsch.ChannelSftp)channel_tFTPConnection_2;
	
	
	
	globalMap.put("conn_tFTPConnection_2", c_tFTPConnection_2);

 



/**
 * [tFTPConnection_2 begin ] stop
 */
	
	/**
	 * [tFTPConnection_2 main ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 


	tos_count_tFTPConnection_2++;

/**
 * [tFTPConnection_2 main ] stop
 */
	
	/**
	 * [tFTPConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tFTPConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tFTPConnection_2 end ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tFTPConnection_2 - "  + ("Done.") );

ok_Hash.put("tFTPConnection_2", true);
end_Hash.put("tFTPConnection_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tFTPGet_1Process(globalMap);



/**
 * [tFTPConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tFTPConnection_2";
	
	

 



/**
 * [tFTPConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[0];

	
			    public String ledger_name;

				public String getLedger_name () {
					return this.ledger_name;
				}

				public Boolean ledger_nameIsNullable(){
				    return true;
				}
				public Boolean ledger_nameIsKey(){
				    return false;
				}
				public Integer ledger_nameLength(){
				    return 2147483647;
				}
				public Integer ledger_namePrecision(){
				    return 0;
				}
				public String ledger_nameDefault(){
				
					return null;
				
				}
				public String ledger_nameComment(){
				
				    return "";
				
				}
				public String ledger_namePattern(){
				
					return "";
				
				}
				public String ledger_nameOriginalDbColumnName(){
				
					return "ledger_name";
				
				}

				
			    public String le_name;

				public String getLe_name () {
					return this.le_name;
				}

				public Boolean le_nameIsNullable(){
				    return true;
				}
				public Boolean le_nameIsKey(){
				    return false;
				}
				public Integer le_nameLength(){
				    return 2147483647;
				}
				public Integer le_namePrecision(){
				    return 0;
				}
				public String le_nameDefault(){
				
					return null;
				
				}
				public String le_nameComment(){
				
				    return "";
				
				}
				public String le_namePattern(){
				
					return "";
				
				}
				public String le_nameOriginalDbColumnName(){
				
					return "le_name";
				
				}

				
			    public String ledger_currency;

				public String getLedger_currency () {
					return this.ledger_currency;
				}

				public Boolean ledger_currencyIsNullable(){
				    return true;
				}
				public Boolean ledger_currencyIsKey(){
				    return false;
				}
				public Integer ledger_currencyLength(){
				    return 2147483647;
				}
				public Integer ledger_currencyPrecision(){
				    return 0;
				}
				public String ledger_currencyDefault(){
				
					return null;
				
				}
				public String ledger_currencyComment(){
				
				    return "";
				
				}
				public String ledger_currencyPattern(){
				
					return "";
				
				}
				public String ledger_currencyOriginalDbColumnName(){
				
					return "ledger_currency";
				
				}

				
			    public String period_name;

				public String getPeriod_name () {
					return this.period_name;
				}

				public Boolean period_nameIsNullable(){
				    return true;
				}
				public Boolean period_nameIsKey(){
				    return false;
				}
				public Integer period_nameLength(){
				    return 2147483647;
				}
				public Integer period_namePrecision(){
				    return 0;
				}
				public String period_nameDefault(){
				
					return null;
				
				}
				public String period_nameComment(){
				
				    return "";
				
				}
				public String period_namePattern(){
				
					return "";
				
				}
				public String period_nameOriginalDbColumnName(){
				
					return "period_name";
				
				}

				
			    public Integer entity;

				public Integer getEntity () {
					return this.entity;
				}

				public Boolean entityIsNullable(){
				    return true;
				}
				public Boolean entityIsKey(){
				    return false;
				}
				public Integer entityLength(){
				    return 10;
				}
				public Integer entityPrecision(){
				    return 0;
				}
				public String entityDefault(){
				
					return null;
				
				}
				public String entityComment(){
				
				    return "";
				
				}
				public String entityPattern(){
				
					return "";
				
				}
				public String entityOriginalDbColumnName(){
				
					return "entity";
				
				}

				
			    public String entity_desc;

				public String getEntity_desc () {
					return this.entity_desc;
				}

				public Boolean entity_descIsNullable(){
				    return true;
				}
				public Boolean entity_descIsKey(){
				    return false;
				}
				public Integer entity_descLength(){
				    return 2147483647;
				}
				public Integer entity_descPrecision(){
				    return 0;
				}
				public String entity_descDefault(){
				
					return null;
				
				}
				public String entity_descComment(){
				
				    return "";
				
				}
				public String entity_descPattern(){
				
					return "";
				
				}
				public String entity_descOriginalDbColumnName(){
				
					return "entity_desc";
				
				}

				
			    public Integer account;

				public Integer getAccount () {
					return this.account;
				}

				public Boolean accountIsNullable(){
				    return true;
				}
				public Boolean accountIsKey(){
				    return false;
				}
				public Integer accountLength(){
				    return 10;
				}
				public Integer accountPrecision(){
				    return 0;
				}
				public String accountDefault(){
				
					return null;
				
				}
				public String accountComment(){
				
				    return "";
				
				}
				public String accountPattern(){
				
					return "";
				
				}
				public String accountOriginalDbColumnName(){
				
					return "account";
				
				}

				
			    public String account_desc;

				public String getAccount_desc () {
					return this.account_desc;
				}

				public Boolean account_descIsNullable(){
				    return true;
				}
				public Boolean account_descIsKey(){
				    return false;
				}
				public Integer account_descLength(){
				    return 2147483647;
				}
				public Integer account_descPrecision(){
				    return 0;
				}
				public String account_descDefault(){
				
					return null;
				
				}
				public String account_descComment(){
				
				    return "";
				
				}
				public String account_descPattern(){
				
					return "";
				
				}
				public String account_descOriginalDbColumnName(){
				
					return "account_desc";
				
				}

				
			    public String location_code;

				public String getLocation_code () {
					return this.location_code;
				}

				public Boolean location_codeIsNullable(){
				    return true;
				}
				public Boolean location_codeIsKey(){
				    return false;
				}
				public Integer location_codeLength(){
				    return 2147483647;
				}
				public Integer location_codePrecision(){
				    return 0;
				}
				public String location_codeDefault(){
				
					return null;
				
				}
				public String location_codeComment(){
				
				    return "";
				
				}
				public String location_codePattern(){
				
					return "";
				
				}
				public String location_codeOriginalDbColumnName(){
				
					return "location_code";
				
				}

				
			    public String location_code_desc;

				public String getLocation_code_desc () {
					return this.location_code_desc;
				}

				public Boolean location_code_descIsNullable(){
				    return true;
				}
				public Boolean location_code_descIsKey(){
				    return false;
				}
				public Integer location_code_descLength(){
				    return 2147483647;
				}
				public Integer location_code_descPrecision(){
				    return 0;
				}
				public String location_code_descDefault(){
				
					return null;
				
				}
				public String location_code_descComment(){
				
				    return "";
				
				}
				public String location_code_descPattern(){
				
					return "";
				
				}
				public String location_code_descOriginalDbColumnName(){
				
					return "location_code_desc";
				
				}

				
			    public Integer department;

				public Integer getDepartment () {
					return this.department;
				}

				public Boolean departmentIsNullable(){
				    return true;
				}
				public Boolean departmentIsKey(){
				    return false;
				}
				public Integer departmentLength(){
				    return 10;
				}
				public Integer departmentPrecision(){
				    return 0;
				}
				public String departmentDefault(){
				
					return null;
				
				}
				public String departmentComment(){
				
				    return "";
				
				}
				public String departmentPattern(){
				
					return "";
				
				}
				public String departmentOriginalDbColumnName(){
				
					return "department";
				
				}

				
			    public String department_desc;

				public String getDepartment_desc () {
					return this.department_desc;
				}

				public Boolean department_descIsNullable(){
				    return true;
				}
				public Boolean department_descIsKey(){
				    return false;
				}
				public Integer department_descLength(){
				    return 2147483647;
				}
				public Integer department_descPrecision(){
				    return 0;
				}
				public String department_descDefault(){
				
					return null;
				
				}
				public String department_descComment(){
				
				    return "";
				
				}
				public String department_descPattern(){
				
					return "";
				
				}
				public String department_descOriginalDbColumnName(){
				
					return "department_desc";
				
				}

				
			    public String product;

				public String getProduct () {
					return this.product;
				}

				public Boolean productIsNullable(){
				    return true;
				}
				public Boolean productIsKey(){
				    return false;
				}
				public Integer productLength(){
				    return 2147483647;
				}
				public Integer productPrecision(){
				    return 0;
				}
				public String productDefault(){
				
					return null;
				
				}
				public String productComment(){
				
				    return "";
				
				}
				public String productPattern(){
				
					return "";
				
				}
				public String productOriginalDbColumnName(){
				
					return "product";
				
				}

				
			    public String product_desc;

				public String getProduct_desc () {
					return this.product_desc;
				}

				public Boolean product_descIsNullable(){
				    return true;
				}
				public Boolean product_descIsKey(){
				    return false;
				}
				public Integer product_descLength(){
				    return 2147483647;
				}
				public Integer product_descPrecision(){
				    return 0;
				}
				public String product_descDefault(){
				
					return null;
				
				}
				public String product_descComment(){
				
				    return "";
				
				}
				public String product_descPattern(){
				
					return "";
				
				}
				public String product_descOriginalDbColumnName(){
				
					return "product_desc";
				
				}

				
			    public Integer inter_company;

				public Integer getInter_company () {
					return this.inter_company;
				}

				public Boolean inter_companyIsNullable(){
				    return true;
				}
				public Boolean inter_companyIsKey(){
				    return false;
				}
				public Integer inter_companyLength(){
				    return 10;
				}
				public Integer inter_companyPrecision(){
				    return 0;
				}
				public String inter_companyDefault(){
				
					return null;
				
				}
				public String inter_companyComment(){
				
				    return "";
				
				}
				public String inter_companyPattern(){
				
					return "";
				
				}
				public String inter_companyOriginalDbColumnName(){
				
					return "inter_company";
				
				}

				
			    public String inter_company_desc;

				public String getInter_company_desc () {
					return this.inter_company_desc;
				}

				public Boolean inter_company_descIsNullable(){
				    return true;
				}
				public Boolean inter_company_descIsKey(){
				    return false;
				}
				public Integer inter_company_descLength(){
				    return 2147483647;
				}
				public Integer inter_company_descPrecision(){
				    return 0;
				}
				public String inter_company_descDefault(){
				
					return null;
				
				}
				public String inter_company_descComment(){
				
				    return "";
				
				}
				public String inter_company_descPattern(){
				
					return "";
				
				}
				public String inter_company_descOriginalDbColumnName(){
				
					return "inter_company_desc";
				
				}

				
			    public Integer inter_location;

				public Integer getInter_location () {
					return this.inter_location;
				}

				public Boolean inter_locationIsNullable(){
				    return true;
				}
				public Boolean inter_locationIsKey(){
				    return false;
				}
				public Integer inter_locationLength(){
				    return 10;
				}
				public Integer inter_locationPrecision(){
				    return 0;
				}
				public String inter_locationDefault(){
				
					return null;
				
				}
				public String inter_locationComment(){
				
				    return "";
				
				}
				public String inter_locationPattern(){
				
					return "";
				
				}
				public String inter_locationOriginalDbColumnName(){
				
					return "inter_location";
				
				}

				
			    public String inter_location_desc;

				public String getInter_location_desc () {
					return this.inter_location_desc;
				}

				public Boolean inter_location_descIsNullable(){
				    return true;
				}
				public Boolean inter_location_descIsKey(){
				    return false;
				}
				public Integer inter_location_descLength(){
				    return 2147483647;
				}
				public Integer inter_location_descPrecision(){
				    return 0;
				}
				public String inter_location_descDefault(){
				
					return null;
				
				}
				public String inter_location_descComment(){
				
				    return "";
				
				}
				public String inter_location_descPattern(){
				
					return "";
				
				}
				public String inter_location_descOriginalDbColumnName(){
				
					return "inter_location_desc";
				
				}

				
			    public String acct_type;

				public String getAcct_type () {
					return this.acct_type;
				}

				public Boolean acct_typeIsNullable(){
				    return true;
				}
				public Boolean acct_typeIsKey(){
				    return false;
				}
				public Integer acct_typeLength(){
				    return 2147483647;
				}
				public Integer acct_typePrecision(){
				    return 0;
				}
				public String acct_typeDefault(){
				
					return null;
				
				}
				public String acct_typeComment(){
				
				    return "";
				
				}
				public String acct_typePattern(){
				
					return "";
				
				}
				public String acct_typeOriginalDbColumnName(){
				
					return "acct_type";
				
				}

				
			    public BigDecimal begin_balance;

				public BigDecimal getBegin_balance () {
					return this.begin_balance;
				}

				public Boolean begin_balanceIsNullable(){
				    return true;
				}
				public Boolean begin_balanceIsKey(){
				    return false;
				}
				public Integer begin_balanceLength(){
				    return 0;
				}
				public Integer begin_balancePrecision(){
				    return 0;
				}
				public String begin_balanceDefault(){
				
					return null;
				
				}
				public String begin_balanceComment(){
				
				    return "";
				
				}
				public String begin_balancePattern(){
				
					return "";
				
				}
				public String begin_balanceOriginalDbColumnName(){
				
					return "begin_balance";
				
				}

				
			    public BigDecimal period_dr;

				public BigDecimal getPeriod_dr () {
					return this.period_dr;
				}

				public Boolean period_drIsNullable(){
				    return true;
				}
				public Boolean period_drIsKey(){
				    return false;
				}
				public Integer period_drLength(){
				    return 0;
				}
				public Integer period_drPrecision(){
				    return 0;
				}
				public String period_drDefault(){
				
					return null;
				
				}
				public String period_drComment(){
				
				    return "";
				
				}
				public String period_drPattern(){
				
					return "";
				
				}
				public String period_drOriginalDbColumnName(){
				
					return "period_dr";
				
				}

				
			    public BigDecimal period_cr;

				public BigDecimal getPeriod_cr () {
					return this.period_cr;
				}

				public Boolean period_crIsNullable(){
				    return true;
				}
				public Boolean period_crIsKey(){
				    return false;
				}
				public Integer period_crLength(){
				    return 0;
				}
				public Integer period_crPrecision(){
				    return 0;
				}
				public String period_crDefault(){
				
					return null;
				
				}
				public String period_crComment(){
				
				    return "";
				
				}
				public String period_crPattern(){
				
					return "";
				
				}
				public String period_crOriginalDbColumnName(){
				
					return "period_cr";
				
				}

				
			    public BigDecimal end_balance;

				public BigDecimal getEnd_balance () {
					return this.end_balance;
				}

				public Boolean end_balanceIsNullable(){
				    return true;
				}
				public Boolean end_balanceIsKey(){
				    return false;
				}
				public Integer end_balanceLength(){
				    return 0;
				}
				public Integer end_balancePrecision(){
				    return 0;
				}
				public String end_balanceDefault(){
				
					return null;
				
				}
				public String end_balanceComment(){
				
				    return "";
				
				}
				public String end_balancePattern(){
				
					return "";
				
				}
				public String end_balanceOriginalDbColumnName(){
				
					return "end_balance";
				
				}

				
			    public String business_unit;

				public String getBusiness_unit () {
					return this.business_unit;
				}

				public Boolean business_unitIsNullable(){
				    return true;
				}
				public Boolean business_unitIsKey(){
				    return false;
				}
				public Integer business_unitLength(){
				    return 50;
				}
				public Integer business_unitPrecision(){
				    return 0;
				}
				public String business_unitDefault(){
				
					return null;
				
				}
				public String business_unitComment(){
				
				    return "";
				
				}
				public String business_unitPattern(){
				
					return "";
				
				}
				public String business_unitOriginalDbColumnName(){
				
					return "business_unit";
				
				}

				
			    public Integer vendor_num;

				public Integer getVendor_num () {
					return this.vendor_num;
				}

				public Boolean vendor_numIsNullable(){
				    return true;
				}
				public Boolean vendor_numIsKey(){
				    return false;
				}
				public Integer vendor_numLength(){
				    return 10;
				}
				public Integer vendor_numPrecision(){
				    return 0;
				}
				public String vendor_numDefault(){
				
					return null;
				
				}
				public String vendor_numComment(){
				
				    return "";
				
				}
				public String vendor_numPattern(){
				
					return "";
				
				}
				public String vendor_numOriginalDbColumnName(){
				
					return "vendor_num";
				
				}

				
			    public String supp_name;

				public String getSupp_name () {
					return this.supp_name;
				}

				public Boolean supp_nameIsNullable(){
				    return true;
				}
				public Boolean supp_nameIsKey(){
				    return false;
				}
				public Integer supp_nameLength(){
				    return 128;
				}
				public Integer supp_namePrecision(){
				    return 0;
				}
				public String supp_nameDefault(){
				
					return null;
				
				}
				public String supp_nameComment(){
				
				    return "";
				
				}
				public String supp_namePattern(){
				
					return "";
				
				}
				public String supp_nameOriginalDbColumnName(){
				
					return "supp_name";
				
				}

				
			    public String vendor_type;

				public String getVendor_type () {
					return this.vendor_type;
				}

				public Boolean vendor_typeIsNullable(){
				    return true;
				}
				public Boolean vendor_typeIsKey(){
				    return false;
				}
				public Integer vendor_typeLength(){
				    return 50;
				}
				public Integer vendor_typePrecision(){
				    return 0;
				}
				public String vendor_typeDefault(){
				
					return null;
				
				}
				public String vendor_typeComment(){
				
				    return "";
				
				}
				public String vendor_typePattern(){
				
					return "";
				
				}
				public String vendor_typeOriginalDbColumnName(){
				
					return "vendor_type";
				
				}

				
			    public String tax_org_type;

				public String getTax_org_type () {
					return this.tax_org_type;
				}

				public Boolean tax_org_typeIsNullable(){
				    return true;
				}
				public Boolean tax_org_typeIsKey(){
				    return false;
				}
				public Integer tax_org_typeLength(){
				    return 50;
				}
				public Integer tax_org_typePrecision(){
				    return 0;
				}
				public String tax_org_typeDefault(){
				
					return null;
				
				}
				public String tax_org_typeComment(){
				
				    return "";
				
				}
				public String tax_org_typePattern(){
				
					return "";
				
				}
				public String tax_org_typeOriginalDbColumnName(){
				
					return "tax_org_type";
				
				}

				
			    public String vendor_site_code;

				public String getVendor_site_code () {
					return this.vendor_site_code;
				}

				public Boolean vendor_site_codeIsNullable(){
				    return true;
				}
				public Boolean vendor_site_codeIsKey(){
				    return false;
				}
				public Integer vendor_site_codeLength(){
				    return 50;
				}
				public Integer vendor_site_codePrecision(){
				    return 0;
				}
				public String vendor_site_codeDefault(){
				
					return null;
				
				}
				public String vendor_site_codeComment(){
				
				    return "";
				
				}
				public String vendor_site_codePattern(){
				
					return "";
				
				}
				public String vendor_site_codeOriginalDbColumnName(){
				
					return "vendor_site_code";
				
				}

				
			    public String supp_status;

				public String getSupp_status () {
					return this.supp_status;
				}

				public Boolean supp_statusIsNullable(){
				    return true;
				}
				public Boolean supp_statusIsKey(){
				    return false;
				}
				public Integer supp_statusLength(){
				    return 50;
				}
				public Integer supp_statusPrecision(){
				    return 0;
				}
				public String supp_statusDefault(){
				
					return null;
				
				}
				public String supp_statusComment(){
				
				    return "";
				
				}
				public String supp_statusPattern(){
				
					return "";
				
				}
				public String supp_statusOriginalDbColumnName(){
				
					return "supp_status";
				
				}

				
			    public String pay_method;

				public String getPay_method () {
					return this.pay_method;
				}

				public Boolean pay_methodIsNullable(){
				    return true;
				}
				public Boolean pay_methodIsKey(){
				    return false;
				}
				public Integer pay_methodLength(){
				    return 50;
				}
				public Integer pay_methodPrecision(){
				    return 0;
				}
				public String pay_methodDefault(){
				
					return null;
				
				}
				public String pay_methodComment(){
				
				    return "";
				
				}
				public String pay_methodPattern(){
				
					return "";
				
				}
				public String pay_methodOriginalDbColumnName(){
				
					return "pay_method";
				
				}

				
			    public String country;

				public String getCountry () {
					return this.country;
				}

				public Boolean countryIsNullable(){
				    return true;
				}
				public Boolean countryIsKey(){
				    return false;
				}
				public Integer countryLength(){
				    return 50;
				}
				public Integer countryPrecision(){
				    return 0;
				}
				public String countryDefault(){
				
					return null;
				
				}
				public String countryComment(){
				
				    return "";
				
				}
				public String countryPattern(){
				
					return "";
				
				}
				public String countryOriginalDbColumnName(){
				
					return "country";
				
				}

				
			    public String address1;

				public String getAddress1 () {
					return this.address1;
				}

				public Boolean address1IsNullable(){
				    return true;
				}
				public Boolean address1IsKey(){
				    return false;
				}
				public Integer address1Length(){
				    return 128;
				}
				public Integer address1Precision(){
				    return 0;
				}
				public String address1Default(){
				
					return null;
				
				}
				public String address1Comment(){
				
				    return "";
				
				}
				public String address1Pattern(){
				
					return "";
				
				}
				public String address1OriginalDbColumnName(){
				
					return "address1";
				
				}

				
			    public String address2;

				public String getAddress2 () {
					return this.address2;
				}

				public Boolean address2IsNullable(){
				    return true;
				}
				public Boolean address2IsKey(){
				    return false;
				}
				public Integer address2Length(){
				    return 64;
				}
				public Integer address2Precision(){
				    return 0;
				}
				public String address2Default(){
				
					return null;
				
				}
				public String address2Comment(){
				
				    return "";
				
				}
				public String address2Pattern(){
				
					return "";
				
				}
				public String address2OriginalDbColumnName(){
				
					return "address2";
				
				}

				
			    public String city;

				public String getCity () {
					return this.city;
				}

				public Boolean cityIsNullable(){
				    return true;
				}
				public Boolean cityIsKey(){
				    return false;
				}
				public Integer cityLength(){
				    return 50;
				}
				public Integer cityPrecision(){
				    return 0;
				}
				public String cityDefault(){
				
					return null;
				
				}
				public String cityComment(){
				
				    return "";
				
				}
				public String cityPattern(){
				
					return "";
				
				}
				public String cityOriginalDbColumnName(){
				
					return "city";
				
				}

				
			    public String state;

				public String getState () {
					return this.state;
				}

				public Boolean stateIsNullable(){
				    return true;
				}
				public Boolean stateIsKey(){
				    return false;
				}
				public Integer stateLength(){
				    return 50;
				}
				public Integer statePrecision(){
				    return 0;
				}
				public String stateDefault(){
				
					return null;
				
				}
				public String stateComment(){
				
				    return "";
				
				}
				public String statePattern(){
				
					return "";
				
				}
				public String stateOriginalDbColumnName(){
				
					return "state";
				
				}

				
			    public Integer postal_code;

				public Integer getPostal_code () {
					return this.postal_code;
				}

				public Boolean postal_codeIsNullable(){
				    return true;
				}
				public Boolean postal_codeIsKey(){
				    return false;
				}
				public Integer postal_codeLength(){
				    return 10;
				}
				public Integer postal_codePrecision(){
				    return 0;
				}
				public String postal_codeDefault(){
				
					return null;
				
				}
				public String postal_codeComment(){
				
				    return "";
				
				}
				public String postal_codePattern(){
				
					return "";
				
				}
				public String postal_codeOriginalDbColumnName(){
				
					return "postal_code";
				
				}

				
			    public String liab_acct;

				public String getLiab_acct () {
					return this.liab_acct;
				}

				public Boolean liab_acctIsNullable(){
				    return true;
				}
				public Boolean liab_acctIsKey(){
				    return false;
				}
				public Integer liab_acctLength(){
				    return 50;
				}
				public Integer liab_acctPrecision(){
				    return 0;
				}
				public String liab_acctDefault(){
				
					return null;
				
				}
				public String liab_acctComment(){
				
				    return "";
				
				}
				public String liab_acctPattern(){
				
					return "";
				
				}
				public String liab_acctOriginalDbColumnName(){
				
					return "liab_acct";
				
				}

				
			    public String prepay_acct;

				public String getPrepay_acct () {
					return this.prepay_acct;
				}

				public Boolean prepay_acctIsNullable(){
				    return true;
				}
				public Boolean prepay_acctIsKey(){
				    return false;
				}
				public Integer prepay_acctLength(){
				    return 50;
				}
				public Integer prepay_acctPrecision(){
				    return 0;
				}
				public String prepay_acctDefault(){
				
					return null;
				
				}
				public String prepay_acctComment(){
				
				    return "";
				
				}
				public String prepay_acctPattern(){
				
					return "";
				
				}
				public String prepay_acctOriginalDbColumnName(){
				
					return "prepay_acct";
				
				}

				
			    public String sup_bank_account_num;

				public String getSup_bank_account_num () {
					return this.sup_bank_account_num;
				}

				public Boolean sup_bank_account_numIsNullable(){
				    return true;
				}
				public Boolean sup_bank_account_numIsKey(){
				    return false;
				}
				public Integer sup_bank_account_numLength(){
				    return 50;
				}
				public Integer sup_bank_account_numPrecision(){
				    return 0;
				}
				public String sup_bank_account_numDefault(){
				
					return null;
				
				}
				public String sup_bank_account_numComment(){
				
				    return "";
				
				}
				public String sup_bank_account_numPattern(){
				
					return "";
				
				}
				public String sup_bank_account_numOriginalDbColumnName(){
				
					return "sup_bank_account_num";
				
				}

				
			    public String sup_bank_account_name;

				public String getSup_bank_account_name () {
					return this.sup_bank_account_name;
				}

				public Boolean sup_bank_account_nameIsNullable(){
				    return true;
				}
				public Boolean sup_bank_account_nameIsKey(){
				    return false;
				}
				public Integer sup_bank_account_nameLength(){
				    return 64;
				}
				public Integer sup_bank_account_namePrecision(){
				    return 0;
				}
				public String sup_bank_account_nameDefault(){
				
					return null;
				
				}
				public String sup_bank_account_nameComment(){
				
				    return "";
				
				}
				public String sup_bank_account_namePattern(){
				
					return "";
				
				}
				public String sup_bank_account_nameOriginalDbColumnName(){
				
					return "sup_bank_account_name";
				
				}

				
			    public String sup_bank_branch_name;

				public String getSup_bank_branch_name () {
					return this.sup_bank_branch_name;
				}

				public Boolean sup_bank_branch_nameIsNullable(){
				    return true;
				}
				public Boolean sup_bank_branch_nameIsKey(){
				    return false;
				}
				public Integer sup_bank_branch_nameLength(){
				    return 50;
				}
				public Integer sup_bank_branch_namePrecision(){
				    return 0;
				}
				public String sup_bank_branch_nameDefault(){
				
					return null;
				
				}
				public String sup_bank_branch_nameComment(){
				
				    return "";
				
				}
				public String sup_bank_branch_namePattern(){
				
					return "";
				
				}
				public String sup_bank_branch_nameOriginalDbColumnName(){
				
					return "sup_bank_branch_name";
				
				}

				
			    public String sup_bank_name;

				public String getSup_bank_name () {
					return this.sup_bank_name;
				}

				public Boolean sup_bank_nameIsNullable(){
				    return true;
				}
				public Boolean sup_bank_nameIsKey(){
				    return false;
				}
				public Integer sup_bank_nameLength(){
				    return 50;
				}
				public Integer sup_bank_namePrecision(){
				    return 0;
				}
				public String sup_bank_nameDefault(){
				
					return null;
				
				}
				public String sup_bank_nameComment(){
				
				    return "";
				
				}
				public String sup_bank_namePattern(){
				
					return "";
				
				}
				public String sup_bank_nameOriginalDbColumnName(){
				
					return "sup_bank_name";
				
				}

				
			    public String sup_ifsc_code;

				public String getSup_ifsc_code () {
					return this.sup_ifsc_code;
				}

				public Boolean sup_ifsc_codeIsNullable(){
				    return true;
				}
				public Boolean sup_ifsc_codeIsKey(){
				    return false;
				}
				public Integer sup_ifsc_codeLength(){
				    return 50;
				}
				public Integer sup_ifsc_codePrecision(){
				    return 0;
				}
				public String sup_ifsc_codeDefault(){
				
					return null;
				
				}
				public String sup_ifsc_codeComment(){
				
				    return "";
				
				}
				public String sup_ifsc_codePattern(){
				
					return "";
				
				}
				public String sup_ifsc_codeOriginalDbColumnName(){
				
					return "sup_ifsc_code";
				
				}

				
			    public String msme_tag;

				public String getMsme_tag () {
					return this.msme_tag;
				}

				public Boolean msme_tagIsNullable(){
				    return true;
				}
				public Boolean msme_tagIsKey(){
				    return false;
				}
				public Integer msme_tagLength(){
				    return 50;
				}
				public Integer msme_tagPrecision(){
				    return 0;
				}
				public String msme_tagDefault(){
				
					return null;
				
				}
				public String msme_tagComment(){
				
				    return "";
				
				}
				public String msme_tagPattern(){
				
					return "";
				
				}
				public String msme_tagOriginalDbColumnName(){
				
					return "msme_tag";
				
				}

				
			    public String vendor_creation_date;

				public String getVendor_creation_date () {
					return this.vendor_creation_date;
				}

				public Boolean vendor_creation_dateIsNullable(){
				    return true;
				}
				public Boolean vendor_creation_dateIsKey(){
				    return false;
				}
				public Integer vendor_creation_dateLength(){
				    return 50;
				}
				public Integer vendor_creation_datePrecision(){
				    return 0;
				}
				public String vendor_creation_dateDefault(){
				
					return null;
				
				}
				public String vendor_creation_dateComment(){
				
				    return "";
				
				}
				public String vendor_creation_datePattern(){
				
					return "";
				
				}
				public String vendor_creation_dateOriginalDbColumnName(){
				
					return "vendor_creation_date";
				
				}

				
			    public String site_creation_date;

				public String getSite_creation_date () {
					return this.site_creation_date;
				}

				public Boolean site_creation_dateIsNullable(){
				    return true;
				}
				public Boolean site_creation_dateIsKey(){
				    return false;
				}
				public Integer site_creation_dateLength(){
				    return 50;
				}
				public Integer site_creation_datePrecision(){
				    return 0;
				}
				public String site_creation_dateDefault(){
				
					return null;
				
				}
				public String site_creation_dateComment(){
				
				    return "";
				
				}
				public String site_creation_datePattern(){
				
					return "";
				
				}
				public String site_creation_dateOriginalDbColumnName(){
				
					return "site_creation_date";
				
				}

				
			    public String last_transaction_date;

				public String getLast_transaction_date () {
					return this.last_transaction_date;
				}

				public Boolean last_transaction_dateIsNullable(){
				    return true;
				}
				public Boolean last_transaction_dateIsKey(){
				    return false;
				}
				public Integer last_transaction_dateLength(){
				    return 50;
				}
				public Integer last_transaction_datePrecision(){
				    return 0;
				}
				public String last_transaction_dateDefault(){
				
					return null;
				
				}
				public String last_transaction_dateComment(){
				
				    return "";
				
				}
				public String last_transaction_datePattern(){
				
					return "";
				
				}
				public String last_transaction_dateOriginalDbColumnName(){
				
					return "last_transaction_date";
				
				}

				
			    public String party_site_name;

				public String getParty_site_name () {
					return this.party_site_name;
				}

				public Boolean party_site_nameIsNullable(){
				    return true;
				}
				public Boolean party_site_nameIsKey(){
				    return false;
				}
				public Integer party_site_nameLength(){
				    return 50;
				}
				public Integer party_site_namePrecision(){
				    return 0;
				}
				public String party_site_nameDefault(){
				
					return null;
				
				}
				public String party_site_nameComment(){
				
				    return "";
				
				}
				public String party_site_namePattern(){
				
					return "";
				
				}
				public String party_site_nameOriginalDbColumnName(){
				
					return "party_site_name";
				
				}

				
			    public String sup_branch_number;

				public String getSup_branch_number () {
					return this.sup_branch_number;
				}

				public Boolean sup_branch_numberIsNullable(){
				    return true;
				}
				public Boolean sup_branch_numberIsKey(){
				    return false;
				}
				public Integer sup_branch_numberLength(){
				    return 50;
				}
				public Integer sup_branch_numberPrecision(){
				    return 0;
				}
				public String sup_branch_numberDefault(){
				
					return null;
				
				}
				public String sup_branch_numberComment(){
				
				    return "";
				
				}
				public String sup_branch_numberPattern(){
				
					return "";
				
				}
				public String sup_branch_numberOriginalDbColumnName(){
				
					return "sup_branch_number";
				
				}

				
			    public String site_created_by;

				public String getSite_created_by () {
					return this.site_created_by;
				}

				public Boolean site_created_byIsNullable(){
				    return true;
				}
				public Boolean site_created_byIsKey(){
				    return false;
				}
				public Integer site_created_byLength(){
				    return 50;
				}
				public Integer site_created_byPrecision(){
				    return 0;
				}
				public String site_created_byDefault(){
				
					return null;
				
				}
				public String site_created_byComment(){
				
				    return "";
				
				}
				public String site_created_byPattern(){
				
					return "";
				
				}
				public String site_created_byOriginalDbColumnName(){
				
					return "site_created_by";
				
				}

				
			    public String pan_number;

				public String getPan_number () {
					return this.pan_number;
				}

				public Boolean pan_numberIsNullable(){
				    return true;
				}
				public Boolean pan_numberIsKey(){
				    return false;
				}
				public Integer pan_numberLength(){
				    return 50;
				}
				public Integer pan_numberPrecision(){
				    return 0;
				}
				public String pan_numberDefault(){
				
					return null;
				
				}
				public String pan_numberComment(){
				
				    return "";
				
				}
				public String pan_numberPattern(){
				
					return "";
				
				}
				public String pan_numberOriginalDbColumnName(){
				
					return "pan_number";
				
				}

				
			    public String gst_number;

				public String getGst_number () {
					return this.gst_number;
				}

				public Boolean gst_numberIsNullable(){
				    return true;
				}
				public Boolean gst_numberIsKey(){
				    return false;
				}
				public Integer gst_numberLength(){
				    return 50;
				}
				public Integer gst_numberPrecision(){
				    return 0;
				}
				public String gst_numberDefault(){
				
					return null;
				
				}
				public String gst_numberComment(){
				
				    return "";
				
				}
				public String gst_numberPattern(){
				
					return "";
				
				}
				public String gst_numberOriginalDbColumnName(){
				
					return "gst_number";
				
				}

				
			    public String msme_no;

				public String getMsme_no () {
					return this.msme_no;
				}

				public Boolean msme_noIsNullable(){
				    return true;
				}
				public Boolean msme_noIsKey(){
				    return false;
				}
				public Integer msme_noLength(){
				    return 50;
				}
				public Integer msme_noPrecision(){
				    return 0;
				}
				public String msme_noDefault(){
				
					return null;
				
				}
				public String msme_noComment(){
				
				    return "";
				
				}
				public String msme_noPattern(){
				
					return "";
				
				}
				public String msme_noOriginalDbColumnName(){
				
					return "msme_no";
				
				}

				
			    public String address3;

				public String getAddress3 () {
					return this.address3;
				}

				public Boolean address3IsNullable(){
				    return true;
				}
				public Boolean address3IsKey(){
				    return false;
				}
				public Integer address3Length(){
				    return 50;
				}
				public Integer address3Precision(){
				    return 0;
				}
				public String address3Default(){
				
					return null;
				
				}
				public String address3Comment(){
				
				    return "";
				
				}
				public String address3Pattern(){
				
					return "";
				
				}
				public String address3OriginalDbColumnName(){
				
					return "address3";
				
				}

				
			    public Integer site_bank_account_num;

				public Integer getSite_bank_account_num () {
					return this.site_bank_account_num;
				}

				public Boolean site_bank_account_numIsNullable(){
				    return true;
				}
				public Boolean site_bank_account_numIsKey(){
				    return false;
				}
				public Integer site_bank_account_numLength(){
				    return 10;
				}
				public Integer site_bank_account_numPrecision(){
				    return 0;
				}
				public String site_bank_account_numDefault(){
				
					return null;
				
				}
				public String site_bank_account_numComment(){
				
				    return "";
				
				}
				public String site_bank_account_numPattern(){
				
					return "";
				
				}
				public String site_bank_account_numOriginalDbColumnName(){
				
					return "site_bank_account_num";
				
				}

				
			    public String site_bank_branch_name;

				public String getSite_bank_branch_name () {
					return this.site_bank_branch_name;
				}

				public Boolean site_bank_branch_nameIsNullable(){
				    return true;
				}
				public Boolean site_bank_branch_nameIsKey(){
				    return false;
				}
				public Integer site_bank_branch_nameLength(){
				    return 50;
				}
				public Integer site_bank_branch_namePrecision(){
				    return 0;
				}
				public String site_bank_branch_nameDefault(){
				
					return null;
				
				}
				public String site_bank_branch_nameComment(){
				
				    return "";
				
				}
				public String site_bank_branch_namePattern(){
				
					return "";
				
				}
				public String site_bank_branch_nameOriginalDbColumnName(){
				
					return "site_bank_branch_name";
				
				}

				
			    public String site_bank_name;

				public String getSite_bank_name () {
					return this.site_bank_name;
				}

				public Boolean site_bank_nameIsNullable(){
				    return true;
				}
				public Boolean site_bank_nameIsKey(){
				    return false;
				}
				public Integer site_bank_nameLength(){
				    return 50;
				}
				public Integer site_bank_namePrecision(){
				    return 0;
				}
				public String site_bank_nameDefault(){
				
					return null;
				
				}
				public String site_bank_nameComment(){
				
				    return "";
				
				}
				public String site_bank_namePattern(){
				
					return "";
				
				}
				public String site_bank_nameOriginalDbColumnName(){
				
					return "site_bank_name";
				
				}

				
			    public String site_branch_number;

				public String getSite_branch_number () {
					return this.site_branch_number;
				}

				public Boolean site_branch_numberIsNullable(){
				    return true;
				}
				public Boolean site_branch_numberIsKey(){
				    return false;
				}
				public Integer site_branch_numberLength(){
				    return 50;
				}
				public Integer site_branch_numberPrecision(){
				    return 0;
				}
				public String site_branch_numberDefault(){
				
					return null;
				
				}
				public String site_branch_numberComment(){
				
				    return "";
				
				}
				public String site_branch_numberPattern(){
				
					return "";
				
				}
				public String site_branch_numberOriginalDbColumnName(){
				
					return "site_branch_number";
				
				}

				
			    public String site_ifsc_code;

				public String getSite_ifsc_code () {
					return this.site_ifsc_code;
				}

				public Boolean site_ifsc_codeIsNullable(){
				    return true;
				}
				public Boolean site_ifsc_codeIsKey(){
				    return false;
				}
				public Integer site_ifsc_codeLength(){
				    return 50;
				}
				public Integer site_ifsc_codePrecision(){
				    return 0;
				}
				public String site_ifsc_codeDefault(){
				
					return null;
				
				}
				public String site_ifsc_codeComment(){
				
				    return "";
				
				}
				public String site_ifsc_codePattern(){
				
					return "";
				
				}
				public String site_ifsc_codeOriginalDbColumnName(){
				
					return "site_ifsc_code";
				
				}

				
			    public String site_bank_account_name;

				public String getSite_bank_account_name () {
					return this.site_bank_account_name;
				}

				public Boolean site_bank_account_nameIsNullable(){
				    return true;
				}
				public Boolean site_bank_account_nameIsKey(){
				    return false;
				}
				public Integer site_bank_account_nameLength(){
				    return 50;
				}
				public Integer site_bank_account_namePrecision(){
				    return 0;
				}
				public String site_bank_account_nameDefault(){
				
					return null;
				
				}
				public String site_bank_account_nameComment(){
				
				    return "";
				
				}
				public String site_bank_account_namePattern(){
				
					return "";
				
				}
				public String site_bank_account_nameOriginalDbColumnName(){
				
					return "site_bank_account_name";
				
				}

				
			    public String vendor_created_by;

				public String getVendor_created_by () {
					return this.vendor_created_by;
				}

				public Boolean vendor_created_byIsNullable(){
				    return true;
				}
				public Boolean vendor_created_byIsKey(){
				    return false;
				}
				public Integer vendor_created_byLength(){
				    return 50;
				}
				public Integer vendor_created_byPrecision(){
				    return 0;
				}
				public String vendor_created_byDefault(){
				
					return null;
				
				}
				public String vendor_created_byComment(){
				
				    return "";
				
				}
				public String vendor_created_byPattern(){
				
					return "";
				
				}
				public String vendor_created_byOriginalDbColumnName(){
				
					return "vendor_created_by";
				
				}

				
			    public String inactivated_date;

				public String getInactivated_date () {
					return this.inactivated_date;
				}

				public Boolean inactivated_dateIsNullable(){
				    return true;
				}
				public Boolean inactivated_dateIsKey(){
				    return false;
				}
				public Integer inactivated_dateLength(){
				    return 50;
				}
				public Integer inactivated_datePrecision(){
				    return 0;
				}
				public String inactivated_dateDefault(){
				
					return null;
				
				}
				public String inactivated_dateComment(){
				
				    return "";
				
				}
				public String inactivated_datePattern(){
				
					return "";
				
				}
				public String inactivated_dateOriginalDbColumnName(){
				
					return "inactivated_date";
				
				}

				
			    public String inactivated_by;

				public String getInactivated_by () {
					return this.inactivated_by;
				}

				public Boolean inactivated_byIsNullable(){
				    return true;
				}
				public Boolean inactivated_byIsKey(){
				    return false;
				}
				public Integer inactivated_byLength(){
				    return 50;
				}
				public Integer inactivated_byPrecision(){
				    return 0;
				}
				public String inactivated_byDefault(){
				
					return null;
				
				}
				public String inactivated_byComment(){
				
				    return "";
				
				}
				public String inactivated_byPattern(){
				
					return "";
				
				}
				public String inactivated_byOriginalDbColumnName(){
				
					return "inactivated_by";
				
				}

				
			    public String address4;

				public String getAddress4 () {
					return this.address4;
				}

				public Boolean address4IsNullable(){
				    return true;
				}
				public Boolean address4IsKey(){
				    return false;
				}
				public Integer address4Length(){
				    return 50;
				}
				public Integer address4Precision(){
				    return 0;
				}
				public String address4Default(){
				
					return null;
				
				}
				public String address4Comment(){
				
				    return "";
				
				}
				public String address4Pattern(){
				
					return "";
				
				}
				public String address4OriginalDbColumnName(){
				
					return "address4";
				
				}

				
			    public String tds_section;

				public String getTds_section () {
					return this.tds_section;
				}

				public Boolean tds_sectionIsNullable(){
				    return true;
				}
				public Boolean tds_sectionIsKey(){
				    return false;
				}
				public Integer tds_sectionLength(){
				    return 50;
				}
				public Integer tds_sectionPrecision(){
				    return 0;
				}
				public String tds_sectionDefault(){
				
					return null;
				
				}
				public String tds_sectionComment(){
				
				    return "";
				
				}
				public String tds_sectionPattern(){
				
					return "";
				
				}
				public String tds_sectionOriginalDbColumnName(){
				
					return "tds_section";
				
				}

				
			    public String tds_code;

				public String getTds_code () {
					return this.tds_code;
				}

				public Boolean tds_codeIsNullable(){
				    return true;
				}
				public Boolean tds_codeIsKey(){
				    return false;
				}
				public Integer tds_codeLength(){
				    return 50;
				}
				public Integer tds_codePrecision(){
				    return 0;
				}
				public String tds_codeDefault(){
				
					return null;
				
				}
				public String tds_codeComment(){
				
				    return "";
				
				}
				public String tds_codePattern(){
				
					return "";
				
				}
				public String tds_codeOriginalDbColumnName(){
				
					return "tds_code";
				
				}

				
			    public Integer tax_rate;

				public Integer getTax_rate () {
					return this.tax_rate;
				}

				public Boolean tax_rateIsNullable(){
				    return true;
				}
				public Boolean tax_rateIsKey(){
				    return false;
				}
				public Integer tax_rateLength(){
				    return 10;
				}
				public Integer tax_ratePrecision(){
				    return 0;
				}
				public String tax_rateDefault(){
				
					return null;
				
				}
				public String tax_rateComment(){
				
				    return "";
				
				}
				public String tax_ratePattern(){
				
					return "";
				
				}
				public String tax_rateOriginalDbColumnName(){
				
					return "tax_rate";
				
				}

				
			    public Integer supplier_number;

				public Integer getSupplier_number () {
					return this.supplier_number;
				}

				public Boolean supplier_numberIsNullable(){
				    return true;
				}
				public Boolean supplier_numberIsKey(){
				    return false;
				}
				public Integer supplier_numberLength(){
				    return 10;
				}
				public Integer supplier_numberPrecision(){
				    return 0;
				}
				public String supplier_numberDefault(){
				
					return null;
				
				}
				public String supplier_numberComment(){
				
				    return "";
				
				}
				public String supplier_numberPattern(){
				
					return "";
				
				}
				public String supplier_numberOriginalDbColumnName(){
				
					return "supplier_number";
				
				}

				
			    public String supplier_name;

				public String getSupplier_name () {
					return this.supplier_name;
				}

				public Boolean supplier_nameIsNullable(){
				    return true;
				}
				public Boolean supplier_nameIsKey(){
				    return false;
				}
				public Integer supplier_nameLength(){
				    return 50;
				}
				public Integer supplier_namePrecision(){
				    return 0;
				}
				public String supplier_nameDefault(){
				
					return null;
				
				}
				public String supplier_nameComment(){
				
				    return "";
				
				}
				public String supplier_namePattern(){
				
					return "";
				
				}
				public String supplier_nameOriginalDbColumnName(){
				
					return "supplier_name";
				
				}

				
			    public String NAME;

				public String getNAME () {
					return this.NAME;
				}

				public Boolean NAMEIsNullable(){
				    return true;
				}
				public Boolean NAMEIsKey(){
				    return false;
				}
				public Integer NAMELength(){
				    return 50;
				}
				public Integer NAMEPrecision(){
				    return 0;
				}
				public String NAMEDefault(){
				
					return null;
				
				}
				public String NAMEComment(){
				
				    return "";
				
				}
				public String NAMEPattern(){
				
					return "";
				
				}
				public String NAMEOriginalDbColumnName(){
				
					return "NAME";
				
				}

				
			    public Integer liab_account;

				public Integer getLiab_account () {
					return this.liab_account;
				}

				public Boolean liab_accountIsNullable(){
				    return true;
				}
				public Boolean liab_accountIsKey(){
				    return false;
				}
				public Integer liab_accountLength(){
				    return 10;
				}
				public Integer liab_accountPrecision(){
				    return 0;
				}
				public String liab_accountDefault(){
				
					return null;
				
				}
				public String liab_accountComment(){
				
				    return "";
				
				}
				public String liab_accountPattern(){
				
					return "";
				
				}
				public String liab_accountOriginalDbColumnName(){
				
					return "liab_account";
				
				}

				
			    public String liab_acct_desc;

				public String getLiab_acct_desc () {
					return this.liab_acct_desc;
				}

				public Boolean liab_acct_descIsNullable(){
				    return true;
				}
				public Boolean liab_acct_descIsKey(){
				    return false;
				}
				public Integer liab_acct_descLength(){
				    return 50;
				}
				public Integer liab_acct_descPrecision(){
				    return 0;
				}
				public String liab_acct_descDefault(){
				
					return null;
				
				}
				public String liab_acct_descComment(){
				
				    return "";
				
				}
				public String liab_acct_descPattern(){
				
					return "";
				
				}
				public String liab_acct_descOriginalDbColumnName(){
				
					return "liab_acct_desc";
				
				}

				
			    public Integer expense_account;

				public Integer getExpense_account () {
					return this.expense_account;
				}

				public Boolean expense_accountIsNullable(){
				    return true;
				}
				public Boolean expense_accountIsKey(){
				    return false;
				}
				public Integer expense_accountLength(){
				    return 10;
				}
				public Integer expense_accountPrecision(){
				    return 0;
				}
				public String expense_accountDefault(){
				
					return null;
				
				}
				public String expense_accountComment(){
				
				    return "";
				
				}
				public String expense_accountPattern(){
				
					return "";
				
				}
				public String expense_accountOriginalDbColumnName(){
				
					return "expense_account";
				
				}

				
			    public String expense_acct_desc;

				public String getExpense_acct_desc () {
					return this.expense_acct_desc;
				}

				public Boolean expense_acct_descIsNullable(){
				    return true;
				}
				public Boolean expense_acct_descIsKey(){
				    return false;
				}
				public Integer expense_acct_descLength(){
				    return 50;
				}
				public Integer expense_acct_descPrecision(){
				    return 0;
				}
				public String expense_acct_descDefault(){
				
					return null;
				
				}
				public String expense_acct_descComment(){
				
				    return "";
				
				}
				public String expense_acct_descPattern(){
				
					return "";
				
				}
				public String expense_acct_descOriginalDbColumnName(){
				
					return "expense_acct_desc";
				
				}

				
			    public String organization_type;

				public String getOrganization_type () {
					return this.organization_type;
				}

				public Boolean organization_typeIsNullable(){
				    return true;
				}
				public Boolean organization_typeIsKey(){
				    return false;
				}
				public Integer organization_typeLength(){
				    return 50;
				}
				public Integer organization_typePrecision(){
				    return 0;
				}
				public String organization_typeDefault(){
				
					return null;
				
				}
				public String organization_typeComment(){
				
				    return "";
				
				}
				public String organization_typePattern(){
				
					return "";
				
				}
				public String organization_typeOriginalDbColumnName(){
				
					return "organization_type";
				
				}

				
			    public String certificate;

				public String getCertificate () {
					return this.certificate;
				}

				public Boolean certificateIsNullable(){
				    return true;
				}
				public Boolean certificateIsKey(){
				    return false;
				}
				public Integer certificateLength(){
				    return 50;
				}
				public Integer certificatePrecision(){
				    return 0;
				}
				public String certificateDefault(){
				
					return null;
				
				}
				public String certificateComment(){
				
				    return "";
				
				}
				public String certificatePattern(){
				
					return "";
				
				}
				public String certificateOriginalDbColumnName(){
				
					return "certificate";
				
				}

				
			    public String invoice_num;

				public String getInvoice_num () {
					return this.invoice_num;
				}

				public Boolean invoice_numIsNullable(){
				    return true;
				}
				public Boolean invoice_numIsKey(){
				    return false;
				}
				public Integer invoice_numLength(){
				    return 50;
				}
				public Integer invoice_numPrecision(){
				    return 0;
				}
				public String invoice_numDefault(){
				
					return null;
				
				}
				public String invoice_numComment(){
				
				    return "";
				
				}
				public String invoice_numPattern(){
				
					return "";
				
				}
				public String invoice_numOriginalDbColumnName(){
				
					return "invoice_num";
				
				}

				
			    public String ref_invoice_num;

				public String getRef_invoice_num () {
					return this.ref_invoice_num;
				}

				public Boolean ref_invoice_numIsNullable(){
				    return true;
				}
				public Boolean ref_invoice_numIsKey(){
				    return false;
				}
				public Integer ref_invoice_numLength(){
				    return 50;
				}
				public Integer ref_invoice_numPrecision(){
				    return 0;
				}
				public String ref_invoice_numDefault(){
				
					return null;
				
				}
				public String ref_invoice_numComment(){
				
				    return "";
				
				}
				public String ref_invoice_numPattern(){
				
					return "";
				
				}
				public String ref_invoice_numOriginalDbColumnName(){
				
					return "ref_invoice_num";
				
				}

				
			    public Integer vouchar_num;

				public Integer getVouchar_num () {
					return this.vouchar_num;
				}

				public Boolean vouchar_numIsNullable(){
				    return true;
				}
				public Boolean vouchar_numIsKey(){
				    return false;
				}
				public Integer vouchar_numLength(){
				    return 10;
				}
				public Integer vouchar_numPrecision(){
				    return 0;
				}
				public String vouchar_numDefault(){
				
					return null;
				
				}
				public String vouchar_numComment(){
				
				    return "";
				
				}
				public String vouchar_numPattern(){
				
					return "";
				
				}
				public String vouchar_numOriginalDbColumnName(){
				
					return "vouchar_num";
				
				}

				
			    public String invoice_date;

				public String getInvoice_date () {
					return this.invoice_date;
				}

				public Boolean invoice_dateIsNullable(){
				    return true;
				}
				public Boolean invoice_dateIsKey(){
				    return false;
				}
				public Integer invoice_dateLength(){
				    return 50;
				}
				public Integer invoice_datePrecision(){
				    return 0;
				}
				public String invoice_dateDefault(){
				
					return null;
				
				}
				public String invoice_dateComment(){
				
				    return "";
				
				}
				public String invoice_datePattern(){
				
					return "";
				
				}
				public String invoice_dateOriginalDbColumnName(){
				
					return "invoice_date";
				
				}

				
			    public String accounting_date;

				public String getAccounting_date () {
					return this.accounting_date;
				}

				public Boolean accounting_dateIsNullable(){
				    return true;
				}
				public Boolean accounting_dateIsKey(){
				    return false;
				}
				public Integer accounting_dateLength(){
				    return 50;
				}
				public Integer accounting_datePrecision(){
				    return 0;
				}
				public String accounting_dateDefault(){
				
					return null;
				
				}
				public String accounting_dateComment(){
				
				    return "";
				
				}
				public String accounting_datePattern(){
				
					return "";
				
				}
				public String accounting_dateOriginalDbColumnName(){
				
					return "accounting_date";
				
				}

				
			    public String accounting_status;

				public String getAccounting_status () {
					return this.accounting_status;
				}

				public Boolean accounting_statusIsNullable(){
				    return true;
				}
				public Boolean accounting_statusIsKey(){
				    return false;
				}
				public Integer accounting_statusLength(){
				    return 50;
				}
				public Integer accounting_statusPrecision(){
				    return 0;
				}
				public String accounting_statusDefault(){
				
					return null;
				
				}
				public String accounting_statusComment(){
				
				    return "";
				
				}
				public String accounting_statusPattern(){
				
					return "";
				
				}
				public String accounting_statusOriginalDbColumnName(){
				
					return "accounting_status";
				
				}

				
			    public String description;

				public String getDescription () {
					return this.description;
				}

				public Boolean descriptionIsNullable(){
				    return true;
				}
				public Boolean descriptionIsKey(){
				    return false;
				}
				public Integer descriptionLength(){
				    return 256;
				}
				public Integer descriptionPrecision(){
				    return 0;
				}
				public String descriptionDefault(){
				
					return null;
				
				}
				public String descriptionComment(){
				
				    return "";
				
				}
				public String descriptionPattern(){
				
					return "";
				
				}
				public String descriptionOriginalDbColumnName(){
				
					return "description";
				
				}

				
			    public Integer line_number;

				public Integer getLine_number () {
					return this.line_number;
				}

				public Boolean line_numberIsNullable(){
				    return true;
				}
				public Boolean line_numberIsKey(){
				    return false;
				}
				public Integer line_numberLength(){
				    return 10;
				}
				public Integer line_numberPrecision(){
				    return 0;
				}
				public String line_numberDefault(){
				
					return null;
				
				}
				public String line_numberComment(){
				
				    return "";
				
				}
				public String line_numberPattern(){
				
					return "";
				
				}
				public String line_numberOriginalDbColumnName(){
				
					return "line_number";
				
				}

				
			    public Integer invoice_amount_entered_curr;

				public Integer getInvoice_amount_entered_curr () {
					return this.invoice_amount_entered_curr;
				}

				public Boolean invoice_amount_entered_currIsNullable(){
				    return true;
				}
				public Boolean invoice_amount_entered_currIsKey(){
				    return false;
				}
				public Integer invoice_amount_entered_currLength(){
				    return 10;
				}
				public Integer invoice_amount_entered_currPrecision(){
				    return 0;
				}
				public String invoice_amount_entered_currDefault(){
				
					return null;
				
				}
				public String invoice_amount_entered_currComment(){
				
				    return "";
				
				}
				public String invoice_amount_entered_currPattern(){
				
					return "";
				
				}
				public String invoice_amount_entered_currOriginalDbColumnName(){
				
					return "invoice_amount_entered_curr";
				
				}

				
			    public Integer invoice_amount_func_curr;

				public Integer getInvoice_amount_func_curr () {
					return this.invoice_amount_func_curr;
				}

				public Boolean invoice_amount_func_currIsNullable(){
				    return true;
				}
				public Boolean invoice_amount_func_currIsKey(){
				    return false;
				}
				public Integer invoice_amount_func_currLength(){
				    return 10;
				}
				public Integer invoice_amount_func_currPrecision(){
				    return 0;
				}
				public String invoice_amount_func_currDefault(){
				
					return null;
				
				}
				public String invoice_amount_func_currComment(){
				
				    return "";
				
				}
				public String invoice_amount_func_currPattern(){
				
					return "";
				
				}
				public String invoice_amount_func_currOriginalDbColumnName(){
				
					return "invoice_amount_func_curr";
				
				}

				
			    public Integer tds_taxable_amt_entered_curr;

				public Integer getTds_taxable_amt_entered_curr () {
					return this.tds_taxable_amt_entered_curr;
				}

				public Boolean tds_taxable_amt_entered_currIsNullable(){
				    return true;
				}
				public Boolean tds_taxable_amt_entered_currIsKey(){
				    return false;
				}
				public Integer tds_taxable_amt_entered_currLength(){
				    return 10;
				}
				public Integer tds_taxable_amt_entered_currPrecision(){
				    return 0;
				}
				public String tds_taxable_amt_entered_currDefault(){
				
					return null;
				
				}
				public String tds_taxable_amt_entered_currComment(){
				
				    return "";
				
				}
				public String tds_taxable_amt_entered_currPattern(){
				
					return "";
				
				}
				public String tds_taxable_amt_entered_currOriginalDbColumnName(){
				
					return "tds_taxable_amt_entered_curr";
				
				}

				
			    public Integer tds_taxable_amount_func_curr;

				public Integer getTds_taxable_amount_func_curr () {
					return this.tds_taxable_amount_func_curr;
				}

				public Boolean tds_taxable_amount_func_currIsNullable(){
				    return true;
				}
				public Boolean tds_taxable_amount_func_currIsKey(){
				    return false;
				}
				public Integer tds_taxable_amount_func_currLength(){
				    return 10;
				}
				public Integer tds_taxable_amount_func_currPrecision(){
				    return 0;
				}
				public String tds_taxable_amount_func_currDefault(){
				
					return null;
				
				}
				public String tds_taxable_amount_func_currComment(){
				
				    return "";
				
				}
				public String tds_taxable_amount_func_currPattern(){
				
					return "";
				
				}
				public String tds_taxable_amount_func_currOriginalDbColumnName(){
				
					return "tds_taxable_amount_func_curr";
				
				}

				
			    public Integer tds_amt_entered_curr;

				public Integer getTds_amt_entered_curr () {
					return this.tds_amt_entered_curr;
				}

				public Boolean tds_amt_entered_currIsNullable(){
				    return true;
				}
				public Boolean tds_amt_entered_currIsKey(){
				    return false;
				}
				public Integer tds_amt_entered_currLength(){
				    return 10;
				}
				public Integer tds_amt_entered_currPrecision(){
				    return 0;
				}
				public String tds_amt_entered_currDefault(){
				
					return null;
				
				}
				public String tds_amt_entered_currComment(){
				
				    return "";
				
				}
				public String tds_amt_entered_currPattern(){
				
					return "";
				
				}
				public String tds_amt_entered_currOriginalDbColumnName(){
				
					return "tds_amt_entered_curr";
				
				}

				
			    public Integer tds_amt_func_curr;

				public Integer getTds_amt_func_curr () {
					return this.tds_amt_func_curr;
				}

				public Boolean tds_amt_func_currIsNullable(){
				    return true;
				}
				public Boolean tds_amt_func_currIsKey(){
				    return false;
				}
				public Integer tds_amt_func_currLength(){
				    return 10;
				}
				public Integer tds_amt_func_currPrecision(){
				    return 0;
				}
				public String tds_amt_func_currDefault(){
				
					return null;
				
				}
				public String tds_amt_func_currComment(){
				
				    return "";
				
				}
				public String tds_amt_func_currPattern(){
				
					return "";
				
				}
				public String tds_amt_func_currOriginalDbColumnName(){
				
					return "tds_amt_func_curr";
				
				}

				
			    public String invoice_currency;

				public String getInvoice_currency () {
					return this.invoice_currency;
				}

				public Boolean invoice_currencyIsNullable(){
				    return true;
				}
				public Boolean invoice_currencyIsKey(){
				    return false;
				}
				public Integer invoice_currencyLength(){
				    return 50;
				}
				public Integer invoice_currencyPrecision(){
				    return 0;
				}
				public String invoice_currencyDefault(){
				
					return null;
				
				}
				public String invoice_currencyComment(){
				
				    return "";
				
				}
				public String invoice_currencyPattern(){
				
					return "";
				
				}
				public String invoice_currencyOriginalDbColumnName(){
				
					return "invoice_currency";
				
				}

				
			    public String org_name;

				public String getOrg_name () {
					return this.org_name;
				}

				public Boolean org_nameIsNullable(){
				    return true;
				}
				public Boolean org_nameIsKey(){
				    return false;
				}
				public Integer org_nameLength(){
				    return 50;
				}
				public Integer org_namePrecision(){
				    return 0;
				}
				public String org_nameDefault(){
				
					return null;
				
				}
				public String org_nameComment(){
				
				    return "";
				
				}
				public String org_namePattern(){
				
					return "";
				
				}
				public String org_nameOriginalDbColumnName(){
				
					return "org_name";
				
				}

				
			    public Integer ad_tds_amt_entered_curr;

				public Integer getAd_tds_amt_entered_curr () {
					return this.ad_tds_amt_entered_curr;
				}

				public Boolean ad_tds_amt_entered_currIsNullable(){
				    return true;
				}
				public Boolean ad_tds_amt_entered_currIsKey(){
				    return false;
				}
				public Integer ad_tds_amt_entered_currLength(){
				    return 10;
				}
				public Integer ad_tds_amt_entered_currPrecision(){
				    return 0;
				}
				public String ad_tds_amt_entered_currDefault(){
				
					return null;
				
				}
				public String ad_tds_amt_entered_currComment(){
				
				    return "";
				
				}
				public String ad_tds_amt_entered_currPattern(){
				
					return "";
				
				}
				public String ad_tds_amt_entered_currOriginalDbColumnName(){
				
					return "ad_tds_amt_entered_curr";
				
				}

				
			    public String tds_applicable;

				public String getTds_applicable () {
					return this.tds_applicable;
				}

				public Boolean tds_applicableIsNullable(){
				    return true;
				}
				public Boolean tds_applicableIsKey(){
				    return false;
				}
				public Integer tds_applicableLength(){
				    return 50;
				}
				public Integer tds_applicablePrecision(){
				    return 0;
				}
				public String tds_applicableDefault(){
				
					return null;
				
				}
				public String tds_applicableComment(){
				
				    return "";
				
				}
				public String tds_applicablePattern(){
				
					return "";
				
				}
				public String tds_applicableOriginalDbColumnName(){
				
					return "tds_applicable";
				
				}

				
			    public String tds_grouping;

				public String getTds_grouping () {
					return this.tds_grouping;
				}

				public Boolean tds_groupingIsNullable(){
				    return true;
				}
				public Boolean tds_groupingIsKey(){
				    return false;
				}
				public Integer tds_groupingLength(){
				    return 50;
				}
				public Integer tds_groupingPrecision(){
				    return 0;
				}
				public String tds_groupingDefault(){
				
					return null;
				
				}
				public String tds_groupingComment(){
				
				    return "";
				
				}
				public String tds_groupingPattern(){
				
					return "";
				
				}
				public String tds_groupingOriginalDbColumnName(){
				
					return "tds_grouping";
				
				}

				
			    public String journal_name;

				public String getJournal_name () {
					return this.journal_name;
				}

				public Boolean journal_nameIsNullable(){
				    return true;
				}
				public Boolean journal_nameIsKey(){
				    return false;
				}
				public Integer journal_nameLength(){
				    return 50;
				}
				public Integer journal_namePrecision(){
				    return 0;
				}
				public String journal_nameDefault(){
				
					return null;
				
				}
				public String journal_nameComment(){
				
				    return "";
				
				}
				public String journal_namePattern(){
				
					return "";
				
				}
				public String journal_nameOriginalDbColumnName(){
				
					return "journal_name";
				
				}

				
			    public String journal_batch_name;

				public String getJournal_batch_name () {
					return this.journal_batch_name;
				}

				public Boolean journal_batch_nameIsNullable(){
				    return true;
				}
				public Boolean journal_batch_nameIsKey(){
				    return false;
				}
				public Integer journal_batch_nameLength(){
				    return 50;
				}
				public Integer journal_batch_namePrecision(){
				    return 0;
				}
				public String journal_batch_nameDefault(){
				
					return null;
				
				}
				public String journal_batch_nameComment(){
				
				    return "";
				
				}
				public String journal_batch_namePattern(){
				
					return "";
				
				}
				public String journal_batch_nameOriginalDbColumnName(){
				
					return "journal_batch_name";
				
				}

				
			    public String posting_status;

				public String getPosting_status () {
					return this.posting_status;
				}

				public Boolean posting_statusIsNullable(){
				    return true;
				}
				public Boolean posting_statusIsKey(){
				    return false;
				}
				public Integer posting_statusLength(){
				    return 50;
				}
				public Integer posting_statusPrecision(){
				    return 0;
				}
				public String posting_statusDefault(){
				
					return null;
				
				}
				public String posting_statusComment(){
				
				    return "";
				
				}
				public String posting_statusPattern(){
				
					return "";
				
				}
				public String posting_statusOriginalDbColumnName(){
				
					return "posting_status";
				
				}

				
			    public String entered_dr;

				public String getEntered_dr () {
					return this.entered_dr;
				}

				public Boolean entered_drIsNullable(){
				    return true;
				}
				public Boolean entered_drIsKey(){
				    return false;
				}
				public Integer entered_drLength(){
				    return 50;
				}
				public Integer entered_drPrecision(){
				    return 0;
				}
				public String entered_drDefault(){
				
					return null;
				
				}
				public String entered_drComment(){
				
				    return "";
				
				}
				public String entered_drPattern(){
				
					return "";
				
				}
				public String entered_drOriginalDbColumnName(){
				
					return "entered_dr";
				
				}

				
			    public String entered_cr;

				public String getEntered_cr () {
					return this.entered_cr;
				}

				public Boolean entered_crIsNullable(){
				    return true;
				}
				public Boolean entered_crIsKey(){
				    return false;
				}
				public Integer entered_crLength(){
				    return 50;
				}
				public Integer entered_crPrecision(){
				    return 0;
				}
				public String entered_crDefault(){
				
					return null;
				
				}
				public String entered_crComment(){
				
				    return "";
				
				}
				public String entered_crPattern(){
				
					return "";
				
				}
				public String entered_crOriginalDbColumnName(){
				
					return "entered_cr";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP) {

        	try {

        		int length = 0;
		
					this.ledger_name = readString(dis);
					
					this.le_name = readString(dis);
					
					this.ledger_currency = readString(dis);
					
					this.period_name = readString(dis);
					
						this.entity = readInteger(dis);
					
					this.entity_desc = readString(dis);
					
						this.account = readInteger(dis);
					
					this.account_desc = readString(dis);
					
					this.location_code = readString(dis);
					
					this.location_code_desc = readString(dis);
					
						this.department = readInteger(dis);
					
					this.department_desc = readString(dis);
					
					this.product = readString(dis);
					
					this.product_desc = readString(dis);
					
						this.inter_company = readInteger(dis);
					
					this.inter_company_desc = readString(dis);
					
						this.inter_location = readInteger(dis);
					
					this.inter_location_desc = readString(dis);
					
					this.acct_type = readString(dis);
					
						this.begin_balance = (BigDecimal) dis.readObject();
					
						this.period_dr = (BigDecimal) dis.readObject();
					
						this.period_cr = (BigDecimal) dis.readObject();
					
						this.end_balance = (BigDecimal) dis.readObject();
					
					this.business_unit = readString(dis);
					
						this.vendor_num = readInteger(dis);
					
					this.supp_name = readString(dis);
					
					this.vendor_type = readString(dis);
					
					this.tax_org_type = readString(dis);
					
					this.vendor_site_code = readString(dis);
					
					this.supp_status = readString(dis);
					
					this.pay_method = readString(dis);
					
					this.country = readString(dis);
					
					this.address1 = readString(dis);
					
					this.address2 = readString(dis);
					
					this.city = readString(dis);
					
					this.state = readString(dis);
					
						this.postal_code = readInteger(dis);
					
					this.liab_acct = readString(dis);
					
					this.prepay_acct = readString(dis);
					
					this.sup_bank_account_num = readString(dis);
					
					this.sup_bank_account_name = readString(dis);
					
					this.sup_bank_branch_name = readString(dis);
					
					this.sup_bank_name = readString(dis);
					
					this.sup_ifsc_code = readString(dis);
					
					this.msme_tag = readString(dis);
					
					this.vendor_creation_date = readString(dis);
					
					this.site_creation_date = readString(dis);
					
					this.last_transaction_date = readString(dis);
					
					this.party_site_name = readString(dis);
					
					this.sup_branch_number = readString(dis);
					
					this.site_created_by = readString(dis);
					
					this.pan_number = readString(dis);
					
					this.gst_number = readString(dis);
					
					this.msme_no = readString(dis);
					
					this.address3 = readString(dis);
					
						this.site_bank_account_num = readInteger(dis);
					
					this.site_bank_branch_name = readString(dis);
					
					this.site_bank_name = readString(dis);
					
					this.site_branch_number = readString(dis);
					
					this.site_ifsc_code = readString(dis);
					
					this.site_bank_account_name = readString(dis);
					
					this.vendor_created_by = readString(dis);
					
					this.inactivated_date = readString(dis);
					
					this.inactivated_by = readString(dis);
					
					this.address4 = readString(dis);
					
					this.tds_section = readString(dis);
					
					this.tds_code = readString(dis);
					
						this.tax_rate = readInteger(dis);
					
						this.supplier_number = readInteger(dis);
					
					this.supplier_name = readString(dis);
					
					this.NAME = readString(dis);
					
						this.liab_account = readInteger(dis);
					
					this.liab_acct_desc = readString(dis);
					
						this.expense_account = readInteger(dis);
					
					this.expense_acct_desc = readString(dis);
					
					this.organization_type = readString(dis);
					
					this.certificate = readString(dis);
					
					this.invoice_num = readString(dis);
					
					this.ref_invoice_num = readString(dis);
					
						this.vouchar_num = readInteger(dis);
					
					this.invoice_date = readString(dis);
					
					this.accounting_date = readString(dis);
					
					this.accounting_status = readString(dis);
					
					this.description = readString(dis);
					
						this.line_number = readInteger(dis);
					
						this.invoice_amount_entered_curr = readInteger(dis);
					
						this.invoice_amount_func_curr = readInteger(dis);
					
						this.tds_taxable_amt_entered_curr = readInteger(dis);
					
						this.tds_taxable_amount_func_curr = readInteger(dis);
					
						this.tds_amt_entered_curr = readInteger(dis);
					
						this.tds_amt_func_curr = readInteger(dis);
					
					this.invoice_currency = readString(dis);
					
					this.org_name = readString(dis);
					
						this.ad_tds_amt_entered_curr = readInteger(dis);
					
					this.tds_applicable = readString(dis);
					
					this.tds_grouping = readString(dis);
					
					this.journal_name = readString(dis);
					
					this.journal_batch_name = readString(dis);
					
					this.posting_status = readString(dis);
					
					this.entered_dr = readString(dis);
					
					this.entered_cr = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_GL_Trial_Balance_Report_SFTP) {

        	try {

        		int length = 0;
		
					this.ledger_name = readString(dis);
					
					this.le_name = readString(dis);
					
					this.ledger_currency = readString(dis);
					
					this.period_name = readString(dis);
					
						this.entity = readInteger(dis);
					
					this.entity_desc = readString(dis);
					
						this.account = readInteger(dis);
					
					this.account_desc = readString(dis);
					
					this.location_code = readString(dis);
					
					this.location_code_desc = readString(dis);
					
						this.department = readInteger(dis);
					
					this.department_desc = readString(dis);
					
					this.product = readString(dis);
					
					this.product_desc = readString(dis);
					
						this.inter_company = readInteger(dis);
					
					this.inter_company_desc = readString(dis);
					
						this.inter_location = readInteger(dis);
					
					this.inter_location_desc = readString(dis);
					
					this.acct_type = readString(dis);
					
						this.begin_balance = (BigDecimal) dis.readObject();
					
						this.period_dr = (BigDecimal) dis.readObject();
					
						this.period_cr = (BigDecimal) dis.readObject();
					
						this.end_balance = (BigDecimal) dis.readObject();
					
					this.business_unit = readString(dis);
					
						this.vendor_num = readInteger(dis);
					
					this.supp_name = readString(dis);
					
					this.vendor_type = readString(dis);
					
					this.tax_org_type = readString(dis);
					
					this.vendor_site_code = readString(dis);
					
					this.supp_status = readString(dis);
					
					this.pay_method = readString(dis);
					
					this.country = readString(dis);
					
					this.address1 = readString(dis);
					
					this.address2 = readString(dis);
					
					this.city = readString(dis);
					
					this.state = readString(dis);
					
						this.postal_code = readInteger(dis);
					
					this.liab_acct = readString(dis);
					
					this.prepay_acct = readString(dis);
					
					this.sup_bank_account_num = readString(dis);
					
					this.sup_bank_account_name = readString(dis);
					
					this.sup_bank_branch_name = readString(dis);
					
					this.sup_bank_name = readString(dis);
					
					this.sup_ifsc_code = readString(dis);
					
					this.msme_tag = readString(dis);
					
					this.vendor_creation_date = readString(dis);
					
					this.site_creation_date = readString(dis);
					
					this.last_transaction_date = readString(dis);
					
					this.party_site_name = readString(dis);
					
					this.sup_branch_number = readString(dis);
					
					this.site_created_by = readString(dis);
					
					this.pan_number = readString(dis);
					
					this.gst_number = readString(dis);
					
					this.msme_no = readString(dis);
					
					this.address3 = readString(dis);
					
						this.site_bank_account_num = readInteger(dis);
					
					this.site_bank_branch_name = readString(dis);
					
					this.site_bank_name = readString(dis);
					
					this.site_branch_number = readString(dis);
					
					this.site_ifsc_code = readString(dis);
					
					this.site_bank_account_name = readString(dis);
					
					this.vendor_created_by = readString(dis);
					
					this.inactivated_date = readString(dis);
					
					this.inactivated_by = readString(dis);
					
					this.address4 = readString(dis);
					
					this.tds_section = readString(dis);
					
					this.tds_code = readString(dis);
					
						this.tax_rate = readInteger(dis);
					
						this.supplier_number = readInteger(dis);
					
					this.supplier_name = readString(dis);
					
					this.NAME = readString(dis);
					
						this.liab_account = readInteger(dis);
					
					this.liab_acct_desc = readString(dis);
					
						this.expense_account = readInteger(dis);
					
					this.expense_acct_desc = readString(dis);
					
					this.organization_type = readString(dis);
					
					this.certificate = readString(dis);
					
					this.invoice_num = readString(dis);
					
					this.ref_invoice_num = readString(dis);
					
						this.vouchar_num = readInteger(dis);
					
					this.invoice_date = readString(dis);
					
					this.accounting_date = readString(dis);
					
					this.accounting_status = readString(dis);
					
					this.description = readString(dis);
					
						this.line_number = readInteger(dis);
					
						this.invoice_amount_entered_curr = readInteger(dis);
					
						this.invoice_amount_func_curr = readInteger(dis);
					
						this.tds_taxable_amt_entered_curr = readInteger(dis);
					
						this.tds_taxable_amount_func_curr = readInteger(dis);
					
						this.tds_amt_entered_curr = readInteger(dis);
					
						this.tds_amt_func_curr = readInteger(dis);
					
					this.invoice_currency = readString(dis);
					
					this.org_name = readString(dis);
					
						this.ad_tds_amt_entered_curr = readInteger(dis);
					
					this.tds_applicable = readString(dis);
					
					this.tds_grouping = readString(dis);
					
					this.journal_name = readString(dis);
					
					this.journal_batch_name = readString(dis);
					
					this.posting_status = readString(dis);
					
					this.entered_dr = readString(dis);
					
					this.entered_cr = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.ledger_name,dos);
					
					// String
				
						writeString(this.le_name,dos);
					
					// String
				
						writeString(this.ledger_currency,dos);
					
					// String
				
						writeString(this.period_name,dos);
					
					// Integer
				
						writeInteger(this.entity,dos);
					
					// String
				
						writeString(this.entity_desc,dos);
					
					// Integer
				
						writeInteger(this.account,dos);
					
					// String
				
						writeString(this.account_desc,dos);
					
					// String
				
						writeString(this.location_code,dos);
					
					// String
				
						writeString(this.location_code_desc,dos);
					
					// Integer
				
						writeInteger(this.department,dos);
					
					// String
				
						writeString(this.department_desc,dos);
					
					// String
				
						writeString(this.product,dos);
					
					// String
				
						writeString(this.product_desc,dos);
					
					// Integer
				
						writeInteger(this.inter_company,dos);
					
					// String
				
						writeString(this.inter_company_desc,dos);
					
					// Integer
				
						writeInteger(this.inter_location,dos);
					
					// String
				
						writeString(this.inter_location_desc,dos);
					
					// String
				
						writeString(this.acct_type,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.begin_balance);
					
					// BigDecimal
				
       			    	dos.writeObject(this.period_dr);
					
					// BigDecimal
				
       			    	dos.writeObject(this.period_cr);
					
					// BigDecimal
				
       			    	dos.writeObject(this.end_balance);
					
					// String
				
						writeString(this.business_unit,dos);
					
					// Integer
				
						writeInteger(this.vendor_num,dos);
					
					// String
				
						writeString(this.supp_name,dos);
					
					// String
				
						writeString(this.vendor_type,dos);
					
					// String
				
						writeString(this.tax_org_type,dos);
					
					// String
				
						writeString(this.vendor_site_code,dos);
					
					// String
				
						writeString(this.supp_status,dos);
					
					// String
				
						writeString(this.pay_method,dos);
					
					// String
				
						writeString(this.country,dos);
					
					// String
				
						writeString(this.address1,dos);
					
					// String
				
						writeString(this.address2,dos);
					
					// String
				
						writeString(this.city,dos);
					
					// String
				
						writeString(this.state,dos);
					
					// Integer
				
						writeInteger(this.postal_code,dos);
					
					// String
				
						writeString(this.liab_acct,dos);
					
					// String
				
						writeString(this.prepay_acct,dos);
					
					// String
				
						writeString(this.sup_bank_account_num,dos);
					
					// String
				
						writeString(this.sup_bank_account_name,dos);
					
					// String
				
						writeString(this.sup_bank_branch_name,dos);
					
					// String
				
						writeString(this.sup_bank_name,dos);
					
					// String
				
						writeString(this.sup_ifsc_code,dos);
					
					// String
				
						writeString(this.msme_tag,dos);
					
					// String
				
						writeString(this.vendor_creation_date,dos);
					
					// String
				
						writeString(this.site_creation_date,dos);
					
					// String
				
						writeString(this.last_transaction_date,dos);
					
					// String
				
						writeString(this.party_site_name,dos);
					
					// String
				
						writeString(this.sup_branch_number,dos);
					
					// String
				
						writeString(this.site_created_by,dos);
					
					// String
				
						writeString(this.pan_number,dos);
					
					// String
				
						writeString(this.gst_number,dos);
					
					// String
				
						writeString(this.msme_no,dos);
					
					// String
				
						writeString(this.address3,dos);
					
					// Integer
				
						writeInteger(this.site_bank_account_num,dos);
					
					// String
				
						writeString(this.site_bank_branch_name,dos);
					
					// String
				
						writeString(this.site_bank_name,dos);
					
					// String
				
						writeString(this.site_branch_number,dos);
					
					// String
				
						writeString(this.site_ifsc_code,dos);
					
					// String
				
						writeString(this.site_bank_account_name,dos);
					
					// String
				
						writeString(this.vendor_created_by,dos);
					
					// String
				
						writeString(this.inactivated_date,dos);
					
					// String
				
						writeString(this.inactivated_by,dos);
					
					// String
				
						writeString(this.address4,dos);
					
					// String
				
						writeString(this.tds_section,dos);
					
					// String
				
						writeString(this.tds_code,dos);
					
					// Integer
				
						writeInteger(this.tax_rate,dos);
					
					// Integer
				
						writeInteger(this.supplier_number,dos);
					
					// String
				
						writeString(this.supplier_name,dos);
					
					// String
				
						writeString(this.NAME,dos);
					
					// Integer
				
						writeInteger(this.liab_account,dos);
					
					// String
				
						writeString(this.liab_acct_desc,dos);
					
					// Integer
				
						writeInteger(this.expense_account,dos);
					
					// String
				
						writeString(this.expense_acct_desc,dos);
					
					// String
				
						writeString(this.organization_type,dos);
					
					// String
				
						writeString(this.certificate,dos);
					
					// String
				
						writeString(this.invoice_num,dos);
					
					// String
				
						writeString(this.ref_invoice_num,dos);
					
					// Integer
				
						writeInteger(this.vouchar_num,dos);
					
					// String
				
						writeString(this.invoice_date,dos);
					
					// String
				
						writeString(this.accounting_date,dos);
					
					// String
				
						writeString(this.accounting_status,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.line_number,dos);
					
					// Integer
				
						writeInteger(this.invoice_amount_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.invoice_amount_func_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_taxable_amt_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_taxable_amount_func_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_amt_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_amt_func_curr,dos);
					
					// String
				
						writeString(this.invoice_currency,dos);
					
					// String
				
						writeString(this.org_name,dos);
					
					// Integer
				
						writeInteger(this.ad_tds_amt_entered_curr,dos);
					
					// String
				
						writeString(this.tds_applicable,dos);
					
					// String
				
						writeString(this.tds_grouping,dos);
					
					// String
				
						writeString(this.journal_name,dos);
					
					// String
				
						writeString(this.journal_batch_name,dos);
					
					// String
				
						writeString(this.posting_status,dos);
					
					// String
				
						writeString(this.entered_dr,dos);
					
					// String
				
						writeString(this.entered_cr,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.ledger_name,dos);
					
					// String
				
						writeString(this.le_name,dos);
					
					// String
				
						writeString(this.ledger_currency,dos);
					
					// String
				
						writeString(this.period_name,dos);
					
					// Integer
				
						writeInteger(this.entity,dos);
					
					// String
				
						writeString(this.entity_desc,dos);
					
					// Integer
				
						writeInteger(this.account,dos);
					
					// String
				
						writeString(this.account_desc,dos);
					
					// String
				
						writeString(this.location_code,dos);
					
					// String
				
						writeString(this.location_code_desc,dos);
					
					// Integer
				
						writeInteger(this.department,dos);
					
					// String
				
						writeString(this.department_desc,dos);
					
					// String
				
						writeString(this.product,dos);
					
					// String
				
						writeString(this.product_desc,dos);
					
					// Integer
				
						writeInteger(this.inter_company,dos);
					
					// String
				
						writeString(this.inter_company_desc,dos);
					
					// Integer
				
						writeInteger(this.inter_location,dos);
					
					// String
				
						writeString(this.inter_location_desc,dos);
					
					// String
				
						writeString(this.acct_type,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.begin_balance);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.period_dr);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.period_cr);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.end_balance);
					
					// String
				
						writeString(this.business_unit,dos);
					
					// Integer
				
						writeInteger(this.vendor_num,dos);
					
					// String
				
						writeString(this.supp_name,dos);
					
					// String
				
						writeString(this.vendor_type,dos);
					
					// String
				
						writeString(this.tax_org_type,dos);
					
					// String
				
						writeString(this.vendor_site_code,dos);
					
					// String
				
						writeString(this.supp_status,dos);
					
					// String
				
						writeString(this.pay_method,dos);
					
					// String
				
						writeString(this.country,dos);
					
					// String
				
						writeString(this.address1,dos);
					
					// String
				
						writeString(this.address2,dos);
					
					// String
				
						writeString(this.city,dos);
					
					// String
				
						writeString(this.state,dos);
					
					// Integer
				
						writeInteger(this.postal_code,dos);
					
					// String
				
						writeString(this.liab_acct,dos);
					
					// String
				
						writeString(this.prepay_acct,dos);
					
					// String
				
						writeString(this.sup_bank_account_num,dos);
					
					// String
				
						writeString(this.sup_bank_account_name,dos);
					
					// String
				
						writeString(this.sup_bank_branch_name,dos);
					
					// String
				
						writeString(this.sup_bank_name,dos);
					
					// String
				
						writeString(this.sup_ifsc_code,dos);
					
					// String
				
						writeString(this.msme_tag,dos);
					
					// String
				
						writeString(this.vendor_creation_date,dos);
					
					// String
				
						writeString(this.site_creation_date,dos);
					
					// String
				
						writeString(this.last_transaction_date,dos);
					
					// String
				
						writeString(this.party_site_name,dos);
					
					// String
				
						writeString(this.sup_branch_number,dos);
					
					// String
				
						writeString(this.site_created_by,dos);
					
					// String
				
						writeString(this.pan_number,dos);
					
					// String
				
						writeString(this.gst_number,dos);
					
					// String
				
						writeString(this.msme_no,dos);
					
					// String
				
						writeString(this.address3,dos);
					
					// Integer
				
						writeInteger(this.site_bank_account_num,dos);
					
					// String
				
						writeString(this.site_bank_branch_name,dos);
					
					// String
				
						writeString(this.site_bank_name,dos);
					
					// String
				
						writeString(this.site_branch_number,dos);
					
					// String
				
						writeString(this.site_ifsc_code,dos);
					
					// String
				
						writeString(this.site_bank_account_name,dos);
					
					// String
				
						writeString(this.vendor_created_by,dos);
					
					// String
				
						writeString(this.inactivated_date,dos);
					
					// String
				
						writeString(this.inactivated_by,dos);
					
					// String
				
						writeString(this.address4,dos);
					
					// String
				
						writeString(this.tds_section,dos);
					
					// String
				
						writeString(this.tds_code,dos);
					
					// Integer
				
						writeInteger(this.tax_rate,dos);
					
					// Integer
				
						writeInteger(this.supplier_number,dos);
					
					// String
				
						writeString(this.supplier_name,dos);
					
					// String
				
						writeString(this.NAME,dos);
					
					// Integer
				
						writeInteger(this.liab_account,dos);
					
					// String
				
						writeString(this.liab_acct_desc,dos);
					
					// Integer
				
						writeInteger(this.expense_account,dos);
					
					// String
				
						writeString(this.expense_acct_desc,dos);
					
					// String
				
						writeString(this.organization_type,dos);
					
					// String
				
						writeString(this.certificate,dos);
					
					// String
				
						writeString(this.invoice_num,dos);
					
					// String
				
						writeString(this.ref_invoice_num,dos);
					
					// Integer
				
						writeInteger(this.vouchar_num,dos);
					
					// String
				
						writeString(this.invoice_date,dos);
					
					// String
				
						writeString(this.accounting_date,dos);
					
					// String
				
						writeString(this.accounting_status,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.line_number,dos);
					
					// Integer
				
						writeInteger(this.invoice_amount_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.invoice_amount_func_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_taxable_amt_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_taxable_amount_func_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_amt_entered_curr,dos);
					
					// Integer
				
						writeInteger(this.tds_amt_func_curr,dos);
					
					// String
				
						writeString(this.invoice_currency,dos);
					
					// String
				
						writeString(this.org_name,dos);
					
					// Integer
				
						writeInteger(this.ad_tds_amt_entered_curr,dos);
					
					// String
				
						writeString(this.tds_applicable,dos);
					
					// String
				
						writeString(this.tds_grouping,dos);
					
					// String
				
						writeString(this.journal_name,dos);
					
					// String
				
						writeString(this.journal_batch_name,dos);
					
					// String
				
						writeString(this.posting_status,dos);
					
					// String
				
						writeString(this.entered_dr,dos);
					
					// String
				
						writeString(this.entered_cr,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ledger_name="+ledger_name);
		sb.append(",le_name="+le_name);
		sb.append(",ledger_currency="+ledger_currency);
		sb.append(",period_name="+period_name);
		sb.append(",entity="+String.valueOf(entity));
		sb.append(",entity_desc="+entity_desc);
		sb.append(",account="+String.valueOf(account));
		sb.append(",account_desc="+account_desc);
		sb.append(",location_code="+location_code);
		sb.append(",location_code_desc="+location_code_desc);
		sb.append(",department="+String.valueOf(department));
		sb.append(",department_desc="+department_desc);
		sb.append(",product="+product);
		sb.append(",product_desc="+product_desc);
		sb.append(",inter_company="+String.valueOf(inter_company));
		sb.append(",inter_company_desc="+inter_company_desc);
		sb.append(",inter_location="+String.valueOf(inter_location));
		sb.append(",inter_location_desc="+inter_location_desc);
		sb.append(",acct_type="+acct_type);
		sb.append(",begin_balance="+String.valueOf(begin_balance));
		sb.append(",period_dr="+String.valueOf(period_dr));
		sb.append(",period_cr="+String.valueOf(period_cr));
		sb.append(",end_balance="+String.valueOf(end_balance));
		sb.append(",business_unit="+business_unit);
		sb.append(",vendor_num="+String.valueOf(vendor_num));
		sb.append(",supp_name="+supp_name);
		sb.append(",vendor_type="+vendor_type);
		sb.append(",tax_org_type="+tax_org_type);
		sb.append(",vendor_site_code="+vendor_site_code);
		sb.append(",supp_status="+supp_status);
		sb.append(",pay_method="+pay_method);
		sb.append(",country="+country);
		sb.append(",address1="+address1);
		sb.append(",address2="+address2);
		sb.append(",city="+city);
		sb.append(",state="+state);
		sb.append(",postal_code="+String.valueOf(postal_code));
		sb.append(",liab_acct="+liab_acct);
		sb.append(",prepay_acct="+prepay_acct);
		sb.append(",sup_bank_account_num="+sup_bank_account_num);
		sb.append(",sup_bank_account_name="+sup_bank_account_name);
		sb.append(",sup_bank_branch_name="+sup_bank_branch_name);
		sb.append(",sup_bank_name="+sup_bank_name);
		sb.append(",sup_ifsc_code="+sup_ifsc_code);
		sb.append(",msme_tag="+msme_tag);
		sb.append(",vendor_creation_date="+vendor_creation_date);
		sb.append(",site_creation_date="+site_creation_date);
		sb.append(",last_transaction_date="+last_transaction_date);
		sb.append(",party_site_name="+party_site_name);
		sb.append(",sup_branch_number="+sup_branch_number);
		sb.append(",site_created_by="+site_created_by);
		sb.append(",pan_number="+pan_number);
		sb.append(",gst_number="+gst_number);
		sb.append(",msme_no="+msme_no);
		sb.append(",address3="+address3);
		sb.append(",site_bank_account_num="+String.valueOf(site_bank_account_num));
		sb.append(",site_bank_branch_name="+site_bank_branch_name);
		sb.append(",site_bank_name="+site_bank_name);
		sb.append(",site_branch_number="+site_branch_number);
		sb.append(",site_ifsc_code="+site_ifsc_code);
		sb.append(",site_bank_account_name="+site_bank_account_name);
		sb.append(",vendor_created_by="+vendor_created_by);
		sb.append(",inactivated_date="+inactivated_date);
		sb.append(",inactivated_by="+inactivated_by);
		sb.append(",address4="+address4);
		sb.append(",tds_section="+tds_section);
		sb.append(",tds_code="+tds_code);
		sb.append(",tax_rate="+String.valueOf(tax_rate));
		sb.append(",supplier_number="+String.valueOf(supplier_number));
		sb.append(",supplier_name="+supplier_name);
		sb.append(",NAME="+NAME);
		sb.append(",liab_account="+String.valueOf(liab_account));
		sb.append(",liab_acct_desc="+liab_acct_desc);
		sb.append(",expense_account="+String.valueOf(expense_account));
		sb.append(",expense_acct_desc="+expense_acct_desc);
		sb.append(",organization_type="+organization_type);
		sb.append(",certificate="+certificate);
		sb.append(",invoice_num="+invoice_num);
		sb.append(",ref_invoice_num="+ref_invoice_num);
		sb.append(",vouchar_num="+String.valueOf(vouchar_num));
		sb.append(",invoice_date="+invoice_date);
		sb.append(",accounting_date="+accounting_date);
		sb.append(",accounting_status="+accounting_status);
		sb.append(",description="+description);
		sb.append(",line_number="+String.valueOf(line_number));
		sb.append(",invoice_amount_entered_curr="+String.valueOf(invoice_amount_entered_curr));
		sb.append(",invoice_amount_func_curr="+String.valueOf(invoice_amount_func_curr));
		sb.append(",tds_taxable_amt_entered_curr="+String.valueOf(tds_taxable_amt_entered_curr));
		sb.append(",tds_taxable_amount_func_curr="+String.valueOf(tds_taxable_amount_func_curr));
		sb.append(",tds_amt_entered_curr="+String.valueOf(tds_amt_entered_curr));
		sb.append(",tds_amt_func_curr="+String.valueOf(tds_amt_func_curr));
		sb.append(",invoice_currency="+invoice_currency);
		sb.append(",org_name="+org_name);
		sb.append(",ad_tds_amt_entered_curr="+String.valueOf(ad_tds_amt_entered_curr));
		sb.append(",tds_applicable="+tds_applicable);
		sb.append(",tds_grouping="+tds_grouping);
		sb.append(",journal_name="+journal_name);
		sb.append(",journal_batch_name="+journal_batch_name);
		sb.append(",posting_status="+posting_status);
		sb.append(",entered_dr="+entered_dr);
		sb.append(",entered_cr="+entered_cr);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(ledger_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ledger_name);
            			}
            		
        			sb.append("|");
        		
        				if(le_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(le_name);
            			}
            		
        			sb.append("|");
        		
        				if(ledger_currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ledger_currency);
            			}
            		
        			sb.append("|");
        		
        				if(period_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(period_name);
            			}
            		
        			sb.append("|");
        		
        				if(entity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(entity);
            			}
            		
        			sb.append("|");
        		
        				if(entity_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(entity_desc);
            			}
            		
        			sb.append("|");
        		
        				if(account == null){
        					sb.append("<null>");
        				}else{
            				sb.append(account);
            			}
            		
        			sb.append("|");
        		
        				if(account_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(account_desc);
            			}
            		
        			sb.append("|");
        		
        				if(location_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(location_code);
            			}
            		
        			sb.append("|");
        		
        				if(location_code_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(location_code_desc);
            			}
            		
        			sb.append("|");
        		
        				if(department == null){
        					sb.append("<null>");
        				}else{
            				sb.append(department);
            			}
            		
        			sb.append("|");
        		
        				if(department_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(department_desc);
            			}
            		
        			sb.append("|");
        		
        				if(product == null){
        					sb.append("<null>");
        				}else{
            				sb.append(product);
            			}
            		
        			sb.append("|");
        		
        				if(product_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(product_desc);
            			}
            		
        			sb.append("|");
        		
        				if(inter_company == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inter_company);
            			}
            		
        			sb.append("|");
        		
        				if(inter_company_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inter_company_desc);
            			}
            		
        			sb.append("|");
        		
        				if(inter_location == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inter_location);
            			}
            		
        			sb.append("|");
        		
        				if(inter_location_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inter_location_desc);
            			}
            		
        			sb.append("|");
        		
        				if(acct_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(acct_type);
            			}
            		
        			sb.append("|");
        		
        				if(begin_balance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(begin_balance);
            			}
            		
        			sb.append("|");
        		
        				if(period_dr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(period_dr);
            			}
            		
        			sb.append("|");
        		
        				if(period_cr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(period_cr);
            			}
            		
        			sb.append("|");
        		
        				if(end_balance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_balance);
            			}
            		
        			sb.append("|");
        		
        				if(business_unit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(business_unit);
            			}
            		
        			sb.append("|");
        		
        				if(vendor_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendor_num);
            			}
            		
        			sb.append("|");
        		
        				if(supp_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(supp_name);
            			}
            		
        			sb.append("|");
        		
        				if(vendor_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendor_type);
            			}
            		
        			sb.append("|");
        		
        				if(tax_org_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tax_org_type);
            			}
            		
        			sb.append("|");
        		
        				if(vendor_site_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendor_site_code);
            			}
            		
        			sb.append("|");
        		
        				if(supp_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(supp_status);
            			}
            		
        			sb.append("|");
        		
        				if(pay_method == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pay_method);
            			}
            		
        			sb.append("|");
        		
        				if(country == null){
        					sb.append("<null>");
        				}else{
            				sb.append(country);
            			}
            		
        			sb.append("|");
        		
        				if(address1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(address1);
            			}
            		
        			sb.append("|");
        		
        				if(address2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(address2);
            			}
            		
        			sb.append("|");
        		
        				if(city == null){
        					sb.append("<null>");
        				}else{
            				sb.append(city);
            			}
            		
        			sb.append("|");
        		
        				if(state == null){
        					sb.append("<null>");
        				}else{
            				sb.append(state);
            			}
            		
        			sb.append("|");
        		
        				if(postal_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(postal_code);
            			}
            		
        			sb.append("|");
        		
        				if(liab_acct == null){
        					sb.append("<null>");
        				}else{
            				sb.append(liab_acct);
            			}
            		
        			sb.append("|");
        		
        				if(prepay_acct == null){
        					sb.append("<null>");
        				}else{
            				sb.append(prepay_acct);
            			}
            		
        			sb.append("|");
        		
        				if(sup_bank_account_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_bank_account_num);
            			}
            		
        			sb.append("|");
        		
        				if(sup_bank_account_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_bank_account_name);
            			}
            		
        			sb.append("|");
        		
        				if(sup_bank_branch_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_bank_branch_name);
            			}
            		
        			sb.append("|");
        		
        				if(sup_bank_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_bank_name);
            			}
            		
        			sb.append("|");
        		
        				if(sup_ifsc_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_ifsc_code);
            			}
            		
        			sb.append("|");
        		
        				if(msme_tag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(msme_tag);
            			}
            		
        			sb.append("|");
        		
        				if(vendor_creation_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendor_creation_date);
            			}
            		
        			sb.append("|");
        		
        				if(site_creation_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_creation_date);
            			}
            		
        			sb.append("|");
        		
        				if(last_transaction_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(last_transaction_date);
            			}
            		
        			sb.append("|");
        		
        				if(party_site_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(party_site_name);
            			}
            		
        			sb.append("|");
        		
        				if(sup_branch_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sup_branch_number);
            			}
            		
        			sb.append("|");
        		
        				if(site_created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_created_by);
            			}
            		
        			sb.append("|");
        		
        				if(pan_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pan_number);
            			}
            		
        			sb.append("|");
        		
        				if(gst_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(gst_number);
            			}
            		
        			sb.append("|");
        		
        				if(msme_no == null){
        					sb.append("<null>");
        				}else{
            				sb.append(msme_no);
            			}
            		
        			sb.append("|");
        		
        				if(address3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(address3);
            			}
            		
        			sb.append("|");
        		
        				if(site_bank_account_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_bank_account_num);
            			}
            		
        			sb.append("|");
        		
        				if(site_bank_branch_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_bank_branch_name);
            			}
            		
        			sb.append("|");
        		
        				if(site_bank_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_bank_name);
            			}
            		
        			sb.append("|");
        		
        				if(site_branch_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_branch_number);
            			}
            		
        			sb.append("|");
        		
        				if(site_ifsc_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_ifsc_code);
            			}
            		
        			sb.append("|");
        		
        				if(site_bank_account_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site_bank_account_name);
            			}
            		
        			sb.append("|");
        		
        				if(vendor_created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendor_created_by);
            			}
            		
        			sb.append("|");
        		
        				if(inactivated_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inactivated_date);
            			}
            		
        			sb.append("|");
        		
        				if(inactivated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inactivated_by);
            			}
            		
        			sb.append("|");
        		
        				if(address4 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(address4);
            			}
            		
        			sb.append("|");
        		
        				if(tds_section == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_section);
            			}
            		
        			sb.append("|");
        		
        				if(tds_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_code);
            			}
            		
        			sb.append("|");
        		
        				if(tax_rate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tax_rate);
            			}
            		
        			sb.append("|");
        		
        				if(supplier_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(supplier_number);
            			}
            		
        			sb.append("|");
        		
        				if(supplier_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(supplier_name);
            			}
            		
        			sb.append("|");
        		
        				if(NAME == null){
        					sb.append("<null>");
        				}else{
            				sb.append(NAME);
            			}
            		
        			sb.append("|");
        		
        				if(liab_account == null){
        					sb.append("<null>");
        				}else{
            				sb.append(liab_account);
            			}
            		
        			sb.append("|");
        		
        				if(liab_acct_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(liab_acct_desc);
            			}
            		
        			sb.append("|");
        		
        				if(expense_account == null){
        					sb.append("<null>");
        				}else{
            				sb.append(expense_account);
            			}
            		
        			sb.append("|");
        		
        				if(expense_acct_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(expense_acct_desc);
            			}
            		
        			sb.append("|");
        		
        				if(organization_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(organization_type);
            			}
            		
        			sb.append("|");
        		
        				if(certificate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(certificate);
            			}
            		
        			sb.append("|");
        		
        				if(invoice_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(invoice_num);
            			}
            		
        			sb.append("|");
        		
        				if(ref_invoice_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ref_invoice_num);
            			}
            		
        			sb.append("|");
        		
        				if(vouchar_num == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vouchar_num);
            			}
            		
        			sb.append("|");
        		
        				if(invoice_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(invoice_date);
            			}
            		
        			sb.append("|");
        		
        				if(accounting_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(accounting_date);
            			}
            		
        			sb.append("|");
        		
        				if(accounting_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(accounting_status);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				if(line_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(line_number);
            			}
            		
        			sb.append("|");
        		
        				if(invoice_amount_entered_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(invoice_amount_entered_curr);
            			}
            		
        			sb.append("|");
        		
        				if(invoice_amount_func_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(invoice_amount_func_curr);
            			}
            		
        			sb.append("|");
        		
        				if(tds_taxable_amt_entered_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_taxable_amt_entered_curr);
            			}
            		
        			sb.append("|");
        		
        				if(tds_taxable_amount_func_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_taxable_amount_func_curr);
            			}
            		
        			sb.append("|");
        		
        				if(tds_amt_entered_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_amt_entered_curr);
            			}
            		
        			sb.append("|");
        		
        				if(tds_amt_func_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_amt_func_curr);
            			}
            		
        			sb.append("|");
        		
        				if(invoice_currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(invoice_currency);
            			}
            		
        			sb.append("|");
        		
        				if(org_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(org_name);
            			}
            		
        			sb.append("|");
        		
        				if(ad_tds_amt_entered_curr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ad_tds_amt_entered_curr);
            			}
            		
        			sb.append("|");
        		
        				if(tds_applicable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_applicable);
            			}
            		
        			sb.append("|");
        		
        				if(tds_grouping == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tds_grouping);
            			}
            		
        			sb.append("|");
        		
        				if(journal_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(journal_name);
            			}
            		
        			sb.append("|");
        		
        				if(journal_batch_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(journal_batch_name);
            			}
            		
        			sb.append("|");
        		
        				if(posting_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(posting_status);
            			}
            		
        			sb.append("|");
        		
        				if(entered_dr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(entered_dr);
            			}
            		
        			sb.append("|");
        		
        				if(entered_cr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(entered_cr);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tFTPGet_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFTPGet_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFTPGet_1");
		org.slf4j.MDC.put("_subJobPid", "q1O4jw_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();



	
	/**
	 * [tFTPGet_1 begin ] start
	 */

				
			int NB_ITERATE_tFileInputDelimited_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFTPGet_1", false);
		start_Hash.put("tFTPGet_1", System.currentTimeMillis());
		
	
	currentComponent="tFTPGet_1";
	
	
		int tos_count_tFTPGet_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFTPGet_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFTPGet_1 = new StringBuilder();
                    log4jParamters_tFTPGet_1.append("Parameters:");
                            log4jParamters_tFTPGet_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("CONNECTION" + " = " + "tFTPConnection_2");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("LOCALDIR" + " = " + "\"\"");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("REMOTEDIR" + " = " + "\"/home/cifcpl/GL_Trial_Balance_Report\"");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("SFTPOVERWRITE" + " = " + "overwrite");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("PERL5_REGEX" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("FILES" + " = " + "[{FILEMASK="+("\"GL_Trial_Balance_Report_\"+ TalendDate.getDate(\"yyyy-MM-dd\") +\".csv\"")+"}]");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tFTPGet_1.append(" | ");
                            log4jParamters_tFTPGet_1.append("PRINT_MESSAGE" + " = " + "false");
                        log4jParamters_tFTPGet_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + (log4jParamters_tFTPGet_1) );
                    } 
                } 
            new BytesLimit65535_tFTPGet_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFTPGet_1", "tFTPGet_1", "tFTPGet");
				talendJobLogProcess(globalMap);
			}
			

 
int nb_file_tFTPGet_1 = 0;  
	final java.util.List<String> msg_tFTPGet_1 = new java.util.ArrayList<String>();

			class MyProgressMonitor_tFTPGet_1 implements com.jcraft.jsch.SftpProgressMonitor {

				private long percent = -1;

				public void init(int op, String src, String dest, long max) {}

				public boolean count(long count) {return true;}

				public void end() {}
			} 

			class SFTPGetter_tFTPGet_1 {

				private com.jcraft.jsch.ChannelSftp cnlSFTP = null;

				private com.jcraft.jsch.SftpProgressMonitor monitor = null;

				private int count = 0;

				public void getAllFiles(String remoteDirectory, String localDirectory) throws com.jcraft.jsch.SftpException {
      
					chdir(remoteDirectory);
					java.util.Vector sftpFiles = cnlSFTP.ls(".");

					for (Object sftpFile : sftpFiles) {
						com.jcraft.jsch.ChannelSftp.LsEntry lsEntry = (com.jcraft.jsch.ChannelSftp.LsEntry) sftpFile;
						com.jcraft.jsch.SftpATTRS attrs = lsEntry.getAttrs();

						if ((".").equals(lsEntry.getFilename()) || ("..").equals(lsEntry.getFilename())) {
						continue;
						}

						if (attrs.isDir()) {
							java.io.File localFile = new java.io.File(localDirectory + "/" + lsEntry.getFilename());
							if (!localFile.exists()) {
								localFile.mkdir();
							}
							getAllFiles(remoteDirectory + "/" + lsEntry.getFilename(), localDirectory + "/" + lsEntry.getFilename());
							chdir(remoteDirectory);
						} else if (!attrs.isLink()) {
							downloadFile(localDirectory, lsEntry.getFilename());
						}
					}
				}

				public void getFiles(String remoteDirectory, String localDirectory, String maskStr) throws com.jcraft.jsch.SftpException {
      
					chdir(remoteDirectory);
					java.util.Vector sftpFiles = cnlSFTP.ls(".");

					for (Object sftpFile : sftpFiles) {
						com.jcraft.jsch.ChannelSftp.LsEntry lsEntry = (com.jcraft.jsch.ChannelSftp.LsEntry) sftpFile;
						com.jcraft.jsch.SftpATTRS attrs = lsEntry.getAttrs();

						if ((".").equals(lsEntry.getFilename()) || ("..").equals(lsEntry.getFilename())) {
							continue;
						}

						if (!attrs.isDir() && !attrs.isLink()) {

							if (lsEntry.getFilename().matches(maskStr)) {
            					downloadFile(localDirectory, lsEntry.getFilename());
          					}
        				}
      				}
				}

				public void chdir(String path) throws com.jcraft.jsch.SftpException{
					if (!".".equals(path)) {
						cnlSFTP.cd(path);
					}
				}

				public String pwd() throws com.jcraft.jsch.SftpException{
					return cnlSFTP.pwd();
				}

				private void downloadFile(String localFileName, String remoteFileName) throws com.jcraft.jsch.SftpException {

					try {
        				cnlSFTP.get(remoteFileName, localFileName, monitor,          
            				com.jcraft.jsch.ChannelSftp.OVERWRITE
					);
						
							log.debug("tFTPGet_1 - Downloaded file " + (count +1) +  " : '" + remoteFileName + "' successfully.");
						
        				msg_tFTPGet_1.add("file [" + remoteFileName + "] downloaded successfully.");
        				
				    	globalMap.put("tFTPGet_1_CURRENT_STATUS", "File transfer OK.");
			      	} catch (com.jcraft.jsch.SftpException e){
globalMap.put("tFTPGet_1_ERROR_MESSAGE",e.getMessage());

        				if (e.id == com.jcraft.jsch.ChannelSftp.SSH_FX_FAILURE || e.id == com.jcraft.jsch.ChannelSftp.SSH_FX_BAD_MESSAGE) {
							msg_tFTPGet_1.add("file [" + remoteFileName + "] downloaded unsuccessfully.");
							globalMap.put("tFTPGet_1_CURRENT_STATUS", "File transfer fail.");
						}
				        throw e;
					}
					count++;
				}
			}

				com.jcraft.jsch.ChannelSftp c_tFTPGet_1 = (com.jcraft.jsch.ChannelSftp)globalMap.get("conn_tFTPConnection_2");
				
					if(c_tFTPGet_1!=null && c_tFTPGet_1.getSession()!=null) {
						log.info("tFTPGet_1 - Use an existing connection.Connection username: " + c_tFTPGet_1.getSession().getUserName() + ", Connection hostname: " + c_tFTPGet_1.getSession().getHost() + ", Connection port: " + c_tFTPGet_1.getSession().getPort() + "."); 
					}
				
				if(c_tFTPGet_1.getHome()!=null && !c_tFTPGet_1.getHome().equals(c_tFTPGet_1.pwd())){
			  		c_tFTPGet_1.cd(c_tFTPGet_1.getHome());
			  	}
			com.jcraft.jsch.SftpProgressMonitor monitor_tFTPGet_1 = new MyProgressMonitor_tFTPGet_1();
			SFTPGetter_tFTPGet_1 getter_tFTPGet_1 = new SFTPGetter_tFTPGet_1();
			getter_tFTPGet_1.cnlSFTP = c_tFTPGet_1;
			getter_tFTPGet_1.monitor = monitor_tFTPGet_1;
			String remotedir_tFTPGet_1 = "/home/cifcpl/GL_Trial_Balance_Report";
			if (!".".equals(remotedir_tFTPGet_1)) {
				c_tFTPGet_1.cd(remotedir_tFTPGet_1);
			}
java.util.List<String> maskList_tFTPGet_1 = new java.util.ArrayList<String>();

  maskList_tFTPGet_1.add("GL_Trial_Balance_Report_"+ TalendDate.getDate("yyyy-MM-dd") +".csv");
String localdir_tFTPGet_1  = "";  
//create folder if local direcotry (assigned by property) not exists
java.io.File dirHandle_tFTPGet_1 = new java.io.File(localdir_tFTPGet_1);

if (!dirHandle_tFTPGet_1.exists()) {
  dirHandle_tFTPGet_1.mkdirs();
}
String root_tFTPGet_1 = getter_tFTPGet_1.pwd();
if ("/".equals(root_tFTPGet_1)) {
	root_tFTPGet_1 = ".";
}

	log.info("tFTPGet_1 - Downloading files from the server.");
for (String maskStr_tFTPGet_1 : maskList_tFTPGet_1) { 

 



/**
 * [tFTPGet_1 begin ] stop
 */
	
	/**
	 * [tFTPGet_1 main ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

	try {
		globalMap.put("tFTPGet_1_CURRENT_STATUS", "No file transfered.");
		String dir_tFTPGet_1 = root_tFTPGet_1;
		
			String mask_tFTPGet_1 = maskStr_tFTPGet_1.replaceAll("\\\\", "/") ;
		
		int i_tFTPGet_1 = mask_tFTPGet_1.lastIndexOf('/'); 

		if (i_tFTPGet_1 != -1){
			dir_tFTPGet_1 = mask_tFTPGet_1.substring(0, i_tFTPGet_1); 
			mask_tFTPGet_1 = mask_tFTPGet_1.substring(i_tFTPGet_1+1);  
		}
  
		
			mask_tFTPGet_1 = org.apache.oro.text.GlobCompiler.globToPerl5(mask_tFTPGet_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
		
  
		if (dir_tFTPGet_1!=null && !"".equals(dir_tFTPGet_1)){
			if ((".*").equals(mask_tFTPGet_1)) {
				getter_tFTPGet_1.getAllFiles(dir_tFTPGet_1, localdir_tFTPGet_1);
			} else {
				getter_tFTPGet_1.getFiles(dir_tFTPGet_1, localdir_tFTPGet_1 ,mask_tFTPGet_1);
			}
		}
		getter_tFTPGet_1.chdir(root_tFTPGet_1);
	} catch(java.lang.Exception e) {
globalMap.put("tFTPGet_1_ERROR_MESSAGE",e.getMessage());
		
    		throw(e);
  		
	}

 


	tos_count_tFTPGet_1++;

/**
 * [tFTPGet_1 main ] stop
 */
	
	/**
	 * [tFTPGet_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 process_data_begin ] stop
 */
	NB_ITERATE_tFileInputDelimited_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tFileInputDelimited_1);
					//Thread.sleep(1000);
				}				
			


	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USER" + " = " + "\"projects\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:rWQteYcxcwYmnZJI6er/NIugIgORMYyhoSUuHbkeUeiNARhRdjvPHDb0").substring(0, 4) + "...");     
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"gl_trial_balance_report\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"gl_trial_balance_report\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = "";
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("gl_trial_balance_report");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("gl_trial_balance_report");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Driver ClassName: ")  + ("org.postgresql.Driver")  + (".") );
    java.lang.Class.forName("org.postgresql.Driver");
    
        String url_tDBOutput_1 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
    dbUser_tDBOutput_1 = "projects";
 
	final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:Te29vNUST9fmjPnNLRxf40wLymPXPWATVW3EIJkpzrV25yWOIV3gJ2Yj");

    String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;

                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection attempts to '")  + (url_tDBOutput_1)  + ("' with the username '")  + (dbUser_tDBOutput_1)  + ("'.") );
    conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1,dbUser_tDBOutput_1,dbPwd_tDBOutput_1);
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection to '")  + (url_tDBOutput_1)  + ("' has succeeded.") );
	
	resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
        conn_tDBOutput_1.setAutoCommit(false);
        int commitEvery_tDBOutput_1 = 10000;
        int commitCounter_tDBOutput_1 = 0;
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"ledger_name\",\"le_name\",\"ledger_currency\",\"period_name\",\"entity\",\"entity_desc\",\"account\",\"account_desc\",\"location_code\",\"location_code_desc\",\"department\",\"department_desc\",\"product\",\"product_desc\",\"inter_company\",\"inter_company_desc\",\"inter_location\",\"inter_location_desc\",\"acct_type\",\"begin_balance\",\"period_dr\",\"period_cr\",\"end_balance\",\"business_unit\",\"vendor_num\",\"supp_name\",\"vendor_type\",\"tax_org_type\",\"vendor_site_code\",\"supp_status\",\"pay_method\",\"country\",\"address1\",\"address2\",\"city\",\"state\",\"postal_code\",\"liab_acct\",\"prepay_acct\",\"sup_bank_account_num\",\"sup_bank_account_name\",\"sup_bank_branch_name\",\"sup_bank_name\",\"sup_ifsc_code\",\"msme_tag\",\"vendor_creation_date\",\"site_creation_date\",\"last_transaction_date\",\"party_site_name\",\"sup_branch_number\",\"site_created_by\",\"pan_number\",\"gst_number\",\"msme_no\",\"address3\",\"site_bank_account_num\",\"site_bank_branch_name\",\"site_bank_name\",\"site_branch_number\",\"site_ifsc_code\",\"site_bank_account_name\",\"vendor_created_by\",\"inactivated_date\",\"inactivated_by\",\"address4\",\"tds_section\",\"tds_code\",\"tax_rate\",\"supplier_number\",\"supplier_name\",\"NAME\",\"liab_account\",\"liab_acct_desc\",\"expense_account\",\"expense_acct_desc\",\"organization_type\",\"certificate\",\"invoice_num\",\"ref_invoice_num\",\"vouchar_num\",\"invoice_date\",\"accounting_date\",\"accounting_status\",\"description\",\"line_number\",\"invoice_amount_entered_curr\",\"invoice_amount_func_curr\",\"tds_taxable_amt_entered_curr\",\"tds_taxable_amount_func_curr\",\"tds_amt_entered_curr\",\"tds_amt_func_curr\",\"invoice_currency\",\"org_name\",\"ad_tds_amt_entered_curr\",\"tds_applicable\",\"tds_grouping\",\"journal_name\",\"journal_batch_name\",\"posting_status\",\"entered_dr\",\"entered_cr\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";
	
	
		int tos_count_tFileInputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputDelimited_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
                    log4jParamters_tFileInputDelimited_1.append("Parameters:");
                            log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = " + "\"GL_Trial_Balance_Report_\"+ TalendDate.getDate(\"yyyy-MM-dd\") +\".csv\"");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "0");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("TRIMSELECT" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("ledger_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("le_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ledger_currency")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("period_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("entity")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("entity_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("account")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("account_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("location_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("location_code_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("department")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("department_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("product")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("product_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inter_company")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inter_company_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inter_location")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inter_location_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("acct_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("begin_balance")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("period_dr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("period_cr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("end_balance")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("business_unit")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendor_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("supp_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendor_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tax_org_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendor_site_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("supp_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("pay_method")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("country")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("address1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("address2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("city")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("state")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("postal_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("liab_acct")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("prepay_acct")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_bank_account_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_bank_account_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_bank_branch_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_bank_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_ifsc_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("msme_tag")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendor_creation_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_creation_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("last_transaction_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("party_site_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sup_branch_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("pan_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("gst_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("msme_no")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("address3")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_bank_account_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_bank_branch_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_bank_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_branch_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_ifsc_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("site_bank_account_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendor_created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inactivated_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inactivated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("address4")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_section")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tax_rate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("supplier_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("supplier_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("NAME")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("liab_account")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("liab_acct_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("expense_account")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("expense_acct_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("organization_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("certificate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("invoice_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ref_invoice_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vouchar_num")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("invoice_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("accounting_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("accounting_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("description")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("line_number")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("invoice_amount_entered_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("invoice_amount_func_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_taxable_amt_entered_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_taxable_amount_func_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_amt_entered_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_amt_func_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("invoice_currency")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("org_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ad_tds_amt_entered_curr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_applicable")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tds_grouping")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("journal_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("journal_batch_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("posting_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("entered_dr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("entered_cr")+"}]");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("SPLITRECORD" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                            log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
                        log4jParamters_tFileInputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + (log4jParamters_tFileInputDelimited_1) );
                    } 
                } 
            new BytesLimit65535_tFileInputDelimited_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tFileInputDelimited_1", "tFileInputDelimited_1", "tFileInputDelimited");
				talendJobLogProcess(globalMap);
			}
			
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				class RowHelper_tFileInputDelimited_1{
				
					public void valueToConn_0(org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1,row1Struct row1 ) throws java.lang.Exception{
						
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
							row1.ledger_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row1.le_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 2;
					
							row1.ledger_currency = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 3;
					
							row1.period_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 4;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.entity = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"entity", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.entity = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 5;
					
							row1.entity_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 6;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.account = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"account", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.account = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 7;
					
							row1.account_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 8;
					
							row1.location_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 9;
					
							row1.location_code_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 10;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.department = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"department", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.department = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 11;
					
							row1.department_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 12;
					
							row1.product = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 13;
					
							row1.product_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 14;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.inter_company = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"inter_company", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.inter_company = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 15;
					
							row1.inter_company_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 16;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.inter_location = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"inter_location", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.inter_location = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 17;
					
							row1.inter_location_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 18;
					
							row1.acct_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 19;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.begin_balance = ParserUtils.parseTo_BigDecimal(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"begin_balance", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.begin_balance = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 20;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.period_dr = ParserUtils.parseTo_BigDecimal(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"period_dr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.period_dr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 21;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.period_cr = ParserUtils.parseTo_BigDecimal(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"period_cr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.period_cr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 22;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.end_balance = ParserUtils.parseTo_BigDecimal(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"end_balance", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.end_balance = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 23;
					
							row1.business_unit = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 24;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.vendor_num = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"vendor_num", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.vendor_num = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 25;
					
							row1.supp_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 26;
					
							row1.vendor_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 27;
					
							row1.tax_org_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 28;
					
							row1.vendor_site_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 29;
					
							row1.supp_status = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 30;
					
							row1.pay_method = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 31;
					
							row1.country = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 32;
					
							row1.address1 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 33;
					
							row1.address2 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 34;
					
							row1.city = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 35;
					
							row1.state = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 36;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.postal_code = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"postal_code", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.postal_code = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 37;
					
							row1.liab_acct = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 38;
					
							row1.prepay_acct = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 39;
					
							row1.sup_bank_account_num = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 40;
					
							row1.sup_bank_account_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 41;
					
							row1.sup_bank_branch_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 42;
					
							row1.sup_bank_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 43;
					
							row1.sup_ifsc_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 44;
					
							row1.msme_tag = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 45;
					
							row1.vendor_creation_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 46;
					
							row1.site_creation_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 47;
					
							row1.last_transaction_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 48;
					
							row1.party_site_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 49;
					
							row1.sup_branch_number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 50;
					
							row1.site_created_by = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 51;
					
							row1.pan_number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 52;
					
							row1.gst_number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 53;
					
							row1.msme_no = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 54;
					
							row1.address3 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 55;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.site_bank_account_num = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"site_bank_account_num", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.site_bank_account_num = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 56;
					
							row1.site_bank_branch_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 57;
					
							row1.site_bank_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 58;
					
							row1.site_branch_number = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 59;
					
							row1.site_ifsc_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 60;
					
							row1.site_bank_account_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 61;
					
							row1.vendor_created_by = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 62;
					
							row1.inactivated_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 63;
					
							row1.inactivated_by = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 64;
					
							row1.address4 = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 65;
					
							row1.tds_section = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 66;
					
							row1.tds_code = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 67;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.tax_rate = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"tax_rate", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.tax_rate = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 68;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.supplier_number = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"supplier_number", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.supplier_number = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 69;
					
							row1.supplier_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 70;
					
							row1.NAME = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 71;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.liab_account = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"liab_account", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.liab_account = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 72;
					
							row1.liab_acct_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 73;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.expense_account = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"expense_account", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.expense_account = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 74;
					
							row1.expense_acct_desc = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 75;
					
							row1.organization_type = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 76;
					
							row1.certificate = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 77;
					
							row1.invoice_num = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 78;
					
							row1.ref_invoice_num = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 79;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.vouchar_num = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"vouchar_num", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.vouchar_num = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 80;
					
							row1.invoice_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 81;
					
							row1.accounting_date = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 82;
					
							row1.accounting_status = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 83;
					
							row1.description = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 84;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.line_number = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"line_number", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.line_number = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 85;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.invoice_amount_entered_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"invoice_amount_entered_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.invoice_amount_entered_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 86;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.invoice_amount_func_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"invoice_amount_func_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.invoice_amount_func_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 87;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.tds_taxable_amt_entered_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"tds_taxable_amt_entered_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.tds_taxable_amt_entered_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 88;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.tds_taxable_amount_func_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"tds_taxable_amount_func_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.tds_taxable_amount_func_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 89;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.tds_amt_entered_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"tds_amt_entered_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.tds_amt_entered_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 90;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.tds_amt_func_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"tds_amt_func_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.tds_amt_func_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 91;
					
							row1.invoice_currency = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 92;
					
							row1.org_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 93;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.ad_tds_amt_entered_curr = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"ad_tds_amt_entered_curr", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.ad_tds_amt_entered_curr = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 94;
					
							row1.tds_applicable = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 95;
					
							row1.tds_grouping = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 96;
					
							row1.journal_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 97;
					
							row1.journal_batch_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 98;
					
							row1.posting_status = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 99;
					
							row1.entered_dr = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
					}
					
					public void valueToConn_1(org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1,row1Struct row1 ) throws java.lang.Exception{
						
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 100;
					
							row1.entered_cr = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
					}
					
					public void valueToConn(org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1,row1Struct row1 ) throws java.lang.Exception{
				
						valueToConn_0(fid_tFileInputDelimited_1,row1 );
					
						valueToConn_1(fid_tFileInputDelimited_1,row1 );
					
					}
				
				}
				RowHelper_tFileInputDelimited_1 rowHelper_tFileInputDelimited_1  = new RowHelper_tFileInputDelimited_1();
			
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = "GL_Trial_Balance_Report_"+ TalendDate.getDate("yyyy-MM-dd") +".csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited("GL_Trial_Balance_Report_"+ TalendDate.getDate("yyyy-MM-dd") +".csv", "ISO-8859-15",";","\n",true,0,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
							
								
									log.error("tFileInputDelimited_1 - " +e.getMessage());
								
								System.err.println(e.getMessage());
							
						}
					
				    
				    	log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row1 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row1 = new row1Struct();
									try {
										
			rowHelper_tFileInputDelimited_1.valueToConn(fid_tFileInputDelimited_1, row1 );
		
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
												log.error("tFileInputDelimited_1 - " +e.getMessage());
											
			                					System.err.println(e.getMessage());
			                					row1 = null;
			                				
										
			    					}
								
			log.debug("tFileInputDelimited_1 - Retrieving the record " + fid_tFileInputDelimited_1.getRowNumber() + ".");
		

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";
	
	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";
	
	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tFileInputDelimited_1","tFileInputDelimited_1","tFileInputDelimited","tDBOutput_1","\"gl_trial_balance_report\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    if(row1.ledger_name == null) {
pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(1, row1.ledger_name);
}

                    if(row1.le_name == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, row1.le_name);
}

                    if(row1.ledger_currency == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, row1.ledger_currency);
}

                    if(row1.period_name == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, row1.period_name);
}

                    if(row1.entity == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(5, row1.entity);
}

                    if(row1.entity_desc == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.entity_desc);
}

                    if(row1.account == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(7, row1.account);
}

                    if(row1.account_desc == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(8, row1.account_desc);
}

                    if(row1.location_code == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(9, row1.location_code);
}

                    if(row1.location_code_desc == null) {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(10, row1.location_code_desc);
}

                    if(row1.department == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(11, row1.department);
}

                    if(row1.department_desc == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, row1.department_desc);
}

                    if(row1.product == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, row1.product);
}

                    if(row1.product_desc == null) {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(14, row1.product_desc);
}

                    if(row1.inter_company == null) {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(15, row1.inter_company);
}

                    if(row1.inter_company_desc == null) {
pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(16, row1.inter_company_desc);
}

                    if(row1.inter_location == null) {
pstmt_tDBOutput_1.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(17, row1.inter_location);
}

                    if(row1.inter_location_desc == null) {
pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(18, row1.inter_location_desc);
}

                    if(row1.acct_type == null) {
pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(19, row1.acct_type);
}

                    pstmt_tDBOutput_1.setBigDecimal(20, row1.begin_balance);

                    pstmt_tDBOutput_1.setBigDecimal(21, row1.period_dr);

                    pstmt_tDBOutput_1.setBigDecimal(22, row1.period_cr);

                    pstmt_tDBOutput_1.setBigDecimal(23, row1.end_balance);

                    if(row1.business_unit == null) {
pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(24, row1.business_unit);
}

                    if(row1.vendor_num == null) {
pstmt_tDBOutput_1.setNull(25, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(25, row1.vendor_num);
}

                    if(row1.supp_name == null) {
pstmt_tDBOutput_1.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(26, row1.supp_name);
}

                    if(row1.vendor_type == null) {
pstmt_tDBOutput_1.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(27, row1.vendor_type);
}

                    if(row1.tax_org_type == null) {
pstmt_tDBOutput_1.setNull(28, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(28, row1.tax_org_type);
}

                    if(row1.vendor_site_code == null) {
pstmt_tDBOutput_1.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(29, row1.vendor_site_code);
}

                    if(row1.supp_status == null) {
pstmt_tDBOutput_1.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(30, row1.supp_status);
}

                    if(row1.pay_method == null) {
pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(31, row1.pay_method);
}

                    if(row1.country == null) {
pstmt_tDBOutput_1.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(32, row1.country);
}

                    if(row1.address1 == null) {
pstmt_tDBOutput_1.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(33, row1.address1);
}

                    if(row1.address2 == null) {
pstmt_tDBOutput_1.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(34, row1.address2);
}

                    if(row1.city == null) {
pstmt_tDBOutput_1.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(35, row1.city);
}

                    if(row1.state == null) {
pstmt_tDBOutput_1.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(36, row1.state);
}

                    if(row1.postal_code == null) {
pstmt_tDBOutput_1.setNull(37, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(37, row1.postal_code);
}

                    if(row1.liab_acct == null) {
pstmt_tDBOutput_1.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(38, row1.liab_acct);
}

                    if(row1.prepay_acct == null) {
pstmt_tDBOutput_1.setNull(39, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(39, row1.prepay_acct);
}

                    if(row1.sup_bank_account_num == null) {
pstmt_tDBOutput_1.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(40, row1.sup_bank_account_num);
}

                    if(row1.sup_bank_account_name == null) {
pstmt_tDBOutput_1.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(41, row1.sup_bank_account_name);
}

                    if(row1.sup_bank_branch_name == null) {
pstmt_tDBOutput_1.setNull(42, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(42, row1.sup_bank_branch_name);
}

                    if(row1.sup_bank_name == null) {
pstmt_tDBOutput_1.setNull(43, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(43, row1.sup_bank_name);
}

                    if(row1.sup_ifsc_code == null) {
pstmt_tDBOutput_1.setNull(44, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(44, row1.sup_ifsc_code);
}

                    if(row1.msme_tag == null) {
pstmt_tDBOutput_1.setNull(45, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(45, row1.msme_tag);
}

                    if(row1.vendor_creation_date == null) {
pstmt_tDBOutput_1.setNull(46, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(46, row1.vendor_creation_date);
}

                    if(row1.site_creation_date == null) {
pstmt_tDBOutput_1.setNull(47, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(47, row1.site_creation_date);
}

                    if(row1.last_transaction_date == null) {
pstmt_tDBOutput_1.setNull(48, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(48, row1.last_transaction_date);
}

                    if(row1.party_site_name == null) {
pstmt_tDBOutput_1.setNull(49, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(49, row1.party_site_name);
}

                    if(row1.sup_branch_number == null) {
pstmt_tDBOutput_1.setNull(50, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(50, row1.sup_branch_number);
}

                    if(row1.site_created_by == null) {
pstmt_tDBOutput_1.setNull(51, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(51, row1.site_created_by);
}

                    if(row1.pan_number == null) {
pstmt_tDBOutput_1.setNull(52, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(52, row1.pan_number);
}

                    if(row1.gst_number == null) {
pstmt_tDBOutput_1.setNull(53, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(53, row1.gst_number);
}

                    if(row1.msme_no == null) {
pstmt_tDBOutput_1.setNull(54, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(54, row1.msme_no);
}

                    if(row1.address3 == null) {
pstmt_tDBOutput_1.setNull(55, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(55, row1.address3);
}

                    if(row1.site_bank_account_num == null) {
pstmt_tDBOutput_1.setNull(56, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(56, row1.site_bank_account_num);
}

                    if(row1.site_bank_branch_name == null) {
pstmt_tDBOutput_1.setNull(57, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(57, row1.site_bank_branch_name);
}

                    if(row1.site_bank_name == null) {
pstmt_tDBOutput_1.setNull(58, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(58, row1.site_bank_name);
}

                    if(row1.site_branch_number == null) {
pstmt_tDBOutput_1.setNull(59, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(59, row1.site_branch_number);
}

                    if(row1.site_ifsc_code == null) {
pstmt_tDBOutput_1.setNull(60, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(60, row1.site_ifsc_code);
}

                    if(row1.site_bank_account_name == null) {
pstmt_tDBOutput_1.setNull(61, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(61, row1.site_bank_account_name);
}

                    if(row1.vendor_created_by == null) {
pstmt_tDBOutput_1.setNull(62, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(62, row1.vendor_created_by);
}

                    if(row1.inactivated_date == null) {
pstmt_tDBOutput_1.setNull(63, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(63, row1.inactivated_date);
}

                    if(row1.inactivated_by == null) {
pstmt_tDBOutput_1.setNull(64, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(64, row1.inactivated_by);
}

                    if(row1.address4 == null) {
pstmt_tDBOutput_1.setNull(65, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(65, row1.address4);
}

                    if(row1.tds_section == null) {
pstmt_tDBOutput_1.setNull(66, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(66, row1.tds_section);
}

                    if(row1.tds_code == null) {
pstmt_tDBOutput_1.setNull(67, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(67, row1.tds_code);
}

                    if(row1.tax_rate == null) {
pstmt_tDBOutput_1.setNull(68, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(68, row1.tax_rate);
}

                    if(row1.supplier_number == null) {
pstmt_tDBOutput_1.setNull(69, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(69, row1.supplier_number);
}

                    if(row1.supplier_name == null) {
pstmt_tDBOutput_1.setNull(70, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(70, row1.supplier_name);
}

                    if(row1.NAME == null) {
pstmt_tDBOutput_1.setNull(71, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(71, row1.NAME);
}

                    if(row1.liab_account == null) {
pstmt_tDBOutput_1.setNull(72, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(72, row1.liab_account);
}

                    if(row1.liab_acct_desc == null) {
pstmt_tDBOutput_1.setNull(73, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(73, row1.liab_acct_desc);
}

                    if(row1.expense_account == null) {
pstmt_tDBOutput_1.setNull(74, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(74, row1.expense_account);
}

                    if(row1.expense_acct_desc == null) {
pstmt_tDBOutput_1.setNull(75, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(75, row1.expense_acct_desc);
}

                    if(row1.organization_type == null) {
pstmt_tDBOutput_1.setNull(76, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(76, row1.organization_type);
}

                    if(row1.certificate == null) {
pstmt_tDBOutput_1.setNull(77, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(77, row1.certificate);
}

                    if(row1.invoice_num == null) {
pstmt_tDBOutput_1.setNull(78, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(78, row1.invoice_num);
}

                    if(row1.ref_invoice_num == null) {
pstmt_tDBOutput_1.setNull(79, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(79, row1.ref_invoice_num);
}

                    if(row1.vouchar_num == null) {
pstmt_tDBOutput_1.setNull(80, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(80, row1.vouchar_num);
}

                    if(row1.invoice_date == null) {
pstmt_tDBOutput_1.setNull(81, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(81, row1.invoice_date);
}

                    if(row1.accounting_date == null) {
pstmt_tDBOutput_1.setNull(82, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(82, row1.accounting_date);
}

                    if(row1.accounting_status == null) {
pstmt_tDBOutput_1.setNull(83, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(83, row1.accounting_status);
}

                    if(row1.description == null) {
pstmt_tDBOutput_1.setNull(84, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(84, row1.description);
}

                    if(row1.line_number == null) {
pstmt_tDBOutput_1.setNull(85, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(85, row1.line_number);
}

                    if(row1.invoice_amount_entered_curr == null) {
pstmt_tDBOutput_1.setNull(86, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(86, row1.invoice_amount_entered_curr);
}

                    if(row1.invoice_amount_func_curr == null) {
pstmt_tDBOutput_1.setNull(87, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(87, row1.invoice_amount_func_curr);
}

                    if(row1.tds_taxable_amt_entered_curr == null) {
pstmt_tDBOutput_1.setNull(88, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(88, row1.tds_taxable_amt_entered_curr);
}

                    if(row1.tds_taxable_amount_func_curr == null) {
pstmt_tDBOutput_1.setNull(89, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(89, row1.tds_taxable_amount_func_curr);
}

                    if(row1.tds_amt_entered_curr == null) {
pstmt_tDBOutput_1.setNull(90, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(90, row1.tds_amt_entered_curr);
}

                    if(row1.tds_amt_func_curr == null) {
pstmt_tDBOutput_1.setNull(91, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(91, row1.tds_amt_func_curr);
}

                    if(row1.invoice_currency == null) {
pstmt_tDBOutput_1.setNull(92, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(92, row1.invoice_currency);
}

                    if(row1.org_name == null) {
pstmt_tDBOutput_1.setNull(93, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(93, row1.org_name);
}

                    if(row1.ad_tds_amt_entered_curr == null) {
pstmt_tDBOutput_1.setNull(94, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(94, row1.ad_tds_amt_entered_curr);
}

                    if(row1.tds_applicable == null) {
pstmt_tDBOutput_1.setNull(95, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(95, row1.tds_applicable);
}

                    if(row1.tds_grouping == null) {
pstmt_tDBOutput_1.setNull(96, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(96, row1.tds_grouping);
}

                    if(row1.journal_name == null) {
pstmt_tDBOutput_1.setNull(97, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(97, row1.journal_name);
}

                    if(row1.journal_batch_name == null) {
pstmt_tDBOutput_1.setNull(98, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(98, row1.journal_batch_name);
}

                    if(row1.posting_status == null) {
pstmt_tDBOutput_1.setNull(99, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(99, row1.posting_status);
}

                    if(row1.entered_dr == null) {
pstmt_tDBOutput_1.setNull(100, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(100, row1.entered_dr);
}

                    if(row1.entered_cr == null) {
pstmt_tDBOutput_1.setNull(101, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(101, row1.entered_cr);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		
    		    commitCounter_tDBOutput_1++;
                if(commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
                if ((batchSize_tDBOutput_1 > 0) && (batchSizeCounter_tDBOutput_1 > 0)) {
                try {
                		int countSum_tDBOutput_1 = 0;
                		    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
            	    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
            	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
            	    	
                batchSizeCounter_tDBOutput_1 = 0;
               }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
			    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
			    	String errormessage_tDBOutput_1;
					if (ne_tDBOutput_1 != null) {
						// build new exception to provide the original cause
						sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
						errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
					}else{
						errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
					}
			    	
			    	int countSum_tDBOutput_1 = 0;
					for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
					
			    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
			    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
			    	System.err.println(errormessage_tDBOutput_1);
			    	
				}
            }
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection starting to commit ")  + (rowsToCommitCount_tDBOutput_1)  + (" record(s).") );
                    }
                    conn_tDBOutput_1.commit();
                    if(rowsToCommitCount_tDBOutput_1 != 0){
                    	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection commit has succeeded.") );
                    	rowsToCommitCount_tDBOutput_1 = 0;
                    }
                    commitCounter_tDBOutput_1=0;
                }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";
	
	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";
	
	



            }
            }finally{
                if(!((Object)("GL_Trial_Balance_Report_"+ TalendDate.getDate("yyyy-MM-dd") +".csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
						log.info("tFileInputDelimited_1 - Retrieved records count: "+ fid_tFileInputDelimited_1.getRowNumber() + ".");
					
                }
			}
			  

 
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Done.") );

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection starting to commit ")  + (rowsToCommitCount_tDBOutput_1)  + (" record(s).") );
			}
			conn_tDBOutput_1.commit();
			if(rowsToCommitCount_tDBOutput_1 != 0){
				
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection commit has succeeded.") );
				rowsToCommitCount_tDBOutput_1 = 0;
			}
			commitCounter_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Closing the connection to the database.") );
    	conn_tDBOutput_1 .close();
    	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection to the database has closed.") );
    	resourceMap.put("finish_tDBOutput_1", true);
    	

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tFileInputDelimited_1","tFileInputDelimited_1","tFileInputDelimited","tDBOutput_1","\"gl_trial_balance_report\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tFileInputDelimited_1);
						}				
					




	
	/**
	 * [tFTPGet_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 process_data_end ] stop
 */
	
	/**
	 * [tFTPGet_1 end ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	
}
nb_file_tFTPGet_1 = getter_tFTPGet_1.count;

	msg_tFTPGet_1.add(getter_tFTPGet_1.count + " files have been downloaded.");
	StringBuffer sb_tFTPGet_1 = new StringBuffer();

	for (String item_tFTPGet_1 : msg_tFTPGet_1) {
		sb_tFTPGet_1.append(item_tFTPGet_1).append("\n");
	}
	globalMap.put("tFTPGet_1_TRANSFER_MESSAGES", sb_tFTPGet_1.toString());

	    
	globalMap.put("tFTPGet_1_NB_FILE",nb_file_tFTPGet_1);
	log.info("tFTPGet_1 - Downloaded files count: " + nb_file_tFTPGet_1  + ".");


 
                if(log.isDebugEnabled())
            log.debug("tFTPGet_1 - "  + ("Done.") );

ok_Hash.put("tFTPGet_1", true);
end_Hash.put("tFTPGet_1", System.currentTimeMillis());




/**
 * [tFTPGet_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFTPGet_1 finally ] start
	 */

	

	
	
	currentComponent="tFTPGet_1";
	
	

 



/**
 * [tFTPGet_1 finally ] stop
 */

	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";
	
	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"gl_trial_balance_report\"";
		



    try {
    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
    } finally {
        if(resourceMap.get("finish_tDBOutput_1") == null){
            java.sql.Connection ctn_tDBOutput_1 = null;
            if((ctn_tDBOutput_1 = (java.sql.Connection)resourceMap.get("conn_tDBOutput_1")) != null){
                try {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Closing the connection to the database.") );
                    ctn_tDBOutput_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection to the database has closed.") );
                } catch (java.sql.SQLException sqlEx_tDBOutput_1) {
                    String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :" + sqlEx_tDBOutput_1.getMessage();
            log.error("tDBOutput_1 - "  + (errorMessage_tDBOutput_1) );
                    System.err.println(errorMessage_tDBOutput_1);
                }
            }
        }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFTPGet_1_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "DAfilg_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final GL_Trial_Balance_Report_SFTP GL_Trial_Balance_Report_SFTPClass = new GL_Trial_Balance_Report_SFTP();

        int exitCode = GL_Trial_Balance_Report_SFTPClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'GL_Trial_Balance_Report_SFTP' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230612_1054-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'GL_Trial_Balance_Report_SFTP' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_7KvQQN9kEe2CtfQ-GaHJEQ");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-08-02T11:48:39.963576900Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = GL_Trial_Balance_Report_SFTP.class.getClassLoader().getResourceAsStream("talend_tac2_repo/gl_trial_balance_report_sftp_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = GL_Trial_Balance_Report_SFTP.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("file_path", "id_Directory");
                        if(context.getStringValue("file_path") == null) {
                            context.file_path = null;
                        } else {
                            context.file_path=(String) context.getProperty("file_path");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("file_path")) {
                context.file_path = (String) parentContextMap.get("file_path");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'GL_Trial_Balance_Report_SFTP' - Started.");
            mdcInfo.putAll(org.slf4j.MDC.getCopyOfContextMap());

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFTPConnection_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFTPConnection_2) {
globalMap.put("tFTPConnection_2_SUBPROCESS_STATE", -1);

e_tFTPConnection_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : GL_Trial_Balance_Report_SFTP");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'GL_Trial_Balance_Report_SFTP' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();
    closeFtpConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }



    private void closeFtpConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tFTPConnection_1");
            if (obj_conn != null) {
                ((com.jcraft.jsch.ChannelSftp) obj_conn).quit();
            }
            obj_conn = globalMap.remove("conn_tFTPConnection_2");
            if (obj_conn != null) {
                ((com.jcraft.jsch.ChannelSftp) obj_conn).quit();
            }
        } catch (java.lang.Exception e) {
        }
    }








    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));


            connections.put("conn_tFTPConnection_1", globalMap.get("conn_tFTPConnection_1"));
            connections.put("conn_tFTPConnection_2", globalMap.get("conn_tFTPConnection_2"));




        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     339071 characters generated by Talend Data Integration 
 *     on the August 2, 2023 at 5:18:39 PM IST
 ************************************************************************************************/