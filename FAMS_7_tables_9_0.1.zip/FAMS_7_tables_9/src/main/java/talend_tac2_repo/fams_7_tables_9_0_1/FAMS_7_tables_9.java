
package talend_tac2_repo.fams_7_tables_9_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: FAMS_7_tables_9 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230315_1127-patch
 * @status 
 */
public class FAMS_7_tables_9 implements TalendJob {
	static {System.setProperty("TalendJob.log", "FAMS_7_tables_9.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(FAMS_7_tables_9.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "FAMS_7_tables_9";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_THzm4A9IEe6leu5mDfS5QQ", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				FAMS_7_tables_9.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(FAMS_7_tables_9.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "MSSQL_PROP");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.118.157\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"1433\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"CHAITANYA\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"FAMS_DWH\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:CDIOujwspfo5UQDWN7wflHqFM6JByqrEpEEBzm3xgAtRj8S7").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "FAMS_Source", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

			    
		    String url_tDBConnection_1 = "jdbc:sqlserver://" + "115.124.118.157" ;
		String port_tDBConnection_1 = "1433";
		String dbname_tDBConnection_1 = "CHAITANYA" ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + "1433";
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    				    
		    	url_tDBConnection_1 += ";databaseName=" + "CHAITANYA"; 
    	}

		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
	String dbUser_tDBConnection_1 = "FAMS_DWH";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:n02k2/5pHhdTs9FVAoZYvA6LT1yyj9Rj6EzILKgbL+sRsUhC");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_1", "");

	globalMap.put("db_tDBConnection_1",  "CHAITANYA");
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

	globalMap.put("driver_tDBConnection_1", "MSSQL_PROP");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"FAMS_DWH_TGT\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:GKg1BahuRQGh4VHehsPqwyCDVpMkeNrc87BK7Hz+SoHfzEQL").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "FAMS_Target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "FAMS_DWH_TGT";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:MtmT0bTC/zX3v9hh7DmFKUfbiCfVkD0vCwA0fWBR75c049nR");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int AssetSaleDetailID;

				public int getAssetSaleDetailID () {
					return this.AssetSaleDetailID;
				}

				public Boolean AssetSaleDetailIDIsNullable(){
				    return false;
				}
				public Boolean AssetSaleDetailIDIsKey(){
				    return true;
				}
				public Integer AssetSaleDetailIDLength(){
				    return 10;
				}
				public Integer AssetSaleDetailIDPrecision(){
				    return 0;
				}
				public String AssetSaleDetailIDDefault(){
				
					return null;
				
				}
				public String AssetSaleDetailIDComment(){
				
				    return "";
				
				}
				public String AssetSaleDetailIDPattern(){
				
					return "";
				
				}
				public String AssetSaleDetailIDOriginalDbColumnName(){
				
					return "AssetSaleDetailID";
				
				}

				
			    public int AssetSaleID;

				public int getAssetSaleID () {
					return this.AssetSaleID;
				}

				public Boolean AssetSaleIDIsNullable(){
				    return false;
				}
				public Boolean AssetSaleIDIsKey(){
				    return false;
				}
				public Integer AssetSaleIDLength(){
				    return 10;
				}
				public Integer AssetSaleIDPrecision(){
				    return 0;
				}
				public String AssetSaleIDDefault(){
				
					return null;
				
				}
				public String AssetSaleIDComment(){
				
				    return "";
				
				}
				public String AssetSaleIDPattern(){
				
					return "";
				
				}
				public String AssetSaleIDOriginalDbColumnName(){
				
					return "AssetSaleID";
				
				}

				
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public java.util.Date OrgAccDepUpto;

				public java.util.Date getOrgAccDepUpto () {
					return this.OrgAccDepUpto;
				}

				public Boolean OrgAccDepUptoIsNullable(){
				    return true;
				}
				public Boolean OrgAccDepUptoIsKey(){
				    return false;
				}
				public Integer OrgAccDepUptoLength(){
				    return 23;
				}
				public Integer OrgAccDepUptoPrecision(){
				    return 3;
				}
				public String OrgAccDepUptoDefault(){
				
					return null;
				
				}
				public String OrgAccDepUptoComment(){
				
				    return "";
				
				}
				public String OrgAccDepUptoPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String OrgAccDepUptoOriginalDbColumnName(){
				
					return "OrgAccDepUpto";
				
				}

				
			    public String OrgPhyID;

				public String getOrgPhyID () {
					return this.OrgPhyID;
				}

				public Boolean OrgPhyIDIsNullable(){
				    return true;
				}
				public Boolean OrgPhyIDIsKey(){
				    return false;
				}
				public Integer OrgPhyIDLength(){
				    return 50;
				}
				public Integer OrgPhyIDPrecision(){
				    return 0;
				}
				public String OrgPhyIDDefault(){
				
					return null;
				
				}
				public String OrgPhyIDComment(){
				
				    return "";
				
				}
				public String OrgPhyIDPattern(){
				
					return "";
				
				}
				public String OrgPhyIDOriginalDbColumnName(){
				
					return "OrgPhyID";
				
				}

				
			    public String SoldPhyID;

				public String getSoldPhyID () {
					return this.SoldPhyID;
				}

				public Boolean SoldPhyIDIsNullable(){
				    return true;
				}
				public Boolean SoldPhyIDIsKey(){
				    return false;
				}
				public Integer SoldPhyIDLength(){
				    return 50;
				}
				public Integer SoldPhyIDPrecision(){
				    return 0;
				}
				public String SoldPhyIDDefault(){
				
					return null;
				
				}
				public String SoldPhyIDComment(){
				
				    return "";
				
				}
				public String SoldPhyIDPattern(){
				
					return "";
				
				}
				public String SoldPhyIDOriginalDbColumnName(){
				
					return "SoldPhyID";
				
				}

				
			    public BigDecimal SoldValue;

				public BigDecimal getSoldValue () {
					return this.SoldValue;
				}

				public Boolean SoldValueIsNullable(){
				    return false;
				}
				public Boolean SoldValueIsKey(){
				    return false;
				}
				public Integer SoldValueLength(){
				    return 12;
				}
				public Integer SoldValuePrecision(){
				    return 2;
				}
				public String SoldValueDefault(){
				
					return null;
				
				}
				public String SoldValueComment(){
				
				    return "";
				
				}
				public String SoldValuePattern(){
				
					return "";
				
				}
				public String SoldValueOriginalDbColumnName(){
				
					return "SoldValue";
				
				}

				
			    public Integer OrgQty;

				public Integer getOrgQty () {
					return this.OrgQty;
				}

				public Boolean OrgQtyIsNullable(){
				    return true;
				}
				public Boolean OrgQtyIsKey(){
				    return false;
				}
				public Integer OrgQtyLength(){
				    return 10;
				}
				public Integer OrgQtyPrecision(){
				    return 0;
				}
				public String OrgQtyDefault(){
				
					return null;
				
				}
				public String OrgQtyComment(){
				
				    return "";
				
				}
				public String OrgQtyPattern(){
				
					return "";
				
				}
				public String OrgQtyOriginalDbColumnName(){
				
					return "OrgQty";
				
				}

				
			    public Integer SoldQty;

				public Integer getSoldQty () {
					return this.SoldQty;
				}

				public Boolean SoldQtyIsNullable(){
				    return true;
				}
				public Boolean SoldQtyIsKey(){
				    return false;
				}
				public Integer SoldQtyLength(){
				    return 10;
				}
				public Integer SoldQtyPrecision(){
				    return 0;
				}
				public String SoldQtyDefault(){
				
					return null;
				
				}
				public String SoldQtyComment(){
				
				    return "";
				
				}
				public String SoldQtyPattern(){
				
					return "";
				
				}
				public String SoldQtyOriginalDbColumnName(){
				
					return "SoldQty";
				
				}

				
			    public BigDecimal OrgAccDep;

				public BigDecimal getOrgAccDep () {
					return this.OrgAccDep;
				}

				public Boolean OrgAccDepIsNullable(){
				    return true;
				}
				public Boolean OrgAccDepIsKey(){
				    return false;
				}
				public Integer OrgAccDepLength(){
				    return 12;
				}
				public Integer OrgAccDepPrecision(){
				    return 2;
				}
				public String OrgAccDepDefault(){
				
					return null;
				
				}
				public String OrgAccDepComment(){
				
				    return "";
				
				}
				public String OrgAccDepPattern(){
				
					return "";
				
				}
				public String OrgAccDepOriginalDbColumnName(){
				
					return "OrgAccDep";
				
				}

				
			    public BigDecimal SoldAccDep;

				public BigDecimal getSoldAccDep () {
					return this.SoldAccDep;
				}

				public Boolean SoldAccDepIsNullable(){
				    return true;
				}
				public Boolean SoldAccDepIsKey(){
				    return false;
				}
				public Integer SoldAccDepLength(){
				    return 12;
				}
				public Integer SoldAccDepPrecision(){
				    return 2;
				}
				public String SoldAccDepDefault(){
				
					return null;
				
				}
				public String SoldAccDepComment(){
				
				    return "";
				
				}
				public String SoldAccDepPattern(){
				
					return "";
				
				}
				public String SoldAccDepOriginalDbColumnName(){
				
					return "SoldAccDep";
				
				}

				
			    public BigDecimal OrgDEP;

				public BigDecimal getOrgDEP () {
					return this.OrgDEP;
				}

				public Boolean OrgDEPIsNullable(){
				    return true;
				}
				public Boolean OrgDEPIsKey(){
				    return false;
				}
				public Integer OrgDEPLength(){
				    return 12;
				}
				public Integer OrgDEPPrecision(){
				    return 2;
				}
				public String OrgDEPDefault(){
				
					return null;
				
				}
				public String OrgDEPComment(){
				
				    return "";
				
				}
				public String OrgDEPPattern(){
				
					return "";
				
				}
				public String OrgDEPOriginalDbColumnName(){
				
					return "OrgDEP";
				
				}

				
			    public BigDecimal SoldDEP;

				public BigDecimal getSoldDEP () {
					return this.SoldDEP;
				}

				public Boolean SoldDEPIsNullable(){
				    return true;
				}
				public Boolean SoldDEPIsKey(){
				    return false;
				}
				public Integer SoldDEPLength(){
				    return 12;
				}
				public Integer SoldDEPPrecision(){
				    return 2;
				}
				public String SoldDEPDefault(){
				
					return null;
				
				}
				public String SoldDEPComment(){
				
				    return "";
				
				}
				public String SoldDEPPattern(){
				
					return "";
				
				}
				public String SoldDEPOriginalDbColumnName(){
				
					return "SoldDEP";
				
				}

				
			    public BigDecimal ProfitLossValue;

				public BigDecimal getProfitLossValue () {
					return this.ProfitLossValue;
				}

				public Boolean ProfitLossValueIsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueIsKey(){
				    return false;
				}
				public Integer ProfitLossValueLength(){
				    return 12;
				}
				public Integer ProfitLossValuePrecision(){
				    return 2;
				}
				public String ProfitLossValueDefault(){
				
					return null;
				
				}
				public String ProfitLossValueComment(){
				
				    return "";
				
				}
				public String ProfitLossValuePattern(){
				
					return "";
				
				}
				public String ProfitLossValueOriginalDbColumnName(){
				
					return "ProfitLossValue";
				
				}

				
			    public BigDecimal AdditionalCost;

				public BigDecimal getAdditionalCost () {
					return this.AdditionalCost;
				}

				public Boolean AdditionalCostIsNullable(){
				    return true;
				}
				public Boolean AdditionalCostIsKey(){
				    return false;
				}
				public Integer AdditionalCostLength(){
				    return 12;
				}
				public Integer AdditionalCostPrecision(){
				    return 2;
				}
				public String AdditionalCostDefault(){
				
					return null;
				
				}
				public String AdditionalCostComment(){
				
				    return "";
				
				}
				public String AdditionalCostPattern(){
				
					return "";
				
				}
				public String AdditionalCostOriginalDbColumnName(){
				
					return "AdditionalCost";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 200;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public BigDecimal DepUpToSaleDate;

				public BigDecimal getDepUpToSaleDate () {
					return this.DepUpToSaleDate;
				}

				public Boolean DepUpToSaleDateIsNullable(){
				    return true;
				}
				public Boolean DepUpToSaleDateIsKey(){
				    return false;
				}
				public Integer DepUpToSaleDateLength(){
				    return 12;
				}
				public Integer DepUpToSaleDatePrecision(){
				    return 2;
				}
				public String DepUpToSaleDateDefault(){
				
					return null;
				
				}
				public String DepUpToSaleDateComment(){
				
				    return "";
				
				}
				public String DepUpToSaleDatePattern(){
				
					return "";
				
				}
				public String DepUpToSaleDateOriginalDbColumnName(){
				
					return "DepUpToSaleDate";
				
				}

				
			    public BigDecimal AccDepUpToSaleDate;

				public BigDecimal getAccDepUpToSaleDate () {
					return this.AccDepUpToSaleDate;
				}

				public Boolean AccDepUpToSaleDateIsNullable(){
				    return true;
				}
				public Boolean AccDepUpToSaleDateIsKey(){
				    return false;
				}
				public Integer AccDepUpToSaleDateLength(){
				    return 12;
				}
				public Integer AccDepUpToSaleDatePrecision(){
				    return 2;
				}
				public String AccDepUpToSaleDateDefault(){
				
					return null;
				
				}
				public String AccDepUpToSaleDateComment(){
				
				    return "";
				
				}
				public String AccDepUpToSaleDatePattern(){
				
					return "";
				
				}
				public String AccDepUpToSaleDateOriginalDbColumnName(){
				
					return "AccDepUpToSaleDate";
				
				}

				
			    public BigDecimal ChildAssetsCost;

				public BigDecimal getChildAssetsCost () {
					return this.ChildAssetsCost;
				}

				public Boolean ChildAssetsCostIsNullable(){
				    return true;
				}
				public Boolean ChildAssetsCostIsKey(){
				    return false;
				}
				public Integer ChildAssetsCostLength(){
				    return 12;
				}
				public Integer ChildAssetsCostPrecision(){
				    return 2;
				}
				public String ChildAssetsCostDefault(){
				
					return null;
				
				}
				public String ChildAssetsCostComment(){
				
				    return "";
				
				}
				public String ChildAssetsCostPattern(){
				
					return "";
				
				}
				public String ChildAssetsCostOriginalDbColumnName(){
				
					return "ChildAssetsCost";
				
				}

				
			    public BigDecimal TotalCost;

				public BigDecimal getTotalCost () {
					return this.TotalCost;
				}

				public Boolean TotalCostIsNullable(){
				    return true;
				}
				public Boolean TotalCostIsKey(){
				    return false;
				}
				public Integer TotalCostLength(){
				    return 12;
				}
				public Integer TotalCostPrecision(){
				    return 2;
				}
				public String TotalCostDefault(){
				
					return null;
				
				}
				public String TotalCostComment(){
				
				    return "";
				
				}
				public String TotalCostPattern(){
				
					return "";
				
				}
				public String TotalCostOriginalDbColumnName(){
				
					return "TotalCost";
				
				}

				
			    public BigDecimal OrgAccDepBook1;

				public BigDecimal getOrgAccDepBook1 () {
					return this.OrgAccDepBook1;
				}

				public Boolean OrgAccDepBook1IsNullable(){
				    return true;
				}
				public Boolean OrgAccDepBook1IsKey(){
				    return false;
				}
				public Integer OrgAccDepBook1Length(){
				    return 12;
				}
				public Integer OrgAccDepBook1Precision(){
				    return 2;
				}
				public String OrgAccDepBook1Default(){
				
					return null;
				
				}
				public String OrgAccDepBook1Comment(){
				
				    return "";
				
				}
				public String OrgAccDepBook1Pattern(){
				
					return "";
				
				}
				public String OrgAccDepBook1OriginalDbColumnName(){
				
					return "OrgAccDepBook1";
				
				}

				
			    public BigDecimal OrgAccDepBook2;

				public BigDecimal getOrgAccDepBook2 () {
					return this.OrgAccDepBook2;
				}

				public Boolean OrgAccDepBook2IsNullable(){
				    return true;
				}
				public Boolean OrgAccDepBook2IsKey(){
				    return false;
				}
				public Integer OrgAccDepBook2Length(){
				    return 12;
				}
				public Integer OrgAccDepBook2Precision(){
				    return 2;
				}
				public String OrgAccDepBook2Default(){
				
					return null;
				
				}
				public String OrgAccDepBook2Comment(){
				
				    return "";
				
				}
				public String OrgAccDepBook2Pattern(){
				
					return "";
				
				}
				public String OrgAccDepBook2OriginalDbColumnName(){
				
					return "OrgAccDepBook2";
				
				}

				
			    public BigDecimal ProfitLossValueBook1;

				public BigDecimal getProfitLossValueBook1 () {
					return this.ProfitLossValueBook1;
				}

				public Boolean ProfitLossValueBook1IsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueBook1IsKey(){
				    return false;
				}
				public Integer ProfitLossValueBook1Length(){
				    return 12;
				}
				public Integer ProfitLossValueBook1Precision(){
				    return 2;
				}
				public String ProfitLossValueBook1Default(){
				
					return null;
				
				}
				public String ProfitLossValueBook1Comment(){
				
				    return "";
				
				}
				public String ProfitLossValueBook1Pattern(){
				
					return "";
				
				}
				public String ProfitLossValueBook1OriginalDbColumnName(){
				
					return "ProfitLossValueBook1";
				
				}

				
			    public BigDecimal ProfitLossValueBook2;

				public BigDecimal getProfitLossValueBook2 () {
					return this.ProfitLossValueBook2;
				}

				public Boolean ProfitLossValueBook2IsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueBook2IsKey(){
				    return false;
				}
				public Integer ProfitLossValueBook2Length(){
				    return 12;
				}
				public Integer ProfitLossValueBook2Precision(){
				    return 2;
				}
				public String ProfitLossValueBook2Default(){
				
					return null;
				
				}
				public String ProfitLossValueBook2Comment(){
				
				    return "";
				
				}
				public String ProfitLossValueBook2Pattern(){
				
					return "";
				
				}
				public String ProfitLossValueBook2OriginalDbColumnName(){
				
					return "ProfitLossValueBook2";
				
				}

				
			    public BigDecimal SoldDEPBook1;

				public BigDecimal getSoldDEPBook1 () {
					return this.SoldDEPBook1;
				}

				public Boolean SoldDEPBook1IsNullable(){
				    return true;
				}
				public Boolean SoldDEPBook1IsKey(){
				    return false;
				}
				public Integer SoldDEPBook1Length(){
				    return 12;
				}
				public Integer SoldDEPBook1Precision(){
				    return 2;
				}
				public String SoldDEPBook1Default(){
				
					return null;
				
				}
				public String SoldDEPBook1Comment(){
				
				    return "";
				
				}
				public String SoldDEPBook1Pattern(){
				
					return "";
				
				}
				public String SoldDEPBook1OriginalDbColumnName(){
				
					return "SoldDEPBook1";
				
				}

				
			    public BigDecimal SoldDEPBook2;

				public BigDecimal getSoldDEPBook2 () {
					return this.SoldDEPBook2;
				}

				public Boolean SoldDEPBook2IsNullable(){
				    return true;
				}
				public Boolean SoldDEPBook2IsKey(){
				    return false;
				}
				public Integer SoldDEPBook2Length(){
				    return 12;
				}
				public Integer SoldDEPBook2Precision(){
				    return 2;
				}
				public String SoldDEPBook2Default(){
				
					return null;
				
				}
				public String SoldDEPBook2Comment(){
				
				    return "";
				
				}
				public String SoldDEPBook2Pattern(){
				
					return "";
				
				}
				public String SoldDEPBook2OriginalDbColumnName(){
				
					return "SoldDEPBook2";
				
				}

				
			    public BigDecimal TotalDep;

				public BigDecimal getTotalDep () {
					return this.TotalDep;
				}

				public Boolean TotalDepIsNullable(){
				    return true;
				}
				public Boolean TotalDepIsKey(){
				    return false;
				}
				public Integer TotalDepLength(){
				    return 12;
				}
				public Integer TotalDepPrecision(){
				    return 2;
				}
				public String TotalDepDefault(){
				
					return null;
				
				}
				public String TotalDepComment(){
				
				    return "";
				
				}
				public String TotalDepPattern(){
				
					return "";
				
				}
				public String TotalDepOriginalDbColumnName(){
				
					return "TotalDep";
				
				}

				
			    public BigDecimal TotalDepBook1;

				public BigDecimal getTotalDepBook1 () {
					return this.TotalDepBook1;
				}

				public Boolean TotalDepBook1IsNullable(){
				    return true;
				}
				public Boolean TotalDepBook1IsKey(){
				    return false;
				}
				public Integer TotalDepBook1Length(){
				    return 12;
				}
				public Integer TotalDepBook1Precision(){
				    return 2;
				}
				public String TotalDepBook1Default(){
				
					return null;
				
				}
				public String TotalDepBook1Comment(){
				
				    return "";
				
				}
				public String TotalDepBook1Pattern(){
				
					return "";
				
				}
				public String TotalDepBook1OriginalDbColumnName(){
				
					return "TotalDepBook1";
				
				}

				
			    public BigDecimal TotalDepBook2;

				public BigDecimal getTotalDepBook2 () {
					return this.TotalDepBook2;
				}

				public Boolean TotalDepBook2IsNullable(){
				    return true;
				}
				public Boolean TotalDepBook2IsKey(){
				    return false;
				}
				public Integer TotalDepBook2Length(){
				    return 12;
				}
				public Integer TotalDepBook2Precision(){
				    return 2;
				}
				public String TotalDepBook2Default(){
				
					return null;
				
				}
				public String TotalDepBook2Comment(){
				
				    return "";
				
				}
				public String TotalDepBook2Pattern(){
				
					return "";
				
				}
				public String TotalDepBook2OriginalDbColumnName(){
				
					return "TotalDepBook2";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.AssetSaleDetailID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.AssetSaleDetailID != other.AssetSaleDetailID)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.AssetSaleDetailID = this.AssetSaleDetailID;
	            other.AssetSaleID = this.AssetSaleID;
	            other.AssetID = this.AssetID;
	            other.OrgAccDepUpto = this.OrgAccDepUpto;
	            other.OrgPhyID = this.OrgPhyID;
	            other.SoldPhyID = this.SoldPhyID;
	            other.SoldValue = this.SoldValue;
	            other.OrgQty = this.OrgQty;
	            other.SoldQty = this.SoldQty;
	            other.OrgAccDep = this.OrgAccDep;
	            other.SoldAccDep = this.SoldAccDep;
	            other.OrgDEP = this.OrgDEP;
	            other.SoldDEP = this.SoldDEP;
	            other.ProfitLossValue = this.ProfitLossValue;
	            other.AdditionalCost = this.AdditionalCost;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            other.Remarks = this.Remarks;
	            other.DepUpToSaleDate = this.DepUpToSaleDate;
	            other.AccDepUpToSaleDate = this.AccDepUpToSaleDate;
	            other.ChildAssetsCost = this.ChildAssetsCost;
	            other.TotalCost = this.TotalCost;
	            other.OrgAccDepBook1 = this.OrgAccDepBook1;
	            other.OrgAccDepBook2 = this.OrgAccDepBook2;
	            other.ProfitLossValueBook1 = this.ProfitLossValueBook1;
	            other.ProfitLossValueBook2 = this.ProfitLossValueBook2;
	            other.SoldDEPBook1 = this.SoldDEPBook1;
	            other.SoldDEPBook2 = this.SoldDEPBook2;
	            other.TotalDep = this.TotalDep;
	            other.TotalDepBook1 = this.TotalDepBook1;
	            other.TotalDepBook2 = this.TotalDepBook2;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.AssetSaleDetailID = this.AssetSaleDetailID;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleDetailID = dis.readInt();
					
			        this.AssetSaleID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.OrgAccDepUpto = readDate(dis);
					
					this.OrgPhyID = readString(dis);
					
					this.SoldPhyID = readString(dis);
					
						this.SoldValue = (BigDecimal) dis.readObject();
					
						this.OrgQty = readInteger(dis);
					
						this.SoldQty = readInteger(dis);
					
						this.OrgAccDep = (BigDecimal) dis.readObject();
					
						this.SoldAccDep = (BigDecimal) dis.readObject();
					
						this.OrgDEP = (BigDecimal) dis.readObject();
					
						this.SoldDEP = (BigDecimal) dis.readObject();
					
						this.ProfitLossValue = (BigDecimal) dis.readObject();
					
						this.AdditionalCost = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.Remarks = readString(dis);
					
						this.DepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.AccDepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.ChildAssetsCost = (BigDecimal) dis.readObject();
					
						this.TotalCost = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook1 = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook2 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook1 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook2 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook1 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook2 = (BigDecimal) dis.readObject();
					
						this.TotalDep = (BigDecimal) dis.readObject();
					
						this.TotalDepBook1 = (BigDecimal) dis.readObject();
					
						this.TotalDepBook2 = (BigDecimal) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleDetailID = dis.readInt();
					
			        this.AssetSaleID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.OrgAccDepUpto = readDate(dis);
					
					this.OrgPhyID = readString(dis);
					
					this.SoldPhyID = readString(dis);
					
						this.SoldValue = (BigDecimal) dis.readObject();
					
						this.OrgQty = readInteger(dis);
					
						this.SoldQty = readInteger(dis);
					
						this.OrgAccDep = (BigDecimal) dis.readObject();
					
						this.SoldAccDep = (BigDecimal) dis.readObject();
					
						this.OrgDEP = (BigDecimal) dis.readObject();
					
						this.SoldDEP = (BigDecimal) dis.readObject();
					
						this.ProfitLossValue = (BigDecimal) dis.readObject();
					
						this.AdditionalCost = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.Remarks = readString(dis);
					
						this.DepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.AccDepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.ChildAssetsCost = (BigDecimal) dis.readObject();
					
						this.TotalCost = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook1 = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook2 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook1 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook2 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook1 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook2 = (BigDecimal) dis.readObject();
					
						this.TotalDep = (BigDecimal) dis.readObject();
					
						this.TotalDepBook1 = (BigDecimal) dis.readObject();
					
						this.TotalDepBook2 = (BigDecimal) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleDetailID);
					
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// java.util.Date
				
						writeDate(this.OrgAccDepUpto,dos);
					
					// String
				
						writeString(this.OrgPhyID,dos);
					
					// String
				
						writeString(this.SoldPhyID,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldValue);
					
					// Integer
				
						writeInteger(this.OrgQty,dos);
					
					// Integer
				
						writeInteger(this.SoldQty,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValue);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AdditionalCost);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.DepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AccDepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ChildAssetsCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook2);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleDetailID);
					
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// java.util.Date
				
						writeDate(this.OrgAccDepUpto,dos);
					
					// String
				
						writeString(this.OrgPhyID,dos);
					
					// String
				
						writeString(this.SoldPhyID,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldValue);
					
					// Integer
				
						writeInteger(this.OrgQty,dos);
					
					// Integer
				
						writeInteger(this.SoldQty,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValue);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AdditionalCost);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.DepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AccDepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ChildAssetsCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook2);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetSaleDetailID="+String.valueOf(AssetSaleDetailID));
		sb.append(",AssetSaleID="+String.valueOf(AssetSaleID));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",OrgAccDepUpto="+String.valueOf(OrgAccDepUpto));
		sb.append(",OrgPhyID="+OrgPhyID);
		sb.append(",SoldPhyID="+SoldPhyID);
		sb.append(",SoldValue="+String.valueOf(SoldValue));
		sb.append(",OrgQty="+String.valueOf(OrgQty));
		sb.append(",SoldQty="+String.valueOf(SoldQty));
		sb.append(",OrgAccDep="+String.valueOf(OrgAccDep));
		sb.append(",SoldAccDep="+String.valueOf(SoldAccDep));
		sb.append(",OrgDEP="+String.valueOf(OrgDEP));
		sb.append(",SoldDEP="+String.valueOf(SoldDEP));
		sb.append(",ProfitLossValue="+String.valueOf(ProfitLossValue));
		sb.append(",AdditionalCost="+String.valueOf(AdditionalCost));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",Remarks="+Remarks);
		sb.append(",DepUpToSaleDate="+String.valueOf(DepUpToSaleDate));
		sb.append(",AccDepUpToSaleDate="+String.valueOf(AccDepUpToSaleDate));
		sb.append(",ChildAssetsCost="+String.valueOf(ChildAssetsCost));
		sb.append(",TotalCost="+String.valueOf(TotalCost));
		sb.append(",OrgAccDepBook1="+String.valueOf(OrgAccDepBook1));
		sb.append(",OrgAccDepBook2="+String.valueOf(OrgAccDepBook2));
		sb.append(",ProfitLossValueBook1="+String.valueOf(ProfitLossValueBook1));
		sb.append(",ProfitLossValueBook2="+String.valueOf(ProfitLossValueBook2));
		sb.append(",SoldDEPBook1="+String.valueOf(SoldDEPBook1));
		sb.append(",SoldDEPBook2="+String.valueOf(SoldDEPBook2));
		sb.append(",TotalDep="+String.valueOf(TotalDep));
		sb.append(",TotalDepBook1="+String.valueOf(TotalDepBook1));
		sb.append(",TotalDepBook2="+String.valueOf(TotalDepBook2));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetSaleDetailID);
        			
        			sb.append("|");
        		
        				sb.append(AssetSaleID);
        			
        			sb.append("|");
        		
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				if(OrgAccDepUpto == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepUpto);
            			}
            		
        			sb.append("|");
        		
        				if(OrgPhyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgPhyID);
            			}
            		
        			sb.append("|");
        		
        				if(SoldPhyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldPhyID);
            			}
            		
        			sb.append("|");
        		
        				if(SoldValue == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldValue);
            			}
            		
        			sb.append("|");
        		
        				if(OrgQty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgQty);
            			}
            		
        			sb.append("|");
        		
        				if(SoldQty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldQty);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDep);
            			}
            		
        			sb.append("|");
        		
        				if(SoldAccDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldAccDep);
            			}
            		
        			sb.append("|");
        		
        				if(OrgDEP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgDEP);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEP);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValue == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValue);
            			}
            		
        			sb.append("|");
        		
        				if(AdditionalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AdditionalCost);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(DepUpToSaleDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepUpToSaleDate);
            			}
            		
        			sb.append("|");
        		
        				if(AccDepUpToSaleDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccDepUpToSaleDate);
            			}
            		
        			sb.append("|");
        		
        				if(ChildAssetsCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ChildAssetsCost);
            			}
            		
        			sb.append("|");
        		
        				if(TotalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalCost);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDepBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepBook1);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDepBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepBook2);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValueBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValueBook1);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValueBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValueBook2);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEPBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEPBook1);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEPBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEPBook2);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDep);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDepBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDepBook1);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDepBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDepBook2);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.AssetSaleDetailID, other.AssetSaleDetailID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"AssetSaleDetail\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("AssetSaleDetail");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("AssetSaleDetail");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
            int rsTruncCountNumber_tDBOutput_1 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_1 = stmtTruncCount_tDBOutput_1.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_1 + "\"")) {
                    if(rsTruncCount_tDBOutput_1.next()) {
                        rsTruncCountNumber_tDBOutput_1 = rsTruncCount_tDBOutput_1.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_1+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_1.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_1 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_1+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_1 += rsTruncCountNumber_tDBOutput_1;
            }
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"AssetSaleDetailID\",\"AssetSaleID\",\"AssetID\",\"OrgAccDepUpto\",\"OrgPhyID\",\"SoldPhyID\",\"SoldValue\",\"OrgQty\",\"SoldQty\",\"OrgAccDep\",\"SoldAccDep\",\"OrgDEP\",\"SoldDEP\",\"ProfitLossValue\",\"AdditionalCost\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"Remarks\",\"DepUpToSaleDate\",\"AccDepUpToSaleDate\",\"ChildAssetsCost\",\"TotalCost\",\"OrgAccDepBook1\",\"OrgAccDepBook2\",\"ProfitLossValueBook1\",\"ProfitLossValueBook2\",\"SoldDEPBook1\",\"SoldDEPBook2\",\"TotalDep\",\"TotalDepBook1\",\"TotalDepBook2\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"AssetSaleDetail\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT FAMS.AssetSaleDetail.AssetSaleDetailID, 		FAMS.AssetSaleDetail.AssetSaleID, 		FAMS.AssetSaleDetail.AssetID, 		FAMS.AssetSaleDetail.OrgAccDepUpto, 		FAMS.AssetSaleDetail.OrgPhyID, 		FAMS.AssetSaleDetail.SoldPhyID, 		FAMS.AssetSaleDetail.SoldValue, 		FAMS.AssetSaleDetail.OrgQty, 		FAMS.AssetSaleDetail.SoldQty, 		FAMS.AssetSaleDetail.OrgAccDep, 		FAMS.AssetSaleDetail.SoldAccDep, 		FAMS.AssetSaleDetail.OrgDEP, 		FAMS.AssetSaleDetail.SoldDEP, 		FAMS.AssetSaleDetail.ProfitLossValue, 		FAMS.AssetSaleDetail.AdditionalCost, 		FAMS.AssetSaleDetail.CreatedBy, 		FAMS.AssetSaleDetail.CreatedDate, 		FAMS.AssetSaleDetail.ModifiedBy, 		FAMS.AssetSaleDetail.ModifiedDate, 		FAMS.AssetSaleDetail.Remarks, 		FAMS.AssetSaleDetail.DepUpToSaleDate, 		FAMS.AssetSaleDetail.AccDepUpToSaleDate, 		FAMS.AssetSaleDetail.ChildAssetsCost, 		FAMS.AssetSaleDetail.TotalCost, 		FAMS.AssetSaleDetail.OrgAccDepBook1, 		FAMS.AssetSaleDetail.OrgAccDepBook2, 		FAMS.AssetSaleDetail.ProfitLossValueBook1, 		FAMS.AssetSaleDetail.ProfitLossValueBook2, 		FAMS.AssetSaleDetail.SoldDEPBook1, 		FAMS.AssetSaleDetail.SoldDEPBook2, 		FAMS.AssetSaleDetail.TotalDep, 		FAMS.AssetSaleDetail.TotalDepBook1, 		FAMS.AssetSaleDetail.TotalDepBook2 FROM	FAMS.AssetSaleDetail\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSaleDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSaleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepUpto")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgPhyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldPhyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldValue")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgQty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldQty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldAccDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgDEP")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEP")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValue")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AdditionalCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepUpToSaleDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AccDepUpToSaleDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ChildAssetsCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValueBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValueBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEPBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEPBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDepBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDepBook2")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"AssetSaleDetail\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1); 
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT FAMS.AssetSaleDetail.AssetSaleDetailID,\n		FAMS.AssetSaleDetail.AssetSaleID,\n		FAMS.AssetSaleDetail.AssetID,\n		FA"
+"MS.AssetSaleDetail.OrgAccDepUpto,\n		FAMS.AssetSaleDetail.OrgPhyID,\n		FAMS.AssetSaleDetail.SoldPhyID,\n		FAMS.AssetSaleDet"
+"ail.SoldValue,\n		FAMS.AssetSaleDetail.OrgQty,\n		FAMS.AssetSaleDetail.SoldQty,\n		FAMS.AssetSaleDetail.OrgAccDep,\n		FAMS.A"
+"ssetSaleDetail.SoldAccDep,\n		FAMS.AssetSaleDetail.OrgDEP,\n		FAMS.AssetSaleDetail.SoldDEP,\n		FAMS.AssetSaleDetail.ProfitL"
+"ossValue,\n		FAMS.AssetSaleDetail.AdditionalCost,\n		FAMS.AssetSaleDetail.CreatedBy,\n		FAMS.AssetSaleDetail.CreatedDate,\n	"
+"	FAMS.AssetSaleDetail.ModifiedBy,\n		FAMS.AssetSaleDetail.ModifiedDate,\n		FAMS.AssetSaleDetail.Remarks,\n		FAMS.AssetSaleD"
+"etail.DepUpToSaleDate,\n		FAMS.AssetSaleDetail.AccDepUpToSaleDate,\n		FAMS.AssetSaleDetail.ChildAssetsCost,\n		FAMS.AssetSa"
+"leDetail.TotalCost,\n		FAMS.AssetSaleDetail.OrgAccDepBook1,\n		FAMS.AssetSaleDetail.OrgAccDepBook2,\n		FAMS.AssetSaleDetail"
+".ProfitLossValueBook1,\n		FAMS.AssetSaleDetail.ProfitLossValueBook2,\n		FAMS.AssetSaleDetail.SoldDEPBook1,\n		FAMS.AssetSal"
+"eDetail.SoldDEPBook2,\n		FAMS.AssetSaleDetail.TotalDep,\n		FAMS.AssetSaleDetail.TotalDepBook1,\n		FAMS.AssetSaleDetail.Tota"
+"lDepBook2\nFROM	FAMS.AssetSaleDetail";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.AssetSaleDetailID = 0;
							} else {
		                          
            row1.AssetSaleDetailID = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.AssetSaleID = 0;
							} else {
		                          
            row1.AssetSaleID = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.AssetID = 0;
							} else {
		                          
            row1.AssetID = rs_tDBInput_1.getInt(3);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.OrgAccDepUpto = null;
							} else {
										
			row1.OrgAccDepUpto = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 4);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.OrgPhyID = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(5);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OrgPhyID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.OrgPhyID = tmpContent_tDBInput_1;
                }
            } else {
                row1.OrgPhyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.SoldPhyID = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(6);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SoldPhyID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.SoldPhyID = tmpContent_tDBInput_1;
                }
            } else {
                row1.SoldPhyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.SoldValue = null;
							} else {
		                          
            row1.SoldValue = rs_tDBInput_1.getBigDecimal(7);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.OrgQty = null;
							} else {
		                          
            row1.OrgQty = rs_tDBInput_1.getInt(8);
            if(rs_tDBInput_1.wasNull()){
                    row1.OrgQty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.SoldQty = null;
							} else {
		                          
            row1.SoldQty = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    row1.SoldQty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row1.OrgAccDep = null;
							} else {
		                          
            row1.OrgAccDep = rs_tDBInput_1.getBigDecimal(10);
            if(rs_tDBInput_1.wasNull()){
                    row1.OrgAccDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row1.SoldAccDep = null;
							} else {
		                          
            row1.SoldAccDep = rs_tDBInput_1.getBigDecimal(11);
            if(rs_tDBInput_1.wasNull()){
                    row1.SoldAccDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row1.OrgDEP = null;
							} else {
		                          
            row1.OrgDEP = rs_tDBInput_1.getBigDecimal(12);
            if(rs_tDBInput_1.wasNull()){
                    row1.OrgDEP = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row1.SoldDEP = null;
							} else {
		                          
            row1.SoldDEP = rs_tDBInput_1.getBigDecimal(13);
            if(rs_tDBInput_1.wasNull()){
                    row1.SoldDEP = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row1.ProfitLossValue = null;
							} else {
		                          
            row1.ProfitLossValue = rs_tDBInput_1.getBigDecimal(14);
            if(rs_tDBInput_1.wasNull()){
                    row1.ProfitLossValue = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row1.AdditionalCost = null;
							} else {
		                          
            row1.AdditionalCost = rs_tDBInput_1.getBigDecimal(15);
            if(rs_tDBInput_1.wasNull()){
                    row1.AdditionalCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row1.CreatedBy = 0;
							} else {
		                          
            row1.CreatedBy = rs_tDBInput_1.getInt(16);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row1.CreatedDate = null;
							} else {
										
			row1.CreatedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 17);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row1.ModifiedBy = null;
							} else {
		                          
            row1.ModifiedBy = rs_tDBInput_1.getInt(18);
            if(rs_tDBInput_1.wasNull()){
                    row1.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row1.ModifiedDate = null;
							} else {
										
			row1.ModifiedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 19);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row1.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_1 = rs_tDBInput_1.getString(20);
            if(tmpContent_tDBInput_1 != null) {
            	if (talendToDBList_tDBInput_1 .contains(rsmd_tDBInput_1.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
            	} else {
                	row1.Remarks = tmpContent_tDBInput_1;
                }
            } else {
                row1.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row1.DepUpToSaleDate = null;
							} else {
		                          
            row1.DepUpToSaleDate = rs_tDBInput_1.getBigDecimal(21);
            if(rs_tDBInput_1.wasNull()){
                    row1.DepUpToSaleDate = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row1.AccDepUpToSaleDate = null;
							} else {
		                          
            row1.AccDepUpToSaleDate = rs_tDBInput_1.getBigDecimal(22);
            if(rs_tDBInput_1.wasNull()){
                    row1.AccDepUpToSaleDate = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row1.ChildAssetsCost = null;
							} else {
		                          
            row1.ChildAssetsCost = rs_tDBInput_1.getBigDecimal(23);
            if(rs_tDBInput_1.wasNull()){
                    row1.ChildAssetsCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row1.TotalCost = null;
							} else {
		                          
            row1.TotalCost = rs_tDBInput_1.getBigDecimal(24);
            if(rs_tDBInput_1.wasNull()){
                    row1.TotalCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row1.OrgAccDepBook1 = null;
							} else {
		                          
            row1.OrgAccDepBook1 = rs_tDBInput_1.getBigDecimal(25);
            if(rs_tDBInput_1.wasNull()){
                    row1.OrgAccDepBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row1.OrgAccDepBook2 = null;
							} else {
		                          
            row1.OrgAccDepBook2 = rs_tDBInput_1.getBigDecimal(26);
            if(rs_tDBInput_1.wasNull()){
                    row1.OrgAccDepBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row1.ProfitLossValueBook1 = null;
							} else {
		                          
            row1.ProfitLossValueBook1 = rs_tDBInput_1.getBigDecimal(27);
            if(rs_tDBInput_1.wasNull()){
                    row1.ProfitLossValueBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row1.ProfitLossValueBook2 = null;
							} else {
		                          
            row1.ProfitLossValueBook2 = rs_tDBInput_1.getBigDecimal(28);
            if(rs_tDBInput_1.wasNull()){
                    row1.ProfitLossValueBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row1.SoldDEPBook1 = null;
							} else {
		                          
            row1.SoldDEPBook1 = rs_tDBInput_1.getBigDecimal(29);
            if(rs_tDBInput_1.wasNull()){
                    row1.SoldDEPBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row1.SoldDEPBook2 = null;
							} else {
		                          
            row1.SoldDEPBook2 = rs_tDBInput_1.getBigDecimal(30);
            if(rs_tDBInput_1.wasNull()){
                    row1.SoldDEPBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row1.TotalDep = null;
							} else {
		                          
            row1.TotalDep = rs_tDBInput_1.getBigDecimal(31);
            if(rs_tDBInput_1.wasNull()){
                    row1.TotalDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row1.TotalDepBook1 = null;
							} else {
		                          
            row1.TotalDepBook1 = rs_tDBInput_1.getBigDecimal(32);
            if(rs_tDBInput_1.wasNull()){
                    row1.TotalDepBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row1.TotalDepBook2 = null;
							} else {
		                          
            row1.TotalDepBook2 = rs_tDBInput_1.getBigDecimal(33);
            if(rs_tDBInput_1.wasNull()){
                    row1.TotalDepBook2 = null;
            }
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					





 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"AssetSaleDetail\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, row1.AssetSaleDetailID);

                    pstmt_tDBOutput_1.setInt(2, row1.AssetSaleID);

                    pstmt_tDBOutput_1.setInt(3, row1.AssetID);

                    if(row1.OrgAccDepUpto != null) {
pstmt_tDBOutput_1.setTimestamp(4, new java.sql.Timestamp(row1.OrgAccDepUpto.getTime()));
} else {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row1.OrgPhyID == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, row1.OrgPhyID);
}

                    if(row1.SoldPhyID == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(6, row1.SoldPhyID);
}

                    pstmt_tDBOutput_1.setBigDecimal(7, row1.SoldValue);

                    if(row1.OrgQty == null) {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(8, row1.OrgQty);
}

                    if(row1.SoldQty == null) {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(9, row1.SoldQty);
}

                    pstmt_tDBOutput_1.setBigDecimal(10, row1.OrgAccDep);

                    pstmt_tDBOutput_1.setBigDecimal(11, row1.SoldAccDep);

                    pstmt_tDBOutput_1.setBigDecimal(12, row1.OrgDEP);

                    pstmt_tDBOutput_1.setBigDecimal(13, row1.SoldDEP);

                    pstmt_tDBOutput_1.setBigDecimal(14, row1.ProfitLossValue);

                    pstmt_tDBOutput_1.setBigDecimal(15, row1.AdditionalCost);

                    pstmt_tDBOutput_1.setInt(16, row1.CreatedBy);

                    if(row1.CreatedDate != null) {
pstmt_tDBOutput_1.setTimestamp(17, new java.sql.Timestamp(row1.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(17, java.sql.Types.TIMESTAMP);
}

                    if(row1.ModifiedBy == null) {
pstmt_tDBOutput_1.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(18, row1.ModifiedBy);
}

                    if(row1.ModifiedDate != null) {
pstmt_tDBOutput_1.setTimestamp(19, new java.sql.Timestamp(row1.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(19, java.sql.Types.TIMESTAMP);
}

                    if(row1.Remarks == null) {
pstmt_tDBOutput_1.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(20, row1.Remarks);
}

                    pstmt_tDBOutput_1.setBigDecimal(21, row1.DepUpToSaleDate);

                    pstmt_tDBOutput_1.setBigDecimal(22, row1.AccDepUpToSaleDate);

                    pstmt_tDBOutput_1.setBigDecimal(23, row1.ChildAssetsCost);

                    pstmt_tDBOutput_1.setBigDecimal(24, row1.TotalCost);

                    pstmt_tDBOutput_1.setBigDecimal(25, row1.OrgAccDepBook1);

                    pstmt_tDBOutput_1.setBigDecimal(26, row1.OrgAccDepBook2);

                    pstmt_tDBOutput_1.setBigDecimal(27, row1.ProfitLossValueBook1);

                    pstmt_tDBOutput_1.setBigDecimal(28, row1.ProfitLossValueBook2);

                    pstmt_tDBOutput_1.setBigDecimal(29, row1.SoldDEPBook1);

                    pstmt_tDBOutput_1.setBigDecimal(30, row1.SoldDEPBook2);

                    pstmt_tDBOutput_1.setBigDecimal(31, row1.TotalDep);

                    pstmt_tDBOutput_1.setBigDecimal(32, row1.TotalDepBook1);

                    pstmt_tDBOutput_1.setBigDecimal(33, row1.TotalDepBook2);

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"AssetSaleDetail\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetSaleDetail\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];

	
			    public int AssetSaleDetailID;

				public int getAssetSaleDetailID () {
					return this.AssetSaleDetailID;
				}

				public Boolean AssetSaleDetailIDIsNullable(){
				    return false;
				}
				public Boolean AssetSaleDetailIDIsKey(){
				    return false;
				}
				public Integer AssetSaleDetailIDLength(){
				    return 10;
				}
				public Integer AssetSaleDetailIDPrecision(){
				    return 0;
				}
				public String AssetSaleDetailIDDefault(){
				
					return null;
				
				}
				public String AssetSaleDetailIDComment(){
				
				    return "";
				
				}
				public String AssetSaleDetailIDPattern(){
				
					return "";
				
				}
				public String AssetSaleDetailIDOriginalDbColumnName(){
				
					return "AssetSaleDetailID";
				
				}

				
			    public int AssetSaleID;

				public int getAssetSaleID () {
					return this.AssetSaleID;
				}

				public Boolean AssetSaleIDIsNullable(){
				    return false;
				}
				public Boolean AssetSaleIDIsKey(){
				    return false;
				}
				public Integer AssetSaleIDLength(){
				    return 10;
				}
				public Integer AssetSaleIDPrecision(){
				    return 0;
				}
				public String AssetSaleIDDefault(){
				
					return null;
				
				}
				public String AssetSaleIDComment(){
				
				    return "";
				
				}
				public String AssetSaleIDPattern(){
				
					return "";
				
				}
				public String AssetSaleIDOriginalDbColumnName(){
				
					return "AssetSaleID";
				
				}

				
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public java.util.Date OrgAccDepUpto;

				public java.util.Date getOrgAccDepUpto () {
					return this.OrgAccDepUpto;
				}

				public Boolean OrgAccDepUptoIsNullable(){
				    return true;
				}
				public Boolean OrgAccDepUptoIsKey(){
				    return false;
				}
				public Integer OrgAccDepUptoLength(){
				    return 23;
				}
				public Integer OrgAccDepUptoPrecision(){
				    return 3;
				}
				public String OrgAccDepUptoDefault(){
				
					return null;
				
				}
				public String OrgAccDepUptoComment(){
				
				    return "";
				
				}
				public String OrgAccDepUptoPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String OrgAccDepUptoOriginalDbColumnName(){
				
					return "OrgAccDepUpto";
				
				}

				
			    public String OrgPhyID;

				public String getOrgPhyID () {
					return this.OrgPhyID;
				}

				public Boolean OrgPhyIDIsNullable(){
				    return true;
				}
				public Boolean OrgPhyIDIsKey(){
				    return false;
				}
				public Integer OrgPhyIDLength(){
				    return 50;
				}
				public Integer OrgPhyIDPrecision(){
				    return 0;
				}
				public String OrgPhyIDDefault(){
				
					return null;
				
				}
				public String OrgPhyIDComment(){
				
				    return "";
				
				}
				public String OrgPhyIDPattern(){
				
					return "";
				
				}
				public String OrgPhyIDOriginalDbColumnName(){
				
					return "OrgPhyID";
				
				}

				
			    public String SoldPhyID;

				public String getSoldPhyID () {
					return this.SoldPhyID;
				}

				public Boolean SoldPhyIDIsNullable(){
				    return true;
				}
				public Boolean SoldPhyIDIsKey(){
				    return false;
				}
				public Integer SoldPhyIDLength(){
				    return 50;
				}
				public Integer SoldPhyIDPrecision(){
				    return 0;
				}
				public String SoldPhyIDDefault(){
				
					return null;
				
				}
				public String SoldPhyIDComment(){
				
				    return "";
				
				}
				public String SoldPhyIDPattern(){
				
					return "";
				
				}
				public String SoldPhyIDOriginalDbColumnName(){
				
					return "SoldPhyID";
				
				}

				
			    public BigDecimal SoldValue;

				public BigDecimal getSoldValue () {
					return this.SoldValue;
				}

				public Boolean SoldValueIsNullable(){
				    return false;
				}
				public Boolean SoldValueIsKey(){
				    return false;
				}
				public Integer SoldValueLength(){
				    return 12;
				}
				public Integer SoldValuePrecision(){
				    return 2;
				}
				public String SoldValueDefault(){
				
					return null;
				
				}
				public String SoldValueComment(){
				
				    return "";
				
				}
				public String SoldValuePattern(){
				
					return "";
				
				}
				public String SoldValueOriginalDbColumnName(){
				
					return "SoldValue";
				
				}

				
			    public Integer OrgQty;

				public Integer getOrgQty () {
					return this.OrgQty;
				}

				public Boolean OrgQtyIsNullable(){
				    return true;
				}
				public Boolean OrgQtyIsKey(){
				    return false;
				}
				public Integer OrgQtyLength(){
				    return 10;
				}
				public Integer OrgQtyPrecision(){
				    return 0;
				}
				public String OrgQtyDefault(){
				
					return null;
				
				}
				public String OrgQtyComment(){
				
				    return "";
				
				}
				public String OrgQtyPattern(){
				
					return "";
				
				}
				public String OrgQtyOriginalDbColumnName(){
				
					return "OrgQty";
				
				}

				
			    public Integer SoldQty;

				public Integer getSoldQty () {
					return this.SoldQty;
				}

				public Boolean SoldQtyIsNullable(){
				    return true;
				}
				public Boolean SoldQtyIsKey(){
				    return false;
				}
				public Integer SoldQtyLength(){
				    return 10;
				}
				public Integer SoldQtyPrecision(){
				    return 0;
				}
				public String SoldQtyDefault(){
				
					return null;
				
				}
				public String SoldQtyComment(){
				
				    return "";
				
				}
				public String SoldQtyPattern(){
				
					return "";
				
				}
				public String SoldQtyOriginalDbColumnName(){
				
					return "SoldQty";
				
				}

				
			    public BigDecimal OrgAccDep;

				public BigDecimal getOrgAccDep () {
					return this.OrgAccDep;
				}

				public Boolean OrgAccDepIsNullable(){
				    return true;
				}
				public Boolean OrgAccDepIsKey(){
				    return false;
				}
				public Integer OrgAccDepLength(){
				    return 12;
				}
				public Integer OrgAccDepPrecision(){
				    return 2;
				}
				public String OrgAccDepDefault(){
				
					return null;
				
				}
				public String OrgAccDepComment(){
				
				    return "";
				
				}
				public String OrgAccDepPattern(){
				
					return "";
				
				}
				public String OrgAccDepOriginalDbColumnName(){
				
					return "OrgAccDep";
				
				}

				
			    public BigDecimal SoldAccDep;

				public BigDecimal getSoldAccDep () {
					return this.SoldAccDep;
				}

				public Boolean SoldAccDepIsNullable(){
				    return true;
				}
				public Boolean SoldAccDepIsKey(){
				    return false;
				}
				public Integer SoldAccDepLength(){
				    return 12;
				}
				public Integer SoldAccDepPrecision(){
				    return 2;
				}
				public String SoldAccDepDefault(){
				
					return null;
				
				}
				public String SoldAccDepComment(){
				
				    return "";
				
				}
				public String SoldAccDepPattern(){
				
					return "";
				
				}
				public String SoldAccDepOriginalDbColumnName(){
				
					return "SoldAccDep";
				
				}

				
			    public BigDecimal OrgDEP;

				public BigDecimal getOrgDEP () {
					return this.OrgDEP;
				}

				public Boolean OrgDEPIsNullable(){
				    return true;
				}
				public Boolean OrgDEPIsKey(){
				    return false;
				}
				public Integer OrgDEPLength(){
				    return 12;
				}
				public Integer OrgDEPPrecision(){
				    return 2;
				}
				public String OrgDEPDefault(){
				
					return null;
				
				}
				public String OrgDEPComment(){
				
				    return "";
				
				}
				public String OrgDEPPattern(){
				
					return "";
				
				}
				public String OrgDEPOriginalDbColumnName(){
				
					return "OrgDEP";
				
				}

				
			    public BigDecimal SoldDEP;

				public BigDecimal getSoldDEP () {
					return this.SoldDEP;
				}

				public Boolean SoldDEPIsNullable(){
				    return true;
				}
				public Boolean SoldDEPIsKey(){
				    return false;
				}
				public Integer SoldDEPLength(){
				    return 12;
				}
				public Integer SoldDEPPrecision(){
				    return 2;
				}
				public String SoldDEPDefault(){
				
					return null;
				
				}
				public String SoldDEPComment(){
				
				    return "";
				
				}
				public String SoldDEPPattern(){
				
					return "";
				
				}
				public String SoldDEPOriginalDbColumnName(){
				
					return "SoldDEP";
				
				}

				
			    public BigDecimal ProfitLossValue;

				public BigDecimal getProfitLossValue () {
					return this.ProfitLossValue;
				}

				public Boolean ProfitLossValueIsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueIsKey(){
				    return false;
				}
				public Integer ProfitLossValueLength(){
				    return 12;
				}
				public Integer ProfitLossValuePrecision(){
				    return 2;
				}
				public String ProfitLossValueDefault(){
				
					return null;
				
				}
				public String ProfitLossValueComment(){
				
				    return "";
				
				}
				public String ProfitLossValuePattern(){
				
					return "";
				
				}
				public String ProfitLossValueOriginalDbColumnName(){
				
					return "ProfitLossValue";
				
				}

				
			    public BigDecimal AdditionalCost;

				public BigDecimal getAdditionalCost () {
					return this.AdditionalCost;
				}

				public Boolean AdditionalCostIsNullable(){
				    return true;
				}
				public Boolean AdditionalCostIsKey(){
				    return false;
				}
				public Integer AdditionalCostLength(){
				    return 12;
				}
				public Integer AdditionalCostPrecision(){
				    return 2;
				}
				public String AdditionalCostDefault(){
				
					return null;
				
				}
				public String AdditionalCostComment(){
				
				    return "";
				
				}
				public String AdditionalCostPattern(){
				
					return "";
				
				}
				public String AdditionalCostOriginalDbColumnName(){
				
					return "AdditionalCost";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 200;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public BigDecimal DepUpToSaleDate;

				public BigDecimal getDepUpToSaleDate () {
					return this.DepUpToSaleDate;
				}

				public Boolean DepUpToSaleDateIsNullable(){
				    return true;
				}
				public Boolean DepUpToSaleDateIsKey(){
				    return false;
				}
				public Integer DepUpToSaleDateLength(){
				    return 12;
				}
				public Integer DepUpToSaleDatePrecision(){
				    return 2;
				}
				public String DepUpToSaleDateDefault(){
				
					return null;
				
				}
				public String DepUpToSaleDateComment(){
				
				    return "";
				
				}
				public String DepUpToSaleDatePattern(){
				
					return "";
				
				}
				public String DepUpToSaleDateOriginalDbColumnName(){
				
					return "DepUpToSaleDate";
				
				}

				
			    public BigDecimal AccDepUpToSaleDate;

				public BigDecimal getAccDepUpToSaleDate () {
					return this.AccDepUpToSaleDate;
				}

				public Boolean AccDepUpToSaleDateIsNullable(){
				    return true;
				}
				public Boolean AccDepUpToSaleDateIsKey(){
				    return false;
				}
				public Integer AccDepUpToSaleDateLength(){
				    return 12;
				}
				public Integer AccDepUpToSaleDatePrecision(){
				    return 2;
				}
				public String AccDepUpToSaleDateDefault(){
				
					return null;
				
				}
				public String AccDepUpToSaleDateComment(){
				
				    return "";
				
				}
				public String AccDepUpToSaleDatePattern(){
				
					return "";
				
				}
				public String AccDepUpToSaleDateOriginalDbColumnName(){
				
					return "AccDepUpToSaleDate";
				
				}

				
			    public BigDecimal ChildAssetsCost;

				public BigDecimal getChildAssetsCost () {
					return this.ChildAssetsCost;
				}

				public Boolean ChildAssetsCostIsNullable(){
				    return true;
				}
				public Boolean ChildAssetsCostIsKey(){
				    return false;
				}
				public Integer ChildAssetsCostLength(){
				    return 12;
				}
				public Integer ChildAssetsCostPrecision(){
				    return 2;
				}
				public String ChildAssetsCostDefault(){
				
					return null;
				
				}
				public String ChildAssetsCostComment(){
				
				    return "";
				
				}
				public String ChildAssetsCostPattern(){
				
					return "";
				
				}
				public String ChildAssetsCostOriginalDbColumnName(){
				
					return "ChildAssetsCost";
				
				}

				
			    public BigDecimal TotalCost;

				public BigDecimal getTotalCost () {
					return this.TotalCost;
				}

				public Boolean TotalCostIsNullable(){
				    return true;
				}
				public Boolean TotalCostIsKey(){
				    return false;
				}
				public Integer TotalCostLength(){
				    return 12;
				}
				public Integer TotalCostPrecision(){
				    return 2;
				}
				public String TotalCostDefault(){
				
					return null;
				
				}
				public String TotalCostComment(){
				
				    return "";
				
				}
				public String TotalCostPattern(){
				
					return "";
				
				}
				public String TotalCostOriginalDbColumnName(){
				
					return "TotalCost";
				
				}

				
			    public BigDecimal OrgAccDepBook1;

				public BigDecimal getOrgAccDepBook1 () {
					return this.OrgAccDepBook1;
				}

				public Boolean OrgAccDepBook1IsNullable(){
				    return true;
				}
				public Boolean OrgAccDepBook1IsKey(){
				    return false;
				}
				public Integer OrgAccDepBook1Length(){
				    return 12;
				}
				public Integer OrgAccDepBook1Precision(){
				    return 2;
				}
				public String OrgAccDepBook1Default(){
				
					return null;
				
				}
				public String OrgAccDepBook1Comment(){
				
				    return "";
				
				}
				public String OrgAccDepBook1Pattern(){
				
					return "";
				
				}
				public String OrgAccDepBook1OriginalDbColumnName(){
				
					return "OrgAccDepBook1";
				
				}

				
			    public BigDecimal OrgAccDepBook2;

				public BigDecimal getOrgAccDepBook2 () {
					return this.OrgAccDepBook2;
				}

				public Boolean OrgAccDepBook2IsNullable(){
				    return true;
				}
				public Boolean OrgAccDepBook2IsKey(){
				    return false;
				}
				public Integer OrgAccDepBook2Length(){
				    return 12;
				}
				public Integer OrgAccDepBook2Precision(){
				    return 2;
				}
				public String OrgAccDepBook2Default(){
				
					return null;
				
				}
				public String OrgAccDepBook2Comment(){
				
				    return "";
				
				}
				public String OrgAccDepBook2Pattern(){
				
					return "";
				
				}
				public String OrgAccDepBook2OriginalDbColumnName(){
				
					return "OrgAccDepBook2";
				
				}

				
			    public BigDecimal ProfitLossValueBook1;

				public BigDecimal getProfitLossValueBook1 () {
					return this.ProfitLossValueBook1;
				}

				public Boolean ProfitLossValueBook1IsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueBook1IsKey(){
				    return false;
				}
				public Integer ProfitLossValueBook1Length(){
				    return 12;
				}
				public Integer ProfitLossValueBook1Precision(){
				    return 2;
				}
				public String ProfitLossValueBook1Default(){
				
					return null;
				
				}
				public String ProfitLossValueBook1Comment(){
				
				    return "";
				
				}
				public String ProfitLossValueBook1Pattern(){
				
					return "";
				
				}
				public String ProfitLossValueBook1OriginalDbColumnName(){
				
					return "ProfitLossValueBook1";
				
				}

				
			    public BigDecimal ProfitLossValueBook2;

				public BigDecimal getProfitLossValueBook2 () {
					return this.ProfitLossValueBook2;
				}

				public Boolean ProfitLossValueBook2IsNullable(){
				    return true;
				}
				public Boolean ProfitLossValueBook2IsKey(){
				    return false;
				}
				public Integer ProfitLossValueBook2Length(){
				    return 12;
				}
				public Integer ProfitLossValueBook2Precision(){
				    return 2;
				}
				public String ProfitLossValueBook2Default(){
				
					return null;
				
				}
				public String ProfitLossValueBook2Comment(){
				
				    return "";
				
				}
				public String ProfitLossValueBook2Pattern(){
				
					return "";
				
				}
				public String ProfitLossValueBook2OriginalDbColumnName(){
				
					return "ProfitLossValueBook2";
				
				}

				
			    public BigDecimal SoldDEPBook1;

				public BigDecimal getSoldDEPBook1 () {
					return this.SoldDEPBook1;
				}

				public Boolean SoldDEPBook1IsNullable(){
				    return true;
				}
				public Boolean SoldDEPBook1IsKey(){
				    return false;
				}
				public Integer SoldDEPBook1Length(){
				    return 12;
				}
				public Integer SoldDEPBook1Precision(){
				    return 2;
				}
				public String SoldDEPBook1Default(){
				
					return null;
				
				}
				public String SoldDEPBook1Comment(){
				
				    return "";
				
				}
				public String SoldDEPBook1Pattern(){
				
					return "";
				
				}
				public String SoldDEPBook1OriginalDbColumnName(){
				
					return "SoldDEPBook1";
				
				}

				
			    public BigDecimal SoldDEPBook2;

				public BigDecimal getSoldDEPBook2 () {
					return this.SoldDEPBook2;
				}

				public Boolean SoldDEPBook2IsNullable(){
				    return true;
				}
				public Boolean SoldDEPBook2IsKey(){
				    return false;
				}
				public Integer SoldDEPBook2Length(){
				    return 12;
				}
				public Integer SoldDEPBook2Precision(){
				    return 2;
				}
				public String SoldDEPBook2Default(){
				
					return null;
				
				}
				public String SoldDEPBook2Comment(){
				
				    return "";
				
				}
				public String SoldDEPBook2Pattern(){
				
					return "";
				
				}
				public String SoldDEPBook2OriginalDbColumnName(){
				
					return "SoldDEPBook2";
				
				}

				
			    public BigDecimal TotalDep;

				public BigDecimal getTotalDep () {
					return this.TotalDep;
				}

				public Boolean TotalDepIsNullable(){
				    return true;
				}
				public Boolean TotalDepIsKey(){
				    return false;
				}
				public Integer TotalDepLength(){
				    return 12;
				}
				public Integer TotalDepPrecision(){
				    return 2;
				}
				public String TotalDepDefault(){
				
					return null;
				
				}
				public String TotalDepComment(){
				
				    return "";
				
				}
				public String TotalDepPattern(){
				
					return "";
				
				}
				public String TotalDepOriginalDbColumnName(){
				
					return "TotalDep";
				
				}

				
			    public BigDecimal TotalDepBook1;

				public BigDecimal getTotalDepBook1 () {
					return this.TotalDepBook1;
				}

				public Boolean TotalDepBook1IsNullable(){
				    return true;
				}
				public Boolean TotalDepBook1IsKey(){
				    return false;
				}
				public Integer TotalDepBook1Length(){
				    return 12;
				}
				public Integer TotalDepBook1Precision(){
				    return 2;
				}
				public String TotalDepBook1Default(){
				
					return null;
				
				}
				public String TotalDepBook1Comment(){
				
				    return "";
				
				}
				public String TotalDepBook1Pattern(){
				
					return "";
				
				}
				public String TotalDepBook1OriginalDbColumnName(){
				
					return "TotalDepBook1";
				
				}

				
			    public BigDecimal TotalDepBook2;

				public BigDecimal getTotalDepBook2 () {
					return this.TotalDepBook2;
				}

				public Boolean TotalDepBook2IsNullable(){
				    return true;
				}
				public Boolean TotalDepBook2IsKey(){
				    return false;
				}
				public Integer TotalDepBook2Length(){
				    return 12;
				}
				public Integer TotalDepBook2Precision(){
				    return 2;
				}
				public String TotalDepBook2Default(){
				
					return null;
				
				}
				public String TotalDepBook2Comment(){
				
				    return "";
				
				}
				public String TotalDepBook2Pattern(){
				
					return "";
				
				}
				public String TotalDepBook2OriginalDbColumnName(){
				
					return "TotalDepBook2";
				
				}

				
			    public String OperationType;

				public String getOperationType () {
					return this.OperationType;
				}

				public Boolean OperationTypeIsNullable(){
				    return true;
				}
				public Boolean OperationTypeIsKey(){
				    return false;
				}
				public Integer OperationTypeLength(){
				    return 10;
				}
				public Integer OperationTypePrecision(){
				    return 0;
				}
				public String OperationTypeDefault(){
				
					return null;
				
				}
				public String OperationTypeComment(){
				
				    return "";
				
				}
				public String OperationTypePattern(){
				
					return "";
				
				}
				public String OperationTypeOriginalDbColumnName(){
				
					return "OperationType";
				
				}

				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleDetailID = dis.readInt();
					
			        this.AssetSaleID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.OrgAccDepUpto = readDate(dis);
					
					this.OrgPhyID = readString(dis);
					
					this.SoldPhyID = readString(dis);
					
						this.SoldValue = (BigDecimal) dis.readObject();
					
						this.OrgQty = readInteger(dis);
					
						this.SoldQty = readInteger(dis);
					
						this.OrgAccDep = (BigDecimal) dis.readObject();
					
						this.SoldAccDep = (BigDecimal) dis.readObject();
					
						this.OrgDEP = (BigDecimal) dis.readObject();
					
						this.SoldDEP = (BigDecimal) dis.readObject();
					
						this.ProfitLossValue = (BigDecimal) dis.readObject();
					
						this.AdditionalCost = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.Remarks = readString(dis);
					
						this.DepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.AccDepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.ChildAssetsCost = (BigDecimal) dis.readObject();
					
						this.TotalCost = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook1 = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook2 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook1 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook2 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook1 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook2 = (BigDecimal) dis.readObject();
					
						this.TotalDep = (BigDecimal) dis.readObject();
					
						this.TotalDepBook1 = (BigDecimal) dis.readObject();
					
						this.TotalDepBook2 = (BigDecimal) dis.readObject();
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleDetailID = dis.readInt();
					
			        this.AssetSaleID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.OrgAccDepUpto = readDate(dis);
					
					this.OrgPhyID = readString(dis);
					
					this.SoldPhyID = readString(dis);
					
						this.SoldValue = (BigDecimal) dis.readObject();
					
						this.OrgQty = readInteger(dis);
					
						this.SoldQty = readInteger(dis);
					
						this.OrgAccDep = (BigDecimal) dis.readObject();
					
						this.SoldAccDep = (BigDecimal) dis.readObject();
					
						this.OrgDEP = (BigDecimal) dis.readObject();
					
						this.SoldDEP = (BigDecimal) dis.readObject();
					
						this.ProfitLossValue = (BigDecimal) dis.readObject();
					
						this.AdditionalCost = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.Remarks = readString(dis);
					
						this.DepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.AccDepUpToSaleDate = (BigDecimal) dis.readObject();
					
						this.ChildAssetsCost = (BigDecimal) dis.readObject();
					
						this.TotalCost = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook1 = (BigDecimal) dis.readObject();
					
						this.OrgAccDepBook2 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook1 = (BigDecimal) dis.readObject();
					
						this.ProfitLossValueBook2 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook1 = (BigDecimal) dis.readObject();
					
						this.SoldDEPBook2 = (BigDecimal) dis.readObject();
					
						this.TotalDep = (BigDecimal) dis.readObject();
					
						this.TotalDepBook1 = (BigDecimal) dis.readObject();
					
						this.TotalDepBook2 = (BigDecimal) dis.readObject();
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleDetailID);
					
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// java.util.Date
				
						writeDate(this.OrgAccDepUpto,dos);
					
					// String
				
						writeString(this.OrgPhyID,dos);
					
					// String
				
						writeString(this.SoldPhyID,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldValue);
					
					// Integer
				
						writeInteger(this.OrgQty,dos);
					
					// Integer
				
						writeInteger(this.SoldQty,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValue);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AdditionalCost);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.DepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AccDepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ChildAssetsCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook2);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleDetailID);
					
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// java.util.Date
				
						writeDate(this.OrgAccDepUpto,dos);
					
					// String
				
						writeString(this.OrgPhyID,dos);
					
					// String
				
						writeString(this.SoldPhyID,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldValue);
					
					// Integer
				
						writeInteger(this.OrgQty,dos);
					
					// Integer
				
						writeInteger(this.SoldQty,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldAccDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEP);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValue);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AdditionalCost);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.DepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.AccDepUpToSaleDate);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ChildAssetsCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalCost);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.OrgAccDepBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ProfitLossValueBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.SoldDEPBook2);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDep);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook1);
					
					// BigDecimal
				
       			    	dos.writeObject(this.TotalDepBook2);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetSaleDetailID="+String.valueOf(AssetSaleDetailID));
		sb.append(",AssetSaleID="+String.valueOf(AssetSaleID));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",OrgAccDepUpto="+String.valueOf(OrgAccDepUpto));
		sb.append(",OrgPhyID="+OrgPhyID);
		sb.append(",SoldPhyID="+SoldPhyID);
		sb.append(",SoldValue="+String.valueOf(SoldValue));
		sb.append(",OrgQty="+String.valueOf(OrgQty));
		sb.append(",SoldQty="+String.valueOf(SoldQty));
		sb.append(",OrgAccDep="+String.valueOf(OrgAccDep));
		sb.append(",SoldAccDep="+String.valueOf(SoldAccDep));
		sb.append(",OrgDEP="+String.valueOf(OrgDEP));
		sb.append(",SoldDEP="+String.valueOf(SoldDEP));
		sb.append(",ProfitLossValue="+String.valueOf(ProfitLossValue));
		sb.append(",AdditionalCost="+String.valueOf(AdditionalCost));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",Remarks="+Remarks);
		sb.append(",DepUpToSaleDate="+String.valueOf(DepUpToSaleDate));
		sb.append(",AccDepUpToSaleDate="+String.valueOf(AccDepUpToSaleDate));
		sb.append(",ChildAssetsCost="+String.valueOf(ChildAssetsCost));
		sb.append(",TotalCost="+String.valueOf(TotalCost));
		sb.append(",OrgAccDepBook1="+String.valueOf(OrgAccDepBook1));
		sb.append(",OrgAccDepBook2="+String.valueOf(OrgAccDepBook2));
		sb.append(",ProfitLossValueBook1="+String.valueOf(ProfitLossValueBook1));
		sb.append(",ProfitLossValueBook2="+String.valueOf(ProfitLossValueBook2));
		sb.append(",SoldDEPBook1="+String.valueOf(SoldDEPBook1));
		sb.append(",SoldDEPBook2="+String.valueOf(SoldDEPBook2));
		sb.append(",TotalDep="+String.valueOf(TotalDep));
		sb.append(",TotalDepBook1="+String.valueOf(TotalDepBook1));
		sb.append(",TotalDepBook2="+String.valueOf(TotalDepBook2));
		sb.append(",OperationType="+OperationType);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetSaleDetailID);
        			
        			sb.append("|");
        		
        				sb.append(AssetSaleID);
        			
        			sb.append("|");
        		
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				if(OrgAccDepUpto == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepUpto);
            			}
            		
        			sb.append("|");
        		
        				if(OrgPhyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgPhyID);
            			}
            		
        			sb.append("|");
        		
        				if(SoldPhyID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldPhyID);
            			}
            		
        			sb.append("|");
        		
        				if(SoldValue == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldValue);
            			}
            		
        			sb.append("|");
        		
        				if(OrgQty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgQty);
            			}
            		
        			sb.append("|");
        		
        				if(SoldQty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldQty);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDep);
            			}
            		
        			sb.append("|");
        		
        				if(SoldAccDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldAccDep);
            			}
            		
        			sb.append("|");
        		
        				if(OrgDEP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgDEP);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEP);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValue == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValue);
            			}
            		
        			sb.append("|");
        		
        				if(AdditionalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AdditionalCost);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(DepUpToSaleDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DepUpToSaleDate);
            			}
            		
        			sb.append("|");
        		
        				if(AccDepUpToSaleDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AccDepUpToSaleDate);
            			}
            		
        			sb.append("|");
        		
        				if(ChildAssetsCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ChildAssetsCost);
            			}
            		
        			sb.append("|");
        		
        				if(TotalCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalCost);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDepBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepBook1);
            			}
            		
        			sb.append("|");
        		
        				if(OrgAccDepBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgAccDepBook2);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValueBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValueBook1);
            			}
            		
        			sb.append("|");
        		
        				if(ProfitLossValueBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ProfitLossValueBook2);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEPBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEPBook1);
            			}
            		
        			sb.append("|");
        		
        				if(SoldDEPBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SoldDEPBook2);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDep == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDep);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDepBook1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDepBook1);
            			}
            		
        			sb.append("|");
        		
        				if(TotalDepBook2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TotalDepBook2);
            			}
            		
        			sb.append("|");
        		
        				if(OperationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OperationType);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"AssetSaleDetail_Log\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("AssetSaleDetail_Log");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("AssetSaleDetail_Log");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
            int rsTruncCountNumber_tDBOutput_2 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_2 = stmtTruncCount_tDBOutput_2.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_2 + "\"")) {
                    if(rsTruncCount_tDBOutput_2.next()) {
                        rsTruncCountNumber_tDBOutput_2 = rsTruncCount_tDBOutput_2.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_2.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_2 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_2+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_2 += rsTruncCountNumber_tDBOutput_2;
            }
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"AssetSaleDetailID\",\"AssetSaleID\",\"AssetID\",\"OrgAccDepUpto\",\"OrgPhyID\",\"SoldPhyID\",\"SoldValue\",\"OrgQty\",\"SoldQty\",\"OrgAccDep\",\"SoldAccDep\",\"OrgDEP\",\"SoldDEP\",\"ProfitLossValue\",\"AdditionalCost\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"Remarks\",\"DepUpToSaleDate\",\"AccDepUpToSaleDate\",\"ChildAssetsCost\",\"TotalCost\",\"OrgAccDepBook1\",\"OrgAccDepBook2\",\"ProfitLossValueBook1\",\"ProfitLossValueBook2\",\"SoldDEPBook1\",\"SoldDEPBook2\",\"TotalDep\",\"TotalDepBook1\",\"TotalDepBook2\",\"OperationType\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"AssetSaleDetail_Log\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT FAMS.AssetSaleDetail_Log.AssetSaleDetailID, 		FAMS.AssetSaleDetail_Log.AssetSaleID, 		FAMS.AssetSaleDetail_Log.AssetID, 		FAMS.AssetSaleDetail_Log.OrgAccDepUpto, 		FAMS.AssetSaleDetail_Log.OrgPhyID, 		FAMS.AssetSaleDetail_Log.SoldPhyID, 		FAMS.AssetSaleDetail_Log.SoldValue, 		FAMS.AssetSaleDetail_Log.OrgQty, 		FAMS.AssetSaleDetail_Log.SoldQty, 		FAMS.AssetSaleDetail_Log.OrgAccDep, 		FAMS.AssetSaleDetail_Log.SoldAccDep, 		FAMS.AssetSaleDetail_Log.OrgDEP, 		FAMS.AssetSaleDetail_Log.SoldDEP, 		FAMS.AssetSaleDetail_Log.ProfitLossValue, 		FAMS.AssetSaleDetail_Log.AdditionalCost, 		FAMS.AssetSaleDetail_Log.CreatedBy, 		FAMS.AssetSaleDetail_Log.CreatedDate, 		FAMS.AssetSaleDetail_Log.ModifiedBy, 		FAMS.AssetSaleDetail_Log.ModifiedDate, 		FAMS.AssetSaleDetail_Log.Remarks, 		FAMS.AssetSaleDetail_Log.DepUpToSaleDate, 		FAMS.AssetSaleDetail_Log.AccDepUpToSaleDate, 		FAMS.AssetSaleDetail_Log.ChildAssetsCost, 		FAMS.AssetSaleDetail_Log.TotalCost, 		FAMS.AssetSaleDetail_Log.OrgAccDepBook1, 		FAMS.AssetSaleDetail_Log.OrgAccDepBook2, 		FAMS.AssetSaleDetail_Log.ProfitLossValueBook1, 		FAMS.AssetSaleDetail_Log.ProfitLossValueBook2, 		FAMS.AssetSaleDetail_Log.SoldDEPBook1, 		FAMS.AssetSaleDetail_Log.SoldDEPBook2, 		FAMS.AssetSaleDetail_Log.TotalDep, 		FAMS.AssetSaleDetail_Log.TotalDepBook1, 		FAMS.AssetSaleDetail_Log.TotalDepBook2, 		FAMS.AssetSaleDetail_Log.OperationType FROM	FAMS.AssetSaleDetail_Log\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSaleDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSaleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepUpto")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgPhyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldPhyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldValue")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgQty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldQty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldAccDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgDEP")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEP")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValue")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AdditionalCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DepUpToSaleDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AccDepUpToSaleDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ChildAssetsCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalCost")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgAccDepBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValueBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ProfitLossValueBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEPBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SoldDEPBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDep")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDepBook1")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TotalDepBook2")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OperationType")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"AssetSaleDetail_Log\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2); 
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT FAMS.AssetSaleDetail_Log.AssetSaleDetailID,\n		FAMS.AssetSaleDetail_Log.AssetSaleID,\n		FAMS.AssetSaleDetail_Log.A"
+"ssetID,\n		FAMS.AssetSaleDetail_Log.OrgAccDepUpto,\n		FAMS.AssetSaleDetail_Log.OrgPhyID,\n		FAMS.AssetSaleDetail_Log.SoldPh"
+"yID,\n		FAMS.AssetSaleDetail_Log.SoldValue,\n		FAMS.AssetSaleDetail_Log.OrgQty,\n		FAMS.AssetSaleDetail_Log.SoldQty,\n		FAMS"
+".AssetSaleDetail_Log.OrgAccDep,\n		FAMS.AssetSaleDetail_Log.SoldAccDep,\n		FAMS.AssetSaleDetail_Log.OrgDEP,\n		FAMS.AssetSa"
+"leDetail_Log.SoldDEP,\n		FAMS.AssetSaleDetail_Log.ProfitLossValue,\n		FAMS.AssetSaleDetail_Log.AdditionalCost,\n		FAMS.Asse"
+"tSaleDetail_Log.CreatedBy,\n		FAMS.AssetSaleDetail_Log.CreatedDate,\n		FAMS.AssetSaleDetail_Log.ModifiedBy,\n		FAMS.AssetSa"
+"leDetail_Log.ModifiedDate,\n		FAMS.AssetSaleDetail_Log.Remarks,\n		FAMS.AssetSaleDetail_Log.DepUpToSaleDate,\n		FAMS.AssetS"
+"aleDetail_Log.AccDepUpToSaleDate,\n		FAMS.AssetSaleDetail_Log.ChildAssetsCost,\n		FAMS.AssetSaleDetail_Log.TotalCost,\n		FA"
+"MS.AssetSaleDetail_Log.OrgAccDepBook1,\n		FAMS.AssetSaleDetail_Log.OrgAccDepBook2,\n		FAMS.AssetSaleDetail_Log.ProfitLossV"
+"alueBook1,\n		FAMS.AssetSaleDetail_Log.ProfitLossValueBook2,\n		FAMS.AssetSaleDetail_Log.SoldDEPBook1,\n		FAMS.AssetSaleDet"
+"ail_Log.SoldDEPBook2,\n		FAMS.AssetSaleDetail_Log.TotalDep,\n		FAMS.AssetSaleDetail_Log.TotalDepBook1,\n		FAMS.AssetSaleDet"
+"ail_Log.TotalDepBook2,\n		FAMS.AssetSaleDetail_Log.OperationType\nFROM	FAMS.AssetSaleDetail_Log";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.AssetSaleDetailID = 0;
							} else {
		                          
            row2.AssetSaleDetailID = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.AssetSaleID = 0;
							} else {
		                          
            row2.AssetSaleID = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.AssetID = 0;
							} else {
		                          
            row2.AssetID = rs_tDBInput_2.getInt(3);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.OrgAccDepUpto = null;
							} else {
										
			row2.OrgAccDepUpto = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 4);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.OrgPhyID = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(5);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.OrgPhyID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.OrgPhyID = tmpContent_tDBInput_2;
                }
            } else {
                row2.OrgPhyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.SoldPhyID = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(6);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.SoldPhyID = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.SoldPhyID = tmpContent_tDBInput_2;
                }
            } else {
                row2.SoldPhyID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.SoldValue = null;
							} else {
		                          
            row2.SoldValue = rs_tDBInput_2.getBigDecimal(7);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.OrgQty = null;
							} else {
		                          
            row2.OrgQty = rs_tDBInput_2.getInt(8);
            if(rs_tDBInput_2.wasNull()){
                    row2.OrgQty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.SoldQty = null;
							} else {
		                          
            row2.SoldQty = rs_tDBInput_2.getInt(9);
            if(rs_tDBInput_2.wasNull()){
                    row2.SoldQty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.OrgAccDep = null;
							} else {
		                          
            row2.OrgAccDep = rs_tDBInput_2.getBigDecimal(10);
            if(rs_tDBInput_2.wasNull()){
                    row2.OrgAccDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row2.SoldAccDep = null;
							} else {
		                          
            row2.SoldAccDep = rs_tDBInput_2.getBigDecimal(11);
            if(rs_tDBInput_2.wasNull()){
                    row2.SoldAccDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row2.OrgDEP = null;
							} else {
		                          
            row2.OrgDEP = rs_tDBInput_2.getBigDecimal(12);
            if(rs_tDBInput_2.wasNull()){
                    row2.OrgDEP = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row2.SoldDEP = null;
							} else {
		                          
            row2.SoldDEP = rs_tDBInput_2.getBigDecimal(13);
            if(rs_tDBInput_2.wasNull()){
                    row2.SoldDEP = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 14) {
								row2.ProfitLossValue = null;
							} else {
		                          
            row2.ProfitLossValue = rs_tDBInput_2.getBigDecimal(14);
            if(rs_tDBInput_2.wasNull()){
                    row2.ProfitLossValue = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 15) {
								row2.AdditionalCost = null;
							} else {
		                          
            row2.AdditionalCost = rs_tDBInput_2.getBigDecimal(15);
            if(rs_tDBInput_2.wasNull()){
                    row2.AdditionalCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 16) {
								row2.CreatedBy = 0;
							} else {
		                          
            row2.CreatedBy = rs_tDBInput_2.getInt(16);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 17) {
								row2.CreatedDate = null;
							} else {
										
			row2.CreatedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 17);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 18) {
								row2.ModifiedBy = null;
							} else {
		                          
            row2.ModifiedBy = rs_tDBInput_2.getInt(18);
            if(rs_tDBInput_2.wasNull()){
                    row2.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 19) {
								row2.ModifiedDate = null;
							} else {
										
			row2.ModifiedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 19);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 20) {
								row2.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(20);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.Remarks = tmpContent_tDBInput_2;
                }
            } else {
                row2.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 21) {
								row2.DepUpToSaleDate = null;
							} else {
		                          
            row2.DepUpToSaleDate = rs_tDBInput_2.getBigDecimal(21);
            if(rs_tDBInput_2.wasNull()){
                    row2.DepUpToSaleDate = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 22) {
								row2.AccDepUpToSaleDate = null;
							} else {
		                          
            row2.AccDepUpToSaleDate = rs_tDBInput_2.getBigDecimal(22);
            if(rs_tDBInput_2.wasNull()){
                    row2.AccDepUpToSaleDate = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 23) {
								row2.ChildAssetsCost = null;
							} else {
		                          
            row2.ChildAssetsCost = rs_tDBInput_2.getBigDecimal(23);
            if(rs_tDBInput_2.wasNull()){
                    row2.ChildAssetsCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 24) {
								row2.TotalCost = null;
							} else {
		                          
            row2.TotalCost = rs_tDBInput_2.getBigDecimal(24);
            if(rs_tDBInput_2.wasNull()){
                    row2.TotalCost = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 25) {
								row2.OrgAccDepBook1 = null;
							} else {
		                          
            row2.OrgAccDepBook1 = rs_tDBInput_2.getBigDecimal(25);
            if(rs_tDBInput_2.wasNull()){
                    row2.OrgAccDepBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 26) {
								row2.OrgAccDepBook2 = null;
							} else {
		                          
            row2.OrgAccDepBook2 = rs_tDBInput_2.getBigDecimal(26);
            if(rs_tDBInput_2.wasNull()){
                    row2.OrgAccDepBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 27) {
								row2.ProfitLossValueBook1 = null;
							} else {
		                          
            row2.ProfitLossValueBook1 = rs_tDBInput_2.getBigDecimal(27);
            if(rs_tDBInput_2.wasNull()){
                    row2.ProfitLossValueBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 28) {
								row2.ProfitLossValueBook2 = null;
							} else {
		                          
            row2.ProfitLossValueBook2 = rs_tDBInput_2.getBigDecimal(28);
            if(rs_tDBInput_2.wasNull()){
                    row2.ProfitLossValueBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 29) {
								row2.SoldDEPBook1 = null;
							} else {
		                          
            row2.SoldDEPBook1 = rs_tDBInput_2.getBigDecimal(29);
            if(rs_tDBInput_2.wasNull()){
                    row2.SoldDEPBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 30) {
								row2.SoldDEPBook2 = null;
							} else {
		                          
            row2.SoldDEPBook2 = rs_tDBInput_2.getBigDecimal(30);
            if(rs_tDBInput_2.wasNull()){
                    row2.SoldDEPBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 31) {
								row2.TotalDep = null;
							} else {
		                          
            row2.TotalDep = rs_tDBInput_2.getBigDecimal(31);
            if(rs_tDBInput_2.wasNull()){
                    row2.TotalDep = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 32) {
								row2.TotalDepBook1 = null;
							} else {
		                          
            row2.TotalDepBook1 = rs_tDBInput_2.getBigDecimal(32);
            if(rs_tDBInput_2.wasNull()){
                    row2.TotalDepBook1 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 33) {
								row2.TotalDepBook2 = null;
							} else {
		                          
            row2.TotalDepBook2 = rs_tDBInput_2.getBigDecimal(33);
            if(rs_tDBInput_2.wasNull()){
                    row2.TotalDepBook2 = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 34) {
								row2.OperationType = null;
							} else {
	                         		
           		tmpContent_tDBInput_2 = rs_tDBInput_2.getString(34);
            if(tmpContent_tDBInput_2 != null) {
            	if (talendToDBList_tDBInput_2 .contains(rsmd_tDBInput_2.getColumnTypeName(34).toUpperCase(java.util.Locale.ENGLISH))) {
            		row2.OperationType = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
            	} else {
                	row2.OperationType = tmpContent_tDBInput_2;
                }
            } else {
                row2.OperationType = null;
            }
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					





 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"AssetSaleDetail_Log\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, row2.AssetSaleDetailID);

                    pstmt_tDBOutput_2.setInt(2, row2.AssetSaleID);

                    pstmt_tDBOutput_2.setInt(3, row2.AssetID);

                    if(row2.OrgAccDepUpto != null) {
pstmt_tDBOutput_2.setTimestamp(4, new java.sql.Timestamp(row2.OrgAccDepUpto.getTime()));
} else {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row2.OrgPhyID == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, row2.OrgPhyID);
}

                    if(row2.SoldPhyID == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(6, row2.SoldPhyID);
}

                    pstmt_tDBOutput_2.setBigDecimal(7, row2.SoldValue);

                    if(row2.OrgQty == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, row2.OrgQty);
}

                    if(row2.SoldQty == null) {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(9, row2.SoldQty);
}

                    pstmt_tDBOutput_2.setBigDecimal(10, row2.OrgAccDep);

                    pstmt_tDBOutput_2.setBigDecimal(11, row2.SoldAccDep);

                    pstmt_tDBOutput_2.setBigDecimal(12, row2.OrgDEP);

                    pstmt_tDBOutput_2.setBigDecimal(13, row2.SoldDEP);

                    pstmt_tDBOutput_2.setBigDecimal(14, row2.ProfitLossValue);

                    pstmt_tDBOutput_2.setBigDecimal(15, row2.AdditionalCost);

                    pstmt_tDBOutput_2.setInt(16, row2.CreatedBy);

                    if(row2.CreatedDate != null) {
pstmt_tDBOutput_2.setTimestamp(17, new java.sql.Timestamp(row2.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.TIMESTAMP);
}

                    if(row2.ModifiedBy == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(18, row2.ModifiedBy);
}

                    if(row2.ModifiedDate != null) {
pstmt_tDBOutput_2.setTimestamp(19, new java.sql.Timestamp(row2.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.TIMESTAMP);
}

                    if(row2.Remarks == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(20, row2.Remarks);
}

                    pstmt_tDBOutput_2.setBigDecimal(21, row2.DepUpToSaleDate);

                    pstmt_tDBOutput_2.setBigDecimal(22, row2.AccDepUpToSaleDate);

                    pstmt_tDBOutput_2.setBigDecimal(23, row2.ChildAssetsCost);

                    pstmt_tDBOutput_2.setBigDecimal(24, row2.TotalCost);

                    pstmt_tDBOutput_2.setBigDecimal(25, row2.OrgAccDepBook1);

                    pstmt_tDBOutput_2.setBigDecimal(26, row2.OrgAccDepBook2);

                    pstmt_tDBOutput_2.setBigDecimal(27, row2.ProfitLossValueBook1);

                    pstmt_tDBOutput_2.setBigDecimal(28, row2.ProfitLossValueBook2);

                    pstmt_tDBOutput_2.setBigDecimal(29, row2.SoldDEPBook1);

                    pstmt_tDBOutput_2.setBigDecimal(30, row2.SoldDEPBook2);

                    pstmt_tDBOutput_2.setBigDecimal(31, row2.TotalDep);

                    pstmt_tDBOutput_2.setBigDecimal(32, row2.TotalDepBook1);

                    pstmt_tDBOutput_2.setBigDecimal(33, row2.TotalDepBook2);

                    if(row2.OperationType == null) {
pstmt_tDBOutput_2.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(34, row2.OperationType);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_2)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"AssetSaleDetail_Log\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetSaleDetail_Log\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];

	
			    public int AssetDocumentID;

				public int getAssetDocumentID () {
					return this.AssetDocumentID;
				}

				public Boolean AssetDocumentIDIsNullable(){
				    return false;
				}
				public Boolean AssetDocumentIDIsKey(){
				    return false;
				}
				public Integer AssetDocumentIDLength(){
				    return 10;
				}
				public Integer AssetDocumentIDPrecision(){
				    return 0;
				}
				public String AssetDocumentIDDefault(){
				
					return null;
				
				}
				public String AssetDocumentIDComment(){
				
				    return "";
				
				}
				public String AssetDocumentIDPattern(){
				
					return "";
				
				}
				public String AssetDocumentIDOriginalDbColumnName(){
				
					return "AssetDocumentID";
				
				}

				
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public String DocumentName;

				public String getDocumentName () {
					return this.DocumentName;
				}

				public Boolean DocumentNameIsNullable(){
				    return true;
				}
				public Boolean DocumentNameIsKey(){
				    return false;
				}
				public Integer DocumentNameLength(){
				    return 500;
				}
				public Integer DocumentNamePrecision(){
				    return 0;
				}
				public String DocumentNameDefault(){
				
					return null;
				
				}
				public String DocumentNameComment(){
				
				    return "";
				
				}
				public String DocumentNamePattern(){
				
					return "";
				
				}
				public String DocumentNameOriginalDbColumnName(){
				
					return "DocumentName";
				
				}

				
			    public String Attachment;

				public String getAttachment () {
					return this.Attachment;
				}

				public Boolean AttachmentIsNullable(){
				    return true;
				}
				public Boolean AttachmentIsKey(){
				    return false;
				}
				public Integer AttachmentLength(){
				    return 150;
				}
				public Integer AttachmentPrecision(){
				    return 0;
				}
				public String AttachmentDefault(){
				
					return null;
				
				}
				public String AttachmentComment(){
				
				    return "";
				
				}
				public String AttachmentPattern(){
				
					return "";
				
				}
				public String AttachmentOriginalDbColumnName(){
				
					return "Attachment";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetDocumentID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.DocumentName = readString(dis);
					
					this.Attachment = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetDocumentID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.DocumentName = readString(dis);
					
					this.Attachment = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetDocumentID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// String
				
						writeString(this.DocumentName,dos);
					
					// String
				
						writeString(this.Attachment,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetDocumentID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// String
				
						writeString(this.DocumentName,dos);
					
					// String
				
						writeString(this.Attachment,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetDocumentID="+String.valueOf(AssetDocumentID));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",DocumentName="+DocumentName);
		sb.append(",Attachment="+Attachment);
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetDocumentID);
        			
        			sb.append("|");
        		
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				if(DocumentName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DocumentName);
            			}
            		
        			sb.append("|");
        		
        				if(Attachment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Attachment);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"AssetSalesDocument\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("AssetSalesDocument");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("AssetSalesDocument");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"AssetDocumentID\",\"AssetID\",\"DocumentName\",\"Attachment\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"AssetSalesDocument\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT FAMS.AssetSalesDocument.AssetDocumentID, 		FAMS.AssetSalesDocument.AssetID, 		FAMS.AssetSalesDocument.DocumentName, 		FAMS.AssetSalesDocument.Attachment, 		FAMS.AssetSalesDocument.CreatedBy, 		FAMS.AssetSalesDocument.CreatedDate, 		FAMS.AssetSalesDocument.ModifiedBy, 		FAMS.AssetSalesDocument.ModifiedDate FROM	FAMS.AssetSalesDocument  WHERE FAMS.AssetSalesDocument.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.AssetSalesDocument.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetDocumentID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DocumentName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Attachment")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"AssetSalesDocument\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3); 
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT FAMS.AssetSalesDocument.AssetDocumentID,\n		FAMS.AssetSalesDocument.AssetID,\n		FAMS.AssetSalesDocument.DocumentNa"
+"me,\n		FAMS.AssetSalesDocument.Attachment,\n		FAMS.AssetSalesDocument.CreatedBy,\n		FAMS.AssetSalesDocument.CreatedDate,\n		"
+"FAMS.AssetSalesDocument.ModifiedBy,\n		FAMS.AssetSalesDocument.ModifiedDate\nFROM	FAMS.AssetSalesDocument\nWHERE FAMS.Asse"
+"tSalesDocument.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAMS.AssetSalesDocument.CreatedDate <"
+" CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.AssetDocumentID = 0;
							} else {
		                          
            row3.AssetDocumentID = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.AssetID = 0;
							} else {
		                          
            row3.AssetID = rs_tDBInput_3.getInt(2);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.DocumentName = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(3);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.DocumentName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.DocumentName = tmpContent_tDBInput_3;
                }
            } else {
                row3.DocumentName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.Attachment = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(4);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Attachment = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Attachment = tmpContent_tDBInput_3;
                }
            } else {
                row3.Attachment = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.CreatedBy = 0;
							} else {
		                          
            row3.CreatedBy = rs_tDBInput_3.getInt(5);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.CreatedDate = null;
							} else {
										
			row3.CreatedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 6);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.ModifiedBy = null;
							} else {
		                          
            row3.ModifiedBy = rs_tDBInput_3.getInt(7);
            if(rs_tDBInput_3.wasNull()){
                    row3.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.ModifiedDate = null;
							} else {
										
			row3.ModifiedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 8);
			
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					





 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"AssetSalesDocument\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, row3.AssetDocumentID);

                    pstmt_tDBOutput_3.setInt(2, row3.AssetID);

                    if(row3.DocumentName == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row3.DocumentName);
}

                    if(row3.Attachment == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, row3.Attachment);
}

                    pstmt_tDBOutput_3.setInt(5, row3.CreatedBy);

                    if(row3.CreatedDate != null) {
pstmt_tDBOutput_3.setTimestamp(6, new java.sql.Timestamp(row3.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row3.ModifiedBy == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(7, row3.ModifiedBy);
}

                    if(row3.ModifiedDate != null) {
pstmt_tDBOutput_3.setTimestamp(8, new java.sql.Timestamp(row3.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_3)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"AssetSalesDocument\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetSalesDocument\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];

	
			    public int AssetSaleID;

				public int getAssetSaleID () {
					return this.AssetSaleID;
				}

				public Boolean AssetSaleIDIsNullable(){
				    return false;
				}
				public Boolean AssetSaleIDIsKey(){
				    return false;
				}
				public Integer AssetSaleIDLength(){
				    return 10;
				}
				public Integer AssetSaleIDPrecision(){
				    return 0;
				}
				public String AssetSaleIDDefault(){
				
					return null;
				
				}
				public String AssetSaleIDComment(){
				
				    return "";
				
				}
				public String AssetSaleIDPattern(){
				
					return "";
				
				}
				public String AssetSaleIDOriginalDbColumnName(){
				
					return "AssetSaleID";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public short SaleType;

				public short getSaleType () {
					return this.SaleType;
				}

				public Boolean SaleTypeIsNullable(){
				    return false;
				}
				public Boolean SaleTypeIsKey(){
				    return false;
				}
				public Integer SaleTypeLength(){
				    return 5;
				}
				public Integer SaleTypePrecision(){
				    return 0;
				}
				public String SaleTypeDefault(){
				
					return null;
				
				}
				public String SaleTypeComment(){
				
				    return "";
				
				}
				public String SaleTypePattern(){
				
					return "";
				
				}
				public String SaleTypeOriginalDbColumnName(){
				
					return "SaleType";
				
				}

				
			    public String InvoiceNo;

				public String getInvoiceNo () {
					return this.InvoiceNo;
				}

				public Boolean InvoiceNoIsNullable(){
				    return false;
				}
				public Boolean InvoiceNoIsKey(){
				    return false;
				}
				public Integer InvoiceNoLength(){
				    return 50;
				}
				public Integer InvoiceNoPrecision(){
				    return 0;
				}
				public String InvoiceNoDefault(){
				
					return null;
				
				}
				public String InvoiceNoComment(){
				
				    return "";
				
				}
				public String InvoiceNoPattern(){
				
					return "";
				
				}
				public String InvoiceNoOriginalDbColumnName(){
				
					return "InvoiceNo";
				
				}

				
			    public Integer VendorID;

				public Integer getVendorID () {
					return this.VendorID;
				}

				public Boolean VendorIDIsNullable(){
				    return true;
				}
				public Boolean VendorIDIsKey(){
				    return false;
				}
				public Integer VendorIDLength(){
				    return 10;
				}
				public Integer VendorIDPrecision(){
				    return 0;
				}
				public String VendorIDDefault(){
				
					return null;
				
				}
				public String VendorIDComment(){
				
				    return "";
				
				}
				public String VendorIDPattern(){
				
					return "";
				
				}
				public String VendorIDOriginalDbColumnName(){
				
					return "VendorID";
				
				}

				
			    public java.util.Date DateSoldOn;

				public java.util.Date getDateSoldOn () {
					return this.DateSoldOn;
				}

				public Boolean DateSoldOnIsNullable(){
				    return true;
				}
				public Boolean DateSoldOnIsKey(){
				    return false;
				}
				public Integer DateSoldOnLength(){
				    return 23;
				}
				public Integer DateSoldOnPrecision(){
				    return 3;
				}
				public String DateSoldOnDefault(){
				
					return null;
				
				}
				public String DateSoldOnComment(){
				
				    return "";
				
				}
				public String DateSoldOnPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String DateSoldOnOriginalDbColumnName(){
				
					return "DateSoldOn";
				
				}

				
			    public Integer BookAccountingYearID;

				public Integer getBookAccountingYearID () {
					return this.BookAccountingYearID;
				}

				public Boolean BookAccountingYearIDIsNullable(){
				    return true;
				}
				public Boolean BookAccountingYearIDIsKey(){
				    return false;
				}
				public Integer BookAccountingYearIDLength(){
				    return 10;
				}
				public Integer BookAccountingYearIDPrecision(){
				    return 0;
				}
				public String BookAccountingYearIDDefault(){
				
					return null;
				
				}
				public String BookAccountingYearIDComment(){
				
				    return "";
				
				}
				public String BookAccountingYearIDPattern(){
				
					return "";
				
				}
				public String BookAccountingYearIDOriginalDbColumnName(){
				
					return "BookAccountingYearID";
				
				}

				
			    public String Description;

				public String getDescription () {
					return this.Description;
				}

				public Boolean DescriptionIsNullable(){
				    return true;
				}
				public Boolean DescriptionIsKey(){
				    return false;
				}
				public Integer DescriptionLength(){
				    return 500;
				}
				public Integer DescriptionPrecision(){
				    return 0;
				}
				public String DescriptionDefault(){
				
					return null;
				
				}
				public String DescriptionComment(){
				
				    return "";
				
				}
				public String DescriptionPattern(){
				
					return "";
				
				}
				public String DescriptionOriginalDbColumnName(){
				
					return "Description";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public int CompanyBookID;

				public int getCompanyBookID () {
					return this.CompanyBookID;
				}

				public Boolean CompanyBookIDIsNullable(){
				    return false;
				}
				public Boolean CompanyBookIDIsKey(){
				    return false;
				}
				public Integer CompanyBookIDLength(){
				    return 10;
				}
				public Integer CompanyBookIDPrecision(){
				    return 0;
				}
				public String CompanyBookIDDefault(){
				
					return null;
				
				}
				public String CompanyBookIDComment(){
				
				    return "";
				
				}
				public String CompanyBookIDPattern(){
				
					return "";
				
				}
				public String CompanyBookIDOriginalDbColumnName(){
				
					return "CompanyBookID";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 200;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public Integer OrgQuantity;

				public Integer getOrgQuantity () {
					return this.OrgQuantity;
				}

				public Boolean OrgQuantityIsNullable(){
				    return true;
				}
				public Boolean OrgQuantityIsKey(){
				    return false;
				}
				public Integer OrgQuantityLength(){
				    return 10;
				}
				public Integer OrgQuantityPrecision(){
				    return 0;
				}
				public String OrgQuantityDefault(){
				
					return null;
				
				}
				public String OrgQuantityComment(){
				
				    return "";
				
				}
				public String OrgQuantityPattern(){
				
					return "";
				
				}
				public String OrgQuantityOriginalDbColumnName(){
				
					return "OrgQuantity";
				
				}

				
			    public Integer AssetID;

				public Integer getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return true;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public Integer AssetUser;

				public Integer getAssetUser () {
					return this.AssetUser;
				}

				public Boolean AssetUserIsNullable(){
				    return true;
				}
				public Boolean AssetUserIsKey(){
				    return false;
				}
				public Integer AssetUserLength(){
				    return 10;
				}
				public Integer AssetUserPrecision(){
				    return 0;
				}
				public String AssetUserDefault(){
				
					return null;
				
				}
				public String AssetUserComment(){
				
				    return "";
				
				}
				public String AssetUserPattern(){
				
					return "";
				
				}
				public String AssetUserOriginalDbColumnName(){
				
					return "AssetUser";
				
				}

				
			    public String OperationType;

				public String getOperationType () {
					return this.OperationType;
				}

				public Boolean OperationTypeIsNullable(){
				    return true;
				}
				public Boolean OperationTypeIsKey(){
				    return false;
				}
				public Integer OperationTypeLength(){
				    return 10;
				}
				public Integer OperationTypePrecision(){
				    return 0;
				}
				public String OperationTypeDefault(){
				
					return null;
				
				}
				public String OperationTypeComment(){
				
				    return "";
				
				}
				public String OperationTypePattern(){
				
					return "";
				
				}
				public String OperationTypeOriginalDbColumnName(){
				
					return "OperationType";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.SaleType = dis.readShort();
					
					this.InvoiceNo = readString(dis);
					
						this.VendorID = readInteger(dis);
					
					this.DateSoldOn = readDate(dis);
					
						this.BookAccountingYearID = readInteger(dis);
					
					this.Description = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
			        this.CompanyBookID = dis.readInt();
					
					this.Remarks = readString(dis);
					
						this.OrgQuantity = readInteger(dis);
					
						this.AssetID = readInteger(dis);
					
						this.AssetUser = readInteger(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSaleID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.SaleType = dis.readShort();
					
					this.InvoiceNo = readString(dis);
					
						this.VendorID = readInteger(dis);
					
					this.DateSoldOn = readDate(dis);
					
						this.BookAccountingYearID = readInteger(dis);
					
					this.Description = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
			        this.CompanyBookID = dis.readInt();
					
					this.Remarks = readString(dis);
					
						this.OrgQuantity = readInteger(dis);
					
						this.AssetID = readInteger(dis);
					
						this.AssetUser = readInteger(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// short
				
		            	dos.writeShort(this.SaleType);
					
					// String
				
						writeString(this.InvoiceNo,dos);
					
					// Integer
				
						writeInteger(this.VendorID,dos);
					
					// java.util.Date
				
						writeDate(this.DateSoldOn,dos);
					
					// Integer
				
						writeInteger(this.BookAccountingYearID,dos);
					
					// String
				
						writeString(this.Description,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyBookID);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// Integer
				
						writeInteger(this.OrgQuantity,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// Integer
				
						writeInteger(this.AssetUser,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSaleID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// short
				
		            	dos.writeShort(this.SaleType);
					
					// String
				
						writeString(this.InvoiceNo,dos);
					
					// Integer
				
						writeInteger(this.VendorID,dos);
					
					// java.util.Date
				
						writeDate(this.DateSoldOn,dos);
					
					// Integer
				
						writeInteger(this.BookAccountingYearID,dos);
					
					// String
				
						writeString(this.Description,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// int
				
		            	dos.writeInt(this.CompanyBookID);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// Integer
				
						writeInteger(this.OrgQuantity,dos);
					
					// Integer
				
						writeInteger(this.AssetID,dos);
					
					// Integer
				
						writeInteger(this.AssetUser,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetSaleID="+String.valueOf(AssetSaleID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",SaleType="+String.valueOf(SaleType));
		sb.append(",InvoiceNo="+InvoiceNo);
		sb.append(",VendorID="+String.valueOf(VendorID));
		sb.append(",DateSoldOn="+String.valueOf(DateSoldOn));
		sb.append(",BookAccountingYearID="+String.valueOf(BookAccountingYearID));
		sb.append(",Description="+Description);
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",CompanyBookID="+String.valueOf(CompanyBookID));
		sb.append(",Remarks="+Remarks);
		sb.append(",OrgQuantity="+String.valueOf(OrgQuantity));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",AssetUser="+String.valueOf(AssetUser));
		sb.append(",OperationType="+OperationType);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetSaleID);
        			
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				sb.append(SaleType);
        			
        			sb.append("|");
        		
        				if(InvoiceNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(InvoiceNo);
            			}
            		
        			sb.append("|");
        		
        				if(VendorID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorID);
            			}
            		
        			sb.append("|");
        		
        				if(DateSoldOn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DateSoldOn);
            			}
            		
        			sb.append("|");
        		
        				if(BookAccountingYearID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BookAccountingYearID);
            			}
            		
        			sb.append("|");
        		
        				if(Description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Description);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CompanyBookID);
        			
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(OrgQuantity == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OrgQuantity);
            			}
            		
        			sb.append("|");
        		
        				if(AssetID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetUser == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetUser);
            			}
            		
        			sb.append("|");
        		
        				if(OperationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OperationType);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"AssetSale_Log\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("AssetSale_Log");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("AssetSale_Log");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
            int rsTruncCountNumber_tDBOutput_4 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_4 = stmtTruncCount_tDBOutput_4.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_4 + "\"")) {
                    if(rsTruncCount_tDBOutput_4.next()) {
                        rsTruncCountNumber_tDBOutput_4 = rsTruncCount_tDBOutput_4.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_4.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_4 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_4+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_4 += rsTruncCountNumber_tDBOutput_4;
            }
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"AssetSaleID\",\"CompanyID\",\"SaleType\",\"InvoiceNo\",\"VendorID\",\"DateSoldOn\",\"BookAccountingYearID\",\"Description\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"CompanyBookID\",\"Remarks\",\"OrgQuantity\",\"AssetID\",\"AssetUser\",\"OperationType\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"AssetSale_Log\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT FAMS.AssetSale_Log.AssetSaleID, 		FAMS.AssetSale_Log.CompanyID, 		FAMS.AssetSale_Log.SaleType, 		FAMS.AssetSale_Log.InvoiceNo, 		FAMS.AssetSale_Log.VendorID, 		FAMS.AssetSale_Log.DateSoldOn, 		FAMS.AssetSale_Log.BookAccountingYearID, 		FAMS.AssetSale_Log.Description, 		FAMS.AssetSale_Log.CreatedBy, 		FAMS.AssetSale_Log.CreatedDate, 		FAMS.AssetSale_Log.ModifiedBy, 		FAMS.AssetSale_Log.ModifiedDate, 		FAMS.AssetSale_Log.CompanyBookID, 		FAMS.AssetSale_Log.Remarks, 		FAMS.AssetSale_Log.OrgQuantity, 		FAMS.AssetSale_Log.AssetID, 		FAMS.AssetSale_Log.AssetUser, 		FAMS.AssetSale_Log.OperationType FROM	FAMS.AssetSale_Log\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSaleID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SaleType")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("InvoiceNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("DateSoldOn")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BookAccountingYearID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Description")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyBookID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OrgQuantity")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetUser")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OperationType")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"AssetSale_Log\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_4  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4); 
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_4 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT FAMS.AssetSale_Log.AssetSaleID,\n		FAMS.AssetSale_Log.CompanyID,\n		FAMS.AssetSale_Log.SaleType,\n		FAMS.AssetSale_"
+"Log.InvoiceNo,\n		FAMS.AssetSale_Log.VendorID,\n		FAMS.AssetSale_Log.DateSoldOn,\n		FAMS.AssetSale_Log.BookAccountingYearID"
+",\n		FAMS.AssetSale_Log.Description,\n		FAMS.AssetSale_Log.CreatedBy,\n		FAMS.AssetSale_Log.CreatedDate,\n		FAMS.AssetSale_L"
+"og.ModifiedBy,\n		FAMS.AssetSale_Log.ModifiedDate,\n		FAMS.AssetSale_Log.CompanyBookID,\n		FAMS.AssetSale_Log.Remarks,\n		FA"
+"MS.AssetSale_Log.OrgQuantity,\n		FAMS.AssetSale_Log.AssetID,\n		FAMS.AssetSale_Log.AssetUser,\n		FAMS.AssetSale_Log.Operati"
+"onType\nFROM	FAMS.AssetSale_Log";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.AssetSaleID = 0;
							} else {
		                          
            row4.AssetSaleID = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.CompanyID = 0;
							} else {
		                          
            row4.CompanyID = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.SaleType = 0;
							} else {
		                          
            row4.SaleType = rs_tDBInput_4.getShort(3);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.InvoiceNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(4);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.InvoiceNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.InvoiceNo = tmpContent_tDBInput_4;
                }
            } else {
                row4.InvoiceNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.VendorID = null;
							} else {
		                          
            row4.VendorID = rs_tDBInput_4.getInt(5);
            if(rs_tDBInput_4.wasNull()){
                    row4.VendorID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.DateSoldOn = null;
							} else {
										
			row4.DateSoldOn = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 6);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.BookAccountingYearID = null;
							} else {
		                          
            row4.BookAccountingYearID = rs_tDBInput_4.getInt(7);
            if(rs_tDBInput_4.wasNull()){
                    row4.BookAccountingYearID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.Description = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(8);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Description = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Description = tmpContent_tDBInput_4;
                }
            } else {
                row4.Description = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.CreatedBy = 0;
							} else {
		                          
            row4.CreatedBy = rs_tDBInput_4.getInt(9);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.CreatedDate = null;
							} else {
										
			row4.CreatedDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 10);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 11) {
								row4.ModifiedBy = null;
							} else {
		                          
            row4.ModifiedBy = rs_tDBInput_4.getInt(11);
            if(rs_tDBInput_4.wasNull()){
                    row4.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 12) {
								row4.ModifiedDate = null;
							} else {
										
			row4.ModifiedDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 12);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 13) {
								row4.CompanyBookID = 0;
							} else {
		                          
            row4.CompanyBookID = rs_tDBInput_4.getInt(13);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 14) {
								row4.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(14);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.Remarks = tmpContent_tDBInput_4;
                }
            } else {
                row4.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 15) {
								row4.OrgQuantity = null;
							} else {
		                          
            row4.OrgQuantity = rs_tDBInput_4.getInt(15);
            if(rs_tDBInput_4.wasNull()){
                    row4.OrgQuantity = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 16) {
								row4.AssetID = null;
							} else {
		                          
            row4.AssetID = rs_tDBInput_4.getInt(16);
            if(rs_tDBInput_4.wasNull()){
                    row4.AssetID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 17) {
								row4.AssetUser = null;
							} else {
		                          
            row4.AssetUser = rs_tDBInput_4.getInt(17);
            if(rs_tDBInput_4.wasNull()){
                    row4.AssetUser = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 18) {
								row4.OperationType = null;
							} else {
	                         		
           		tmpContent_tDBInput_4 = rs_tDBInput_4.getString(18);
            if(tmpContent_tDBInput_4 != null) {
            	if (talendToDBList_tDBInput_4 .contains(rsmd_tDBInput_4.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row4.OperationType = FormatterUtils.formatUnwithE(tmpContent_tDBInput_4);
            	} else {
                	row4.OperationType = tmpContent_tDBInput_4;
                }
            } else {
                row4.OperationType = null;
            }
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					





 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"AssetSale_Log\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, row4.AssetSaleID);

                    pstmt_tDBOutput_4.setInt(2, row4.CompanyID);

                    pstmt_tDBOutput_4.setShort(3, row4.SaleType);

                    if(row4.InvoiceNo == null) {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(4, row4.InvoiceNo);
}

                    if(row4.VendorID == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(5, row4.VendorID);
}

                    if(row4.DateSoldOn != null) {
pstmt_tDBOutput_4.setTimestamp(6, new java.sql.Timestamp(row4.DateSoldOn.getTime()));
} else {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row4.BookAccountingYearID == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(7, row4.BookAccountingYearID);
}

                    if(row4.Description == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(8, row4.Description);
}

                    pstmt_tDBOutput_4.setInt(9, row4.CreatedBy);

                    if(row4.CreatedDate != null) {
pstmt_tDBOutput_4.setTimestamp(10, new java.sql.Timestamp(row4.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.TIMESTAMP);
}

                    if(row4.ModifiedBy == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(11, row4.ModifiedBy);
}

                    if(row4.ModifiedDate != null) {
pstmt_tDBOutput_4.setTimestamp(12, new java.sql.Timestamp(row4.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(12, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_4.setInt(13, row4.CompanyBookID);

                    if(row4.Remarks == null) {
pstmt_tDBOutput_4.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(14, row4.Remarks);
}

                    if(row4.OrgQuantity == null) {
pstmt_tDBOutput_4.setNull(15, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(15, row4.OrgQuantity);
}

                    if(row4.AssetID == null) {
pstmt_tDBOutput_4.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(16, row4.AssetID);
}

                    if(row4.AssetUser == null) {
pstmt_tDBOutput_4.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(17, row4.AssetUser);
}

                    if(row4.OperationType == null) {
pstmt_tDBOutput_4.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(18, row4.OperationType);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_4)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"AssetSale_Log\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetSale_Log\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int AssetSentOutID;

				public int getAssetSentOutID () {
					return this.AssetSentOutID;
				}

				public Boolean AssetSentOutIDIsNullable(){
				    return false;
				}
				public Boolean AssetSentOutIDIsKey(){
				    return true;
				}
				public Integer AssetSentOutIDLength(){
				    return 10;
				}
				public Integer AssetSentOutIDPrecision(){
				    return 0;
				}
				public String AssetSentOutIDDefault(){
				
					return null;
				
				}
				public String AssetSentOutIDComment(){
				
				    return "";
				
				}
				public String AssetSentOutIDPattern(){
				
					return "";
				
				}
				public String AssetSentOutIDOriginalDbColumnName(){
				
					return "AssetSentOutID";
				
				}

				
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public java.util.Date AssetOutDate;

				public java.util.Date getAssetOutDate () {
					return this.AssetOutDate;
				}

				public Boolean AssetOutDateIsNullable(){
				    return false;
				}
				public Boolean AssetOutDateIsKey(){
				    return false;
				}
				public Integer AssetOutDateLength(){
				    return 10;
				}
				public Integer AssetOutDatePrecision(){
				    return 0;
				}
				public String AssetOutDateDefault(){
				
					return null;
				
				}
				public String AssetOutDateComment(){
				
				    return "";
				
				}
				public String AssetOutDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String AssetOutDateOriginalDbColumnName(){
				
					return "AssetOutDate";
				
				}

				
			    public Integer AssetMaintenanceContractDetailID;

				public Integer getAssetMaintenanceContractDetailID () {
					return this.AssetMaintenanceContractDetailID;
				}

				public Boolean AssetMaintenanceContractDetailIDIsNullable(){
				    return true;
				}
				public Boolean AssetMaintenanceContractDetailIDIsKey(){
				    return false;
				}
				public Integer AssetMaintenanceContractDetailIDLength(){
				    return 10;
				}
				public Integer AssetMaintenanceContractDetailIDPrecision(){
				    return 0;
				}
				public String AssetMaintenanceContractDetailIDDefault(){
				
					return null;
				
				}
				public String AssetMaintenanceContractDetailIDComment(){
				
				    return "";
				
				}
				public String AssetMaintenanceContractDetailIDPattern(){
				
					return "";
				
				}
				public String AssetMaintenanceContractDetailIDOriginalDbColumnName(){
				
					return "AssetMaintenanceContractDetailID";
				
				}

				
			    public Integer AssetWarrantyDetailID;

				public Integer getAssetWarrantyDetailID () {
					return this.AssetWarrantyDetailID;
				}

				public Boolean AssetWarrantyDetailIDIsNullable(){
				    return true;
				}
				public Boolean AssetWarrantyDetailIDIsKey(){
				    return false;
				}
				public Integer AssetWarrantyDetailIDLength(){
				    return 10;
				}
				public Integer AssetWarrantyDetailIDPrecision(){
				    return 0;
				}
				public String AssetWarrantyDetailIDDefault(){
				
					return null;
				
				}
				public String AssetWarrantyDetailIDComment(){
				
				    return "";
				
				}
				public String AssetWarrantyDetailIDPattern(){
				
					return "";
				
				}
				public String AssetWarrantyDetailIDOriginalDbColumnName(){
				
					return "AssetWarrantyDetailID";
				
				}

				
			    public Integer AssetInsuranceDetailID;

				public Integer getAssetInsuranceDetailID () {
					return this.AssetInsuranceDetailID;
				}

				public Boolean AssetInsuranceDetailIDIsNullable(){
				    return true;
				}
				public Boolean AssetInsuranceDetailIDIsKey(){
				    return false;
				}
				public Integer AssetInsuranceDetailIDLength(){
				    return 10;
				}
				public Integer AssetInsuranceDetailIDPrecision(){
				    return 0;
				}
				public String AssetInsuranceDetailIDDefault(){
				
					return null;
				
				}
				public String AssetInsuranceDetailIDComment(){
				
				    return "";
				
				}
				public String AssetInsuranceDetailIDPattern(){
				
					return "";
				
				}
				public String AssetInsuranceDetailIDOriginalDbColumnName(){
				
					return "AssetInsuranceDetailID";
				
				}

				
			    public int ServiceID;

				public int getServiceID () {
					return this.ServiceID;
				}

				public Boolean ServiceIDIsNullable(){
				    return false;
				}
				public Boolean ServiceIDIsKey(){
				    return false;
				}
				public Integer ServiceIDLength(){
				    return 10;
				}
				public Integer ServiceIDPrecision(){
				    return 0;
				}
				public String ServiceIDDefault(){
				
					return null;
				
				}
				public String ServiceIDComment(){
				
				    return "";
				
				}
				public String ServiceIDPattern(){
				
					return "";
				
				}
				public String ServiceIDOriginalDbColumnName(){
				
					return "ServiceID";
				
				}

				
			    public Integer Incharge;

				public Integer getIncharge () {
					return this.Incharge;
				}

				public Boolean InchargeIsNullable(){
				    return true;
				}
				public Boolean InchargeIsKey(){
				    return false;
				}
				public Integer InchargeLength(){
				    return 10;
				}
				public Integer InchargePrecision(){
				    return 0;
				}
				public String InchargeDefault(){
				
					return null;
				
				}
				public String InchargeComment(){
				
				    return "";
				
				}
				public String InchargePattern(){
				
					return "";
				
				}
				public String InchargeOriginalDbColumnName(){
				
					return "Incharge";
				
				}

				
			    public int Sender;

				public int getSender () {
					return this.Sender;
				}

				public Boolean SenderIsNullable(){
				    return false;
				}
				public Boolean SenderIsKey(){
				    return false;
				}
				public Integer SenderLength(){
				    return 10;
				}
				public Integer SenderPrecision(){
				    return 0;
				}
				public String SenderDefault(){
				
					return null;
				
				}
				public String SenderComment(){
				
				    return "";
				
				}
				public String SenderPattern(){
				
					return "";
				
				}
				public String SenderOriginalDbColumnName(){
				
					return "Sender";
				
				}

				
			    public String TicketRefNo;

				public String getTicketRefNo () {
					return this.TicketRefNo;
				}

				public Boolean TicketRefNoIsNullable(){
				    return false;
				}
				public Boolean TicketRefNoIsKey(){
				    return false;
				}
				public Integer TicketRefNoLength(){
				    return 100;
				}
				public Integer TicketRefNoPrecision(){
				    return 0;
				}
				public String TicketRefNoDefault(){
				
					return null;
				
				}
				public String TicketRefNoComment(){
				
				    return "";
				
				}
				public String TicketRefNoPattern(){
				
					return "";
				
				}
				public String TicketRefNoOriginalDbColumnName(){
				
					return "TicketRefNo";
				
				}

				
			    public int VendorID;

				public int getVendorID () {
					return this.VendorID;
				}

				public Boolean VendorIDIsNullable(){
				    return false;
				}
				public Boolean VendorIDIsKey(){
				    return false;
				}
				public Integer VendorIDLength(){
				    return 10;
				}
				public Integer VendorIDPrecision(){
				    return 0;
				}
				public String VendorIDDefault(){
				
					return null;
				
				}
				public String VendorIDComment(){
				
				    return "";
				
				}
				public String VendorIDPattern(){
				
					return "";
				
				}
				public String VendorIDOriginalDbColumnName(){
				
					return "VendorID";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 100;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public java.util.Date ExpectedDateOfReturn;

				public java.util.Date getExpectedDateOfReturn () {
					return this.ExpectedDateOfReturn;
				}

				public Boolean ExpectedDateOfReturnIsNullable(){
				    return false;
				}
				public Boolean ExpectedDateOfReturnIsKey(){
				    return false;
				}
				public Integer ExpectedDateOfReturnLength(){
				    return 10;
				}
				public Integer ExpectedDateOfReturnPrecision(){
				    return 0;
				}
				public String ExpectedDateOfReturnDefault(){
				
					return null;
				
				}
				public String ExpectedDateOfReturnComment(){
				
				    return "";
				
				}
				public String ExpectedDateOfReturnPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpectedDateOfReturnOriginalDbColumnName(){
				
					return "ExpectedDateOfReturn";
				
				}

				
			    public String InchargeFrom;

				public String getInchargeFrom () {
					return this.InchargeFrom;
				}

				public Boolean InchargeFromIsNullable(){
				    return true;
				}
				public Boolean InchargeFromIsKey(){
				    return false;
				}
				public Integer InchargeFromLength(){
				    return 30;
				}
				public Integer InchargeFromPrecision(){
				    return 0;
				}
				public String InchargeFromDefault(){
				
					return null;
				
				}
				public String InchargeFromComment(){
				
				    return "";
				
				}
				public String InchargeFromPattern(){
				
					return "";
				
				}
				public String InchargeFromOriginalDbColumnName(){
				
					return "InchargeFrom";
				
				}

				
			    public short IsReceived;

				public short getIsReceived () {
					return this.IsReceived;
				}

				public Boolean IsReceivedIsNullable(){
				    return false;
				}
				public Boolean IsReceivedIsKey(){
				    return false;
				}
				public Integer IsReceivedLength(){
				    return 5;
				}
				public Integer IsReceivedPrecision(){
				    return 0;
				}
				public String IsReceivedDefault(){
				
					return null;
				
				}
				public String IsReceivedComment(){
				
				    return "";
				
				}
				public String IsReceivedPattern(){
				
					return "";
				
				}
				public String IsReceivedOriginalDbColumnName(){
				
					return "IsReceived";
				
				}

				
			    public String StatusId;

				public String getStatusId () {
					return this.StatusId;
				}

				public Boolean StatusIdIsNullable(){
				    return true;
				}
				public Boolean StatusIdIsKey(){
				    return false;
				}
				public Integer StatusIdLength(){
				    return 2;
				}
				public Integer StatusIdPrecision(){
				    return 0;
				}
				public String StatusIdDefault(){
				
					return null;
				
				}
				public String StatusIdComment(){
				
				    return "";
				
				}
				public String StatusIdPattern(){
				
					return "";
				
				}
				public String StatusIdOriginalDbColumnName(){
				
					return "StatusId";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.AssetSentOutID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.AssetSentOutID != other.AssetSentOutID)
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.AssetSentOutID = this.AssetSentOutID;
	            other.AssetID = this.AssetID;
	            other.CompanyID = this.CompanyID;
	            other.AssetOutDate = this.AssetOutDate;
	            other.AssetMaintenanceContractDetailID = this.AssetMaintenanceContractDetailID;
	            other.AssetWarrantyDetailID = this.AssetWarrantyDetailID;
	            other.AssetInsuranceDetailID = this.AssetInsuranceDetailID;
	            other.ServiceID = this.ServiceID;
	            other.Incharge = this.Incharge;
	            other.Sender = this.Sender;
	            other.TicketRefNo = this.TicketRefNo;
	            other.VendorID = this.VendorID;
	            other.Remarks = this.Remarks;
	            other.ExpectedDateOfReturn = this.ExpectedDateOfReturn;
	            other.InchargeFrom = this.InchargeFrom;
	            other.IsReceived = this.IsReceived;
	            other.StatusId = this.StatusId;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.AssetSentOutID = this.AssetSentOutID;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSentOutID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
					this.AssetOutDate = readDate(dis);
					
						this.AssetMaintenanceContractDetailID = readInteger(dis);
					
						this.AssetWarrantyDetailID = readInteger(dis);
					
						this.AssetInsuranceDetailID = readInteger(dis);
					
			        this.ServiceID = dis.readInt();
					
						this.Incharge = readInteger(dis);
					
			        this.Sender = dis.readInt();
					
					this.TicketRefNo = readString(dis);
					
			        this.VendorID = dis.readInt();
					
					this.Remarks = readString(dis);
					
					this.ExpectedDateOfReturn = readDate(dis);
					
					this.InchargeFrom = readString(dis);
					
			        this.IsReceived = dis.readShort();
					
					this.StatusId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.AssetSentOutID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
					this.AssetOutDate = readDate(dis);
					
						this.AssetMaintenanceContractDetailID = readInteger(dis);
					
						this.AssetWarrantyDetailID = readInteger(dis);
					
						this.AssetInsuranceDetailID = readInteger(dis);
					
			        this.ServiceID = dis.readInt();
					
						this.Incharge = readInteger(dis);
					
			        this.Sender = dis.readInt();
					
					this.TicketRefNo = readString(dis);
					
			        this.VendorID = dis.readInt();
					
					this.Remarks = readString(dis);
					
					this.ExpectedDateOfReturn = readDate(dis);
					
					this.InchargeFrom = readString(dis);
					
			        this.IsReceived = dis.readShort();
					
					this.StatusId = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSentOutID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// java.util.Date
				
						writeDate(this.AssetOutDate,dos);
					
					// Integer
				
						writeInteger(this.AssetMaintenanceContractDetailID,dos);
					
					// Integer
				
						writeInteger(this.AssetWarrantyDetailID,dos);
					
					// Integer
				
						writeInteger(this.AssetInsuranceDetailID,dos);
					
					// int
				
		            	dos.writeInt(this.ServiceID);
					
					// Integer
				
						writeInteger(this.Incharge,dos);
					
					// int
				
		            	dos.writeInt(this.Sender);
					
					// String
				
						writeString(this.TicketRefNo,dos);
					
					// int
				
		            	dos.writeInt(this.VendorID);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// java.util.Date
				
						writeDate(this.ExpectedDateOfReturn,dos);
					
					// String
				
						writeString(this.InchargeFrom,dos);
					
					// short
				
		            	dos.writeShort(this.IsReceived);
					
					// String
				
						writeString(this.StatusId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetSentOutID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// java.util.Date
				
						writeDate(this.AssetOutDate,dos);
					
					// Integer
				
						writeInteger(this.AssetMaintenanceContractDetailID,dos);
					
					// Integer
				
						writeInteger(this.AssetWarrantyDetailID,dos);
					
					// Integer
				
						writeInteger(this.AssetInsuranceDetailID,dos);
					
					// int
				
		            	dos.writeInt(this.ServiceID);
					
					// Integer
				
						writeInteger(this.Incharge,dos);
					
					// int
				
		            	dos.writeInt(this.Sender);
					
					// String
				
						writeString(this.TicketRefNo,dos);
					
					// int
				
		            	dos.writeInt(this.VendorID);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// java.util.Date
				
						writeDate(this.ExpectedDateOfReturn,dos);
					
					// String
				
						writeString(this.InchargeFrom,dos);
					
					// short
				
		            	dos.writeShort(this.IsReceived);
					
					// String
				
						writeString(this.StatusId,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetSentOutID="+String.valueOf(AssetSentOutID));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",AssetOutDate="+String.valueOf(AssetOutDate));
		sb.append(",AssetMaintenanceContractDetailID="+String.valueOf(AssetMaintenanceContractDetailID));
		sb.append(",AssetWarrantyDetailID="+String.valueOf(AssetWarrantyDetailID));
		sb.append(",AssetInsuranceDetailID="+String.valueOf(AssetInsuranceDetailID));
		sb.append(",ServiceID="+String.valueOf(ServiceID));
		sb.append(",Incharge="+String.valueOf(Incharge));
		sb.append(",Sender="+String.valueOf(Sender));
		sb.append(",TicketRefNo="+TicketRefNo);
		sb.append(",VendorID="+String.valueOf(VendorID));
		sb.append(",Remarks="+Remarks);
		sb.append(",ExpectedDateOfReturn="+String.valueOf(ExpectedDateOfReturn));
		sb.append(",InchargeFrom="+InchargeFrom);
		sb.append(",IsReceived="+String.valueOf(IsReceived));
		sb.append(",StatusId="+StatusId);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetSentOutID);
        			
        			sb.append("|");
        		
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				if(AssetOutDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetOutDate);
            			}
            		
        			sb.append("|");
        		
        				if(AssetMaintenanceContractDetailID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetMaintenanceContractDetailID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetWarrantyDetailID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetWarrantyDetailID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetInsuranceDetailID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetInsuranceDetailID);
            			}
            		
        			sb.append("|");
        		
        				sb.append(ServiceID);
        			
        			sb.append("|");
        		
        				if(Incharge == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Incharge);
            			}
            		
        			sb.append("|");
        		
        				sb.append(Sender);
        			
        			sb.append("|");
        		
        				if(TicketRefNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TicketRefNo);
            			}
            		
        			sb.append("|");
        		
        				sb.append(VendorID);
        			
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(ExpectedDateOfReturn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ExpectedDateOfReturn);
            			}
            		
        			sb.append("|");
        		
        				if(InchargeFrom == null){
        					sb.append("<null>");
        				}else{
            				sb.append(InchargeFrom);
            			}
            		
        			sb.append("|");
        		
        				sb.append(IsReceived);
        			
        			sb.append("|");
        		
        				if(StatusId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(StatusId);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.AssetSentOutID, other.AssetSentOutID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"AssetSentOutDetails\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE_ACTION" + " = " + "TRUNCATE");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_5 = null;
	dbschema_tDBOutput_5 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_5 = null;
if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
	tableName_tDBOutput_5 = ("AssetSentOutDetails");
} else {
	tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "\".\"" + ("AssetSentOutDetails");
}


int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

boolean whetherReject_tDBOutput_5 = false;

java.sql.Connection conn_tDBOutput_5 = null;
String dbUser_tDBOutput_5 = null;

	conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_5 = 10000;
   int batchSizeCounter_tDBOutput_5=0;

int count_tDBOutput_5=0;
            int rsTruncCountNumber_tDBOutput_5 = 0;
            try(java.sql.Statement stmtTruncCount_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                try (java.sql.ResultSet rsTruncCount_tDBOutput_5 = stmtTruncCount_tDBOutput_5.executeQuery("SELECT COUNT(1) FROM \"" + tableName_tDBOutput_5 + "\"")) {
                    if(rsTruncCount_tDBOutput_5.next()) {
                        rsTruncCountNumber_tDBOutput_5 = rsTruncCount_tDBOutput_5.getInt(1);
                    }
                }
            }
            try (java.sql.Statement stmtTrunc_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Truncating")  + (" table '")  + ("\"" +tableName_tDBOutput_5+ "\"")  + ("'.") );
                stmtTrunc_tDBOutput_5.executeUpdate("TRUNCATE TABLE \"" + tableName_tDBOutput_5 + "\"");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Truncate")  + (" table '")  + ("\"" +tableName_tDBOutput_5+ "\"")  + ("' has succeeded.") );
                deletedCount_tDBOutput_5 += rsTruncCountNumber_tDBOutput_5;
            }
        java.lang.StringBuilder sb_tDBOutput_5 = new java.lang.StringBuilder();
        sb_tDBOutput_5.append("INSERT INTO \"").append(tableName_tDBOutput_5).append("\" (\"AssetSentOutID\",\"AssetID\",\"CompanyID\",\"AssetOutDate\",\"AssetMaintenanceContractDetailID\",\"AssetWarrantyDetailID\",\"AssetInsuranceDetailID\",\"ServiceID\",\"Incharge\",\"Sender\",\"TicketRefNo\",\"VendorID\",\"Remarks\",\"ExpectedDateOfReturn\",\"InchargeFrom\",\"IsReceived\",\"StatusId\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_5 = sb_tDBOutput_5.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing '")  + (insert_tDBOutput_5)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
	    resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
	    

 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		
		int tos_count_tDBInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
                    log4jParamters_tDBInput_5.append("Parameters:");
                            log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"AssetSentOutDetails\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERY" + " = " + "\"SELECT FAMS.AssetSentOutDetails.AssetSentOutID, 		FAMS.AssetSentOutDetails.AssetID, 		FAMS.AssetSentOutDetails.CompanyID, 		FAMS.AssetSentOutDetails.AssetOutDate, 		FAMS.AssetSentOutDetails.AssetMaintenanceContractDetailID, 		FAMS.AssetSentOutDetails.AssetWarrantyDetailID, 		FAMS.AssetSentOutDetails.AssetInsuranceDetailID, 		FAMS.AssetSentOutDetails.ServiceID, 		FAMS.AssetSentOutDetails.Incharge, 		FAMS.AssetSentOutDetails.Sender, 		FAMS.AssetSentOutDetails.TicketRefNo, 		FAMS.AssetSentOutDetails.VendorID, 		FAMS.AssetSentOutDetails.Remarks, 		FAMS.AssetSentOutDetails.ExpectedDateOfReturn, 		FAMS.AssetSentOutDetails.InchargeFrom, 		FAMS.AssetSentOutDetails.IsReceived, 		FAMS.AssetSentOutDetails.StatusId FROM	FAMS.AssetSentOutDetails\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSentOutID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetOutDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetMaintenanceContractDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetWarrantyDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetInsuranceDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ServiceID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Incharge")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Sender")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TicketRefNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ExpectedDateOfReturn")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("InchargeFrom")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IsReceived")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("StatusId")+"}]");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + (log4jParamters_tDBInput_5) );
                    } 
                } 
            new BytesLimit65535_tDBInput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_5", "\"AssetSentOutDetails\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_5 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_5 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_5  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_5, talendToDBArray_tDBInput_5); 
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				conn_tDBInput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_5 != null) {
					if(conn_tDBInput_5.getMetaData() != null) {
						
							log.debug("tDBInput_5 - Uses an existing connection with username '" + conn_tDBInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_5 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();

		    String dbquery_tDBInput_5 = "SELECT FAMS.AssetSentOutDetails.AssetSentOutID,\n		FAMS.AssetSentOutDetails.AssetID,\n		FAMS.AssetSentOutDetails.CompanyI"
+"D,\n		FAMS.AssetSentOutDetails.AssetOutDate,\n		FAMS.AssetSentOutDetails.AssetMaintenanceContractDetailID,\n		FAMS.AssetSen"
+"tOutDetails.AssetWarrantyDetailID,\n		FAMS.AssetSentOutDetails.AssetInsuranceDetailID,\n		FAMS.AssetSentOutDetails.Service"
+"ID,\n		FAMS.AssetSentOutDetails.Incharge,\n		FAMS.AssetSentOutDetails.Sender,\n		FAMS.AssetSentOutDetails.TicketRefNo,\n		FA"
+"MS.AssetSentOutDetails.VendorID,\n		FAMS.AssetSentOutDetails.Remarks,\n		FAMS.AssetSentOutDetails.ExpectedDateOfReturn,\n		"
+"FAMS.AssetSentOutDetails.InchargeFrom,\n		FAMS.AssetSentOutDetails.IsReceived,\n		FAMS.AssetSentOutDetails.StatusId\nFROM	F"
+"AMS.AssetSentOutDetails";
		    
	    		log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");
			

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    	log.debug("tDBInput_5 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row5.AssetSentOutID = 0;
							} else {
		                          
            row5.AssetSentOutID = rs_tDBInput_5.getInt(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row5.AssetID = 0;
							} else {
		                          
            row5.AssetID = rs_tDBInput_5.getInt(2);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row5.CompanyID = 0;
							} else {
		                          
            row5.CompanyID = rs_tDBInput_5.getInt(3);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row5.AssetOutDate = null;
							} else {
										
			row5.AssetOutDate = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 4);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row5.AssetMaintenanceContractDetailID = null;
							} else {
		                          
            row5.AssetMaintenanceContractDetailID = rs_tDBInput_5.getInt(5);
            if(rs_tDBInput_5.wasNull()){
                    row5.AssetMaintenanceContractDetailID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row5.AssetWarrantyDetailID = null;
							} else {
		                          
            row5.AssetWarrantyDetailID = rs_tDBInput_5.getInt(6);
            if(rs_tDBInput_5.wasNull()){
                    row5.AssetWarrantyDetailID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 7) {
								row5.AssetInsuranceDetailID = null;
							} else {
		                          
            row5.AssetInsuranceDetailID = rs_tDBInput_5.getInt(7);
            if(rs_tDBInput_5.wasNull()){
                    row5.AssetInsuranceDetailID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 8) {
								row5.ServiceID = 0;
							} else {
		                          
            row5.ServiceID = rs_tDBInput_5.getInt(8);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 9) {
								row5.Incharge = null;
							} else {
		                          
            row5.Incharge = rs_tDBInput_5.getInt(9);
            if(rs_tDBInput_5.wasNull()){
                    row5.Incharge = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 10) {
								row5.Sender = 0;
							} else {
		                          
            row5.Sender = rs_tDBInput_5.getInt(10);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 11) {
								row5.TicketRefNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(11);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.TicketRefNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.TicketRefNo = tmpContent_tDBInput_5;
                }
            } else {
                row5.TicketRefNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 12) {
								row5.VendorID = 0;
							} else {
		                          
            row5.VendorID = rs_tDBInput_5.getInt(12);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 13) {
								row5.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(13);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.Remarks = tmpContent_tDBInput_5;
                }
            } else {
                row5.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 14) {
								row5.ExpectedDateOfReturn = null;
							} else {
										
			row5.ExpectedDateOfReturn = mssqlGTU_tDBInput_5.getDate(rsmd_tDBInput_5, rs_tDBInput_5, 14);
			
		                    }
							if(colQtyInRs_tDBInput_5 < 15) {
								row5.InchargeFrom = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(15);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.InchargeFrom = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.InchargeFrom = tmpContent_tDBInput_5;
                }
            } else {
                row5.InchargeFrom = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 16) {
								row5.IsReceived = 0;
							} else {
		                          
            row5.IsReceived = rs_tDBInput_5.getShort(16);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 17) {
								row5.StatusId = null;
							} else {
	                         		
           		tmpContent_tDBInput_5 = rs_tDBInput_5.getString(17);
            if(tmpContent_tDBInput_5 != null) {
            	if (talendToDBList_tDBInput_5 .contains(rsmd_tDBInput_5.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row5.StatusId = FormatterUtils.formatUnwithE(tmpContent_tDBInput_5);
            	} else {
                	row5.StatusId = tmpContent_tDBInput_5;
                }
            } else {
                row5.StatusId = null;
            }
		                    }
					
						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");
					





 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tDBInput_5","\"AssetSentOutDetails\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		



        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, row5.AssetSentOutID);

                    pstmt_tDBOutput_5.setInt(2, row5.AssetID);

                    pstmt_tDBOutput_5.setInt(3, row5.CompanyID);

                    if(row5.AssetOutDate != null) {
pstmt_tDBOutput_5.setTimestamp(4, new java.sql.Timestamp(row5.AssetOutDate.getTime()));
} else {
pstmt_tDBOutput_5.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row5.AssetMaintenanceContractDetailID == null) {
pstmt_tDBOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(5, row5.AssetMaintenanceContractDetailID);
}

                    if(row5.AssetWarrantyDetailID == null) {
pstmt_tDBOutput_5.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(6, row5.AssetWarrantyDetailID);
}

                    if(row5.AssetInsuranceDetailID == null) {
pstmt_tDBOutput_5.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(7, row5.AssetInsuranceDetailID);
}

                    pstmt_tDBOutput_5.setInt(8, row5.ServiceID);

                    if(row5.Incharge == null) {
pstmt_tDBOutput_5.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(9, row5.Incharge);
}

                    pstmt_tDBOutput_5.setInt(10, row5.Sender);

                    if(row5.TicketRefNo == null) {
pstmt_tDBOutput_5.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(11, row5.TicketRefNo);
}

                    pstmt_tDBOutput_5.setInt(12, row5.VendorID);

                    if(row5.Remarks == null) {
pstmt_tDBOutput_5.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(13, row5.Remarks);
}

                    if(row5.ExpectedDateOfReturn != null) {
pstmt_tDBOutput_5.setTimestamp(14, new java.sql.Timestamp(row5.ExpectedDateOfReturn.getTime()));
} else {
pstmt_tDBOutput_5.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(row5.InchargeFrom == null) {
pstmt_tDBOutput_5.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(15, row5.InchargeFrom);
}

                    pstmt_tDBOutput_5.setShort(16, row5.IsReceived);

                    if(row5.StatusId == null) {
pstmt_tDBOutput_5.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(17, row5.StatusId);
}

			
    		pstmt_tDBOutput_5.addBatch();
    		nb_line_tDBOutput_5++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_5++;
    		  
    			if ((batchSize_tDBOutput_5 > 0) && (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {
                try {
						int countSum_tDBOutput_5 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            	    	batchSizeCounter_tDBOutput_5 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
				    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
				    	String errormessage_tDBOutput_5;
						if (ne_tDBOutput_5 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
							errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
						}else{
							errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
						}
				    	
				    	int countSum_tDBOutput_5 = 0;
						for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
				    	System.err.println(errormessage_tDBOutput_5);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
}
globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
	    		log.debug("tDBInput_5 - Retrieved records count: "+nb_line_tDBInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Done.") );

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());




/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_5 = 0;
				if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
	    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
	    	String errormessage_tDBOutput_5;
			if (ne_tDBOutput_5 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
				errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
			}else{
				errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
			}
	    	
	    	int countSum_tDBOutput_5 = 0;
			for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
				countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
			}
			rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
			
	    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
	    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
	    	System.err.println(errormessage_tDBOutput_5);
	    	
		}
	    
        if(pstmt_tDBOutput_5 != null) {
        		
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_5)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tDBInput_5","\"AssetSentOutDetails\"","tMSSqlInput","tDBOutput_5","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"AssetSentOutDetails\"";
		

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int EmailDetailsid;

				public int getEmailDetailsid () {
					return this.EmailDetailsid;
				}

				public Boolean EmailDetailsidIsNullable(){
				    return false;
				}
				public Boolean EmailDetailsidIsKey(){
				    return true;
				}
				public Integer EmailDetailsidLength(){
				    return 10;
				}
				public Integer EmailDetailsidPrecision(){
				    return 0;
				}
				public String EmailDetailsidDefault(){
				
					return null;
				
				}
				public String EmailDetailsidComment(){
				
				    return "";
				
				}
				public String EmailDetailsidPattern(){
				
					return "";
				
				}
				public String EmailDetailsidOriginalDbColumnName(){
				
					return "EmailDetailsid";
				
				}

				
			    public Integer AssetSentOutID;

				public Integer getAssetSentOutID () {
					return this.AssetSentOutID;
				}

				public Boolean AssetSentOutIDIsNullable(){
				    return true;
				}
				public Boolean AssetSentOutIDIsKey(){
				    return false;
				}
				public Integer AssetSentOutIDLength(){
				    return 10;
				}
				public Integer AssetSentOutIDPrecision(){
				    return 0;
				}
				public String AssetSentOutIDDefault(){
				
					return null;
				
				}
				public String AssetSentOutIDComment(){
				
				    return "";
				
				}
				public String AssetSentOutIDPattern(){
				
					return "";
				
				}
				public String AssetSentOutIDOriginalDbColumnName(){
				
					return "AssetSentOutID";
				
				}

				
			    public Integer AssetId;

				public Integer getAssetId () {
					return this.AssetId;
				}

				public Boolean AssetIdIsNullable(){
				    return true;
				}
				public Boolean AssetIdIsKey(){
				    return false;
				}
				public Integer AssetIdLength(){
				    return 10;
				}
				public Integer AssetIdPrecision(){
				    return 0;
				}
				public String AssetIdDefault(){
				
					return null;
				
				}
				public String AssetIdComment(){
				
				    return "";
				
				}
				public String AssetIdPattern(){
				
					return "";
				
				}
				public String AssetIdOriginalDbColumnName(){
				
					return "AssetId";
				
				}

				
			    public String TicketRefNo;

				public String getTicketRefNo () {
					return this.TicketRefNo;
				}

				public Boolean TicketRefNoIsNullable(){
				    return true;
				}
				public Boolean TicketRefNoIsKey(){
				    return false;
				}
				public Integer TicketRefNoLength(){
				    return 200;
				}
				public Integer TicketRefNoPrecision(){
				    return 0;
				}
				public String TicketRefNoDefault(){
				
					return null;
				
				}
				public String TicketRefNoComment(){
				
				    return "";
				
				}
				public String TicketRefNoPattern(){
				
					return "";
				
				}
				public String TicketRefNoOriginalDbColumnName(){
				
					return "TicketRefNo";
				
				}

				
			    public java.util.Date AssetOutDate;

				public java.util.Date getAssetOutDate () {
					return this.AssetOutDate;
				}

				public Boolean AssetOutDateIsNullable(){
				    return true;
				}
				public Boolean AssetOutDateIsKey(){
				    return false;
				}
				public Integer AssetOutDateLength(){
				    return 23;
				}
				public Integer AssetOutDatePrecision(){
				    return 3;
				}
				public String AssetOutDateDefault(){
				
					return null;
				
				}
				public String AssetOutDateComment(){
				
				    return "";
				
				}
				public String AssetOutDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String AssetOutDateOriginalDbColumnName(){
				
					return "AssetOutDate";
				
				}

				
			    public String AssetCode;

				public String getAssetCode () {
					return this.AssetCode;
				}

				public Boolean AssetCodeIsNullable(){
				    return true;
				}
				public Boolean AssetCodeIsKey(){
				    return false;
				}
				public Integer AssetCodeLength(){
				    return 100;
				}
				public Integer AssetCodePrecision(){
				    return 0;
				}
				public String AssetCodeDefault(){
				
					return null;
				
				}
				public String AssetCodeComment(){
				
				    return "";
				
				}
				public String AssetCodePattern(){
				
					return "";
				
				}
				public String AssetCodeOriginalDbColumnName(){
				
					return "AssetCode";
				
				}

				
			    public String AssetUser;

				public String getAssetUser () {
					return this.AssetUser;
				}

				public Boolean AssetUserIsNullable(){
				    return true;
				}
				public Boolean AssetUserIsKey(){
				    return false;
				}
				public Integer AssetUserLength(){
				    return 200;
				}
				public Integer AssetUserPrecision(){
				    return 0;
				}
				public String AssetUserDefault(){
				
					return null;
				
				}
				public String AssetUserComment(){
				
				    return "";
				
				}
				public String AssetUserPattern(){
				
					return "";
				
				}
				public String AssetUserOriginalDbColumnName(){
				
					return "AssetUser";
				
				}

				
			    public String UnderWarranty;

				public String getUnderWarranty () {
					return this.UnderWarranty;
				}

				public Boolean UnderWarrantyIsNullable(){
				    return true;
				}
				public Boolean UnderWarrantyIsKey(){
				    return false;
				}
				public Integer UnderWarrantyLength(){
				    return 100;
				}
				public Integer UnderWarrantyPrecision(){
				    return 0;
				}
				public String UnderWarrantyDefault(){
				
					return null;
				
				}
				public String UnderWarrantyComment(){
				
				    return "";
				
				}
				public String UnderWarrantyPattern(){
				
					return "";
				
				}
				public String UnderWarrantyOriginalDbColumnName(){
				
					return "UnderWarranty";
				
				}

				
			    public String UnderAmc;

				public String getUnderAmc () {
					return this.UnderAmc;
				}

				public Boolean UnderAmcIsNullable(){
				    return true;
				}
				public Boolean UnderAmcIsKey(){
				    return false;
				}
				public Integer UnderAmcLength(){
				    return 100;
				}
				public Integer UnderAmcPrecision(){
				    return 0;
				}
				public String UnderAmcDefault(){
				
					return null;
				
				}
				public String UnderAmcComment(){
				
				    return "";
				
				}
				public String UnderAmcPattern(){
				
					return "";
				
				}
				public String UnderAmcOriginalDbColumnName(){
				
					return "UnderAmc";
				
				}

				
			    public String UnderInsurance;

				public String getUnderInsurance () {
					return this.UnderInsurance;
				}

				public Boolean UnderInsuranceIsNullable(){
				    return true;
				}
				public Boolean UnderInsuranceIsKey(){
				    return false;
				}
				public Integer UnderInsuranceLength(){
				    return 100;
				}
				public Integer UnderInsurancePrecision(){
				    return 0;
				}
				public String UnderInsuranceDefault(){
				
					return null;
				
				}
				public String UnderInsuranceComment(){
				
				    return "";
				
				}
				public String UnderInsurancePattern(){
				
					return "";
				
				}
				public String UnderInsuranceOriginalDbColumnName(){
				
					return "UnderInsurance";
				
				}

				
			    public String ServiceDescription;

				public String getServiceDescription () {
					return this.ServiceDescription;
				}

				public Boolean ServiceDescriptionIsNullable(){
				    return true;
				}
				public Boolean ServiceDescriptionIsKey(){
				    return false;
				}
				public Integer ServiceDescriptionLength(){
				    return 500;
				}
				public Integer ServiceDescriptionPrecision(){
				    return 0;
				}
				public String ServiceDescriptionDefault(){
				
					return null;
				
				}
				public String ServiceDescriptionComment(){
				
				    return "";
				
				}
				public String ServiceDescriptionPattern(){
				
					return "";
				
				}
				public String ServiceDescriptionOriginalDbColumnName(){
				
					return "ServiceDescription";
				
				}

				
			    public String Sender;

				public String getSender () {
					return this.Sender;
				}

				public Boolean SenderIsNullable(){
				    return true;
				}
				public Boolean SenderIsKey(){
				    return false;
				}
				public Integer SenderLength(){
				    return 200;
				}
				public Integer SenderPrecision(){
				    return 0;
				}
				public String SenderDefault(){
				
					return null;
				
				}
				public String SenderComment(){
				
				    return "";
				
				}
				public String SenderPattern(){
				
					return "";
				
				}
				public String SenderOriginalDbColumnName(){
				
					return "Sender";
				
				}

				
			    public String VendorName;

				public String getVendorName () {
					return this.VendorName;
				}

				public Boolean VendorNameIsNullable(){
				    return true;
				}
				public Boolean VendorNameIsKey(){
				    return false;
				}
				public Integer VendorNameLength(){
				    return 200;
				}
				public Integer VendorNamePrecision(){
				    return 0;
				}
				public String VendorNameDefault(){
				
					return null;
				
				}
				public String VendorNameComment(){
				
				    return "";
				
				}
				public String VendorNamePattern(){
				
					return "";
				
				}
				public String VendorNameOriginalDbColumnName(){
				
					return "VendorName";
				
				}

				
			    public String Incharge;

				public String getIncharge () {
					return this.Incharge;
				}

				public Boolean InchargeIsNullable(){
				    return true;
				}
				public Boolean InchargeIsKey(){
				    return false;
				}
				public Integer InchargeLength(){
				    return 200;
				}
				public Integer InchargePrecision(){
				    return 0;
				}
				public String InchargeDefault(){
				
					return null;
				
				}
				public String InchargeComment(){
				
				    return "";
				
				}
				public String InchargePattern(){
				
					return "";
				
				}
				public String InchargeOriginalDbColumnName(){
				
					return "Incharge";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 200;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public java.util.Date ExpectedDate;

				public java.util.Date getExpectedDate () {
					return this.ExpectedDate;
				}

				public Boolean ExpectedDateIsNullable(){
				    return true;
				}
				public Boolean ExpectedDateIsKey(){
				    return false;
				}
				public Integer ExpectedDateLength(){
				    return 23;
				}
				public Integer ExpectedDatePrecision(){
				    return 3;
				}
				public String ExpectedDateDefault(){
				
					return null;
				
				}
				public String ExpectedDateComment(){
				
				    return "";
				
				}
				public String ExpectedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ExpectedDateOriginalDbColumnName(){
				
					return "ExpectedDate";
				
				}

				
			    public java.util.Date createddate;

				public java.util.Date getCreateddate () {
					return this.createddate;
				}

				public Boolean createddateIsNullable(){
				    return true;
				}
				public Boolean createddateIsKey(){
				    return false;
				}
				public Integer createddateLength(){
				    return 23;
				}
				public Integer createddatePrecision(){
				    return 3;
				}
				public String createddateDefault(){
				
					return null;
				
				}
				public String createddateComment(){
				
				    return "";
				
				}
				public String createddatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String createddateOriginalDbColumnName(){
				
					return "createddate";
				
				}

				
			    public String AssetUserEmail;

				public String getAssetUserEmail () {
					return this.AssetUserEmail;
				}

				public Boolean AssetUserEmailIsNullable(){
				    return true;
				}
				public Boolean AssetUserEmailIsKey(){
				    return false;
				}
				public Integer AssetUserEmailLength(){
				    return 200;
				}
				public Integer AssetUserEmailPrecision(){
				    return 0;
				}
				public String AssetUserEmailDefault(){
				
					return null;
				
				}
				public String AssetUserEmailComment(){
				
				    return "";
				
				}
				public String AssetUserEmailPattern(){
				
					return "";
				
				}
				public String AssetUserEmailOriginalDbColumnName(){
				
					return "AssetUserEmail";
				
				}

				
			    public String senderEmail;

				public String getSenderEmail () {
					return this.senderEmail;
				}

				public Boolean senderEmailIsNullable(){
				    return true;
				}
				public Boolean senderEmailIsKey(){
				    return false;
				}
				public Integer senderEmailLength(){
				    return 200;
				}
				public Integer senderEmailPrecision(){
				    return 0;
				}
				public String senderEmailDefault(){
				
					return null;
				
				}
				public String senderEmailComment(){
				
				    return "";
				
				}
				public String senderEmailPattern(){
				
					return "";
				
				}
				public String senderEmailOriginalDbColumnName(){
				
					return "senderEmail";
				
				}

				
			    public String vendorEmail;

				public String getVendorEmail () {
					return this.vendorEmail;
				}

				public Boolean vendorEmailIsNullable(){
				    return true;
				}
				public Boolean vendorEmailIsKey(){
				    return false;
				}
				public Integer vendorEmailLength(){
				    return 200;
				}
				public Integer vendorEmailPrecision(){
				    return 0;
				}
				public String vendorEmailDefault(){
				
					return null;
				
				}
				public String vendorEmailComment(){
				
				    return "";
				
				}
				public String vendorEmailPattern(){
				
					return "";
				
				}
				public String vendorEmailOriginalDbColumnName(){
				
					return "vendorEmail";
				
				}

				
			    public String inChargeEmail;

				public String getInChargeEmail () {
					return this.inChargeEmail;
				}

				public Boolean inChargeEmailIsNullable(){
				    return true;
				}
				public Boolean inChargeEmailIsKey(){
				    return false;
				}
				public Integer inChargeEmailLength(){
				    return 200;
				}
				public Integer inChargeEmailPrecision(){
				    return 0;
				}
				public String inChargeEmailDefault(){
				
					return null;
				
				}
				public String inChargeEmailComment(){
				
				    return "";
				
				}
				public String inChargeEmailPattern(){
				
					return "";
				
				}
				public String inChargeEmailOriginalDbColumnName(){
				
					return "inChargeEmail";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.EmailDetailsid;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.EmailDetailsid != other.EmailDetailsid)
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.EmailDetailsid = this.EmailDetailsid;
	            other.AssetSentOutID = this.AssetSentOutID;
	            other.AssetId = this.AssetId;
	            other.TicketRefNo = this.TicketRefNo;
	            other.AssetOutDate = this.AssetOutDate;
	            other.AssetCode = this.AssetCode;
	            other.AssetUser = this.AssetUser;
	            other.UnderWarranty = this.UnderWarranty;
	            other.UnderAmc = this.UnderAmc;
	            other.UnderInsurance = this.UnderInsurance;
	            other.ServiceDescription = this.ServiceDescription;
	            other.Sender = this.Sender;
	            other.VendorName = this.VendorName;
	            other.Incharge = this.Incharge;
	            other.Remarks = this.Remarks;
	            other.ExpectedDate = this.ExpectedDate;
	            other.createddate = this.createddate;
	            other.AssetUserEmail = this.AssetUserEmail;
	            other.senderEmail = this.senderEmail;
	            other.vendorEmail = this.vendorEmail;
	            other.inChargeEmail = this.inChargeEmail;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.EmailDetailsid = this.EmailDetailsid;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_9, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.EmailDetailsid = dis.readInt();
					
						this.AssetSentOutID = readInteger(dis);
					
						this.AssetId = readInteger(dis);
					
					this.TicketRefNo = readString(dis);
					
					this.AssetOutDate = readDate(dis);
					
					this.AssetCode = readString(dis);
					
					this.AssetUser = readString(dis);
					
					this.UnderWarranty = readString(dis);
					
					this.UnderAmc = readString(dis);
					
					this.UnderInsurance = readString(dis);
					
					this.ServiceDescription = readString(dis);
					
					this.Sender = readString(dis);
					
					this.VendorName = readString(dis);
					
					this.Incharge = readString(dis);
					
					this.Remarks = readString(dis);
					
					this.ExpectedDate = readDate(dis);
					
					this.createddate = readDate(dis);
					
					this.AssetUserEmail = readString(dis);
					
					this.senderEmail = readString(dis);
					
					this.vendorEmail = readString(dis);
					
					this.inChargeEmail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_9) {

        	try {

        		int length = 0;
		
			        this.EmailDetailsid = dis.readInt();
					
						this.AssetSentOutID = readInteger(dis);
					
						this.AssetId = readInteger(dis);
					
					this.TicketRefNo = readString(dis);
					
					this.AssetOutDate = readDate(dis);
					
					this.AssetCode = readString(dis);
					
					this.AssetUser = readString(dis);
					
					this.UnderWarranty = readString(dis);
					
					this.UnderAmc = readString(dis);
					
					this.UnderInsurance = readString(dis);
					
					this.ServiceDescription = readString(dis);
					
					this.Sender = readString(dis);
					
					this.VendorName = readString(dis);
					
					this.Incharge = readString(dis);
					
					this.Remarks = readString(dis);
					
					this.ExpectedDate = readDate(dis);
					
					this.createddate = readDate(dis);
					
					this.AssetUserEmail = readString(dis);
					
					this.senderEmail = readString(dis);
					
					this.vendorEmail = readString(dis);
					
					this.inChargeEmail = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmailDetailsid);
					
					// Integer
				
						writeInteger(this.AssetSentOutID,dos);
					
					// Integer
				
						writeInteger(this.AssetId,dos);
					
					// String
				
						writeString(this.TicketRefNo,dos);
					
					// java.util.Date
				
						writeDate(this.AssetOutDate,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.AssetUser,dos);
					
					// String
				
						writeString(this.UnderWarranty,dos);
					
					// String
				
						writeString(this.UnderAmc,dos);
					
					// String
				
						writeString(this.UnderInsurance,dos);
					
					// String
				
						writeString(this.ServiceDescription,dos);
					
					// String
				
						writeString(this.Sender,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// String
				
						writeString(this.Incharge,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// java.util.Date
				
						writeDate(this.ExpectedDate,dos);
					
					// java.util.Date
				
						writeDate(this.createddate,dos);
					
					// String
				
						writeString(this.AssetUserEmail,dos);
					
					// String
				
						writeString(this.senderEmail,dos);
					
					// String
				
						writeString(this.vendorEmail,dos);
					
					// String
				
						writeString(this.inChargeEmail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.EmailDetailsid);
					
					// Integer
				
						writeInteger(this.AssetSentOutID,dos);
					
					// Integer
				
						writeInteger(this.AssetId,dos);
					
					// String
				
						writeString(this.TicketRefNo,dos);
					
					// java.util.Date
				
						writeDate(this.AssetOutDate,dos);
					
					// String
				
						writeString(this.AssetCode,dos);
					
					// String
				
						writeString(this.AssetUser,dos);
					
					// String
				
						writeString(this.UnderWarranty,dos);
					
					// String
				
						writeString(this.UnderAmc,dos);
					
					// String
				
						writeString(this.UnderInsurance,dos);
					
					// String
				
						writeString(this.ServiceDescription,dos);
					
					// String
				
						writeString(this.Sender,dos);
					
					// String
				
						writeString(this.VendorName,dos);
					
					// String
				
						writeString(this.Incharge,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// java.util.Date
				
						writeDate(this.ExpectedDate,dos);
					
					// java.util.Date
				
						writeDate(this.createddate,dos);
					
					// String
				
						writeString(this.AssetUserEmail,dos);
					
					// String
				
						writeString(this.senderEmail,dos);
					
					// String
				
						writeString(this.vendorEmail,dos);
					
					// String
				
						writeString(this.inChargeEmail,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("EmailDetailsid="+String.valueOf(EmailDetailsid));
		sb.append(",AssetSentOutID="+String.valueOf(AssetSentOutID));
		sb.append(",AssetId="+String.valueOf(AssetId));
		sb.append(",TicketRefNo="+TicketRefNo);
		sb.append(",AssetOutDate="+String.valueOf(AssetOutDate));
		sb.append(",AssetCode="+AssetCode);
		sb.append(",AssetUser="+AssetUser);
		sb.append(",UnderWarranty="+UnderWarranty);
		sb.append(",UnderAmc="+UnderAmc);
		sb.append(",UnderInsurance="+UnderInsurance);
		sb.append(",ServiceDescription="+ServiceDescription);
		sb.append(",Sender="+Sender);
		sb.append(",VendorName="+VendorName);
		sb.append(",Incharge="+Incharge);
		sb.append(",Remarks="+Remarks);
		sb.append(",ExpectedDate="+String.valueOf(ExpectedDate));
		sb.append(",createddate="+String.valueOf(createddate));
		sb.append(",AssetUserEmail="+AssetUserEmail);
		sb.append(",senderEmail="+senderEmail);
		sb.append(",vendorEmail="+vendorEmail);
		sb.append(",inChargeEmail="+inChargeEmail);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(EmailDetailsid);
        			
        			sb.append("|");
        		
        				if(AssetSentOutID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetSentOutID);
            			}
            		
        			sb.append("|");
        		
        				if(AssetId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetId);
            			}
            		
        			sb.append("|");
        		
        				if(TicketRefNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TicketRefNo);
            			}
            		
        			sb.append("|");
        		
        				if(AssetOutDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetOutDate);
            			}
            		
        			sb.append("|");
        		
        				if(AssetCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetCode);
            			}
            		
        			sb.append("|");
        		
        				if(AssetUser == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetUser);
            			}
            		
        			sb.append("|");
        		
        				if(UnderWarranty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UnderWarranty);
            			}
            		
        			sb.append("|");
        		
        				if(UnderAmc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UnderAmc);
            			}
            		
        			sb.append("|");
        		
        				if(UnderInsurance == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UnderInsurance);
            			}
            		
        			sb.append("|");
        		
        				if(ServiceDescription == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ServiceDescription);
            			}
            		
        			sb.append("|");
        		
        				if(Sender == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Sender);
            			}
            		
        			sb.append("|");
        		
        				if(VendorName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorName);
            			}
            		
        			sb.append("|");
        		
        				if(Incharge == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Incharge);
            			}
            		
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				if(ExpectedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ExpectedDate);
            			}
            		
        			sb.append("|");
        		
        				if(createddate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(createddate);
            			}
            		
        			sb.append("|");
        		
        				if(AssetUserEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(AssetUserEmail);
            			}
            		
        			sb.append("|");
        		
        				if(senderEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(senderEmail);
            			}
            		
        			sb.append("|");
        		
        				if(vendorEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(vendorEmail);
            			}
            		
        			sb.append("|");
        		
        				if(inChargeEmail == null){
        					sb.append("<null>");
        				}else{
            				sb.append(inChargeEmail);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.EmailDetailsid, other.EmailDetailsid);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tDBOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
                    log4jParamters_tDBOutput_6.append("Parameters:");
                            log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"AssetSentOutDetailsEmailDetails\"");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + (log4jParamters_tDBOutput_6) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_6", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_6 = null;
	dbschema_tDBOutput_6 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_6 = null;
if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
	tableName_tDBOutput_6 = ("AssetSentOutDetailsEmailDetails");
} else {
	tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "\".\"" + ("AssetSentOutDetailsEmailDetails");
}


int nb_line_tDBOutput_6 = 0;
int nb_line_update_tDBOutput_6 = 0;
int nb_line_inserted_tDBOutput_6 = 0;
int nb_line_deleted_tDBOutput_6 = 0;
int nb_line_rejected_tDBOutput_6 = 0;

int deletedCount_tDBOutput_6=0;
int updatedCount_tDBOutput_6=0;
int insertedCount_tDBOutput_6=0;
int rowsToCommitCount_tDBOutput_6=0;
int rejectedCount_tDBOutput_6=0;

boolean whetherReject_tDBOutput_6 = false;

java.sql.Connection conn_tDBOutput_6 = null;
String dbUser_tDBOutput_6 = null;

	conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_6.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_6.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_6 = 10000;
   int batchSizeCounter_tDBOutput_6=0;

int count_tDBOutput_6=0;
        java.lang.StringBuilder sb_tDBOutput_6 = new java.lang.StringBuilder();
        sb_tDBOutput_6.append("INSERT INTO \"").append(tableName_tDBOutput_6).append("\" (\"EmailDetailsid\",\"AssetSentOutID\",\"AssetId\",\"TicketRefNo\",\"AssetOutDate\",\"AssetCode\",\"AssetUser\",\"UnderWarranty\",\"UnderAmc\",\"UnderInsurance\",\"ServiceDescription\",\"Sender\",\"VendorName\",\"Incharge\",\"Remarks\",\"ExpectedDate\",\"createddate\",\"AssetUserEmail\",\"senderEmail\",\"vendorEmail\",\"inChargeEmail\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_6 = sb_tDBOutput_6.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing '")  + (insert_tDBOutput_6)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
	    resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
	    

 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		
		int tos_count_tDBInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
                    log4jParamters_tDBInput_6.append("Parameters:");
                            log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"AssetSentOutDetailsEmailDetails\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERY" + " = " + "\"SELECT FAMS.AssetSentOutDetailsEmailDetails.EmailDetailsid, 		FAMS.AssetSentOutDetailsEmailDetails.AssetSentOutID, 		FAMS.AssetSentOutDetailsEmailDetails.AssetId, 		FAMS.AssetSentOutDetailsEmailDetails.TicketRefNo, 		FAMS.AssetSentOutDetailsEmailDetails.AssetOutDate, 		FAMS.AssetSentOutDetailsEmailDetails.AssetCode, 		FAMS.AssetSentOutDetailsEmailDetails.AssetUser, 		FAMS.AssetSentOutDetailsEmailDetails.UnderWarranty, 		FAMS.AssetSentOutDetailsEmailDetails.UnderAmc, 		FAMS.AssetSentOutDetailsEmailDetails.UnderInsurance, 		FAMS.AssetSentOutDetailsEmailDetails.ServiceDescription, 		FAMS.AssetSentOutDetailsEmailDetails.Sender, 		FAMS.AssetSentOutDetailsEmailDetails.VendorName, 		FAMS.AssetSentOutDetailsEmailDetails.Incharge, 		FAMS.AssetSentOutDetailsEmailDetails.Remarks, 		FAMS.AssetSentOutDetailsEmailDetails.ExpectedDate, 		FAMS.AssetSentOutDetailsEmailDetails.createddate, 		FAMS.AssetSentOutDetailsEmailDetails.AssetUserEmail, 		FAMS.AssetSentOutDetailsEmailDetails.senderEmail, 		FAMS.AssetSentOutDetailsEmailDetails.vendorEmail, 		FAMS.AssetSentOutDetailsEmailDetails.inChargeEmail FROM	FAMS.AssetSentOutDetailsEmailDetails  WHERE FAMS.AssetSentOutDetailsEmailDetails.createddate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.AssetSentOutDetailsEmailDetails.createddate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("EmailDetailsid")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetSentOutID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetId")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TicketRefNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetOutDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCode")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetUser")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UnderWarranty")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UnderAmc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("UnderInsurance")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ServiceDescription")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Sender")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorName")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Incharge")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ExpectedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("createddate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetUserEmail")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("senderEmail")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("vendorEmail")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("inChargeEmail")+"}]");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + (log4jParamters_tDBInput_6) );
                    } 
                } 
            new BytesLimit65535_tDBInput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_6", "\"AssetSentOutDetailsEmailDetails\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_6 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_6 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_6  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_6, talendToDBArray_tDBInput_6); 
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				conn_tDBInput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_6 != null) {
					if(conn_tDBInput_6.getMetaData() != null) {
						
							log.debug("tDBInput_6 - Uses an existing connection with username '" + conn_tDBInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_6 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();

		    String dbquery_tDBInput_6 = "SELECT FAMS.AssetSentOutDetailsEmailDetails.EmailDetailsid,\n		FAMS.AssetSentOutDetailsEmailDetails.AssetSentOutID,\n		FA"
+"MS.AssetSentOutDetailsEmailDetails.AssetId,\n		FAMS.AssetSentOutDetailsEmailDetails.TicketRefNo,\n		FAMS.AssetSentOutDetai"
+"lsEmailDetails.AssetOutDate,\n		FAMS.AssetSentOutDetailsEmailDetails.AssetCode,\n		FAMS.AssetSentOutDetailsEmailDetails.As"
+"setUser,\n		FAMS.AssetSentOutDetailsEmailDetails.UnderWarranty,\n		FAMS.AssetSentOutDetailsEmailDetails.UnderAmc,\n		FAMS.A"
+"ssetSentOutDetailsEmailDetails.UnderInsurance,\n		FAMS.AssetSentOutDetailsEmailDetails.ServiceDescription,\n		FAMS.AssetSe"
+"ntOutDetailsEmailDetails.Sender,\n		FAMS.AssetSentOutDetailsEmailDetails.VendorName,\n		FAMS.AssetSentOutDetailsEmailDetai"
+"ls.Incharge,\n		FAMS.AssetSentOutDetailsEmailDetails.Remarks,\n		FAMS.AssetSentOutDetailsEmailDetails.ExpectedDate,\n		FAMS"
+".AssetSentOutDetailsEmailDetails.createddate,\n		FAMS.AssetSentOutDetailsEmailDetails.AssetUserEmail,\n		FAMS.AssetSentOut"
+"DetailsEmailDetails.senderEmail,\n		FAMS.AssetSentOutDetailsEmailDetails.vendorEmail,\n		FAMS.AssetSentOutDetailsEmailDeta"
+"ils.inChargeEmail\nFROM	FAMS.AssetSentOutDetailsEmailDetails\nWHERE FAMS.AssetSentOutDetailsEmailDetails.createddate >= D"
+"ATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAMS.AssetSentOutDetailsEmailDetails.createddate < CAST(GETDATE() AS"
+" DATE)";
		    
	    		log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");
			

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    	log.debug("tDBInput_6 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row6.EmailDetailsid = 0;
							} else {
		                          
            row6.EmailDetailsid = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row6.AssetSentOutID = null;
							} else {
		                          
            row6.AssetSentOutID = rs_tDBInput_6.getInt(2);
            if(rs_tDBInput_6.wasNull()){
                    row6.AssetSentOutID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row6.AssetId = null;
							} else {
		                          
            row6.AssetId = rs_tDBInput_6.getInt(3);
            if(rs_tDBInput_6.wasNull()){
                    row6.AssetId = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row6.TicketRefNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(4);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.TicketRefNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.TicketRefNo = tmpContent_tDBInput_6;
                }
            } else {
                row6.TicketRefNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 5) {
								row6.AssetOutDate = null;
							} else {
										
			row6.AssetOutDate = mssqlGTU_tDBInput_6.getDate(rsmd_tDBInput_6, rs_tDBInput_6, 5);
			
		                    }
							if(colQtyInRs_tDBInput_6 < 6) {
								row6.AssetCode = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(6);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.AssetCode = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.AssetCode = tmpContent_tDBInput_6;
                }
            } else {
                row6.AssetCode = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 7) {
								row6.AssetUser = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(7);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.AssetUser = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.AssetUser = tmpContent_tDBInput_6;
                }
            } else {
                row6.AssetUser = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 8) {
								row6.UnderWarranty = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(8);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.UnderWarranty = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.UnderWarranty = tmpContent_tDBInput_6;
                }
            } else {
                row6.UnderWarranty = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 9) {
								row6.UnderAmc = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(9);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.UnderAmc = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.UnderAmc = tmpContent_tDBInput_6;
                }
            } else {
                row6.UnderAmc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 10) {
								row6.UnderInsurance = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(10);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.UnderInsurance = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.UnderInsurance = tmpContent_tDBInput_6;
                }
            } else {
                row6.UnderInsurance = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 11) {
								row6.ServiceDescription = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(11);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.ServiceDescription = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.ServiceDescription = tmpContent_tDBInput_6;
                }
            } else {
                row6.ServiceDescription = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 12) {
								row6.Sender = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(12);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.Sender = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.Sender = tmpContent_tDBInput_6;
                }
            } else {
                row6.Sender = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 13) {
								row6.VendorName = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(13);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.VendorName = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.VendorName = tmpContent_tDBInput_6;
                }
            } else {
                row6.VendorName = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 14) {
								row6.Incharge = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(14);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.Incharge = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.Incharge = tmpContent_tDBInput_6;
                }
            } else {
                row6.Incharge = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 15) {
								row6.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(15);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.Remarks = tmpContent_tDBInput_6;
                }
            } else {
                row6.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 16) {
								row6.ExpectedDate = null;
							} else {
										
			row6.ExpectedDate = mssqlGTU_tDBInput_6.getDate(rsmd_tDBInput_6, rs_tDBInput_6, 16);
			
		                    }
							if(colQtyInRs_tDBInput_6 < 17) {
								row6.createddate = null;
							} else {
										
			row6.createddate = mssqlGTU_tDBInput_6.getDate(rsmd_tDBInput_6, rs_tDBInput_6, 17);
			
		                    }
							if(colQtyInRs_tDBInput_6 < 18) {
								row6.AssetUserEmail = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(18);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.AssetUserEmail = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.AssetUserEmail = tmpContent_tDBInput_6;
                }
            } else {
                row6.AssetUserEmail = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 19) {
								row6.senderEmail = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(19);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.senderEmail = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.senderEmail = tmpContent_tDBInput_6;
                }
            } else {
                row6.senderEmail = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 20) {
								row6.vendorEmail = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(20);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.vendorEmail = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.vendorEmail = tmpContent_tDBInput_6;
                }
            } else {
                row6.vendorEmail = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 21) {
								row6.inChargeEmail = null;
							} else {
	                         		
           		tmpContent_tDBInput_6 = rs_tDBInput_6.getString(21);
            if(tmpContent_tDBInput_6 != null) {
            	if (talendToDBList_tDBInput_6 .contains(rsmd_tDBInput_6.getColumnTypeName(21).toUpperCase(java.util.Locale.ENGLISH))) {
            		row6.inChargeEmail = FormatterUtils.formatUnwithE(tmpContent_tDBInput_6);
            	} else {
                	row6.inChargeEmail = tmpContent_tDBInput_6;
                }
            } else {
                row6.inChargeEmail = null;
            }
		                    }
					
						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");
					





 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_6","\"AssetSentOutDetailsEmailDetails\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		



        whetherReject_tDBOutput_6 = false;
                    pstmt_tDBOutput_6.setInt(1, row6.EmailDetailsid);

                    if(row6.AssetSentOutID == null) {
pstmt_tDBOutput_6.setNull(2, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(2, row6.AssetSentOutID);
}

                    if(row6.AssetId == null) {
pstmt_tDBOutput_6.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(3, row6.AssetId);
}

                    if(row6.TicketRefNo == null) {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(4, row6.TicketRefNo);
}

                    if(row6.AssetOutDate != null) {
pstmt_tDBOutput_6.setTimestamp(5, new java.sql.Timestamp(row6.AssetOutDate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(row6.AssetCode == null) {
pstmt_tDBOutput_6.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(6, row6.AssetCode);
}

                    if(row6.AssetUser == null) {
pstmt_tDBOutput_6.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(7, row6.AssetUser);
}

                    if(row6.UnderWarranty == null) {
pstmt_tDBOutput_6.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(8, row6.UnderWarranty);
}

                    if(row6.UnderAmc == null) {
pstmt_tDBOutput_6.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(9, row6.UnderAmc);
}

                    if(row6.UnderInsurance == null) {
pstmt_tDBOutput_6.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(10, row6.UnderInsurance);
}

                    if(row6.ServiceDescription == null) {
pstmt_tDBOutput_6.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(11, row6.ServiceDescription);
}

                    if(row6.Sender == null) {
pstmt_tDBOutput_6.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(12, row6.Sender);
}

                    if(row6.VendorName == null) {
pstmt_tDBOutput_6.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(13, row6.VendorName);
}

                    if(row6.Incharge == null) {
pstmt_tDBOutput_6.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(14, row6.Incharge);
}

                    if(row6.Remarks == null) {
pstmt_tDBOutput_6.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(15, row6.Remarks);
}

                    if(row6.ExpectedDate != null) {
pstmt_tDBOutput_6.setTimestamp(16, new java.sql.Timestamp(row6.ExpectedDate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(16, java.sql.Types.TIMESTAMP);
}

                    if(row6.createddate != null) {
pstmt_tDBOutput_6.setTimestamp(17, new java.sql.Timestamp(row6.createddate.getTime()));
} else {
pstmt_tDBOutput_6.setNull(17, java.sql.Types.TIMESTAMP);
}

                    if(row6.AssetUserEmail == null) {
pstmt_tDBOutput_6.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(18, row6.AssetUserEmail);
}

                    if(row6.senderEmail == null) {
pstmt_tDBOutput_6.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(19, row6.senderEmail);
}

                    if(row6.vendorEmail == null) {
pstmt_tDBOutput_6.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(20, row6.vendorEmail);
}

                    if(row6.inChargeEmail == null) {
pstmt_tDBOutput_6.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(21, row6.inChargeEmail);
}

			
    		pstmt_tDBOutput_6.addBatch();
    		nb_line_tDBOutput_6++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Adding the record ")  + (nb_line_tDBOutput_6)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_6++;
    		  
    			if ((batchSize_tDBOutput_6 > 0) && (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {
                try {
						int countSum_tDBOutput_6 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            	    	batchSizeCounter_tDBOutput_6 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
				    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
				    	String errormessage_tDBOutput_6;
						if (ne_tDBOutput_6 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
							errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
						}else{
							errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
						}
				    	
				    	int countSum_tDBOutput_6 = 0;
						for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
				    	System.err.println(errormessage_tDBOutput_6);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
}
globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
	    		log.debug("tDBInput_6 - Retrieved records count: "+nb_line_tDBInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Done.") );

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());




/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_6 = 0;
				if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
	    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
	    	String errormessage_tDBOutput_6;
			if (ne_tDBOutput_6 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
				errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
			}else{
				errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
			}
	    	
	    	int countSum_tDBOutput_6 = 0;
			for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
				countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
			}
			rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
			
	    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
	    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
	    	System.err.println(errormessage_tDBOutput_6);
	    	
		}
	    
        if(pstmt_tDBOutput_6 != null) {
        		
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
        globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_6)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_6","\"AssetSentOutDetailsEmailDetails\"","tMSSqlInput","tDBOutput_6","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Done.") );

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"AssetSentOutDetailsEmailDetails\"";
		

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMSSqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();

    public static void main(String[] args){
        final FAMS_7_tables_9 FAMS_7_tables_9Class = new FAMS_7_tables_9();

        int exitCode = FAMS_7_tables_9Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'FAMS_7_tables_9' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try {
            	jobInfo.load(new java.io.FileInputStream(jobInfoFile));
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230315_1127-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'FAMS_7_tables_9' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_THzm4A9IEe6leu5mDfS5QQ");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-07-11T13:36:44.215492400Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = FAMS_7_tables_9.class.getClassLoader().getResourceAsStream("talend_tac2_repo/fams_7_tables_9_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = FAMS_7_tables_9.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'FAMS_7_tables_9' - Started.");

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}
try {
errorCode = null;tDBInput_5Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_5) {
globalMap.put("tDBInput_5_SUBPROCESS_STATE", -1);

e_tDBInput_5.printStackTrace();

}
try {
errorCode = null;tDBInput_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_6) {
globalMap.put("tDBInput_6_SUBPROCESS_STATE", -1);

e_tDBInput_6.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : FAMS_7_tables_9");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'FAMS_7_tables_9' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     523380 characters generated by Talend Data Integration 
 *     on the July 11, 2023 at 7:06:44 PM IST
 ************************************************************************************************/