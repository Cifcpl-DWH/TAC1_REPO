
package talend_tac2_repo.fams_7_tables_5_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: FAMS_7_tables_5 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230315_1127-patch
 * @status 
 */
public class FAMS_7_tables_5 implements TalendJob {
	static {System.setProperty("TalendJob.log", "FAMS_7_tables_5.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(FAMS_7_tables_5.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "FAMS_7_tables_5";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_8duqgAtIEe6iHdc52bJqvg", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				FAMS_7_tables_5.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(FAMS_7_tables_5.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "MSSQL_PROP");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.118.157\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"1433\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"CHAITANYA\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"FAMS_DWH\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:tpXh65g0m/V9tIqhvILl9LaRgjuXmQEDVfE1BaXPrP4VFs+E").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "FAMS_Source", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

			    
		    String url_tDBConnection_1 = "jdbc:sqlserver://" + "115.124.118.157" ;
		String port_tDBConnection_1 = "1433";
		String dbname_tDBConnection_1 = "CHAITANYA" ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + "1433";
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    				    
		    	url_tDBConnection_1 += ";databaseName=" + "CHAITANYA"; 
    	}

		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
	String dbUser_tDBConnection_1 = "FAMS_DWH";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:9WpKIPxV8+Qgs/8Vjo/Od+esfO/TMqaNcyDWTwubOZiSkBcZ");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_1", "");

	globalMap.put("db_tDBConnection_1",  "CHAITANYA");
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

	globalMap.put("driver_tDBConnection_1", "MSSQL_PROP");

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="FAMS_Source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"cis\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"FAMS_DWH_TGT\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:BO764cWJ+p5RHHteIq67E+swshRSaNFfpSzhBNSVpGLcUoTa").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "FAMS_Target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"cis";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "FAMS_DWH_TGT";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:ryA3mFSE2cPYowxS+WrcULxHHH3R2w4J6X1i01T9I2mblqwS");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int CostBreakupExchangeRateDetailID;

				public int getCostBreakupExchangeRateDetailID () {
					return this.CostBreakupExchangeRateDetailID;
				}

				public Boolean CostBreakupExchangeRateDetailIDIsNullable(){
				    return false;
				}
				public Boolean CostBreakupExchangeRateDetailIDIsKey(){
				    return true;
				}
				public Integer CostBreakupExchangeRateDetailIDLength(){
				    return 10;
				}
				public Integer CostBreakupExchangeRateDetailIDPrecision(){
				    return 0;
				}
				public String CostBreakupExchangeRateDetailIDDefault(){
				
					return null;
				
				}
				public String CostBreakupExchangeRateDetailIDComment(){
				
				    return "";
				
				}
				public String CostBreakupExchangeRateDetailIDPattern(){
				
					return "";
				
				}
				public String CostBreakupExchangeRateDetailIDOriginalDbColumnName(){
				
					return "CostBreakupExchangeRateDetailID";
				
				}

				
			    public int CostBreakupExchangeRateID;

				public int getCostBreakupExchangeRateID () {
					return this.CostBreakupExchangeRateID;
				}

				public Boolean CostBreakupExchangeRateIDIsNullable(){
				    return false;
				}
				public Boolean CostBreakupExchangeRateIDIsKey(){
				    return false;
				}
				public Integer CostBreakupExchangeRateIDLength(){
				    return 10;
				}
				public Integer CostBreakupExchangeRateIDPrecision(){
				    return 0;
				}
				public String CostBreakupExchangeRateIDDefault(){
				
					return null;
				
				}
				public String CostBreakupExchangeRateIDComment(){
				
				    return "";
				
				}
				public String CostBreakupExchangeRateIDPattern(){
				
					return "";
				
				}
				public String CostBreakupExchangeRateIDOriginalDbColumnName(){
				
					return "CostBreakupExchangeRateID";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public int CostBreakUpID;

				public int getCostBreakUpID () {
					return this.CostBreakUpID;
				}

				public Boolean CostBreakUpIDIsNullable(){
				    return false;
				}
				public Boolean CostBreakUpIDIsKey(){
				    return false;
				}
				public Integer CostBreakUpIDLength(){
				    return 10;
				}
				public Integer CostBreakUpIDPrecision(){
				    return 0;
				}
				public String CostBreakUpIDDefault(){
				
					return null;
				
				}
				public String CostBreakUpIDComment(){
				
				    return "";
				
				}
				public String CostBreakUpIDPattern(){
				
					return "";
				
				}
				public String CostBreakUpIDOriginalDbColumnName(){
				
					return "CostBreakUpID";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.CostBreakupExchangeRateDetailID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.CostBreakupExchangeRateDetailID != other.CostBreakupExchangeRateDetailID)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.CostBreakupExchangeRateDetailID = this.CostBreakupExchangeRateDetailID;
	            other.CostBreakupExchangeRateID = this.CostBreakupExchangeRateID;
	            other.CompanyID = this.CompanyID;
	            other.CostBreakUpID = this.CostBreakUpID;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.CostBreakupExchangeRateDetailID = this.CostBreakupExchangeRateDetailID;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.CostBreakupExchangeRateDetailID = dis.readInt();
					
			        this.CostBreakupExchangeRateID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.CostBreakUpID = dis.readInt();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.CostBreakupExchangeRateDetailID = dis.readInt();
					
			        this.CostBreakupExchangeRateID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.CostBreakUpID = dis.readInt();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateDetailID);
					
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// int
				
		            	dos.writeInt(this.CostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateDetailID);
					
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// int
				
		            	dos.writeInt(this.CostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("CostBreakupExchangeRateDetailID="+String.valueOf(CostBreakupExchangeRateDetailID));
		sb.append(",CostBreakupExchangeRateID="+String.valueOf(CostBreakupExchangeRateID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",CostBreakUpID="+String.valueOf(CostBreakUpID));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(CostBreakupExchangeRateDetailID);
        			
        			sb.append("|");
        		
        				sb.append(CostBreakupExchangeRateID);
        			
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				sb.append(CostBreakUpID);
        			
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.CostBreakupExchangeRateDetailID, other.CostBreakupExchangeRateDetailID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"AssetCostBreakupExchangeDetail\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("AssetCostBreakupExchangeDetail");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("AssetCostBreakupExchangeDetail");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"CostBreakupExchangeRateDetailID\",\"CostBreakupExchangeRateID\",\"CompanyID\",\"CostBreakUpID\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"AssetCostBreakupExchangeDetail\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT FAMS.AssetCostBreakupExchangeDetail.CostBreakupExchangeRateDetailID, 		FAMS.AssetCostBreakupExchangeDetail.CostBreakupExchangeRateID, 		FAMS.AssetCostBreakupExchangeDetail.CompanyID, 		FAMS.AssetCostBreakupExchangeDetail.CostBreakUpID, 		FAMS.AssetCostBreakupExchangeDetail.CreatedBy, 		FAMS.AssetCostBreakupExchangeDetail.CreatedDate, 		FAMS.AssetCostBreakupExchangeDetail.ModifiedBy, 		FAMS.AssetCostBreakupExchangeDetail.ModifiedDate FROM	FAMS.AssetCostBreakupExchangeDetail  WHERE FAMS.AssetCostBreakupExchangeDetail.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.AssetCostBreakupExchangeDetail.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("CostBreakupExchangeRateDetailID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostBreakupExchangeRateID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostBreakUpID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"AssetCostBreakupExchangeDetail\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1); 
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_1 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

		    String dbquery_tDBInput_1 = "SELECT FAMS.AssetCostBreakupExchangeDetail.CostBreakupExchangeRateDetailID,\n		FAMS.AssetCostBreakupExchangeDetail.CostB"
+"reakupExchangeRateID,\n		FAMS.AssetCostBreakupExchangeDetail.CompanyID,\n		FAMS.AssetCostBreakupExchangeDetail.CostBreakUp"
+"ID,\n		FAMS.AssetCostBreakupExchangeDetail.CreatedBy,\n		FAMS.AssetCostBreakupExchangeDetail.CreatedDate,\n		FAMS.AssetCost"
+"BreakupExchangeDetail.ModifiedBy,\n		FAMS.AssetCostBreakupExchangeDetail.ModifiedDate\nFROM	FAMS.AssetCostBreakupExchangeD"
+"etail\nWHERE FAMS.AssetCostBreakupExchangeDetail.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAM"
+"S.AssetCostBreakupExchangeDetail.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.CostBreakupExchangeRateDetailID = 0;
							} else {
		                          
            row1.CostBreakupExchangeRateDetailID = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.CostBreakupExchangeRateID = 0;
							} else {
		                          
            row1.CostBreakupExchangeRateID = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.CompanyID = 0;
							} else {
		                          
            row1.CompanyID = rs_tDBInput_1.getInt(3);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.CostBreakUpID = 0;
							} else {
		                          
            row1.CostBreakUpID = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.CreatedBy = 0;
							} else {
		                          
            row1.CreatedBy = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.CreatedDate = null;
							} else {
										
			row1.CreatedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 6);
			
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.ModifiedBy = null;
							} else {
		                          
            row1.ModifiedBy = rs_tDBInput_1.getInt(7);
            if(rs_tDBInput_1.wasNull()){
                    row1.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.ModifiedDate = null;
							} else {
										
			row1.ModifiedDate = mssqlGTU_tDBInput_1.getDate(rsmd_tDBInput_1, rs_tDBInput_1, 8);
			
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					





 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"AssetCostBreakupExchangeDetail\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, row1.CostBreakupExchangeRateDetailID);

                    pstmt_tDBOutput_1.setInt(2, row1.CostBreakupExchangeRateID);

                    pstmt_tDBOutput_1.setInt(3, row1.CompanyID);

                    pstmt_tDBOutput_1.setInt(4, row1.CostBreakUpID);

                    pstmt_tDBOutput_1.setInt(5, row1.CreatedBy);

                    if(row1.CreatedDate != null) {
pstmt_tDBOutput_1.setTimestamp(6, new java.sql.Timestamp(row1.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row1.ModifiedBy == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(7, row1.ModifiedBy);
}

                    if(row1.ModifiedDate != null) {
pstmt_tDBOutput_1.setTimestamp(8, new java.sql.Timestamp(row1.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}
globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_1)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"AssetCostBreakupExchangeDetail\"","tMSSqlInput","tDBOutput_1","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"AssetCostBreakupExchangeDetail\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int CostBreakupExchangeRateID;

				public int getCostBreakupExchangeRateID () {
					return this.CostBreakupExchangeRateID;
				}

				public Boolean CostBreakupExchangeRateIDIsNullable(){
				    return false;
				}
				public Boolean CostBreakupExchangeRateIDIsKey(){
				    return false;
				}
				public Integer CostBreakupExchangeRateIDLength(){
				    return 10;
				}
				public Integer CostBreakupExchangeRateIDPrecision(){
				    return 0;
				}
				public String CostBreakupExchangeRateIDDefault(){
				
					return null;
				
				}
				public String CostBreakupExchangeRateIDComment(){
				
				    return "";
				
				}
				public String CostBreakupExchangeRateIDPattern(){
				
					return "";
				
				}
				public String CostBreakupExchangeRateIDOriginalDbColumnName(){
				
					return "CostBreakupExchangeRateID";
				
				}

				
			    public int AssetCostBreakUpID;

				public int getAssetCostBreakUpID () {
					return this.AssetCostBreakUpID;
				}

				public Boolean AssetCostBreakUpIDIsNullable(){
				    return false;
				}
				public Boolean AssetCostBreakUpIDIsKey(){
				    return true;
				}
				public Integer AssetCostBreakUpIDLength(){
				    return 10;
				}
				public Integer AssetCostBreakUpIDPrecision(){
				    return 0;
				}
				public String AssetCostBreakUpIDDefault(){
				
					return null;
				
				}
				public String AssetCostBreakUpIDComment(){
				
				    return "";
				
				}
				public String AssetCostBreakUpIDPattern(){
				
					return "";
				
				}
				public String AssetCostBreakUpIDOriginalDbColumnName(){
				
					return "AssetCostBreakUpID";
				
				}

				
			    public int CompanyID;

				public int getCompanyID () {
					return this.CompanyID;
				}

				public Boolean CompanyIDIsNullable(){
				    return false;
				}
				public Boolean CompanyIDIsKey(){
				    return false;
				}
				public Integer CompanyIDLength(){
				    return 10;
				}
				public Integer CompanyIDPrecision(){
				    return 0;
				}
				public String CompanyIDDefault(){
				
					return null;
				
				}
				public String CompanyIDComment(){
				
				    return "";
				
				}
				public String CompanyIDPattern(){
				
					return "";
				
				}
				public String CompanyIDOriginalDbColumnName(){
				
					return "CompanyID";
				
				}

				
			    public int TransactionCurrency;

				public int getTransactionCurrency () {
					return this.TransactionCurrency;
				}

				public Boolean TransactionCurrencyIsNullable(){
				    return false;
				}
				public Boolean TransactionCurrencyIsKey(){
				    return false;
				}
				public Integer TransactionCurrencyLength(){
				    return 10;
				}
				public Integer TransactionCurrencyPrecision(){
				    return 0;
				}
				public String TransactionCurrencyDefault(){
				
					return null;
				
				}
				public String TransactionCurrencyComment(){
				
				    return "";
				
				}
				public String TransactionCurrencyPattern(){
				
					return "";
				
				}
				public String TransactionCurrencyOriginalDbColumnName(){
				
					return "TransactionCurrency";
				
				}

				
			    public BigDecimal ExchangeRate;

				public BigDecimal getExchangeRate () {
					return this.ExchangeRate;
				}

				public Boolean ExchangeRateIsNullable(){
				    return false;
				}
				public Boolean ExchangeRateIsKey(){
				    return false;
				}
				public Integer ExchangeRateLength(){
				    return 8;
				}
				public Integer ExchangeRatePrecision(){
				    return 3;
				}
				public String ExchangeRateDefault(){
				
					return null;
				
				}
				public String ExchangeRateComment(){
				
				    return "";
				
				}
				public String ExchangeRatePattern(){
				
					return "";
				
				}
				public String ExchangeRateOriginalDbColumnName(){
				
					return "ExchangeRate";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.AssetCostBreakUpID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.AssetCostBreakUpID != other.AssetCostBreakUpID)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.CostBreakupExchangeRateID = this.CostBreakupExchangeRateID;
	            other.AssetCostBreakUpID = this.AssetCostBreakUpID;
	            other.CompanyID = this.CompanyID;
	            other.TransactionCurrency = this.TransactionCurrency;
	            other.ExchangeRate = this.ExchangeRate;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.AssetCostBreakUpID = this.AssetCostBreakUpID;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.CostBreakupExchangeRateID = dis.readInt();
					
			        this.AssetCostBreakUpID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.TransactionCurrency = dis.readInt();
					
						this.ExchangeRate = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.CostBreakupExchangeRateID = dis.readInt();
					
			        this.AssetCostBreakUpID = dis.readInt();
					
			        this.CompanyID = dis.readInt();
					
			        this.TransactionCurrency = dis.readInt();
					
						this.ExchangeRate = (BigDecimal) dis.readObject();
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateID);
					
					// int
				
		            	dos.writeInt(this.AssetCostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// int
				
		            	dos.writeInt(this.TransactionCurrency);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ExchangeRate);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.CostBreakupExchangeRateID);
					
					// int
				
		            	dos.writeInt(this.AssetCostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.CompanyID);
					
					// int
				
		            	dos.writeInt(this.TransactionCurrency);
					
					// BigDecimal
				
       			    	dos.writeObject(this.ExchangeRate);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("CostBreakupExchangeRateID="+String.valueOf(CostBreakupExchangeRateID));
		sb.append(",AssetCostBreakUpID="+String.valueOf(AssetCostBreakUpID));
		sb.append(",CompanyID="+String.valueOf(CompanyID));
		sb.append(",TransactionCurrency="+String.valueOf(TransactionCurrency));
		sb.append(",ExchangeRate="+String.valueOf(ExchangeRate));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(CostBreakupExchangeRateID);
        			
        			sb.append("|");
        		
        				sb.append(AssetCostBreakUpID);
        			
        			sb.append("|");
        		
        				sb.append(CompanyID);
        			
        			sb.append("|");
        		
        				sb.append(TransactionCurrency);
        			
        			sb.append("|");
        		
        				if(ExchangeRate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ExchangeRate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.AssetCostBreakUpID, other.AssetCostBreakUpID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"AssetCostBreakupExchangeRate\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("AssetCostBreakupExchangeRate");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("AssetCostBreakupExchangeRate");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"CostBreakupExchangeRateID\",\"AssetCostBreakUpID\",\"CompanyID\",\"TransactionCurrency\",\"ExchangeRate\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"AssetCostBreakupExchangeRate\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT FAMS.AssetCostBreakupExchangeRate.CostBreakupExchangeRateID, 		FAMS.AssetCostBreakupExchangeRate.AssetCostBreakUpID, 		FAMS.AssetCostBreakupExchangeRate.CompanyID, 		FAMS.AssetCostBreakupExchangeRate.TransactionCurrency, 		FAMS.AssetCostBreakupExchangeRate.ExchangeRate, 		FAMS.AssetCostBreakupExchangeRate.CreatedBy, 		FAMS.AssetCostBreakupExchangeRate.CreatedDate, 		FAMS.AssetCostBreakupExchangeRate.ModifiedBy, 		FAMS.AssetCostBreakupExchangeRate.ModifiedDate FROM	FAMS.AssetCostBreakupExchangeRate  WHERE FAMS.AssetCostBreakupExchangeRate.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.AssetCostBreakupExchangeRate.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("CostBreakupExchangeRateID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCostBreakUpID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TransactionCurrency")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ExchangeRate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"AssetCostBreakupExchangeRate\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2); 
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_2 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

		    String dbquery_tDBInput_2 = "SELECT FAMS.AssetCostBreakupExchangeRate.CostBreakupExchangeRateID,\n		FAMS.AssetCostBreakupExchangeRate.AssetCostBreakU"
+"pID,\n		FAMS.AssetCostBreakupExchangeRate.CompanyID,\n		FAMS.AssetCostBreakupExchangeRate.TransactionCurrency,\n		FAMS.Asse"
+"tCostBreakupExchangeRate.ExchangeRate,\n		FAMS.AssetCostBreakupExchangeRate.CreatedBy,\n		FAMS.AssetCostBreakupExchangeRat"
+"e.CreatedDate,\n		FAMS.AssetCostBreakupExchangeRate.ModifiedBy,\n		FAMS.AssetCostBreakupExchangeRate.ModifiedDate\nFROM	FAM"
+"S.AssetCostBreakupExchangeRate\nWHERE FAMS.AssetCostBreakupExchangeRate.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() A"
+"S DATE))\n      AND FAMS.AssetCostBreakupExchangeRate.CreatedDate < CAST(GETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.CostBreakupExchangeRateID = 0;
							} else {
		                          
            row2.CostBreakupExchangeRateID = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.AssetCostBreakUpID = 0;
							} else {
		                          
            row2.AssetCostBreakUpID = rs_tDBInput_2.getInt(2);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.CompanyID = 0;
							} else {
		                          
            row2.CompanyID = rs_tDBInput_2.getInt(3);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.TransactionCurrency = 0;
							} else {
		                          
            row2.TransactionCurrency = rs_tDBInput_2.getInt(4);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.ExchangeRate = null;
							} else {
		                          
            row2.ExchangeRate = rs_tDBInput_2.getBigDecimal(5);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.CreatedBy = 0;
							} else {
		                          
            row2.CreatedBy = rs_tDBInput_2.getInt(6);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.CreatedDate = null;
							} else {
										
			row2.CreatedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 7);
			
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.ModifiedBy = null;
							} else {
		                          
            row2.ModifiedBy = rs_tDBInput_2.getInt(8);
            if(rs_tDBInput_2.wasNull()){
                    row2.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.ModifiedDate = null;
							} else {
										
			row2.ModifiedDate = mssqlGTU_tDBInput_2.getDate(rsmd_tDBInput_2, rs_tDBInput_2, 9);
			
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					





 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"AssetCostBreakupExchangeRate\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, row2.CostBreakupExchangeRateID);

                    pstmt_tDBOutput_2.setInt(2, row2.AssetCostBreakUpID);

                    pstmt_tDBOutput_2.setInt(3, row2.CompanyID);

                    pstmt_tDBOutput_2.setInt(4, row2.TransactionCurrency);

                    pstmt_tDBOutput_2.setBigDecimal(5, row2.ExchangeRate);

                    pstmt_tDBOutput_2.setInt(6, row2.CreatedBy);

                    if(row2.CreatedDate != null) {
pstmt_tDBOutput_2.setTimestamp(7, new java.sql.Timestamp(row2.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.TIMESTAMP);
}

                    if(row2.ModifiedBy == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, row2.ModifiedBy);
}

                    if(row2.ModifiedDate != null) {
pstmt_tDBOutput_2.setTimestamp(9, new java.sql.Timestamp(row2.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}
globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_2)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"AssetCostBreakupExchangeRate\"","tMSSqlInput","tDBOutput_2","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"AssetCostBreakupExchangeRate\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];

	
			    public int AssetCostBreakUpID;

				public int getAssetCostBreakUpID () {
					return this.AssetCostBreakUpID;
				}

				public Boolean AssetCostBreakUpIDIsNullable(){
				    return false;
				}
				public Boolean AssetCostBreakUpIDIsKey(){
				    return false;
				}
				public Integer AssetCostBreakUpIDLength(){
				    return 10;
				}
				public Integer AssetCostBreakUpIDPrecision(){
				    return 0;
				}
				public String AssetCostBreakUpIDDefault(){
				
					return null;
				
				}
				public String AssetCostBreakUpIDComment(){
				
				    return "";
				
				}
				public String AssetCostBreakUpIDPattern(){
				
					return "";
				
				}
				public String AssetCostBreakUpIDOriginalDbColumnName(){
				
					return "AssetCostBreakUpID";
				
				}

				
			    public int AssetID;

				public int getAssetID () {
					return this.AssetID;
				}

				public Boolean AssetIDIsNullable(){
				    return false;
				}
				public Boolean AssetIDIsKey(){
				    return false;
				}
				public Integer AssetIDLength(){
				    return 10;
				}
				public Integer AssetIDPrecision(){
				    return 0;
				}
				public String AssetIDDefault(){
				
					return null;
				
				}
				public String AssetIDComment(){
				
				    return "";
				
				}
				public String AssetIDPattern(){
				
					return "";
				
				}
				public String AssetIDOriginalDbColumnName(){
				
					return "AssetID";
				
				}

				
			    public String VoucherNo;

				public String getVoucherNo () {
					return this.VoucherNo;
				}

				public Boolean VoucherNoIsNullable(){
				    return true;
				}
				public Boolean VoucherNoIsKey(){
				    return false;
				}
				public Integer VoucherNoLength(){
				    return 50;
				}
				public Integer VoucherNoPrecision(){
				    return 0;
				}
				public String VoucherNoDefault(){
				
					return null;
				
				}
				public String VoucherNoComment(){
				
				    return "";
				
				}
				public String VoucherNoPattern(){
				
					return "";
				
				}
				public String VoucherNoOriginalDbColumnName(){
				
					return "VoucherNo";
				
				}

				
			    public java.util.Date VoucherDate;

				public java.util.Date getVoucherDate () {
					return this.VoucherDate;
				}

				public Boolean VoucherDateIsNullable(){
				    return true;
				}
				public Boolean VoucherDateIsKey(){
				    return false;
				}
				public Integer VoucherDateLength(){
				    return 23;
				}
				public Integer VoucherDatePrecision(){
				    return 3;
				}
				public String VoucherDateDefault(){
				
					return null;
				
				}
				public String VoucherDateComment(){
				
				    return "";
				
				}
				public String VoucherDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String VoucherDateOriginalDbColumnName(){
				
					return "VoucherDate";
				
				}

				
			    public String PartyBillNo;

				public String getPartyBillNo () {
					return this.PartyBillNo;
				}

				public Boolean PartyBillNoIsNullable(){
				    return true;
				}
				public Boolean PartyBillNoIsKey(){
				    return false;
				}
				public Integer PartyBillNoLength(){
				    return 50;
				}
				public Integer PartyBillNoPrecision(){
				    return 0;
				}
				public String PartyBillNoDefault(){
				
					return null;
				
				}
				public String PartyBillNoComment(){
				
				    return "";
				
				}
				public String PartyBillNoPattern(){
				
					return "";
				
				}
				public String PartyBillNoOriginalDbColumnName(){
				
					return "PartyBillNo";
				
				}

				
			    public java.util.Date PartyBillDate;

				public java.util.Date getPartyBillDate () {
					return this.PartyBillDate;
				}

				public Boolean PartyBillDateIsNullable(){
				    return true;
				}
				public Boolean PartyBillDateIsKey(){
				    return false;
				}
				public Integer PartyBillDateLength(){
				    return 23;
				}
				public Integer PartyBillDatePrecision(){
				    return 3;
				}
				public String PartyBillDateDefault(){
				
					return null;
				
				}
				public String PartyBillDateComment(){
				
				    return "";
				
				}
				public String PartyBillDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String PartyBillDateOriginalDbColumnName(){
				
					return "PartyBillDate";
				
				}

				
			    public String Particulars;

				public String getParticulars () {
					return this.Particulars;
				}

				public Boolean ParticularsIsNullable(){
				    return true;
				}
				public Boolean ParticularsIsKey(){
				    return false;
				}
				public Integer ParticularsLength(){
				    return 300;
				}
				public Integer ParticularsPrecision(){
				    return 0;
				}
				public String ParticularsDefault(){
				
					return null;
				
				}
				public String ParticularsComment(){
				
				    return "";
				
				}
				public String ParticularsPattern(){
				
					return "";
				
				}
				public String ParticularsOriginalDbColumnName(){
				
					return "Particulars";
				
				}

				
			    public BigDecimal Amount;

				public BigDecimal getAmount () {
					return this.Amount;
				}

				public Boolean AmountIsNullable(){
				    return false;
				}
				public Boolean AmountIsKey(){
				    return false;
				}
				public Integer AmountLength(){
				    return 12;
				}
				public Integer AmountPrecision(){
				    return 2;
				}
				public String AmountDefault(){
				
					return null;
				
				}
				public String AmountComment(){
				
				    return "";
				
				}
				public String AmountPattern(){
				
					return "";
				
				}
				public String AmountOriginalDbColumnName(){
				
					return "Amount";
				
				}

				
			    public Integer CostBreakupCategoryID;

				public Integer getCostBreakupCategoryID () {
					return this.CostBreakupCategoryID;
				}

				public Boolean CostBreakupCategoryIDIsNullable(){
				    return true;
				}
				public Boolean CostBreakupCategoryIDIsKey(){
				    return false;
				}
				public Integer CostBreakupCategoryIDLength(){
				    return 10;
				}
				public Integer CostBreakupCategoryIDPrecision(){
				    return 0;
				}
				public String CostBreakupCategoryIDDefault(){
				
					return null;
				
				}
				public String CostBreakupCategoryIDComment(){
				
				    return "";
				
				}
				public String CostBreakupCategoryIDPattern(){
				
					return "";
				
				}
				public String CostBreakupCategoryIDOriginalDbColumnName(){
				
					return "CostBreakupCategoryID";
				
				}

				
			    public Integer VendorID;

				public Integer getVendorID () {
					return this.VendorID;
				}

				public Boolean VendorIDIsNullable(){
				    return true;
				}
				public Boolean VendorIDIsKey(){
				    return false;
				}
				public Integer VendorIDLength(){
				    return 10;
				}
				public Integer VendorIDPrecision(){
				    return 0;
				}
				public String VendorIDDefault(){
				
					return null;
				
				}
				public String VendorIDComment(){
				
				    return "";
				
				}
				public String VendorIDPattern(){
				
					return "";
				
				}
				public String VendorIDOriginalDbColumnName(){
				
					return "VendorID";
				
				}

				
			    public String Remarks;

				public String getRemarks () {
					return this.Remarks;
				}

				public Boolean RemarksIsNullable(){
				    return true;
				}
				public Boolean RemarksIsKey(){
				    return false;
				}
				public Integer RemarksLength(){
				    return 500;
				}
				public Integer RemarksPrecision(){
				    return 0;
				}
				public String RemarksDefault(){
				
					return null;
				
				}
				public String RemarksComment(){
				
				    return "";
				
				}
				public String RemarksPattern(){
				
					return "";
				
				}
				public String RemarksOriginalDbColumnName(){
				
					return "Remarks";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				
			    public String OperationType;

				public String getOperationType () {
					return this.OperationType;
				}

				public Boolean OperationTypeIsNullable(){
				    return true;
				}
				public Boolean OperationTypeIsKey(){
				    return false;
				}
				public Integer OperationTypeLength(){
				    return 10;
				}
				public Integer OperationTypePrecision(){
				    return 0;
				}
				public String OperationTypeDefault(){
				
					return null;
				
				}
				public String OperationTypeComment(){
				
				    return "";
				
				}
				public String OperationTypePattern(){
				
					return "";
				
				}
				public String OperationTypeOriginalDbColumnName(){
				
					return "OperationType";
				
				}

				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.AssetCostBreakUpID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.VoucherNo = readString(dis);
					
					this.VoucherDate = readDate(dis);
					
					this.PartyBillNo = readString(dis);
					
					this.PartyBillDate = readDate(dis);
					
					this.Particulars = readString(dis);
					
						this.Amount = (BigDecimal) dis.readObject();
					
						this.CostBreakupCategoryID = readInteger(dis);
					
						this.VendorID = readInteger(dis);
					
					this.Remarks = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.AssetCostBreakUpID = dis.readInt();
					
			        this.AssetID = dis.readInt();
					
					this.VoucherNo = readString(dis);
					
					this.VoucherDate = readDate(dis);
					
					this.PartyBillNo = readString(dis);
					
					this.PartyBillDate = readDate(dis);
					
					this.Particulars = readString(dis);
					
						this.Amount = (BigDecimal) dis.readObject();
					
						this.CostBreakupCategoryID = readInteger(dis);
					
						this.VendorID = readInteger(dis);
					
					this.Remarks = readString(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
					this.OperationType = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetCostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// String
				
						writeString(this.VoucherNo,dos);
					
					// java.util.Date
				
						writeDate(this.VoucherDate,dos);
					
					// String
				
						writeString(this.PartyBillNo,dos);
					
					// java.util.Date
				
						writeDate(this.PartyBillDate,dos);
					
					// String
				
						writeString(this.Particulars,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.Amount);
					
					// Integer
				
						writeInteger(this.CostBreakupCategoryID,dos);
					
					// Integer
				
						writeInteger(this.VendorID,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetCostBreakUpID);
					
					// int
				
		            	dos.writeInt(this.AssetID);
					
					// String
				
						writeString(this.VoucherNo,dos);
					
					// java.util.Date
				
						writeDate(this.VoucherDate,dos);
					
					// String
				
						writeString(this.PartyBillNo,dos);
					
					// java.util.Date
				
						writeDate(this.PartyBillDate,dos);
					
					// String
				
						writeString(this.Particulars,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.Amount);
					
					// Integer
				
						writeInteger(this.CostBreakupCategoryID,dos);
					
					// Integer
				
						writeInteger(this.VendorID,dos);
					
					// String
				
						writeString(this.Remarks,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
					// String
				
						writeString(this.OperationType,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetCostBreakUpID="+String.valueOf(AssetCostBreakUpID));
		sb.append(",AssetID="+String.valueOf(AssetID));
		sb.append(",VoucherNo="+VoucherNo);
		sb.append(",VoucherDate="+String.valueOf(VoucherDate));
		sb.append(",PartyBillNo="+PartyBillNo);
		sb.append(",PartyBillDate="+String.valueOf(PartyBillDate));
		sb.append(",Particulars="+Particulars);
		sb.append(",Amount="+String.valueOf(Amount));
		sb.append(",CostBreakupCategoryID="+String.valueOf(CostBreakupCategoryID));
		sb.append(",VendorID="+String.valueOf(VendorID));
		sb.append(",Remarks="+Remarks);
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
		sb.append(",OperationType="+OperationType);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetCostBreakUpID);
        			
        			sb.append("|");
        		
        				sb.append(AssetID);
        			
        			sb.append("|");
        		
        				if(VoucherNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VoucherNo);
            			}
            		
        			sb.append("|");
        		
        				if(VoucherDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VoucherDate);
            			}
            		
        			sb.append("|");
        		
        				if(PartyBillNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PartyBillNo);
            			}
            		
        			sb.append("|");
        		
        				if(PartyBillDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PartyBillDate);
            			}
            		
        			sb.append("|");
        		
        				if(Particulars == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Particulars);
            			}
            		
        			sb.append("|");
        		
        				if(Amount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Amount);
            			}
            		
        			sb.append("|");
        		
        				if(CostBreakupCategoryID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CostBreakupCategoryID);
            			}
            		
        			sb.append("|");
        		
        				if(VendorID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(VendorID);
            			}
            		
        			sb.append("|");
        		
        				if(Remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Remarks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        				if(OperationType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OperationType);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"AssetCostBreakup_Log\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("AssetCostBreakup_Log");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("AssetCostBreakup_Log");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"AssetCostBreakUpID\",\"AssetID\",\"VoucherNo\",\"VoucherDate\",\"PartyBillNo\",\"PartyBillDate\",\"Particulars\",\"Amount\",\"CostBreakupCategoryID\",\"VendorID\",\"Remarks\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\",\"OperationType\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"AssetCostBreakup_Log\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT FAMS.AssetCostBreakup_Log.AssetCostBreakUpID, 		FAMS.AssetCostBreakup_Log.AssetID, 		FAMS.AssetCostBreakup_Log.VoucherNo, 		FAMS.AssetCostBreakup_Log.VoucherDate, 		FAMS.AssetCostBreakup_Log.PartyBillNo, 		FAMS.AssetCostBreakup_Log.PartyBillDate, 		FAMS.AssetCostBreakup_Log.Particulars, 		FAMS.AssetCostBreakup_Log.Amount, 		FAMS.AssetCostBreakup_Log.CostBreakupCategoryID, 		FAMS.AssetCostBreakup_Log.VendorID, 		FAMS.AssetCostBreakup_Log.Remarks, 		FAMS.AssetCostBreakup_Log.CreatedBy, 		FAMS.AssetCostBreakup_Log.CreatedDate, 		FAMS.AssetCostBreakup_Log.ModifiedBy, 		FAMS.AssetCostBreakup_Log.ModifiedDate, 		FAMS.AssetCostBreakup_Log.OperationType FROM	FAMS.AssetCostBreakup_Log  WHERE FAMS.AssetCostBreakup_Log.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))        AND FAMS.AssetCostBreakup_Log.CreatedDate < CAST(GETDATE() AS DATE)\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetCostBreakUpID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("AssetID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VoucherNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VoucherDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PartyBillNo")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PartyBillDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Particulars")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Amount")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CostBreakupCategoryID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("VendorID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OperationType")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"AssetCostBreakup_Log\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3); 
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_3 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

		    String dbquery_tDBInput_3 = "SELECT FAMS.AssetCostBreakup_Log.AssetCostBreakUpID,\n		FAMS.AssetCostBreakup_Log.AssetID,\n		FAMS.AssetCostBreakup_Log.V"
+"oucherNo,\n		FAMS.AssetCostBreakup_Log.VoucherDate,\n		FAMS.AssetCostBreakup_Log.PartyBillNo,\n		FAMS.AssetCostBreakup_Log."
+"PartyBillDate,\n		FAMS.AssetCostBreakup_Log.Particulars,\n		FAMS.AssetCostBreakup_Log.Amount,\n		FAMS.AssetCostBreakup_Log."
+"CostBreakupCategoryID,\n		FAMS.AssetCostBreakup_Log.VendorID,\n		FAMS.AssetCostBreakup_Log.Remarks,\n		FAMS.AssetCostBreaku"
+"p_Log.CreatedBy,\n		FAMS.AssetCostBreakup_Log.CreatedDate,\n		FAMS.AssetCostBreakup_Log.ModifiedBy,\n		FAMS.AssetCostBreaku"
+"p_Log.ModifiedDate,\n		FAMS.AssetCostBreakup_Log.OperationType\nFROM	FAMS.AssetCostBreakup_Log\nWHERE FAMS.AssetCostBreaku"
+"p_Log.CreatedDate >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))\n      AND FAMS.AssetCostBreakup_Log.CreatedDate < CAST(G"
+"ETDATE() AS DATE)";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.AssetCostBreakUpID = 0;
							} else {
		                          
            row3.AssetCostBreakUpID = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.AssetID = 0;
							} else {
		                          
            row3.AssetID = rs_tDBInput_3.getInt(2);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.VoucherNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(3);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.VoucherNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.VoucherNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.VoucherNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.VoucherDate = null;
							} else {
										
			row3.VoucherDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 4);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.PartyBillNo = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(5);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.PartyBillNo = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.PartyBillNo = tmpContent_tDBInput_3;
                }
            } else {
                row3.PartyBillNo = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.PartyBillDate = null;
							} else {
										
			row3.PartyBillDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 6);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.Particulars = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(7);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Particulars = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Particulars = tmpContent_tDBInput_3;
                }
            } else {
                row3.Particulars = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.Amount = null;
							} else {
		                          
            row3.Amount = rs_tDBInput_3.getBigDecimal(8);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.CostBreakupCategoryID = null;
							} else {
		                          
            row3.CostBreakupCategoryID = rs_tDBInput_3.getInt(9);
            if(rs_tDBInput_3.wasNull()){
                    row3.CostBreakupCategoryID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.VendorID = null;
							} else {
		                          
            row3.VendorID = rs_tDBInput_3.getInt(10);
            if(rs_tDBInput_3.wasNull()){
                    row3.VendorID = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 11) {
								row3.Remarks = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(11);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.Remarks = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.Remarks = tmpContent_tDBInput_3;
                }
            } else {
                row3.Remarks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 12) {
								row3.CreatedBy = 0;
							} else {
		                          
            row3.CreatedBy = rs_tDBInput_3.getInt(12);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 13) {
								row3.CreatedDate = null;
							} else {
										
			row3.CreatedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 13);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 14) {
								row3.ModifiedBy = null;
							} else {
		                          
            row3.ModifiedBy = rs_tDBInput_3.getInt(14);
            if(rs_tDBInput_3.wasNull()){
                    row3.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 15) {
								row3.ModifiedDate = null;
							} else {
										
			row3.ModifiedDate = mssqlGTU_tDBInput_3.getDate(rsmd_tDBInput_3, rs_tDBInput_3, 15);
			
		                    }
							if(colQtyInRs_tDBInput_3 < 16) {
								row3.OperationType = null;
							} else {
	                         		
           		tmpContent_tDBInput_3 = rs_tDBInput_3.getString(16);
            if(tmpContent_tDBInput_3 != null) {
            	if (talendToDBList_tDBInput_3 .contains(rsmd_tDBInput_3.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
            		row3.OperationType = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
            	} else {
                	row3.OperationType = tmpContent_tDBInput_3;
                }
            } else {
                row3.OperationType = null;
            }
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					





 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"AssetCostBreakup_Log\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, row3.AssetCostBreakUpID);

                    pstmt_tDBOutput_3.setInt(2, row3.AssetID);

                    if(row3.VoucherNo == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, row3.VoucherNo);
}

                    if(row3.VoucherDate != null) {
pstmt_tDBOutput_3.setTimestamp(4, new java.sql.Timestamp(row3.VoucherDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row3.PartyBillNo == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row3.PartyBillNo);
}

                    if(row3.PartyBillDate != null) {
pstmt_tDBOutput_3.setTimestamp(6, new java.sql.Timestamp(row3.PartyBillDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(row3.Particulars == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, row3.Particulars);
}

                    pstmt_tDBOutput_3.setBigDecimal(8, row3.Amount);

                    if(row3.CostBreakupCategoryID == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(9, row3.CostBreakupCategoryID);
}

                    if(row3.VendorID == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(10, row3.VendorID);
}

                    if(row3.Remarks == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, row3.Remarks);
}

                    pstmt_tDBOutput_3.setInt(12, row3.CreatedBy);

                    if(row3.CreatedDate != null) {
pstmt_tDBOutput_3.setTimestamp(13, new java.sql.Timestamp(row3.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.TIMESTAMP);
}

                    if(row3.ModifiedBy == null) {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(14, row3.ModifiedBy);
}

                    if(row3.ModifiedDate != null) {
pstmt_tDBOutput_3.setTimestamp(15, new java.sql.Timestamp(row3.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.TIMESTAMP);
}

                    if(row3.OperationType == null) {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(16, row3.OperationType);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}
globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_3)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"AssetCostBreakup_Log\"","tMSSqlInput","tDBOutput_3","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"AssetCostBreakup_Log\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_FAMS_7_tables_5 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int AssetDepreciationID;

				public int getAssetDepreciationID () {
					return this.AssetDepreciationID;
				}

				public Boolean AssetDepreciationIDIsNullable(){
				    return false;
				}
				public Boolean AssetDepreciationIDIsKey(){
				    return true;
				}
				public Integer AssetDepreciationIDLength(){
				    return 10;
				}
				public Integer AssetDepreciationIDPrecision(){
				    return 0;
				}
				public String AssetDepreciationIDDefault(){
				
					return null;
				
				}
				public String AssetDepreciationIDComment(){
				
				    return "";
				
				}
				public String AssetDepreciationIDPattern(){
				
					return "";
				
				}
				public String AssetDepreciationIDOriginalDbColumnName(){
				
					return "AssetDepreciationID";
				
				}

				
			    public int CompanyBookID;

				public int getCompanyBookID () {
					return this.CompanyBookID;
				}

				public Boolean CompanyBookIDIsNullable(){
				    return false;
				}
				public Boolean CompanyBookIDIsKey(){
				    return false;
				}
				public Integer CompanyBookIDLength(){
				    return 10;
				}
				public Integer CompanyBookIDPrecision(){
				    return 0;
				}
				public String CompanyBookIDDefault(){
				
					return null;
				
				}
				public String CompanyBookIDComment(){
				
				    return "";
				
				}
				public String CompanyBookIDPattern(){
				
					return "";
				
				}
				public String CompanyBookIDOriginalDbColumnName(){
				
					return "CompanyBookID";
				
				}

				
			    public int BookAccountingYearID;

				public int getBookAccountingYearID () {
					return this.BookAccountingYearID;
				}

				public Boolean BookAccountingYearIDIsNullable(){
				    return false;
				}
				public Boolean BookAccountingYearIDIsKey(){
				    return false;
				}
				public Integer BookAccountingYearIDLength(){
				    return 10;
				}
				public Integer BookAccountingYearIDPrecision(){
				    return 0;
				}
				public String BookAccountingYearIDDefault(){
				
					return null;
				
				}
				public String BookAccountingYearIDComment(){
				
				    return "";
				
				}
				public String BookAccountingYearIDPattern(){
				
					return "";
				
				}
				public String BookAccountingYearIDOriginalDbColumnName(){
				
					return "BookAccountingYearID";
				
				}

				
			    public java.util.Date FromDate;

				public java.util.Date getFromDate () {
					return this.FromDate;
				}

				public Boolean FromDateIsNullable(){
				    return false;
				}
				public Boolean FromDateIsKey(){
				    return false;
				}
				public Integer FromDateLength(){
				    return 23;
				}
				public Integer FromDatePrecision(){
				    return 3;
				}
				public String FromDateDefault(){
				
					return null;
				
				}
				public String FromDateComment(){
				
				    return "";
				
				}
				public String FromDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String FromDateOriginalDbColumnName(){
				
					return "FromDate";
				
				}

				
			    public java.util.Date ToDate;

				public java.util.Date getToDate () {
					return this.ToDate;
				}

				public Boolean ToDateIsNullable(){
				    return false;
				}
				public Boolean ToDateIsKey(){
				    return false;
				}
				public Integer ToDateLength(){
				    return 23;
				}
				public Integer ToDatePrecision(){
				    return 3;
				}
				public String ToDateDefault(){
				
					return null;
				
				}
				public String ToDateComment(){
				
				    return "";
				
				}
				public String ToDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ToDateOriginalDbColumnName(){
				
					return "ToDate";
				
				}

				
			    public int CreatedBy;

				public int getCreatedBy () {
					return this.CreatedBy;
				}

				public Boolean CreatedByIsNullable(){
				    return false;
				}
				public Boolean CreatedByIsKey(){
				    return false;
				}
				public Integer CreatedByLength(){
				    return 10;
				}
				public Integer CreatedByPrecision(){
				    return 0;
				}
				public String CreatedByDefault(){
				
					return null;
				
				}
				public String CreatedByComment(){
				
				    return "";
				
				}
				public String CreatedByPattern(){
				
					return "";
				
				}
				public String CreatedByOriginalDbColumnName(){
				
					return "CreatedBy";
				
				}

				
			    public java.util.Date CreatedDate;

				public java.util.Date getCreatedDate () {
					return this.CreatedDate;
				}

				public Boolean CreatedDateIsNullable(){
				    return false;
				}
				public Boolean CreatedDateIsKey(){
				    return false;
				}
				public Integer CreatedDateLength(){
				    return 23;
				}
				public Integer CreatedDatePrecision(){
				    return 3;
				}
				public String CreatedDateDefault(){
				
					return null;
				
				}
				public String CreatedDateComment(){
				
				    return "";
				
				}
				public String CreatedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String CreatedDateOriginalDbColumnName(){
				
					return "CreatedDate";
				
				}

				
			    public Integer ModifiedBy;

				public Integer getModifiedBy () {
					return this.ModifiedBy;
				}

				public Boolean ModifiedByIsNullable(){
				    return true;
				}
				public Boolean ModifiedByIsKey(){
				    return false;
				}
				public Integer ModifiedByLength(){
				    return 10;
				}
				public Integer ModifiedByPrecision(){
				    return 0;
				}
				public String ModifiedByDefault(){
				
					return null;
				
				}
				public String ModifiedByComment(){
				
				    return "";
				
				}
				public String ModifiedByPattern(){
				
					return "";
				
				}
				public String ModifiedByOriginalDbColumnName(){
				
					return "ModifiedBy";
				
				}

				
			    public java.util.Date ModifiedDate;

				public java.util.Date getModifiedDate () {
					return this.ModifiedDate;
				}

				public Boolean ModifiedDateIsNullable(){
				    return true;
				}
				public Boolean ModifiedDateIsKey(){
				    return false;
				}
				public Integer ModifiedDateLength(){
				    return 23;
				}
				public Integer ModifiedDatePrecision(){
				    return 3;
				}
				public String ModifiedDateDefault(){
				
					return null;
				
				}
				public String ModifiedDateComment(){
				
				    return "";
				
				}
				public String ModifiedDatePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String ModifiedDateOriginalDbColumnName(){
				
					return "ModifiedDate";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.AssetDepreciationID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.AssetDepreciationID != other.AssetDepreciationID)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.AssetDepreciationID = this.AssetDepreciationID;
	            other.CompanyBookID = this.CompanyBookID;
	            other.BookAccountingYearID = this.BookAccountingYearID;
	            other.FromDate = this.FromDate;
	            other.ToDate = this.ToDate;
	            other.CreatedBy = this.CreatedBy;
	            other.CreatedDate = this.CreatedDate;
	            other.ModifiedBy = this.ModifiedBy;
	            other.ModifiedDate = this.ModifiedDate;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.AssetDepreciationID = this.AssetDepreciationID;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.AssetDepreciationID = dis.readInt();
					
			        this.CompanyBookID = dis.readInt();
					
			        this.BookAccountingYearID = dis.readInt();
					
					this.FromDate = readDate(dis);
					
					this.ToDate = readDate(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_FAMS_7_tables_5) {

        	try {

        		int length = 0;
		
			        this.AssetDepreciationID = dis.readInt();
					
			        this.CompanyBookID = dis.readInt();
					
			        this.BookAccountingYearID = dis.readInt();
					
					this.FromDate = readDate(dis);
					
					this.ToDate = readDate(dis);
					
			        this.CreatedBy = dis.readInt();
					
					this.CreatedDate = readDate(dis);
					
						this.ModifiedBy = readInteger(dis);
					
					this.ModifiedDate = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetDepreciationID);
					
					// int
				
		            	dos.writeInt(this.CompanyBookID);
					
					// int
				
		            	dos.writeInt(this.BookAccountingYearID);
					
					// java.util.Date
				
						writeDate(this.FromDate,dos);
					
					// java.util.Date
				
						writeDate(this.ToDate,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.AssetDepreciationID);
					
					// int
				
		            	dos.writeInt(this.CompanyBookID);
					
					// int
				
		            	dos.writeInt(this.BookAccountingYearID);
					
					// java.util.Date
				
						writeDate(this.FromDate,dos);
					
					// java.util.Date
				
						writeDate(this.ToDate,dos);
					
					// int
				
		            	dos.writeInt(this.CreatedBy);
					
					// java.util.Date
				
						writeDate(this.CreatedDate,dos);
					
					// Integer
				
						writeInteger(this.ModifiedBy,dos);
					
					// java.util.Date
				
						writeDate(this.ModifiedDate,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("AssetDepreciationID="+String.valueOf(AssetDepreciationID));
		sb.append(",CompanyBookID="+String.valueOf(CompanyBookID));
		sb.append(",BookAccountingYearID="+String.valueOf(BookAccountingYearID));
		sb.append(",FromDate="+String.valueOf(FromDate));
		sb.append(",ToDate="+String.valueOf(ToDate));
		sb.append(",CreatedBy="+String.valueOf(CreatedBy));
		sb.append(",CreatedDate="+String.valueOf(CreatedDate));
		sb.append(",ModifiedBy="+String.valueOf(ModifiedBy));
		sb.append(",ModifiedDate="+String.valueOf(ModifiedDate));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(AssetDepreciationID);
        			
        			sb.append("|");
        		
        				sb.append(CompanyBookID);
        			
        			sb.append("|");
        		
        				sb.append(BookAccountingYearID);
        			
        			sb.append("|");
        		
        				if(FromDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FromDate);
            			}
            		
        			sb.append("|");
        		
        				if(ToDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ToDate);
            			}
            		
        			sb.append("|");
        		
        				sb.append(CreatedBy);
        			
        			sb.append("|");
        		
        				if(CreatedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CreatedDate);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedBy == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedBy);
            			}
            		
        			sb.append("|");
        		
        				if(ModifiedDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ModifiedDate);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.AssetDepreciationID, other.AssetDepreciationID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"AssetDepreciation\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE_ACTION" + " = " + "NONE");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "FAMS_Target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("AssetDepreciation");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("AssetDepreciation");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"AssetDepreciationID\",\"CompanyBookID\",\"BookAccountingYearID\",\"FromDate\",\"ToDate\",\"CreatedBy\",\"CreatedDate\",\"ModifiedBy\",\"ModifiedDate\") VALUES (?,?,?,?,?,?,?,?,?)");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"AssetDepreciation\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT FAMS.AssetDepreciation.AssetDepreciationID, 		FAMS.AssetDepreciation.CompanyBookID, 		FAMS.AssetDepreciation.BookAccountingYearID, 		FAMS.AssetDepreciation.FromDate, 		FAMS.AssetDepreciation.ToDate, 		FAMS.AssetDepreciation.CreatedBy, 		FAMS.AssetDepreciation.CreatedDate, 		FAMS.AssetDepreciation.ModifiedBy, 		FAMS.AssetDepreciation.ModifiedDate FROM	FAMS.AssetDepreciation  \"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("AssetDepreciationID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CompanyBookID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("BookAccountingYearID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FromDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ToDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CreatedDate")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedBy")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ModifiedDate")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("SET_QUERY_TIMEOUT" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"AssetDepreciation\"", "tMSSqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_4 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tDBInput_4 = new java.util.ArrayList();
			String[] talendToDBArray_tDBInput_4  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tDBInput_4, talendToDBArray_tDBInput_4); 
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tDBInput_4 = (String)globalMap.get("dbschema_tDBConnection_1");
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();

		    String dbquery_tDBInput_4 = "SELECT FAMS.AssetDepreciation.AssetDepreciationID,\n		FAMS.AssetDepreciation.CompanyBookID,\n		FAMS.AssetDepreciation.Boo"
+"kAccountingYearID,\n		FAMS.AssetDepreciation.FromDate,\n		FAMS.AssetDepreciation.ToDate,\n		FAMS.AssetDepreciation.CreatedB"
+"y,\n		FAMS.AssetDepreciation.CreatedDate,\n		FAMS.AssetDepreciation.ModifiedBy,\n		FAMS.AssetDepreciation.ModifiedDate\nFROM"
+"	FAMS.AssetDepreciation\n";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.AssetDepreciationID = 0;
							} else {
		                          
            row4.AssetDepreciationID = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.CompanyBookID = 0;
							} else {
		                          
            row4.CompanyBookID = rs_tDBInput_4.getInt(2);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.BookAccountingYearID = 0;
							} else {
		                          
            row4.BookAccountingYearID = rs_tDBInput_4.getInt(3);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.FromDate = null;
							} else {
										
			row4.FromDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 4);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.ToDate = null;
							} else {
										
			row4.ToDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 5);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.CreatedBy = 0;
							} else {
		                          
            row4.CreatedBy = rs_tDBInput_4.getInt(6);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.CreatedDate = null;
							} else {
										
			row4.CreatedDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 7);
			
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.ModifiedBy = null;
							} else {
		                          
            row4.ModifiedBy = rs_tDBInput_4.getInt(8);
            if(rs_tDBInput_4.wasNull()){
                    row4.ModifiedBy = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.ModifiedDate = null;
							} else {
										
			row4.ModifiedDate = mssqlGTU_tDBInput_4.getDate(rsmd_tDBInput_4, rs_tDBInput_4, 9);
			
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					





 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"AssetDepreciation\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, row4.AssetDepreciationID);

                    pstmt_tDBOutput_4.setInt(2, row4.CompanyBookID);

                    pstmt_tDBOutput_4.setInt(3, row4.BookAccountingYearID);

                    if(row4.FromDate != null) {
pstmt_tDBOutput_4.setTimestamp(4, new java.sql.Timestamp(row4.FromDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(row4.ToDate != null) {
pstmt_tDBOutput_4.setTimestamp(5, new java.sql.Timestamp(row4.ToDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_4.setInt(6, row4.CreatedBy);

                    if(row4.CreatedDate != null) {
pstmt_tDBOutput_4.setTimestamp(7, new java.sql.Timestamp(row4.CreatedDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.TIMESTAMP);
}

                    if(row4.ModifiedBy == null) {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(8, row4.ModifiedBy);
}

                    if(row4.ModifiedDate != null) {
pstmt_tDBOutput_4.setTimestamp(9, new java.sql.Timestamp(row4.ModifiedDate.getTime()));
} else {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}
globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tDBOutput_4)  + (" record(s).") );


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"AssetDepreciation\"","tMSSqlInput","tDBOutput_4","FAMS_Target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"AssetDepreciation\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="FAMS_Target";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMSSqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	



	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Closing the connection ")  + ("conn_tDBConnection_1")  + (" to the database.") );
        conn_tDBClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Connection ")  + ("conn_tDBConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();

    public static void main(String[] args){
        final FAMS_7_tables_5 FAMS_7_tables_5Class = new FAMS_7_tables_5();

        int exitCode = FAMS_7_tables_5Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'FAMS_7_tables_5' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try {
            	jobInfo.load(new java.io.FileInputStream(jobInfoFile));
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230315_1127-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'FAMS_7_tables_5' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_8duqgAtIEe6iHdc52bJqvg");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-07-11T13:35:46.300791Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = FAMS_7_tables_5.class.getClassLoader().getResourceAsStream("talend_tac2_repo/fams_7_tables_5_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = FAMS_7_tables_5.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'FAMS_7_tables_5' - Started.");

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : FAMS_7_tables_5");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'FAMS_7_tables_5' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     276244 characters generated by Talend Data Integration 
 *     on the July 11, 2023 at 7:05:46 PM IST
 ************************************************************************************************/